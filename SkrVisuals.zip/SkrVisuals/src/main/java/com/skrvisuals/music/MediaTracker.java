package com.skrvisuals.music;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Отслеживает «сейчас играет» через System Media Transport Controls (SMTC) Windows.
 * Работает для любых плееров, интегрированных с системой — в первую очередь
 * Spotify и Яндекс Музыка.
 *
 * Реализация: один фоновый процесс PowerShell получает сессии SMTC через WinRT
 * (GlobalSystemMediaTransportControlsSessionManager) и печатает события в stdout:
 *   META\t<плеер>\t<название>\t<артист>  — сменился трек
 *   PING                                 — пульс, что процесс жив
 * Обложка скачивается из iTunes Search API (без авторизации), Java-поток
 * читает строки и обновляет состояние для HUD.
 */
public final class MediaTracker {
    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals/MediaTracker");

    private static final int PING_TIMEOUT_MS = 15000;

    private static volatile boolean started = false;
    private static volatile boolean available = false;

    private static volatile String app = "";
    private static volatile String title = "";
    private static volatile String artist = "";
    private static volatile String coverPath = "";
    private static volatile long coverVersion = 0L;
    private static volatile long lastLineTime = 0L;
    /** Трек, для которого обложка уже скачана / скачивается (кэш запросов). */
    private static final java.io.File COVER_DIR = new java.io.File(System.getProperty("java.io.tmpdir"), "skrvisuals/covers");
    static {
        COVER_DIR.mkdirs();
    }
    private static String coverPathForKey(String key) {
        String safe = key.replace("|", "_").replace("/", "_").replace("\\", "_").replace(":", "_").replace(" ", "_");
        return new java.io.File(COVER_DIR, safe + ".jpg").getPath();
    }
    private static boolean downloadCoverFromUrl(String url, String key) throws Exception {
        byte[] bytes = httpGetBytes(url);
        if (bytes.length > 100) {
            saveCover(bytes, key);
            return true;
        }
        return false;
    }
    private static volatile String coverKey = "";
    private static volatile String coverKeyPending = "";
    private static volatile long spawnTime = 0L;
    private static volatile boolean readyForThisProcess = false;
    private static volatile Process currentProcess = null;
    /** Прогресс трека: позиция на момент последнего TIME + флаг «играет». */
    private static volatile double posSec = 0d;
    private static volatile double durSec = 0d;
    private static volatile boolean playing = false;
    private static volatile long timeRecvMs = 0L;
    /** true — плеер сообщил о конце воспроизведения (SMTC-сессия пропала). */
    private static volatile boolean stopped = false;
    private static volatile long stoppedTimeMs = 0L;
    /** Сколько времени после остановки HUD ещё показывает последний трек. */
    private static final long KEEP_TRACK_MS = 300_000L;

    private MediaTracker() {
    }

    /** Запускает трекер (один раз). Безопасно вызывать многократно. */
    public static synchronized void start() {
        if (started) {
            return;
        }
        started = true;
        if (!System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT).contains("windows")) {
            return;
        }
        Thread reader = new Thread(MediaTracker::run, "SkrVisuals-MediaTracker");
        reader.setDaemon(true);
        reader.start();
        Thread watchdog = new Thread(MediaTracker::watchdog, "SkrVisuals-MediaWatchdog");
        watchdog.setDaemon(true);
        watchdog.start();
    }

    /** Пинок плеера медиа-клавишами (пауза+play) для реанимации SMTC. */
    private static volatile long lastNudgeMs = 0L;
    private static final long NUDGE_DELAY_MS = 6000L;
    private static final long NUDGE_INTERVAL_MS = 30_000L;
    private static final long NUDGE_WINDOW_MS = 180_000L;

    /** Убивает зависший процесс (нет READY за 15с или нет пульса) — цикл запустит новый. */
    private static void watchdog() {
        while (true) {
            Process p = currentProcess;
            if (p != null && System.currentTimeMillis() - spawnTime > 15000L) {
                if (!readyForThisProcess || System.currentTimeMillis() - lastLineTime > 15000L) {
                    LOGGER.warn("Media tracker process hung, killing it (will restart)");
                    p.destroyForcibly();
                }
            }
            // Плееры вроде Яндекс Музыки роняют SMTC-сессию между треками и
            // сами её не восстанавливают. Будим плеер парой медиа-нажатий
            // (пауза + play): фокус не крадём, звук мигает на полторы секунды.
            if (readyForThisProcess && stopped && !title.isEmpty()) {
                long now = System.currentTimeMillis();
                long sinceStop = now - stoppedTimeMs;
                if (sinceStop > NUDGE_DELAY_MS && sinceStop < NUDGE_WINDOW_MS
                        && now - lastNudgeMs > NUDGE_INTERVAL_MS) {
                    lastNudgeMs = now;
                    sendCommand("nudge");
                }
            }
            try {
                Thread.sleep(5000L);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private static void run() {
        // Бесконечный перезапуск: если процесс умер или завис — поднимаем новый.
        while (true) {
            Process process = null;
            try {
                ProcessBuilder pb = new ProcessBuilder(
                        "powershell.exe", "-NoProfile", "-NonInteractive",
                        "-ExecutionPolicy", "Bypass", "-EncodedCommand", encodedScript());
                pb.redirectErrorStream(true);
                process = pb.start();
                currentProcess = process;
                spawnTime = System.currentTimeMillis();
                readyForThisProcess = false;
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        lastLineTime = System.currentTimeMillis();
                        handleLine(line);
                    }
                }
                LOGGER.info("Media tracker process exited (code {}), restarting in 3s",
                        process.waitFor());
            } catch (Exception e) {
                LOGGER.warn("Media tracker stopped, restarting in 3s", e);
            } finally {
                available = false;
                if (process != null) {
                    process.destroyForcibly();
                }
            }
            try {
                Thread.sleep(3000L);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private static void handleLine(String line) {
        if (line == null || line.isEmpty()) {
            return;
        }
        if (line.startsWith("PING")) {
            return;
        }
        if (line.startsWith("SESS\t")) {
            LOGGER.info("Media tracker sessions: {}", line.substring(5));
            return;
        }
        if (line.startsWith("ERR\t")) {
            LOGGER.warn("Media tracker: {}", line.substring(4));
            return;
        }
        if (line.equals("READY")) {
            readyForThisProcess = true;
            available = true;
            LOGGER.info("Media tracker connected (SMTC)");
            return;
        }
        if (line.equals("FAILED")) {
            available = false;
            LOGGER.warn("Media tracker: SMTC is unavailable on this system");
            return;
        }
        if (line.equals("CLEAR")) {
            if (!title.isEmpty()) {
                LOGGER.info("Media tracker: playback stopped");
            }
            // Трек не стираем: плееры (Яндекс Музыка) роняют SMTC-сессию
            // между треками, и новая появляется через десятки секунд.
            // Просто фиксируем момент остановки — HUD ещё N минут держит
            // последний трек, а playing=false замирает прогрессбар.
            stopped = true;
            stoppedTimeMs = System.currentTimeMillis();
            playing = false;
            return;
        }
        if (line.startsWith("META\t")) {
            String[] parts = line.split("\t", 4);
            if (parts.length == 4 && !parts[2].equals(title)) {
                LOGGER.info("Media tracker: {} — {} ({})", parts[2], parts[3], parts[1]);
                app = parts[1];
                title = parts[2];
                artist = parts[3];
                posSec = 0d;
                stopped = false;
                stoppedTimeMs = 0L;
                if (!title.isEmpty()) {
                    fetchCoverAsync(title, artist);
                }
            }
            return;
        }
        if (line.startsWith("TIME\t")) {
            String[] parts = line.split("\t", 4);
            if (parts.length == 4) {
                try {
                    posSec = Double.parseDouble(parts[1]);
                    durSec = Double.parseDouble(parts[2]);
                    playing = parts[3].trim().equals("4");
                    timeRecvMs = System.currentTimeMillis();
                } catch (NumberFormatException ignored) {
                }
            }
            return;
        }
        if (line.startsWith("COVER\t")) {
            String url = line.substring("COVER\t".length()).trim();
            if (!url.isEmpty()) {
                // Ключ считаем от текущего трека: после авто-переключения
                // coverKey может ещё указывать на предыдущий трек.
                String key = artist + "|" + title;
                if (!key.equals("|") && !key.isEmpty()) {
                    try {
                        String path = coverPathForKey(key);
                        if (downloadCoverFromUrl(url, key)) {
                            LOGGER.info("Cover: from SMTC for {}", key);
                        } else {
                            LOGGER.warn("Cover: SMTC download failed for {}", key);
                        }
                    } catch (Exception e) {
                        LOGGER.warn("Cover: SMTC error for {}: {}", key, e.toString());
                    }
                }
            }
            return;
        }
    }

    /**
     * Обложку берём из iTunes Search API (без авторизации) — работает и для
     * Spotify, и для Яндекс Музыки. SMTC-миниатюра в PowerShell 5.1 нестабильна.
     */
    private static void fetchCoverAsync(String trackTitle, String trackArtist) {
        String key = trackArtist + "|" + trackTitle;
        if (key.equals(coverKey) || coverKeyPending.equals(key)) {
            return;
        }
        coverKeyPending = key;
        Thread t = new Thread(() -> {
            try {
                String path = coverPathForKey(key);
                if (java.nio.file.Files.isRegularFile(java.nio.file.Path.of(path))) {
                    coverPath = path;
                    coverKey = key;
                    coverVersion++;
                    LOGGER.info("Cover: local cache for {}", key);
                } else {
                    String query = java.net.URLEncoder.encode(
                            (trackArtist + " " + trackTitle).trim(), StandardCharsets.UTF_8);
                    boolean ok = fetchFromITunes(query, key) || fetchFromDeezer(query, key);
                    if (ok) {
                        LOGGER.info("Cover: saved for {}", key);
                    } else {
                        LOGGER.info("Cover: track not found on iTunes or Deezer ({})", key);
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("Cover: fetch failed for {}: {}", key, e.toString());
            } finally {
                coverKeyPending = "";
            }
        }, "SkrVisuals-CoverFetch");
        t.setDaemon(true);
        t.start();
    }

    private static boolean fetchFromITunes(String query, String key) throws Exception {
        String json = httpGet("https://itunes.apple.com/search?term=" + query + "&entity=song&limit=1");
        int idx = json.indexOf("\"artworkUrl100\":\"");
        if (idx < 0) {
            return false;
        }
        int start = idx + "\"artworkUrl100\":\"".length();
        int end = json.indexOf('"', start);
        String coverBig = json.substring(start, end).replace("100x100bb.jpg", "512x512bb.jpg");
        byte[] bytes = httpGetBytes(coverBig);
        saveCover(bytes, key);
        return true;
    }

    private static boolean fetchFromDeezer(String query, String key) throws Exception {
        String json = httpGet("https://api.deezer.com/search?q=" + query + "&limit=1");
        // data[0].album.cover_xl или data[0].album.cover_medium
        for (String size : new String[]{"cover_xl\"", "cover_medium\"", "cover_big\"", "cover\""}) {
            String marker = "\"" + size + ":\"";
            int idx = json.indexOf(marker);
            if (idx >= 0) {
                int start = idx + marker.length();
                int end = json.indexOf('"', start);
                if (end > start) {
                    String url = json.substring(start, end);
                    if (!url.isEmpty()) {
                        try {
                            byte[] bytes = httpGetBytes(url);
                            if (bytes.length > 100) {
                                saveCover(bytes, key);
                                return true;
                            }
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        }
        return false;
    }

    private static void saveCover(byte[] bytes, String key) throws Exception {
        java.nio.file.Path out = java.nio.file.Path.of(
                System.getProperty("java.io.tmpdir"), "skrvisuals_cover.jpg");
        // Атомарная запись: HUD-поток может читать файл в любой момент,
        // поэтому сначала пишем во временный файл, потом переименовываем.
        java.nio.file.Path tmp = java.nio.file.Path.of(
                System.getProperty("java.io.tmpdir"), "skrvisuals_cover.tmp");
        java.nio.file.Files.write(tmp, bytes);
        try {
            java.nio.file.Files.move(tmp, out,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
        } catch (java.nio.file.AtomicMoveNotSupportedException e) {
            java.nio.file.Files.move(tmp, out,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        coverPath = out.toString();
        coverKey = key;
        coverVersion++;
    }

    private static String httpGet(String url) throws Exception {
        return new String(httpGetBytes(url), StandardCharsets.UTF_8);
    }

    private static byte[] httpGetBytes(String url) throws Exception {
        java.net.HttpURLConnection conn =
                (java.net.HttpURLConnection) java.net.URI.create(url).toURL().openConnection();
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(8000);
        conn.setRequestProperty("User-Agent", "SkrVisuals");
        try (java.io.InputStream in = conn.getInputStream()) {
            return in.readAllBytes();
        } finally {
            conn.disconnect();
        }
    }

    private static String encodedScript() {
        return Base64.getEncoder().encodeToString(SCRIPT.getBytes(StandardCharsets.UTF_16LE));
    }

    // ---------------------------------------------------------------- getters

    public static boolean isAvailable() {
        if (System.currentTimeMillis() - lastLineTime > PING_TIMEOUT_MS) {
            return false;
        }
        return available;
    }

    public static String getApp() {
        return app;
    }

    public static String getTitle() {
        return title;
    }

    public static String getArtist() {
        return artist;
    }

    public static String getCoverPath() {
        return coverPath;
    }

    /** Увеличивается при каждой новой обложке (сигнал перезагрузить текстуру). */
    public static long getCoverVersion() {
        return coverVersion;
    }

    public static boolean isPlaying() {
        return playing;
    }

    /** true — воспроизведение остановлено (SMTC-сессия плеера пропала). */
    public static boolean isStopped() {
        return stopped;
    }

    /**
     * Есть ли трек для отображения. После остановки (плеер роняет SMTC-сессию
     * между треками) ещё какое-то время держим последний трек на экране.
     */
    public static boolean hasRecentTrack() {
        if (title.isEmpty()) {
            return false;
        }
        if (!stopped) {
            return true;
        }
        return System.currentTimeMillis() - stoppedTimeMs < KEEP_TRACK_MS;
    }

    public static double getDurationSeconds() {
        return durSec;
    }

    /** Позиция с до-тиканьем между опросами SMTC (плавная секунду за секундой). */
    public static double getElapsedSeconds() {
        double elapsed = posSec;
        if (playing && timeRecvMs > 0L) {
            elapsed += (System.currentTimeMillis() - timeRecvMs) / 1000.0;
        }
        if (durSec > 0d) {
            elapsed = Math.min(elapsed, durSec);
        }
        return Math.max(0d, elapsed);
    }

    /** Команда плееру: next / prev / toggle / stop (через файл, читаемый скриптом). */
    public static void sendCommand(String cmd) {
        try {
            java.nio.file.Path file = java.nio.file.Path.of(
                    System.getProperty("java.io.tmpdir"), "skrvisuals_media_cmd.txt");
            java.nio.file.Files.writeString(file, cmd);
        } catch (Exception e) {
            LOGGER.warn("Failed to send media command", e);
        }
    }

    // ---------------------------------------------------------------- script

    private static final String SCRIPT = """
            $ErrorActionPreference = 'SilentlyContinue'
            [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
            Add-Type -AssemblyName System.Runtime.WindowsRuntime
            # Глобальные медиа-клавиши (без кражи фокуса): нужны, чтобы
            # «разбудить» SMTC Яндекс Музыки, когда она роняет сессию
            # между треками при автопереключении.
            Add-Type -TypeDefinition 'using System.Runtime.InteropServices; public class MediaKey { [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, System.UIntPtr dwExtraInfo); }'
            $asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
            function Await($WinRtTask, $ResultType) {
                $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
                $netTask = $asTask.Invoke($null, @($WinRtTask))
                # Ограниченное ожидание: зависший WinRT-вызов (бывает при смене
                # трека) не должен навсегда блокировать цикл опроса.
                if (-not $netTask.Wait(3000)) {
                    throw 'WinRT call timed out'
                }
                return $netTask.Result
            }
            $null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
            $mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
            if ($null -eq $mgr) { Write-Output 'FAILED'; exit }
            Write-Output 'READY'
            $lastKey = ''
            $ticks = 0
            $lastSess = ''
            $cur = $null
            $cmdFile = Join-Path $env:TEMP 'skrvisuals_media_cmd.txt'
            $emptyTicks = 0
            $lastNudgeTick = -999
            while ($true) {
                $ticks++
                if ($ticks % 7 -eq 0) { Write-Output 'PING' }
                $sessions = @()
                try {
                    $sessions = @($mgr.GetSessions())
                } catch {
                    Write-Output ("ERR`tGetSessions: " + $_.Exception.Message)
                }
                $ids = ($sessions | ForEach-Object { $_.SourceAppUserModelId }) -join ','
                if ($ids -ne $lastSess) {
                    $lastSess = $ids
                    Write-Output ("SESS`t" + $sessions.Count + "`t" + $ids)
                }
                $shown = $false
                foreach ($s in $sessions) {
                    try {
                        $mp = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
                    } catch {
                        Write-Output ("ERR`tProps: " + $_.Exception.Message)
                        continue
                    }
                    if ($null -eq $mp -or [string]::IsNullOrEmpty($mp.Title)) { continue }
                    $cur = $s
                    $name = $s.SourceAppUserModelId
                    if ($name -like '*Spotify*') { $name = 'Spotify' }
                    elseif ($name -like '*Yandex*') { $name = 'Yandex Music' }
                    $key = $name + '|' + $mp.Title + '|' + $mp.Artist
                    if ($key -ne $lastKey) {
                        $lastKey = $key
                        Write-Output ("META`t" + $name + "`t" + ($mp.Title -replace "`t", ' ') + "`t" + ($mp.Artist -replace "`t", ' '))
                    }
                    try {
                        $artUri = $null
                        try {
                            $artUri = $mp.Art
                        } catch {}
                        if ($artUri -and $artUri -is [Uri]) {
                            $abs = $artUri.AbsoluteUri
                            if ($abs -match '^https?://') {
                                Write-Output ("COVER`t" + $abs)
                            }
                        }
                    $tl = $s.GetTimelineProperties()
                        $pi = $s.GetPlaybackInfo()
                        $st = $pi.PlaybackStatus
                        $pos = $tl.Position.TotalSeconds
                        $dur = $tl.EndTime.TotalSeconds
                        if ($st.value__ -eq 4) {
                            $rate = 1.0
                            try {
                                $r = $tl.PlaybackRate
                                if ($null -ne $r) { $rate = $r }
                            } catch {}
                            $elapsed = ((Get-Date) - $tl.LastUpdatedTime.DateTime).TotalSeconds
                            if ($elapsed -lt 0) { $elapsed = 0 }
                            $pos = $pos + $elapsed * $rate
                            if ($dur -gt 0 -and $pos -gt $dur) { $pos = $dur }
                        }
                        Write-Output ("TIME`t" + [int]$pos + "`t" + [int]$dur + "`t" + $st.value__)
                    } catch {
                        Write-Output ("ERR`tTimeline: " + $_.Exception.Message)
                    }
                    $shown = $true
                    break
                }
                if (-not $shown) {
                    $emptyTicks++
                    # Смена трека может давать пустой Title на пару тиков —
                    # стираем трек только если он реально пропал надолго.
                    if ($emptyTicks -ge 15 -and $lastKey -ne '') {
                        $lastKey = ''
                        $cur = $null
                        Write-Output 'CLEAR'
                    }
                    # Яндекс Музыка при автопереключении трека роняет SMTC-сессию
                    # и не регистрирует новую сама. Через ~3.5 секунды «будим»
                    # плеер: пауза + play глобальными медиа-клавишами (фокус
                    # не крадём, звук прерывается на долю секунды). Не чаще
                    # раза в ~30 секунд.
                    if ($emptyTicks -eq 5 -and $lastKey -ne '' -and ($ticks - $lastNudgeTick) -gt 45) {
                        $lastNudgeTick = $ticks
                        [MediaKey]::keybd_event(0xB3, 0, 0, [System.UIntPtr]::Zero)
                        [MediaKey]::keybd_event(0xB3, 0, 2, [System.UIntPtr]::Zero)
                        Start-Sleep -Milliseconds 1500
                        [MediaKey]::keybd_event(0xB3, 0, 0, [System.UIntPtr]::Zero)
                        [MediaKey]::keybd_event(0xB3, 0, 2, [System.UIntPtr]::Zero)
                    }
                } else {
                    $emptyTicks = 0
                }
                if (Test-Path $cmdFile) {
                    $cmd = ''
                    try { $cmd = (Get-Content $cmdFile -Raw).Trim() } catch {}
                    Remove-Item $cmdFile -Force -ErrorAction SilentlyContinue
                    # nudge будит SMTC Яндекс Музыки медиа-клавишами — работает
                    # даже когда сессия уже пропала, поэтому вне проверки $cur.
                    if ($cmd -eq 'nudge') {
                        [MediaKey]::keybd_event(0xB3, 0, 0, [System.UIntPtr]::Zero)
                        [MediaKey]::keybd_event(0xB3, 0, 2, [System.UIntPtr]::Zero)
                        Start-Sleep -Milliseconds 1500
                        [MediaKey]::keybd_event(0xB3, 0, 0, [System.UIntPtr]::Zero)
                        [MediaKey]::keybd_event(0xB3, 0, 2, [System.UIntPtr]::Zero)
                    } elseif ($cur -ne $null -and $cmd -ne '') {
                        switch ($cmd) {
                            'next'   { $null = $cur.TrySkipNextAsync() }
                            'prev'   { $null = $cur.TrySkipPreviousAsync() }
                            'stop'   { $null = $cur.TryStopAsync() }
                            'toggle' {
                                $st = $cur.GetPlaybackInfo().PlaybackStatus
                                if ($st -eq 4) { $null = $cur.TryPauseAsync() } else { $null = $cur.TryPlayAsync() }
                            }
                        }
                    }
                }
                Start-Sleep -Milliseconds 700
            }
            """;
}