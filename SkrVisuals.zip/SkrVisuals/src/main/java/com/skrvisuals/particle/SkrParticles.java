package com.skrvisuals.particle;

import com.skrvisuals.modules.impl.Particles;
import com.skrvisuals.ui.theme.Colors;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.SimpleParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Registers the custom textured particle {@code skrvisuals:glow}
 * (texture: textures/particle/glow.png) and its client factory.
 */
public final class SkrParticles {
    public static final SimpleParticleType GLOW = Registry.register(
            Registries.PARTICLE_TYPE,
            Identifier.of("skrvisuals", "glow"),
            new GlowType());

    /** Public subclass so we can reach the protected SimpleParticleType ctor. */
    public static class GlowType extends SimpleParticleType {
        public GlowType() {
            super(false);
        }
    }

    private SkrParticles() {
    }

    /** Call once from the client entrypoint (before registries freeze). */
    public static void registerClient() {
        ParticleFactoryRegistry.getInstance().register(GLOW, Factory::new);
    }

    public static class Factory implements ParticleFactory<SimpleParticleType> {
        private final SpriteProvider spriteProvider;

        public Factory(SpriteProvider spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Override
        public Particle createParticle(SimpleParticleType parameters, ClientWorld world,
                                       double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ) {
            return new GlowParticle(world, x, y, z,
                    velocityX, velocityY, velocityZ, this.spriteProvider);
        }
    }

    public static class GlowParticle extends SpriteBillboardParticle {
        private final float size;

        protected GlowParticle(ClientWorld world, double x, double y, double z,
                               double velocityX, double velocityY, double velocityZ,
                               SpriteProvider sprites) {
            super(world, x, y, z, velocityX, velocityY, velocityZ);
            this.setSprite(sprites);

            Particles module = Particles.getActive();
            float sizeSetting = module != null ? module.getSizeValue() : 0.6F;
            this.size = MathHelper.clamp(sizeSetting * 0.45F, 0.05F, 1.2F);

            // Tint follows the theme accent color.
            int argb = Colors.clientColor();
            this.setColor(
                    ((argb >> 16) & 0xFF) / 255.0F,
                    ((argb >> 8) & 0xFF) / 255.0F,
                    (argb & 0xFF) / 255.0F);
            this.setAlpha(1.0F);
            this.maxAge = 24 + this.random.nextInt(12);
        }

        @Override
        public float getSize(float tickDelta) {
            float fade = 1.0F - (this.age / (float) this.maxAge) * 0.4F;
            return this.size * fade;
        }

        @Override
        public ParticleTextureSheet getType() {
            return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
        }
    }
}