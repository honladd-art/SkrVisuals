package com.skrvisuals;

import com.skrvisuals.modules.ModuleManager;

/**
 * Singleton client root. Kept minimal on purpose — most functionality is a stub
 * and will be added later (config, events, renderers).
 */
public final class Skr {
    public static final Skr INSTANCE = new Skr();

    private final ModuleManager moduleManager = new ModuleManager();

    private Skr() {
    }

    public ModuleManager getModuleManager() {
        return this.moduleManager;
    }

    /** Stub: persist settings. */
    public void saveConfig() {
    }

    /** Stub: hand back to the login surface. */
    public boolean isInGame() {
        return true;
    }
}