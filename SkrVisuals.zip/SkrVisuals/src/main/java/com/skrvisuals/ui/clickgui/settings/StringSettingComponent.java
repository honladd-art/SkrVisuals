package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.modules.settings.StringSetting;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

/**
 * Точь-в-точь порт референсного StringSettingComponent: имя над полем ввода,
 * поле 16px высотой с мигающим курсором, высота строки 20.
 */
public class StringSettingComponent extends SettingComponent {
    private StringSetting stringSetting;

    private boolean focused;

    private String currentText;

    private int cursorPosition;

    private long lastCursorBlink;

    private boolean cursorVisible;

    public StringSettingComponent(Setting setting, ModuleComponent moduleComponent) {
        super(setting, moduleComponent);
    }

    @Override
    public void init() {
        this.stringSetting = (StringSetting) getSetting();
        this.width = 119.5F;
        this.height = 30.0F;
        this.currentText = stringSetting.getValue();
        this.cursorPosition = this.currentText.length();
        super.init();
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        super.render(context, x, y, mouseX, mouseY, delta);
        float alpha = alpha();
        float textFieldX = x + 5.0F;
        float textFieldY = y + 11.0F;
        float textFieldWidth = this.width - 10.0F;
        float textFieldHeight = 16.0F;
        int fill = focused ? Colors.moduleBackground() : Colors.guiBackground();
        int border = focused ? Colors.clientColor() : Colors.keyBorder();
        RenderUtil.roundedRect(context, textFieldX, textFieldY, textFieldWidth, textFieldHeight, 2.0F,
                RenderUtil.withAlpha(fill, alpha * 0.8F));
        RenderUtil.roundedOutline(context, textFieldX, textFieldY, textFieldWidth, textFieldHeight, 2.0F, 1.0F,
                RenderUtil.withAlpha(border, alpha));
        var font = Fonts.get();
        RenderUtil.drawString(context, font, setting.getName(), x + 5.0F, y,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
        if (!currentText.isEmpty())
            RenderUtil.drawString(context, font, currentText, textFieldX + 3.0F, textFieldY + 3.0F,
                    RenderUtil.withAlpha(Colors.textPrimary(), alpha));
        updateCursorBlink();
        if (focused && cursorVisible) {
            float cursorX = textFieldX + 3.0F + font.getWidth(currentText.substring(0, cursorPosition));
            if (cursorX < textFieldX + textFieldWidth) {
                RenderUtil.fill(context, cursorX, textFieldY + 3.0F, 1.0F, textFieldHeight - 6.0F,
                        RenderUtil.withAlpha(Colors.cursorColor(), alpha));
            }
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        float textFieldX = this.x + 5.0F;
        float textFieldY = this.y + 11.0F;
        float textFieldWidth = this.width - 10.0F;
        float textFieldHeight = 16.0F;
        boolean clickedOnField = mouseX >= textFieldX && mouseX <= textFieldX + textFieldWidth
                && mouseY >= textFieldY && mouseY <= textFieldY + textFieldHeight;
        if (clickedOnField && button == 0) {
            this.focused = true;
            float relativeX = (float) mouseX - textFieldX - 3.0F;
            this.cursorPosition = getCursorPositionFromX(relativeX);
        } else if (button == 0) {
            this.focused = false;
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.focused)
            return;
        switch (keyCode) {
            case 256 -> this.focused = false;
            case 257 -> {
                this.focused = false;
                stringSetting.setValue(currentText);
            }
            case 259 -> {
                if (cursorPosition > 0) {
                    currentText = currentText.substring(0, cursorPosition - 1)
                            + currentText.substring(cursorPosition);
                    cursorPosition--;
                    stringSetting.setValue(currentText);
                }
            }
            case 261 -> {
                if (cursorPosition < currentText.length()) {
                    currentText = currentText.substring(0, cursorPosition)
                            + currentText.substring(cursorPosition + 1);
                    stringSetting.setValue(currentText);
                }
            }
            case 262 -> {
                if (cursorPosition < currentText.length())
                    cursorPosition++;
            }
            case 263 -> {
                if (cursorPosition > 0)
                    cursorPosition--;
            }
            case 265 -> cursorPosition = 0;
            case 264 -> cursorPosition = currentText.length();
            default -> {
            }
        }
    }

    @Override
    public void charTyped(char codePoint, int modifiers) {
        if (!this.focused)
            return;
        if (codePoint >= ' ' && codePoint <= '~' && currentText.length() < 32) {
            currentText = currentText.substring(0, cursorPosition) + codePoint
                    + currentText.substring(cursorPosition);
            cursorPosition++;
            stringSetting.setValue(currentText);
        }
    }

    private void updateCursorBlink() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastCursorBlink > 500L) {
            this.cursorVisible = !this.cursorVisible;
            this.lastCursorBlink = currentTime;
        }
    }

    private int getCursorPositionFromX(float x) {
        if (x <= 0.0F)
            return 0;
        var font = Fonts.get();
        for (int i = 0; i <= this.currentText.length(); i++) {
            float textWidth = font.getWidth(this.currentText.substring(0, i));
            if (x < textWidth)
                return i;
        }
        return this.currentText.length();
    }

    public boolean isFocused() {
        return this.focused;
    }
}
