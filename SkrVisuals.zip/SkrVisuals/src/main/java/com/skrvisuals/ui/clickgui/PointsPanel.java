package com.skrvisuals.ui.clickgui;

import java.util.ArrayList;
import java.util.List;

import com.skrvisuals.config.ConfigManager;
import com.skrvisuals.modules.impl.Points;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Content of the "Points" tab (как Friends): управление метками напрямую —
 * поля "Название" + "X/Y/Z", кнопка добавления (без координат — метка
 * ставится на текущей позиции игрока), удаление крестиком, кнопка "Очистить"
 * и переключатели "Показывать" / "Луч" / "Дистанция" / "Координаты".
 */
public class PointsPanel {
    private static final float ROW_HEIGHT = 12.0F;
    private static final float FIELD_HEIGHT = 16.0F;
    private static final float TOGGLE_HEIGHT = 16.0F;
    private static final float GAP = 6.0F;
    private static final float FIELD_GAP = 4.0F;
    private static final float COORD_W = 30.0F;

    private static final int NAME_MAX = 24;
    private static final int COORD_MAX = 7;

    private final ClickScreen gui;

    /** 0 = имя, 1..3 = X/Y/Z. */
    private final String[] inputs = {"", "", "", ""};
    private int focused = -1;
    private long errorUntil = 0L;
    private long lastCursorBlink = 0L;
    private boolean cursorVisible = false;

    private float scroll = 0.0F;
    private float scrollTarget = 0.0F;
    private float contentHeight = 0.0F;
    private final java.util.Map<Integer, com.skrvisuals.ui.anim.Animation> knobAnims = new java.util.HashMap<>();
    private int toggleCounter = 0;

    private float contentX;
    private float contentW;

    private final List<float[]> toggleBoxes = new ArrayList<>();
    private final List<float[]> removeBoxes = new ArrayList<>();
    private final List<float[]> fieldBoxes = new ArrayList<>();
    private float[] addBox = null;
    private float[] clearBox = null;

    public PointsPanel(ClickScreen gui) {
        this.gui = gui;
    }



    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float alpha = gui.getAlpha();
        TextRenderer font = Fonts.get();

        float x = gui.getX() + gui.getSidebarWidth();
        float panelW = gui.getWidth() - gui.getSidebarWidth();
        this.contentW = Math.min(262.0F, panelW - 40.0F);
        this.contentX = x + (panelW - this.contentW) / 2.0F;

        float y = gui.getContentTop() + 6.0F + this.scroll;

        // Переключатели эффектов.
        this.toggleBoxes.clear();
        this.toggleCounter = 0;
        Points points = Points.getActive();
        y = drawToggle(ctx, font, "Показывать", points != null && points.isEnabled(), y, mouseX, mouseY, alpha);
        y = drawToggle(ctx, font, "Луч", settingValue(0), y, mouseX, mouseY, alpha);
        y = drawToggle(ctx, font, "Дистанция", settingValue(1), y, mouseX, mouseY, alpha);
        y = drawToggle(ctx, font, "Координаты", settingValue(2), y, mouseX, mouseY, alpha);
        y += GAP;

        // Поля ввода: имя + X/Y/Z.
        this.fieldBoxes.clear();
        float nameW = this.contentW - 3.0F * COORD_W - 3.0F * FIELD_GAP;
        drawField(ctx, font, 0, this.contentX, y, nameW, mouseX, mouseY, alpha);
        float fx = this.contentX + nameW + FIELD_GAP;
        for (int i = 1; i <= 3; i++) {
            drawField(ctx, font, i, fx, y, COORD_W, mouseX, mouseY, alpha);
            fx += COORD_W + FIELD_GAP;
        }
        y += FIELD_HEIGHT + GAP;

        // Кнопка добавления.
        this.addBox = new float[]{this.contentX, y, this.contentW, ROW_HEIGHT};
        drawButton(ctx, font, "Добавить метку", this.addBox, mouseX, mouseY, alpha, Colors.clientColor());
        y += ROW_HEIGHT + GAP;

        // Строки меток.
        this.removeBoxes.clear();
        for (Points.Waypoint wp : Points.getWaypoints()) {
            y = drawWaypointRow(ctx, font, wp, y, mouseX, mouseY, alpha);
        }

        // Кнопка "Очистить".
        this.clearBox = null;
        if (!Points.getWaypoints().isEmpty()) {
            this.clearBox = new float[]{this.contentX, y, this.contentW, ROW_HEIGHT};
            drawButton(ctx, font, "Очистить", this.clearBox, mouseX, mouseY, alpha, 0xFFFF6B6B);
            y += ROW_HEIGHT + GAP;
        }

        // Скролл-клампинг.
        this.contentHeight = y - (gui.getContentTop() + 6.0F) - this.scroll;
        float availH = gui.getContentHeight() - 6.0F;
        float minScroll = this.contentHeight > availH ? (availH - this.contentHeight) : 0.0F;
        this.scrollTarget = Math.max(minScroll, Math.min(0.0F, this.scrollTarget));
        this.scroll += (this.scrollTarget - this.scroll) * 0.35F;
        if (Math.abs(this.scrollTarget - this.scroll) < 0.05F) {
            this.scroll = this.scrollTarget;
        }
    }

    // ---------------------------------------------------------------- input
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return;
        }
        Points points = Points.getActive();
        for (int i = 0; i < this.toggleBoxes.size(); i++) {
            float[] box = this.toggleBoxes.get(i);
            if (RenderUtil.hovered((float) mouseX, (float) mouseY, box[0], box[1], box[2], box[3])) {
                boolean value = box[4] > 0.5F;
                if (i == 0) {
                    if (points != null) {
                        points.toggle();
                    }
                } else {
                    BooleanSetting setting = settingAt(i - 1);
                    if (setting != null) {
                        setting.setValue(!value);
                        ConfigManager.save();
                    }
                }
                return;
            }
        }

        for (int i = 0; i < this.fieldBoxes.size(); i++) {
            float[] box = this.fieldBoxes.get(i);
            if (RenderUtil.hovered((float) mouseX, (float) mouseY, box[0], box[1], box[2], box[3])) {
                this.focused = i;
                return;
            }
        }

        if (this.addBox != null && RenderUtil.hovered((float) mouseX, (float) mouseY,
                this.addBox[0], this.addBox[1], this.addBox[2], this.addBox[3])) {
            addWaypoint();
            return;
        }

        List<Points.Waypoint> waypoints = Points.getWaypoints();
        for (int i = 0; i < this.removeBoxes.size(); i++) {
            float[] box = this.removeBoxes.get(i);
            if (mouseX >= box[0] && mouseX <= box[0] + box[2]
                    && mouseY >= box[1] && mouseY <= box[1] + box[3]) {
                if (i < waypoints.size()) {
                    Points.remove(waypoints.get(i).name);
                }
                return;
            }
        }

        if (this.clearBox != null && RenderUtil.hovered((float) mouseX, (float) mouseY,
                this.clearBox[0], this.clearBox[1], this.clearBox[2], this.clearBox[3])) {
            Points.clear();
            return;
        }

        this.focused = -1;
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.focused < 0) {
            return;
        }
        switch (keyCode) {
            case 256 -> this.focused = -1;
            case 257 -> { // Enter — добавить метку
                addWaypoint();
                this.focused = -1;
            }
            case 259 -> { // Backspace
                if (this.focused >= 0 && !this.inputs[this.focused].isEmpty()) {
                    this.inputs[this.focused] =
                            this.inputs[this.focused].substring(0, this.inputs[this.focused].length() - 1);
                }
            }
            default -> {
            }
        }
    }

    public void charTyped(char codePoint, int modifiers) {
        if (this.focused < 0) {
            return;
        }
        // Все печатные символы, включая "_" и заглавные буквы.
        if (codePoint >= ' ' && codePoint != 127) {
            int max = this.focused == 0 ? NAME_MAX : COORD_MAX;
            if (this.inputs[this.focused].length() < max) {
                this.inputs[this.focused] += codePoint;
            }
        }
    }

    public void mouseScrolled(double delta) {
        this.scrollTarget += (float) delta * 10.0F;
    }

    public boolean isInputFocused() {
        return this.focused >= 0;
    }

    public boolean isHovered(int mouseX, int mouseY) {
        float x = gui.getX() + gui.getSidebarWidth();
        return mouseX >= x && mouseX <= gui.getX() + gui.getWidth()
                && mouseY >= gui.getContentTop() && mouseY <= gui.getY() + gui.getHeight();
    }

    // --------------------------------------------------------------- actions
    /** Добавляет метку: если координаты пустые — на позиции игрока. */
    private void addWaypoint() {
        String name = this.inputs[0].trim();
        if (name.isEmpty()) {
            return;
        }
        int x, y, z;
        if (this.inputs[1].isBlank() && this.inputs[2].isBlank() && this.inputs[3].isBlank()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) {
                return;
            }
            x = mc.player.getBlockX();
            y = mc.player.getBlockY();
            z = mc.player.getBlockZ();
        } else {
            try {
                x = Integer.parseInt(this.inputs[1].trim());
                y = Integer.parseInt(this.inputs[2].trim());
                z = Integer.parseInt(this.inputs[3].trim());
            } catch (NumberFormatException e) {
                this.errorUntil = System.currentTimeMillis() + 900L;
                return;
            }
        }
        Points.add(name, x, y, z);
        for (int i = 0; i < this.inputs.length; i++) {
            this.inputs[i] = "";
        }
        this.focused = -1;
    }

    // --------------------------------------------------------------- helpers
    private BooleanSetting settingAt(int index) {
        Points points = Points.getActive();
        if (points == null) {
            return null;
        }
        return switch (index) {
            case 0 -> points.getShowLine();
            case 1 -> points.getShowDistance();
            case 2 -> points.getShowCoords();
            default -> null;
        };
    }

    private boolean settingValue(int index) {
        BooleanSetting setting = settingAt(index);
        return setting != null && setting.getValue();
    }


    /** @return новая нижняя координата. */
    private float drawToggle(DrawContext ctx, TextRenderer font, String label, boolean value,
                             float y, int mouseX, int mouseY, float alpha) {
        boolean hovered = RenderUtil.hovered(mouseX, mouseY, this.contentX, y, this.contentW, TOGGLE_HEIGHT);
        RenderUtil.roundedRect(ctx, this.contentX, y, this.contentW, TOGGLE_HEIGHT, 3.0F,
                RenderUtil.withAlpha(hovered ? Colors.settingHover() : Colors.moduleBackground(), alpha));
        if (hovered) {
            RenderUtil.roundedRect(ctx, this.contentX + 1.5F, y + 3.0F, 1.5F, TOGGLE_HEIGHT - 6.0F, 0.75F,
                    RenderUtil.withAlpha(Colors.clientColor(), alpha * 0.9F));
        }
        RenderUtil.drawString(ctx, font, label, this.contentX + 6.0F, y + (TOGGLE_HEIGHT - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(value ? Colors.textPrimary() : Colors.textDescription(), alpha));

        // Свитч.
        com.skrvisuals.ui.anim.Animation knobAnim = this.knobAnims.computeIfAbsent(this.toggleCounter,
                k -> new com.skrvisuals.ui.anim.Animation(com.skrvisuals.ui.anim.Easing.EASE_OUT_CUBIC, 220L));
        knobAnim.run(value ? 1.0F : 0.0F);
        float kv = knobAnim.getValue();
        this.toggleCounter++;
        float trackW = 18.0F, trackH = 8.0F;
        float trackX = this.contentX + this.contentW - trackW - 6.0F;
        float trackY = y + (TOGGLE_HEIGHT - trackH) / 2.0F;
        int trackColor = RenderUtil.lerpColor(Colors.toggleOff(), Colors.clientColor(), kv);
        RenderUtil.roundedRect(ctx, trackX, trackY, trackW, trackH, trackH / 2.0F,
                RenderUtil.withAlpha(trackColor, alpha));
        float knobX = trackX + 0.5F + kv * (trackW - 8.0F);
        RenderUtil.circle(ctx, knobX + 3.5F, trackY + trackH / 2.0F, 3.5F,
                RenderUtil.withAlpha(Colors.toggleKnob(), alpha));

        this.toggleBoxes.add(new float[]{this.contentX, y, this.contentW, TOGGLE_HEIGHT, value ? 1.0F : 0.0F});
        return y + TOGGLE_HEIGHT;
    }

    private void drawField(DrawContext ctx, TextRenderer font, int index,
                           float x, float y, float w, int mouseX, int mouseY, float alpha) {
        boolean focusedField = this.focused == index;
        boolean error = System.currentTimeMillis() < this.errorUntil && index >= 1;
        int fill = focusedField ? Colors.moduleBackground() : Colors.guiBackground();
        int border = error ? 0xFFFF6B6B : focusedField ? Colors.clientColor() : Colors.keyBorder();
        RenderUtil.roundedRect(ctx, x, y, w, FIELD_HEIGHT, 3.0F, RenderUtil.withAlpha(fill, alpha * 0.8F));
        RenderUtil.roundedOutline(ctx, x, y, w, FIELD_HEIGHT, 3.0F, 1.0F, RenderUtil.withAlpha(border, alpha));

        String placeholder = switch (index) {
            case 0 -> "Название";
            case 1 -> "X";
            case 2 -> "Y";
            default -> "Z";
        };
        String value = this.inputs[index];
        String shown = value.isEmpty() ? placeholder : value;
        if (font.getWidth(shown) > w - 6.0F) {
            shown = truncate(font, shown, w - 6.0F);
        }
        RenderUtil.drawString(ctx, font, shown, x + 6.0F, y + (FIELD_HEIGHT - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(value.isEmpty() ? Colors.textPlaceholder() : Colors.textPrimary(), alpha));

        updateCursorBlink();
        if (focusedField && this.cursorVisible) {
            float cursorX = x + 6.0F + font.getWidth(value);
            if (cursorX < x + w - 4.0F) {
                RenderUtil.fill(ctx, cursorX, y + 3.0F, 1.0F, FIELD_HEIGHT - 6.0F,
                        RenderUtil.withAlpha(Colors.cursorColor(), alpha));
            }
        }
        this.fieldBoxes.add(new float[]{x, y, w, FIELD_HEIGHT});
    }

    private void drawButton(DrawContext ctx, TextRenderer font, String label, float[] box,
                            int mouseX, int mouseY, float alpha, int hoverColor) {
        float x = box[0], y = box[1], w = box[2], h = box[3];
        boolean hovered = RenderUtil.hovered(mouseX, mouseY, x, y, w, h);
        RenderUtil.roundedRect(ctx, x, y, w, h, 3.0F,
                RenderUtil.withAlpha(Colors.keyBackground(), alpha));
        RenderUtil.drawString(ctx, font, label, x + 6.0F, y + (h - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(hovered ? hoverColor : Colors.textMuted(), alpha));
    }

    private float drawWaypointRow(DrawContext ctx, TextRenderer font, Points.Waypoint wp,
                                  float y, int mouseX, int mouseY, float alpha) {
        String coords = wp.x + " " + wp.y + " " + wp.z;
        float coordsX = this.contentX + this.contentW - 14.0F - font.getWidth(coords);
        boolean rowHovered = RenderUtil.hovered(mouseX, mouseY, this.contentX, y, this.contentW, ROW_HEIGHT);
        if (rowHovered) {
            RenderUtil.roundedRect(ctx, this.contentX, y, this.contentW, ROW_HEIGHT, 2.0F,
                    RenderUtil.withAlpha(Colors.hoverOverlay(), alpha));
        }
        RenderUtil.drawString(ctx, font, truncate(font, wp.name, coordsX - (this.contentX + 6.0F)),
                this.contentX + 6.0F, y + 2.0F,
                RenderUtil.withAlpha(Colors.textDescription(), alpha));
        RenderUtil.drawString(ctx, font, coords, coordsX, y + 2.0F,
                RenderUtil.withAlpha(Colors.textMuted(), alpha));

        float[] box = new float[]{this.contentX + this.contentW - 12.0F, y + 2.0F, 8.0F, 8.0F};
        this.removeBoxes.add(box);
        boolean xHovered = mouseX >= box[0] && mouseX <= box[0] + box[2]
                && mouseY >= box[1] && mouseY <= box[1] + box[3];
        RenderUtil.drawString(ctx, font, "x", box[0] + 1.0F, box[1] + 1.0F,
                RenderUtil.withAlpha(xHovered ? 0xFFFF6B6B : Colors.textMuted(), alpha));
        return y + ROW_HEIGHT;
    }

    private String truncate(TextRenderer font, String text, float maxW) {
        if (font.getWidth(text) <= maxW) {
            return text;
        }
        while (text.length() > 1 && font.getWidth(text + "…") > maxW) {
            text = text.substring(0, text.length() - 1);
        }
        return text + "…";
    }

    private void updateCursorBlink() {
        long now = System.currentTimeMillis();
        if (now - this.lastCursorBlink > 500L) {
            this.cursorVisible = !this.cursorVisible;
            this.lastCursorBlink = now;
        }
    }
}

