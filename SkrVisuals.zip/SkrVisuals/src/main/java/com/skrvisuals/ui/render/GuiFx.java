package com.skrvisuals.ui.render;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Дешёвые «шейдерные» эффекты GUI: рябь клика, радиальное свечение,
 * бегущий блик (shimmer sweep), каскадное появление элементов.
 * Всё построено на примитивах из {@link RenderUtil} — эффекты намеренно сдержанные.
 */
public final class GuiFx {

    private GuiFx() {
    }

    // ------------------------------------------------------------------ рябь
    private static final class Ripple {
        final float x, y, maxRadius;
        final int color;
        final long start;

        Ripple(float x, float y, int color, float maxRadius) {
            this.x = x;
            this.y = y;
            this.color = color;
            this.maxRadius = maxRadius;
            this.start = System.currentTimeMillis();
        }
    }

    private static final List<Ripple> RIPPLES = new ArrayList<>();
    private static final long RIPPLE_MS = 420L;
    private static final int RIPPLE_MAX = 24;

    /** Создаёт рябь (волну) в точке клика. Цвет — RGB акцента, alpha вычисляется сам. */
    public static void ripple(float x, float y, int color) {
        ripple(x, y, color, 34.0F);
    }

    public static void ripple(float x, float y, int color, float maxRadius) {
        pruneRipples();
        if (RIPPLES.size() >= RIPPLE_MAX) {
            RIPPLES.remove(0);
        }
        RIPPLES.add(new Ripple(x, y, color, maxRadius));
    }

    public static void clearRipples() {
        RIPPLES.clear();
    }

    private static void pruneRipples() {
        long now = System.currentTimeMillis();
        Iterator<Ripple> it = RIPPLES.iterator();
        while (it.hasNext()) {
            if (now - it.next().start > RIPPLE_MS) {
                it.remove();
            }
        }
    }

    /**
     * Рисует активные ряби. Вызывать внутри уже установленного клипа,
     * чтобы волна не выходила за границы панели.
     */
    public static void renderRipples(DrawContext ctx, float alpha) {
        if (RIPPLES.isEmpty() || alpha <= 0.01F) {
            return;
        }
        long now = System.currentTimeMillis();
        Iterator<Ripple> it = RIPPLES.iterator();
        while (it.hasNext()) {
            Ripple r = it.next();
            float p = (now - r.start) / (float) RIPPLE_MS;
            if (p >= 1.0F) {
                it.remove();
                continue;
            }
            float e = 1.0F - (1.0F - p) * (1.0F - p) * (1.0F - p); // ease-out cubic
            float radius = 4.0F + (r.maxRadius - 4.0F) * e;
            float fade = (1.0F - p) * (1.0F - p);
            RenderUtil.circleOutline(ctx, r.x, r.y, radius, 1.4F,
                    RenderUtil.withAlpha(r.color, fade * 0.30F * alpha));
            RenderUtil.circle(ctx, r.x, r.y, radius * 0.55F,
                    RenderUtil.withAlpha(r.color, fade * 0.07F * alpha));
        }
    }

    // ------------------------------------------------------- ease / stagger
    /** Мягкий ease-out cubic (0..1 -> 0..1). */
    public static float easeOut(float p) {
        float t = clamp01(p);
        float inv = 1.0F - t;
        return 1.0F - inv * inv * inv;
    }

    public static float clamp01(float v) {
        return Math.max(0.0F, Math.min(1.0F, v));
    }

    /**
     * Каскадное появление элемента: индекс {@code index} стартует с задержкой
     * {@code delayMs * index} от момента {@code baseTime}. Возвращает прогресс 0..1
     * с ease-out, чтобы элементы «выезжали» по очереди.
     */
    public static float stagger(long baseTime, int index, long delayMs, long durationMs) {
        long elapsed = System.currentTimeMillis() - baseTime - delayMs * Math.max(0, index);
        if (durationMs <= 0L) {
            return 1.0F;
        }
        return easeOut(elapsed / (float) durationMs);
    }

    // ------------------------------------------------------------- shimmer
    /** Периодическая фаза 0..1 для бегущего блика (полный цикл за {@code periodMs}). */
    public static float shimmerPhase(long periodMs) {
        if (periodMs <= 0L) {
            return 0.0F;
        }
        return (System.currentTimeMillis() % periodMs) / (float) periodMs;
    }

    /**
     * Бегущий вертикальный блик (shimmer sweep) по прямоугольнику — мягкая
     * световая полоса, «пробегающая» слева направо. Вызывать внутри scissor.
     * {@code color} — RGB (alpha вычисляется), {@code strength} — 0..1.
     */
    public static void shimmer(DrawContext ctx, float x, float y, float w, float h,
                               float phase, int color, float strength) {
        if (strength <= 0.005F || w <= 0.0F || h <= 0.0F) {
            return;
        }
        // Ширина полосы ~35% прямоугольника, центр едет от -0.2 до 1.2.
        float bandW = w * 0.35F;
        float center = x + (-0.2F + 1.4F * clamp01(phase)) * w;
        int steps = 7;
        for (int i = 0; i < steps; i++) {
            float t = i / (float) (steps - 1);          // 0 — края, 1 — середина полосы
            float half = bandW * (0.5F - 0.5F * t);
            float sx = center - half;
            float sw = half * 2.0F;
            if (sx + sw <= x || sx >= x + w) {
                continue;
            }
            // Обрезаем по границам прямоугольника.
            float cx = Math.max(sx, x);
            float cw = Math.min(sx + sw, x + w) - cx;
            if (cw <= 0.0F) {
                continue;
            }
            float a = strength * (1.0F - t) * (1.0F - t) * 0.5F;
            RenderUtil.fill(ctx, cx, y, cw, h, RenderUtil.withAlpha(color, a));
        }
    }

    // ------------------------------------------------------------ radialGlow
    /**
     * Дешёвое радиальное свечение из концентрических кругов (имитация light-spill).
     * {@code strength} — пиковая alpha (0..1), цвет — RGB.
     */
    public static void radialGlow(DrawContext ctx, float cx, float cy, float radius,
                                  int color, float strength, float alpha) {
        if (strength <= 0.003F || radius <= 0.0F || alpha <= 0.01F) {
            return;
        }
        int steps = 10;
        for (int i = steps; i >= 1; i--) {
            float t = i / (float) steps;                // 1 — внешний край
            float r = radius * t;
            float a = strength * alpha * (1.0F - t) * (1.0F - t);
            if (a <= 0.002F) {
                continue;
            }
            RenderUtil.circle(ctx, cx, cy, r, RenderUtil.withAlpha(color, a));
        }
    }
}
