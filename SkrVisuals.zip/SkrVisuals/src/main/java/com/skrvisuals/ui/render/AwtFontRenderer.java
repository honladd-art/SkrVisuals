package com.skrvisuals.ui.render;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

/** Fully custom AWT font renderer: JetBrains Mono rasterized into our own atlas, drawn with our own quads. */
public class AwtFontRenderer extends TextRenderer {
    private static final String FONT_RESOURCE = "/assets/skrvisuals/font/jetbrains_bold.ttf";
    private static final int BASE = 40;
    private static final float EM_GUI = 9.0f;
    private static final float ASCENT_GUI = 7.0f;
    private static final float SCALE = EM_GUI / BASE;
    private static final int PAGE = 512;
    private static final int CELL = 56;
    private static final int COLS = PAGE / CELL;
    private static final float UV_PAD = 0.25f;
    private static final FontRenderContext FRC = new FontRenderContext(null, true, true);

    private final Font baseFont;
    private final Font fallbackFont;
    private final Map<Integer, Font> styledFonts = new HashMap<>();
    private final Map<Long, Glyph> glyphs = new HashMap<>();
    private final List<NativeImageBackedTexture> pages = new ArrayList<>();
    private final List<Identifier> pageIds = new ArrayList<>();
    private int nextPage;
    private int nextCell;

    private static final class Glyph {
        boolean textured;
        Identifier page;
        float u0, v0, u1, v1;
        int w, h;
        float advance;
        float bearingX;
        float top;
    }

    public AwtFontRenderer() {
        super(id -> null, false);
        Font loaded;
        try (InputStream in = AwtFontRenderer.class.getResourceAsStream(FONT_RESOURCE)) {
            if (in == null) {
                throw new IllegalStateException("Font resource not found: " + FONT_RESOURCE);
            }
            loaded = Font.createFont(Font.TRUETYPE_FONT, in);
            Fonts.LOGGER.info("AWT font renderer loaded {}", FONT_RESOURCE);
        } catch (Exception e) {
            Fonts.LOGGER.error("Failed to load {}, falling back to SansSerif", FONT_RESOURCE, e);
            loaded = new Font(Font.SANS_SERIF, Font.PLAIN, 1);
        }
        this.baseFont = loaded.deriveFont((float) BASE);
        this.fallbackFont = new Font(Font.SANS_SERIF, Font.PLAIN, BASE);
    }

    private static int styleOf(int mask) {
        return ((mask & 1) != 0 ? Font.BOLD : 0) | ((mask & 2) != 0 ? Font.ITALIC : 0);
    }

    private Font fontFor(int mask, int codePoint, boolean forceFallback) {
        if (forceFallback || !baseFont.canDisplay(codePoint)) {
            return fallbackFont.deriveFont(styleOf(mask), (float) BASE);
        }
        return styledFonts.computeIfAbsent(mask, m -> {
            int style = styleOf(m);
            return style == 0 ? baseFont : baseFont.deriveFont(style, (float) BASE);
        });
    }

    private synchronized Glyph glyph(int codePoint, int mask) {
        long key = ((long) codePoint << 2) | mask;
        Glyph g = glyphs.get(key);
        if (g != null) {
            return g;
        }
        g = new Glyph();
        Font f = fontFor(mask, codePoint, false);
        if (!f.canDisplay(codePoint) && !fontFor(mask, codePoint, true).canDisplay(codePoint)) {
            g.advance = BASE * 0.3f;
            glyphs.put(key, g);
            return g;
        }
        GlyphVector gv = f.createGlyphVector(FRC, new String(Character.toChars(codePoint)));
        g.advance = (float) gv.getGlyphPosition(1).getX();
        Rectangle2D b = gv.getVisualBounds();
        if (b.getWidth() > 0 && b.getHeight() > 0) {
            int pad = 2;
            int bw = Math.min(CELL, (int) Math.ceil(b.getWidth()) + pad * 2);
            int bh = Math.min(CELL, (int) Math.ceil(b.getHeight()) + pad * 2);
            if (nextCell >= COLS * COLS) {
                nextPage++;
                nextCell = 0;
            }
            int pageIdx = nextPage;
            int cellIdx = nextCell++;
            ensurePage(pageIdx);
            NativeImage img = pages.get(pageIdx).getImage();
            int cx = (cellIdx % COLS) * CELL;
            int cy = (cellIdx / COLS) * CELL;
            BufferedImage bi = new BufferedImage(bw, bh, BufferedImage.TYPE_INT_ARGB);
            Graphics2D gg = bi.createGraphics();
            gg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            gg.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            gg.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
            gg.setColor(Color.WHITE);
            gg.setFont(f);
            gg.drawGlyphVector(gv, pad - (float) b.getX(), pad - (float) b.getY());
            gg.dispose();
            for (int py = 0; py < bh; py++) {
                for (int px = 0; px < bw; px++) {
                    int argb = bi.getRGB(px, py);
                    if ((argb & 0xFF000000) != 0) {
                        img.setColorArgb(cx + px, cy + py, argb);
                    }
                }
            }
            pages.get(pageIdx).upload();
            g.textured = true;
            g.page = pageIds.get(pageIdx);
            g.w = bw;
            g.h = bh;
            g.u0 = (cx + UV_PAD) / PAGE;
            g.v0 = (cy + UV_PAD) / PAGE;
            g.u1 = (cx + bw - UV_PAD) / PAGE;
            g.v1 = (cy + bh - UV_PAD) / PAGE;
            g.bearingX = (float) b.getX() - pad;
            g.top = (float) b.getY() - pad;
        }
        glyphs.put(key, g);
        return g;
    }

    private void ensurePage(int idx) {
        while (pages.size() <= idx) {
            NativeImageBackedTexture tex = new NativeImageBackedTexture(new NativeImage(PAGE, PAGE, true));
            tex.setFilter(true, false);
            Identifier id = Identifier.of("skrvisuals", "awtfont_page_" + pages.size());
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, tex);
            pages.add(tex);
            pageIds.add(id);
        }
    }

    private static int shadowColor(int color) {
        return (color & 0xFC000000) | ((color & 0xFCFCFC) >> 2);
    }

    private static int[][] parse(String text) {
        List<int[]> pairs = new ArrayList<>();
        int mask = 0;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == 167) {
                if (i < text.length()) {
                    int code = Character.toLowerCase(text.charAt(i));
                    i++;
                    if (code == 'l') {
                        mask |= 1;
                    } else if (code == 'o') {
                        mask |= 2;
                    } else if (code == 'r') {
                        mask = 0;
                    }
                }
                continue;
            }
            pairs.add(new int[]{cp, mask});
        }
        int[] c = new int[pairs.size()];
        int[] m = new int[pairs.size()];
        for (int i = 0; i < pairs.size(); i++) {
            c[i] = pairs.get(i)[0];
            m[i] = pairs.get(i)[1];
        }
        return new int[][]{c, m};
    }

    private float drawRun(int[] cps, int[] masks, float x, float y, int color, Matrix4f matrix, VertexConsumerProvider provider) {
        float cursor = x;
        float baseline = y + ASCENT_GUI;
        for (int i = 0; i < cps.length; i++) {
            Glyph g = glyph(cps[i], masks[i]);
            if (g.textured) {
                float left = cursor + g.bearingX * SCALE;
                float top = baseline + g.top * SCALE;
                float right = left + g.w * SCALE;
                float bottom = top + g.h * SCALE;
                VertexConsumer vc = provider.getBuffer(RenderLayer.getGuiTextured(g.page));
                vc.vertex(matrix, left, top, 0.0F).texture(g.u0, g.v0).color(color);
                vc.vertex(matrix, left, bottom, 0.0F).texture(g.u0, g.v1).color(color);
                vc.vertex(matrix, right, bottom, 0.0F).texture(g.u1, g.v1).color(color);
                vc.vertex(matrix, right, top, 0.0F).texture(g.u1, g.v0).color(color);
            }
            cursor += g.advance * SCALE;
        }
        return cursor;
    }

    private float runWidth(int[] cps, int[] masks) {
        float w = 0.0F;
        for (int i = 0; i < cps.length; i++) {
            w += glyph(cps[i], masks[i]).advance * SCALE;
        }
        return w;
    }

    @Override
    public int draw(String text, float x, float y, int color, boolean shadow, Matrix4f matrix,
                    VertexConsumerProvider provider, TextLayerType layerType, int backgroundColor, int light) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        int[][] run = parse(text);
        if (shadow) {
            drawRun(run[0], run[1], x + 1.0F, y + 1.0F, shadowColor(color), matrix, provider);
        }
        float end = drawRun(run[0], run[1], x, y, color, matrix, provider);
        return (int) Math.ceil(end - x);
    }

    @Override
    public int draw(OrderedText text, float x, float y, int color, boolean shadow, Matrix4f matrix,
                    VertexConsumerProvider provider, TextLayerType layerType, int backgroundColor, int light) {
        if (text == null) {
            return 0;
        }
        List<int[]> list = new ArrayList<>();
        text.accept((index, style, codePoint) -> {
            list.add(new int[]{codePoint, (style.isBold() ? 1 : 0) | (style.isItalic() ? 2 : 0)});
            return true;
        });
        int[] c = new int[list.size()];
        int[] m = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            c[i] = list.get(i)[0];
            m[i] = list.get(i)[1];
        }
        if (shadow) {
            drawRun(c, m, x + 1.0F, y + 1.0F, shadowColor(color), matrix, provider);
        }
        float end = drawRun(c, m, x, y, color, matrix, provider);
        return (int) Math.ceil(end - x);
    }

    @Override
    public int getWidth(String text) {
        if (text == null || text.isEmpty()) {
            return 0;
        }
        int[][] run = parse(text);
        return (int) Math.ceil(runWidth(run[0], run[1]));
    }

    @Override
    public int getWidth(StringVisitable text) {
        return text == null ? 0 : getWidth(text.getString());
    }

    @Override
    public int getWidth(OrderedText text) {
        if (text == null) {
            return 0;
        }
        List<int[]> list = new ArrayList<>();
        text.accept((index, style, codePoint) -> {
            list.add(new int[]{codePoint, (style.isBold() ? 1 : 0) | (style.isItalic() ? 2 : 0)});
            return true;
        });
        int[] c = new int[list.size()];
        int[] m = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            c[i] = list.get(i)[0];
            m[i] = list.get(i)[1];
        }
        return (int) Math.ceil(runWidth(c, m));
    }
}
