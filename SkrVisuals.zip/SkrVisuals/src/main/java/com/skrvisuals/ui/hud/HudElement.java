package com.skrvisuals.ui.hud;

import java.util.List;

import net.minecraft.client.gui.DrawContext;

/**
 * A single movable HUD element. The renderer updates width/height so the
 * drag hit-box stays accurate from the first frame.
 */
public class HudElement {
    public interface Renderer {
        void render(DrawContext context, HudElement element);
    }

    public final String id;
    public float x;
    public float y;
    public int width = 40;
    public int height = 12;
    /** Visual scale multiplier (1 = normal), changed from the settings popup. */
    public float scale = 1f;
    /** Visual opacity multiplier (0..1), changed from the settings popup. */
    public float opacity = 1f;

    private final Renderer renderer;

    public HudElement(String id, float x, float y, Renderer renderer) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.renderer = renderer;
    }

    public void render(DrawContext context) {
        this.renderer.render(context, this);
    }

    public boolean contains(double mouseX, double mouseY) {
        float w = width * scale;
        float h = height * scale;
        return mouseX >= x && mouseX <= x + w
                && mouseY >= y && mouseY <= y + h;
    }
}