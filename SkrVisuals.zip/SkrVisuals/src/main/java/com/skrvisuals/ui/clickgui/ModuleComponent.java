package com.skrvisuals.ui.clickgui;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.settings.BindSetting;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ColorSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.modules.settings.StringSetting;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.clickgui.settings.BindSettingComponent;
import com.skrvisuals.ui.clickgui.settings.BooleanSettingComponent;
import com.skrvisuals.ui.clickgui.settings.ColorSettingComponent;
import com.skrvisuals.ui.clickgui.settings.ModeSettingComponent;
import com.skrvisuals.ui.clickgui.settings.SettingComponent;
import com.skrvisuals.ui.clickgui.settings.SliderSettingComponent;
import com.skrvisuals.ui.clickgui.settings.StringSettingComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.GuiFx;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import com.skrvisuals.util.KeyUtil;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Современная карточка модуля: скруглённая плитка с названием, коротким
 * описанием, анимированным свитчем-переключателем и раскрывающимся блоком
 * настроек. ЛКМ — вкл/выкл, ПКМ (или клик по шеврону) — настройки,
 * СКМ — бинд клавиши.
 */
public class ModuleComponent {
    private static final float CARD_HEIGHT = 28.0F;
    private static final float SWITCH_W = 22.0F;
    private static final float SWITCH_H = 12.0F;
    private static final float SWITCH_MARGIN = 11.0F;
    private static final float SETTINGS_GAP = 4.0F;
    private static final float ROW_PAD = 8.0F;
    private static final float ROW_GAP = 4.0F;

    private final Module module;

    private final ClickScreen gui;

    private float x;
    private float y;
    private float cardWidth = 153.0F;
    private float width;
    private float height;

    private boolean hovered = false;
    private boolean binding = false;
    private boolean expanded = false;
    private boolean hoveringExpand = false;

    private long lastVisibilityCheck = 0L;
    private long bindingStartTime = 0L;
    /** Прогресс каскадного появления (0..1), задаётся из ModuleScreen. */
    private float entrance = 1.0F;
    private long lastToggleAt = 0L;
    private boolean lastEnabled = false;

    private final Animation toggleAnimation = new Animation(Easing.EASE_IN_OUT_QUINT, 400L);
    private final Animation hoverAnimation = new Animation(Easing.EASE_OUT_CUBIC, 180L);
    private final Animation expandAnimation = new Animation(Easing.EASE_OUT_CUBIC, 200L);

    private final List<SettingComponent> visibleSettings = new ArrayList<>();

    public ModuleComponent(Module module, ClickScreen gui) {
        this.module = module;
        this.gui = gui;
    }

    public Module getModule() {
        return this.module;
    }

    public float getX() { return this.x; }
    public float getY() { return this.y; }
    public float getWidth() { return this.width; }
    public float getHeight() { return this.height; }
    public boolean isHovered() { return this.hovered; }
    public boolean isBinding() { return this.binding; }
    public void setEntrance(float entrance) { this.entrance = entrance; }

    /** Ширина карточки задаётся сеткой ({@link ModuleScreen}) каждый кадр. */
    public void setCardWidth(float cardWidth) {
        this.cardWidth = Math.max(80.0F, cardWidth);
    }

    public void init() {
        this.height = CARD_HEIGHT;
        this.lastEnabled = this.module.isEnabled();
        this.lastToggleAt = 0L;
        this.lastVisibilityCheck = 0L;
        rebuildSettings();
    }

    /** Пересобирает компоненты настроек под текущий список видимых настроек. */
    private void rebuildSettings() {
        this.visibleSettings.clear();
        for (Setting setting : this.module.getSettings()) {
            SettingComponent component = createSettingComponent(setting);
            if (component != null) {
                component.init();
                this.visibleSettings.add(component);
            }
        }
    }

    /** Периодически обновляет видимость настроек (hide-condition меняется на лету). */
    private void refreshSettings() {
        if (System.currentTimeMillis() - this.lastVisibilityCheck < 400L) {
            return;
        }
        this.lastVisibilityCheck = System.currentTimeMillis();
        this.module.updateSettings();
        List<Setting> current = this.module.getSettings();
        if (current.size() == this.visibleSettings.size()) {
            boolean same = true;
            for (int i = 0; i < current.size(); i++) {
                if (this.visibleSettings.get(i).getSetting() != current.get(i)) {
                    same = false;
                    break;
                }
            }
            if (same) {
                return;
            }
        }
        rebuildSettings();
    }

    private SettingComponent createSettingComponent(Setting setting) {
        if (setting instanceof BooleanSetting) {
            return new BooleanSettingComponent(setting, this);
        }
        if (setting instanceof SliderSetting) {
            return new SliderSettingComponent(setting, this);
        }
        if (setting instanceof ModeSetting) {
            return new ModeSettingComponent(setting, this);
        }
        if (setting instanceof ColorSetting) {
            return new ColorSettingComponent(setting, this);
        }
        if (setting instanceof StringSetting) {
            return new StringSettingComponent(setting, this);
        }
        if (setting instanceof BindSetting) {
            return new BindSettingComponent(setting, this);
        }
        return null;
    }

    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float partialTicks) {
        refreshSettings();

        this.x = x;
        this.y = y;
        this.width = this.cardWidth;
        this.height = CARD_HEIGHT;
        this.hovered = this.entrance > 0.35F
                && RenderUtil.hovered(mouseX, mouseY, x, y, this.width, this.height);

        if (this.module.isEnabled() != this.lastEnabled) {
            this.lastEnabled = this.module.isEnabled();
            this.lastToggleAt = System.currentTimeMillis();
        }
        float pulse = this.lastToggleAt == 0L ? 0.0F
                : GuiFx.clamp01(1.0F - (System.currentTimeMillis() - this.lastToggleAt) / 420.0F);

        this.toggleAnimation.run(this.module.isEnabled() ? 1.0F : 0.0F);
        this.hoverAnimation.run(this.hovered ? 1.0F : 0.0F);
        this.expandAnimation.run(this.expanded ? 1.0F : 0.0F);
        float hover = this.hoverAnimation.getValue();
        float on = this.toggleAnimation.getValue();
        float expand = this.expandAnimation.getValue();

        float alpha = this.gui.getAlpha() * this.entrance;
        if (alpha <= 0.01F) {
            return;
        }
        TextRenderer font = Fonts.get();
        int accent = Colors.clientColor();

        // ---- Плитка карточки ----
        RenderUtil.roundedGradient(context, x, y, this.width, this.height, 7.0F,
                RenderUtil.withAlpha(Colors.moduleBackgroundTop(), alpha),
                RenderUtil.withAlpha(Colors.moduleBackgroundBottom(), alpha));

        int border = RenderUtil.lerpColor(Colors.moduleBorder(), Colors.moduleBorderHover(), hover);
        border = RenderUtil.lerpColor(border, accent, 0.5F * on);
        RenderUtil.roundedOutline(context, x, y, this.width, this.height, 7.0F, 1.0F,
                RenderUtil.withAlpha(border, alpha * (0.85F + 0.15F * hover)));

        // Левый акцентный маркер включённого модуля.
        if (on > 0.02F) {
            RenderUtil.roundedRect(context, x + 1.5F, y + 7.0F, 2.5F, this.height - 14.0F, 1.25F,
                    RenderUtil.withAlpha(accent, on * alpha));
        }
        // Вспышка-пульс после переключения.
        if (pulse > 0.02F) {
            RenderUtil.roundedOutline(context, x - 1.0F, y - 1.0F, this.width + 2.0F, this.height + 2.0F,
                    8.0F, 1.5F, RenderUtil.withAlpha(accent, pulse * 0.45F * alpha));
        }

        // ---- Геометрия правой части ----
        float switchX = x + this.width - SWITCH_MARGIN - SWITCH_W;
        float switchY = y + (this.height - SWITCH_H) / 2.0F;
        boolean hasSettings = !this.visibleSettings.isEmpty();
        float chevronRight = hasSettings ? switchX - 4.0F : switchX;
        String keyLabel = keyLabel();
        boolean hasKey = !keyLabel.isEmpty();
        float keyRight = chevronRight - 6.0F;
        float textRight = hasKey
                ? keyRight - font.getWidth(keyLabel) - 8.0F
                : chevronRight - 8.0F;

        // ---- Название + описание ----
        float textLeft = x + 11.0F;
        if (textRight - textLeft > 8.0F) {
            RenderUtil.pushScissor(context, textLeft, y, textRight - textLeft, this.height);
            try {
                int nameColor = RenderUtil.lerpColor(Colors.textDescription(), Colors.textPrimary(),
                        Math.max(hover, on));
                RenderUtil.drawString(context, font, this.module.getName(), textLeft, y + 5.5F,
                        RenderUtil.withAlpha(nameColor, alpha));
                String description = truncate(font, this.module.getDescription(), textRight - textLeft);
                if (!description.isEmpty()) {
                    RenderUtil.drawString(context, font, description, textLeft, y + 16.5F,
                            RenderUtil.withAlpha(Colors.textMuted(), alpha * 0.95F));
                }
            } finally {
                RenderUtil.popScissor();
            }
        }

        // ---- Свитч, шеврон, чип клавиши ----
        drawSwitch(context, switchX, switchY, on, alpha, accent);
        drawExpandChevron(context, switchX, mouseX, mouseY, expand, alpha, on);
        drawKeyChip(context, font, keyRight, y + 16.5F, alpha, keyLabel);

        // ---- Блок настроек ----
        if (hasSettings && expand > 0.01F) {
            renderSettings(context, mouseX, mouseY, partialTicks, expand, alpha);
        }

        if (this.hovered) {
            this.gui.setHoveredModule(this);
        }
    }

    /** Анимированный свитч-переключатель (iOS-стиль). */
    private void drawSwitch(DrawContext ctx, float sx, float sy, float on, float alpha, int accent) {
        int track = RenderUtil.lerpColor(Colors.toggleOff(), accent, on);
        RenderUtil.roundedRect(ctx, sx, sy, SWITCH_W, SWITCH_H, SWITCH_H / 2.0F,
                RenderUtil.withAlpha(track, alpha));
        float knobR = 4.5F;
        float knobCx = sx + 1.5F + knobR + on * (SWITCH_W - 3.0F - knobR * 2.0F);
        float knobCy = sy + SWITCH_H / 2.0F;
        RenderUtil.circle(ctx, knobCx, knobCy + 0.7F, knobR + 0.4F,
                RenderUtil.withAlpha(0x40000000, alpha));
        RenderUtil.circle(ctx, knobCx, knobCy, knobR,
                RenderUtil.withAlpha(Colors.toggleKnob(), alpha));
    }

    /** Шеврон раскрытия настроек; клик по нему переключает блок. */
    private void drawExpandChevron(DrawContext ctx, float switchX,
                                   int mouseX, int mouseY, float expand, float alpha, float on) {
        if (this.visibleSettings.isEmpty()) {
            this.hoveringExpand = false;
            return;
        }
        float size = 14.0F;
        float cx = switchX - 4.0F - size / 2.0F;
        float cy = this.y + this.height / 2.0F;
        this.hoveringExpand = RenderUtil.hovered(mouseX, mouseY,
                cx - size / 2.0F, cy - size / 2.0F, size, size);

        float hw = 4.0F;
        float hh = 2.4F;
        float tipY = cy + hh - 2.0F * hh * expand;
        float baseY = cy - hh + 2.0F * hh * expand;
        int color = this.hoveringExpand
                ? Colors.textPrimary()
                : RenderUtil.lerpColor(Colors.textMuted(), Colors.clientColor(), on);
        RenderUtil.fillQuad(ctx, cx - hw, baseY, cx, tipY, cx + hw, baseY, cx + hw, baseY,
                RenderUtil.withAlpha(color, alpha));
    }

    /** Чип клавиши-бинда справа снизу карточки (или анимация бинда). */
    private void drawKeyChip(DrawContext ctx, TextRenderer font, float right, float textY,
                             float alpha, String keyLabel) {
        String label;
        int color;
        if (this.binding) {
            label = "bind" + getBindingAnimation();
            color = Colors.clientColor();
        } else if (keyLabel.isEmpty()) {
            return;
        } else {
            label = keyLabel;
            color = Colors.textMuted();
        }
        RenderUtil.drawString(ctx, font, label, right - font.getWidth(label), textY,
                RenderUtil.withAlpha(color, alpha));
    }

    /** Раскрывающийся блок настроек под карточкой (с клипом по прогрессу). */
    private void renderSettings(DrawContext ctx, int mouseX, int mouseY,
                                float partialTicks, float expand, float alpha) {
        float blockY = this.y + this.height + SETTINGS_GAP;
        float fullH = settingsBlockHeight();
        float blockH = fullH * expand;
        if (blockH <= 1.0F) {
            return;
        }
        RenderUtil.pushScissor(ctx, this.x, blockY, this.width, blockH);
        try {
            RenderUtil.roundedGradient(ctx, this.x, blockY, this.width, fullH, 7.0F,
                    RenderUtil.withAlpha(Colors.settingBackgroundTop(), alpha),
                    RenderUtil.withAlpha(Colors.settingBackgroundBottom(), alpha));
            RenderUtil.roundedOutline(ctx, this.x, blockY, this.width, fullH, 7.0F, 1.0F,
                    RenderUtil.withAlpha(Colors.guiBorder(), alpha * 0.5F));
            float rowY = blockY + ROW_PAD;
            for (SettingComponent setting : this.visibleSettings) {
                setting.render(ctx, this.x, rowY, mouseX, mouseY, partialTicks);
                rowY += setting.getHeight() + ROW_GAP;
            }
        } finally {
            RenderUtil.popScissor();
        }
    }

    /** Полная высота карточки вместе с раскрытыми настройками (для скролла). */
    public float getTotalHeight() {
        float total = this.height > 0.0F ? this.height : CARD_HEIGHT;
        if (!this.visibleSettings.isEmpty()) {
            total += (SETTINGS_GAP + settingsBlockHeight()) * this.expandAnimation.getValue();
        }
        return total;
    }

    private float settingsBlockHeight() {
        float h = ROW_PAD + 2.0F;
        for (SettingComponent setting : this.visibleSettings) {
            h += setting.getHeight() + ROW_GAP;
        }
        return h;
    }

    /** Метка клавиши-бинда: NONE / MOUSE4 / имя клавиши. */
    private String keyLabel() {
        int key = this.module.getKey();
        if (key == -1) {
            return "";
        }
        if (key <= -100) {
            return "M" + (-key - 100 + 1);
        }
        return KeyUtil.name(key);
    }

    private String truncate(TextRenderer font, String text, float maxWidth) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        if (font.getWidth(text) <= maxWidth) {
            return text;
        }
        String result = text;
        while (result.length() > 1 && font.getWidth(result + "…") > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "…";
    }

    private String getBindingAnimation() {
        long elapsed = System.currentTimeMillis() - this.bindingStartTime;
        int dotCount = (int) (elapsed / 500L % 3L) + 1;
        return ".".repeat(dotCount);
    }

    @Override
    public String toString() {
        return "ModuleComponent{" + module.getName() + "}";
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        boolean hasSettings = !this.visibleSettings.isEmpty();
        if (hasSettings && this.hoveringExpand && button == 0) {
            this.expanded = !this.expanded;
            return;
        }
        if (this.hovered && !this.hoveringExpand) {
            if (button == 0 && !this.module.isHidden()) {
                this.module.toggle();
            } else if (button == 2) {
                // СКМ по карточке — начать бинд.
                this.binding = true;
                this.bindingStartTime = System.currentTimeMillis();
            } else if (button == 1 && hasSettings) {
                this.expanded = !this.expanded;
            }
        }
        if (hasSettings && this.expanded) {
            for (SettingComponent setting : this.visibleSettings) {
                setting.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (!this.visibleSettings.isEmpty() && this.expanded) {
            for (SettingComponent setting : this.visibleSettings) {
                setting.mouseReleased(mouseX, mouseY, button);
            }
        }
    }

    public void mouseDragged(double mouseX, double mouseY, int button) {
        if (!this.visibleSettings.isEmpty() && this.expanded) {
            for (SettingComponent setting : this.visibleSettings) {
                if (setting instanceof SliderSettingComponent) {
                    ((SliderSettingComponent) setting).mouseDragged(mouseX, mouseY, button);
                } else if (setting instanceof ColorSettingComponent) {
                    ((ColorSettingComponent) setting).mouseDragged(mouseX, mouseY, button);
                }
            }
        }
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.binding) {
            if (keyCode == 256 || keyCode == 261) {
                this.module.setKey(-1);
            } else {
                this.module.setKey(keyCode);
            }
            this.binding = false;
            return;
        }
        for (SettingComponent setting : this.visibleSettings) {
            setting.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    public void charTyped(char codePoint, int modifiers) {
        for (SettingComponent setting : this.visibleSettings) {
            setting.charTyped(codePoint, modifiers);
        }
    }
}
