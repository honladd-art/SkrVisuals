package com.skrvisuals.ui.mainmenu;

import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import com.skrvisuals.ui.theme.Theme;
import com.skrvisuals.ui.theme.UiStyle;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

public class MainMenuScreen extends Screen {

        private static final float BUTTON_WIDTH = 150.0F;
        private static final float BUTTON_HEIGHT = 28.0F;
        private static final float BUTTON_GAP = 8.0F;
        private static final float BUTTON_ROUND = 8.0F;

        private static final float ICON_SIZE = 38.0F;
        private static final float ICON_GAP = 16.0F;

        private final List<MenuButton> buttons = new ArrayList<>();
        private float fadeAlpha = 0.0F;
        private final long createdNanos = System.nanoTime();

        // Иконки внизу
        private final float[] settingsRect = new float[4];
        private final float[] quitRect = new float[4];
        private float settingsHover, quitHover;

        public MainMenuScreen() {
                super(Text.literal("SkrVisuals"));
        }

        @Override
        protected void init() {
                super.init();
                buttons.clear();
                fadeAlpha = 0.0F;

                float centerX = (this.width - BUTTON_WIDTH) / 2.0F;
                float startY = this.height * 0.38F;
                float gap = BUTTON_HEIGHT + BUTTON_GAP;

                buttons.add(new MenuButton(centerX, startY, BUTTON_WIDTH, BUTTON_HEIGHT,
                                "\u041e\u0434\u0438\u043d\u043e\u0447\u043d\u0430\u044f \u0438\u0433\u0440\u0430",
                                false, () -> {
                                        assert client != null;
                                        client.setScreen(new SelectWorldScreen(this));
                                }));
                buttons.add(new MenuButton(centerX, startY + gap, BUTTON_WIDTH, BUTTON_HEIGHT,
                                "\u0421\u0435\u0442\u0435\u0432\u0430\u044f \u0438\u0433\u0440\u0430", false, () -> {
                                        assert client != null;
                                        client.setScreen(new MultiplayerScreen(this));
                                }));
                buttons.add(new MenuButton(centerX, startY + gap * 2, BUTTON_WIDTH, BUTTON_HEIGHT,
                                "\u041c\u0430\u0433\u0430\u0437\u0438\u043d", true, () -> {
                                }));

                float iconY = this.height - ICON_SIZE - 24.0F;
                float totalW = ICON_SIZE * 2 + ICON_GAP;
                float startX = (this.width - totalW) / 2.0F;

                settingsRect[0] = startX;
                settingsRect[1] = iconY;
                settingsRect[2] = ICON_SIZE;
                settingsRect[3] = ICON_SIZE;

                quitRect[0] = startX + ICON_SIZE + ICON_GAP;
                quitRect[1] = iconY;
                quitRect[2] = ICON_SIZE;
                quitRect[3] = ICON_SIZE;
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
                int sw = this.width;
                int sh = this.height;
                fadeAlpha = MathHelper.lerp(0.07F, fadeAlpha, 1.0F);
                float time = (System.nanoTime() - createdNanos) / 1_000_000_000.0F;

                // Текстура фона меню
                Identifier mainBg = Identifier.of("skrvisuals", "mainmenu/mainmenu.png");
                context.drawTexture(RenderLayer::getGuiTextured, mainBg, 0, 0, 0.0F, 0.0F, sw, sh, sw, sh, 0xFFFFFFFF);
                // ---- Фон: текстура + тёмный overlay + мягкое акцентное свечение -------------
                int base = UiStyle.current().screenBackground();
                RenderUtil.fill4(context, 0, 0, sw, sh,
                                Colors.lighten(base, 0.02F), base, base, Colors.lighten(base, 0.02F));

                int glow = RenderUtil.withAlpha(Theme.accent(),
                                (0.04F + 0.015F * (float) Math.sin(time * 0.8F)) * fadeAlpha);
                MenuStyle.glow(context, sw * 0.5F, -60.0F, sh * 0.6F, glow, 14);

                // Виньетка по краям
                int vig = RenderUtil.withAlpha(0x05070D, 0.50F * fadeAlpha);
                RenderUtil.fill4(context, 0, 0, sw, 100, vig, 0, 0, vig);
                RenderUtil.fill4(context, 0, sh - 100, sw, sh, 0, vig, vig, 0);

                TextRenderer font = Fonts.get();

                // ---- Заголовок "PulseVisuals" --------------------------------------
                String title = "SkrVisuals";
                float titleW = font.getWidth(title);
                float titleX = (sw - titleW) / 2.0F;
                float titleY = sh * 0.22F;

                // Иконка пульса слева от заголовка
                RenderUtil.circle(context, titleX - 26.0F, titleY + font.fontHeight / 2.0F - 1.0F, 10.0F,
                                RenderUtil.withAlpha(Theme.accent(), 0.15F * fadeAlpha));
                RenderUtil.roundedRect(context, titleX - 30.0F, titleY - 4.0F, 4.0F, 20.0F, 2.0F,
                                RenderUtil.withAlpha(Theme.accent(), fadeAlpha));
                RenderUtil.roundedRect(context, titleX - 26.0F, titleY - 2.0F, 12.0F, 4.0F, 2.0F,
                                RenderUtil.withAlpha(Theme.accent(), fadeAlpha));

                RenderUtil.drawString(context, font, title, titleX, titleY,
                                RenderUtil.withAlpha(Colors.textPrimary(), fadeAlpha));

                // Акцентная линия под заголовком =
                // "\u041c\u0438\u043d\u0438\u043c\u0430\u043b\u0438\u0441\u0442\u043d\u044b\u0435
                // \u043c\u0435\u043d\u044e";
                //

                // Акцентная линия под заголовком
                float lineW = 120.0F * fadeAlpha;
                float lineY = titleY + font.fontHeight + 26.0F;
                RenderUtil.fill4(context, (sw - lineW) / 2.0F, lineY, (sw + lineW) / 2.0F, lineY + 2.0F,
                                RenderUtil.withAlpha(Theme.accent(), 0.9F * fadeAlpha),
                                RenderUtil.withAlpha(Theme.accent(), 0.2F * fadeAlpha),
                                RenderUtil.withAlpha(Theme.accent(), 0.2F * fadeAlpha),
                                RenderUtil.withAlpha(Colors.lighten(Theme.accent(), 0.4F), 0.9F * fadeAlpha));

                // ---- Кнопки --------------------------------------------------------
                for (MenuButton button : buttons) {
                        button.render(context, mouseX, mouseY, fadeAlpha);
                }

                // Рябь от кликов
                com.skrvisuals.ui.render.GuiFx.renderRipples(context, fadeAlpha);

                // ---- Иконки внизу --------------------------------------------------
                boolean settingsOver = RenderUtil.hovered(mouseX, mouseY, settingsRect[0], settingsRect[1],
                                settingsRect[2], settingsRect[3]);
                settingsHover += ((settingsOver ? 1.0F : 0.0F) - settingsHover) * 0.18F;
                RenderUtil.roundedRect(context, settingsRect[0], settingsRect[1], settingsRect[2], settingsRect[3],
                                8.0F, RenderUtil.withAlpha(Colors.moduleBackground(), 0.85F * fadeAlpha));
                RenderUtil.roundedOutline(context, settingsRect[0], settingsRect[1], settingsRect[2], settingsRect[3],
                                8.0F, 1.0F, RenderUtil.withAlpha(
                                                RenderUtil.lerpColor(Colors.moduleBorder(), Theme.accent(),
                                                                settingsHover * 0.6F),
                                                fadeAlpha));
                RenderUtil.drawCenteredString(context, font, "\u2699",
                                settingsRect[0] + settingsRect[2] / 2.0F,
                                settingsRect[1] + (settingsRect[3] - font.fontHeight) / 2.0F + 1.0F,
                                RenderUtil.withAlpha(Colors.textPrimary(), fadeAlpha));

                boolean quitOver = RenderUtil.hovered(mouseX, mouseY, quitRect[0], quitRect[1],
                                quitRect[2], quitRect[3]);
                quitHover += ((quitOver ? 1.0F : 0.0F) - quitHover) * 0.18F;
                RenderUtil.roundedRect(context, quitRect[0], quitRect[1], quitRect[2], quitRect[3],
                                8.0F, RenderUtil.withAlpha(Colors.moduleBackground(), 0.85F * fadeAlpha));
                RenderUtil.roundedOutline(context, quitRect[0], quitRect[1], quitRect[2], quitRect[3],
                                8.0F, 1.0F, RenderUtil.withAlpha(
                                                RenderUtil.lerpColor(Colors.moduleBorder(), 0xFFFF6B6B,
                                                                quitHover * 0.6F),
                                                fadeAlpha));
                RenderUtil.drawCenteredString(context, font, "\u2716",
                                quitRect[0] + quitRect[2] / 2.0F,
                                quitRect[1] + (quitRect[3] - font.fontHeight) / 2.0F + 1.0F,
                                RenderUtil.withAlpha(Colors.textPrimary(), fadeAlpha));

                // Версия в левом нижнем углу
                String version = "SkrVisuals 1.21.4";
                RenderUtil.drawString(context, font, version, 12.0F, sh - 14.0F,
                                RenderUtil.withAlpha(Colors.textMuted(), fadeAlpha * 0.6F));
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
                if (button == 0) {
                        float mx = (float) mouseX;
                        float my = (float) mouseY;

                        // Иконка настроек
                        if (RenderUtil.hovered(mx, my, settingsRect[0], settingsRect[1], settingsRect[2],
                                        settingsRect[3])) {
                                assert client != null;
                                client.setScreen(new net.minecraft.client.gui.screen.option.OptionsScreen(this,
                                                client.options));
                                return true;
                        }
                        // Иконка выхода
                        if (RenderUtil.hovered(mx, my, quitRect[0], quitRect[1], quitRect[2], quitRect[3])) {
                                assert client != null;
                                client.scheduleStop();
                                return true;
                        }

                        for (MenuButton mb : buttons) {
                                if (mb.isHovered((int) mouseX, (int) mouseY)) {
                                        mb.click();
                                        return true;
                                }
                        }
                }
                return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
                if (keyCode == 256) { // ESC
                        return true;
                }
                return super.keyPressed(keyCode, scanCode, modifiers);
        }

        /** Одна кнопка главного меню с плавным ховером и акцентным стилем. */
        private static final class MenuButton {
                final float x, y, w, h;
                final String label;
                final boolean accent;
                final Runnable action;
                float hover = 0.0F;

                MenuButton(float x, float y, float w, float h, String label, boolean accent, Runnable action) {
                        this.x = x;
                        this.y = y;
                        this.w = w;
                        this.h = h;
                        this.label = label;
                        this.accent = accent;
                        this.action = action;
                }

                void render(DrawContext ctx, int mouseX, int mouseY, float alpha) {
                        boolean over = RenderUtil.hovered(mouseX, mouseY, x, y, w, h);
                        hover += ((over ? 1.0F : 0.0F) - hover) * 0.16F;
                        if (alpha <= 0.01F)
                                return;

                        int accentColor = Theme.accent();
                        int bg = accent
                                        ? RenderUtil.lerpColor((0x44 << 24) | (accentColor & 0xFFFFFF),
                                                        (0x88 << 24) | (accentColor & 0xFFFFFF), hover)
                                        : RenderUtil.lerpColor(Colors.moduleBackground(), Colors.settingHover(), hover);
                        int border = RenderUtil.lerpColor(Colors.moduleBorder(),
                                        accent ? accentColor : Colors.textMuted(), hover * 0.5F);

                        RenderUtil.roundedShadow(ctx, x, y, w, h, BUTTON_ROUND, 0.2F + hover * 0.25F);
                        RenderUtil.roundedRect(ctx, x, y, w, h, BUTTON_ROUND, RenderUtil.withAlpha(bg, alpha * 0.92F));
                        RenderUtil.roundedOutline(ctx, x, y, w, h, BUTTON_ROUND, 1.2F,
                                        RenderUtil.withAlpha(border, alpha * (0.7F + 0.3F * hover)));

                        // Акцентная полоска слева при ховере
                        if (hover > 0.02F) {
                                RenderUtil.roundedRect(ctx, x + 1.0F, y + 1.0F, 3.0F, h - 2.0F, 2.0F,
                                                RenderUtil.withAlpha(accentColor, alpha * hover * 0.9F));
                        }

                        // Мягкое свечение при ховере
                        if (hover > 0.02F) {
                                RenderUtil.roundedRect(ctx, x, y, w, h, BUTTON_ROUND,
                                                RenderUtil.withAlpha(accentColor, alpha * hover * 0.06F));
                        }

                        TextRenderer f = Fonts.get();
                        float tx = x + 16.0F + (w - 32.0F - f.getWidth(label)) / 2.0F;
                        float ty = y + (h - f.fontHeight) / 2.0F;
                        RenderUtil.drawString(ctx, f, label, tx, ty,
                                        RenderUtil.withAlpha(RenderUtil.lerpColor(Colors.textPrimary(),
                                                        Colors.lighten(accentColor, 0.5F), hover), alpha));
                }

                boolean isHovered(int mx, int my) {
                        return RenderUtil.hovered(mx, my, x, y, w, h);
                }

                void click() {
                        com.skrvisuals.ui.render.GuiFx.ripple(x + w / 2.0F, y + h / 2.0F,
                                        Theme.accent(), Math.max(w, h) * 0.75F);
                        action.run();
                }
        }
}