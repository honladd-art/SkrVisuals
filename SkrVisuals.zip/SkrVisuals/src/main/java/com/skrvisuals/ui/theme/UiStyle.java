package com.skrvisuals.ui.theme;

/**
 * Полный визуальный стиль интерфейса (не путать с {@link Theme} — там только
 * акцентный цвет). Каждому стилю соответствует своя палитра панелей, бордеров
 * и текста, которую используют {@link Colors} и экраны клиента.
 */
public enum UiStyle {
    /** Классический тёмный «glass-dark» стиль. */
    DARK("Тёмная", 0xFF0D1119) {
        @Override public int guiBackground()      { return 0xF2131822; }
        @Override public int guiBackgroundTop()   { return 0xF21A2130; }
        @Override public int guiBackgroundBottom(){ return 0xF20C0F16; }
        @Override public int guiBorder()          { return 0xFF283448; }
        @Override public int sidebarBackground()  { return 0xF0101520; }
        @Override public int headerBackground()   { return 0xD81B2335; }
        @Override public int separatorHorizontal(){ return 0xFF22304A; }
        @Override public int separatorVertical()  { return 0xFF2B3954; }
        @Override public int iconUnselected()     { return 0xFF8A94AC; }
        @Override public int iconTile()           { return 0xFF2A3850; }
        @Override public int searchBackground()   { return 0xD81C2432; }
        @Override public int searchBorderUnfocused() { return 0xFF2E3A52; }
        @Override public int moduleBackground()       { return 0xFF1C2434; }
        @Override public int moduleBackgroundTop()    { return 0xFF232C42; }
        @Override public int moduleBackgroundBottom() { return 0xFF151A27; }
        @Override public int moduleBorder()           { return 0xFF2E3A52; }
        @Override public int moduleBorderHover()      { return 0xFF48618C; }
        @Override public int settingBackground()       { return 0xB0181E29; }
        @Override public int settingBackgroundTop()    { return 0xB0242D3E; }
        @Override public int settingBackgroundBottom() { return 0xB0151B26; }
        @Override public int settingHover()            { return 0xFF27334C; }
        @Override public int textPrimary()     { return 0xFFF0F3FC; }
        @Override public int textPlaceholder() { return 0xFF6C7590; }
        @Override public int textDescription() { return 0xFFA6B0C6; }
        @Override public int textMuted()       { return 0xFF7C86A0; }
        @Override public int keyText()         { return 0xFFE7ECF7; }
        @Override public int keyBackground()   { return 0xFF1A2230; }
        @Override public int keyBorder()       { return 0xFF36445F; }
        @Override public int toggleOff()       { return 0xFF303E58; }
        @Override public int toggleKnob()      { return 0xFF9CA6BE; }
        @Override public int dimOverlay()      { return 0x5C04060C; }
        @Override public int hoverOverlay()    { return 0x16FFFFFF; }
        @Override public int screenBackground(){ return 0xFF0A0E18; }
    },

    /** Тёмно-фиолетовый стиль с сиреневым подтоном панелей. */
    VIOLET("Фиолетовая", 0xFF7B4DD6) {
        @Override public int guiBackground()      { return 0xF2171226; }
        @Override public int guiBackgroundTop()   { return 0xF21F1834; }
        @Override public int guiBackgroundBottom(){ return 0xF2100B1E; }
        @Override public int guiBorder()          { return 0xFF3A2C58; }
        @Override public int sidebarBackground()  { return 0xF0130E20; }
        @Override public int headerBackground()   { return 0xD8231A3A; }
        @Override public int separatorHorizontal(){ return 0xFF322550; }
        @Override public int separatorVertical()  { return 0xFF3B2E60; }
        @Override public int iconUnselected()     { return 0xFF9C90B8; }
        @Override public int iconTile()           { return 0xFF3B2E5C; }
        @Override public int searchBackground()   { return 0xD81F1734; }
        @Override public int searchBorderUnfocused() { return 0xFF3A2C58; }
        @Override public int moduleBackground()       { return 0xFF241C3A; }
        @Override public int moduleBackgroundTop()    { return 0xFF2D2349; }
        @Override public int moduleBackgroundBottom() { return 0xFF1B142C; }
        @Override public int moduleBorder()           { return 0xFF3A2C58; }
        @Override public int moduleBorderHover()      { return 0xFF6B4FA0; }
        @Override public int settingBackground()       { return 0xB01E1730; }
        @Override public int settingBackgroundTop()    { return 0xB02A2047; }
        @Override public int settingBackgroundBottom() { return 0xB0181230; }
        @Override public int settingHover()            { return 0xFF312653; }
        @Override public int textPrimary()     { return 0xFFF3EFFC; }
        @Override public int textPlaceholder() { return 0xFF7B6F96; }
        @Override public int textDescription() { return 0xFFB0A6CC; }
        @Override public int textMuted()       { return 0xFF8B80A8; }
        @Override public int keyText()         { return 0xFFEAE4F7; }
        @Override public int keyBackground()   { return 0xFF221A36; }
        @Override public int keyBorder()       { return 0xFF443568; }
        @Override public int toggleOff()       { return 0xFF3D305C; }
        @Override public int toggleKnob()      { return 0xFFAC9ECB; }
        @Override public int dimOverlay()      { return 0x5C0A0418; }
        @Override public int hoverOverlay()    { return 0x18FFFFFF; }
        @Override public int screenBackground(){ return 0xFF0D0918; }
    },

    /** Светлый стиль: светлые панели, тёмный текст. */
    LIGHT("Светлая", 0xFF3A78E0) {
        @Override public int guiBackground()      { return 0xF6F2F5FC; }
        @Override public int guiBackgroundTop()   { return 0xF6F8FAFF; }
        @Override public int guiBackgroundBottom(){ return 0xF6E8EBF4; }
        @Override public int guiBorder()          { return 0xFFC6CEDE; }
        @Override public int sidebarBackground()  { return 0xF6EAEEF8; }
        @Override public int headerBackground()   { return 0xD8E4E9F5; }
        @Override public int separatorHorizontal(){ return 0xFFD4DBE8; }
        @Override public int separatorVertical()  { return 0xFFCCD4E4; }
        @Override public int iconUnselected()     { return 0xFF7A8299; }
        @Override public int iconTile()           { return 0xFFE1E6F0; }
        @Override public int searchBackground()   { return 0xD8EDF0F7; }
        @Override public int searchBorderUnfocused() { return 0xFFC6CEDE; }
        @Override public int moduleBackground()       { return 0xFFFFFFFF; }
        @Override public int moduleBackgroundTop()    { return 0xFFFFFFFF; }
        @Override public int moduleBackgroundBottom() { return 0xFFF2F5FA; }
        @Override public int moduleBorder()           { return 0xFFCBD3E2; }
        @Override public int moduleBorderHover()      { return 0xFF9AB2DC; }
        @Override public int settingBackground()       { return 0xB0EFF2F8; }
        @Override public int settingBackgroundTop()    { return 0xB0F7F9FD; }
        @Override public int settingBackgroundBottom() { return 0xB0E6EAF3; }
        @Override public int settingHover()            { return 0xFFE2E9F4; }
        @Override public int textPrimary()     { return 0xFF1B2230; }
        @Override public int textPlaceholder() { return 0xFF9AA3B8; }
        @Override public int textDescription() { return 0xFF4C5670; }
        @Override public int textMuted()       { return 0xFF8189A0; }
        @Override public int keyText()         { return 0xFF232B3C; }
        @Override public int keyBackground()   { return 0xFFEDF0F7; }
        @Override public int keyBorder()       { return 0xFFC9D1E0; }
        @Override public int toggleOff()       { return 0xFFC9D1E0; }
        @Override public int toggleKnob()      { return 0xFF5A6480; }
        @Override public int dimOverlay()      { return 0x3C2A3040; }
        @Override public int hoverOverlay()    { return 0x14203050; }
        @Override public int screenBackground(){ return 0xFFDDE3EE; }
    };

    private static UiStyle current = DARK;

    private final String displayName;
    private final int swatch;

    UiStyle(String displayName, int swatch) {
        this.displayName = displayName;
        this.swatch = swatch;
    }

    public static UiStyle current() {
        return current;
    }

    public static void set(UiStyle style) {
        if (style != null) {
            current = style;
        }
    }

    public static void setByName(String name) {
        if (name == null) {
            return;
        }
        for (UiStyle s : values()) {
            if (s.name().equalsIgnoreCase(name)) {
                current = s;
                return;
            }
        }
    }

    /** Цвет образца-кружка для свитчера в меню. */
    public int swatch() {
        return swatch;
    }

    public String getDisplayName() {
        return displayName;
    }

    // ---- Палитра (переопределяется каждым стилем) -------------------------

    public abstract int guiBackground();
    public abstract int guiBackgroundTop();
    public abstract int guiBackgroundBottom();
    public abstract int guiBorder();
    public abstract int sidebarBackground();
    public abstract int headerBackground();
    public abstract int separatorHorizontal();
    public abstract int separatorVertical();
    public abstract int iconUnselected();
    public abstract int iconTile();
    public abstract int searchBackground();
    public abstract int searchBorderUnfocused();
    public abstract int moduleBackground();
    public abstract int moduleBackgroundTop();
    public abstract int moduleBackgroundBottom();
    public abstract int moduleBorder();
    public abstract int moduleBorderHover();
    public abstract int settingBackground();
    public abstract int settingBackgroundTop();
    public abstract int settingBackgroundBottom();
    public abstract int settingHover();
    public abstract int textPrimary();
    public abstract int textPlaceholder();
    public abstract int textDescription();
    public abstract int textMuted();
    public abstract int keyText();
    public abstract int keyBackground();
    public abstract int keyBorder();
    public abstract int toggleOff();
    public abstract int toggleKnob();
    public abstract int dimOverlay();
    public abstract int hoverOverlay();
    /** Цвет фона полноценных экранов (главное меню, список серверов). */
    public abstract int screenBackground();
}