package com.skrvisuals.ui.theme;

/**
 * Selectable main (accent) color of the client. Every visual that used a
 * hard-coded accent now follows {@link #accent()}, so switching the theme
 * recolors the GUI, HUD elements and visual modules at once.
 */
public enum Theme {
    RED("Красный", 0xFFFF5F5F),
    ORANGE("Оранжевый", 0xFFFF9E4D),
    YELLOW("Жёлтый", 0xFFFFD26B),
    GREEN("Зелёный", 0xFF68E08A),
    CYAN("Голубой", 0xFF6BD0FF),
    BLUE("Синий", 0xFF6B8BFF),
    PURPLE("Фиолетовый", 0xFFA97BFF),
    PINK("Розовый", 0xFFFF7BC8),
    /** Пользовательский цвет, выбирается пипеткой в панели Themes. */
    CUSTOM("Свой цвет", 0xFFFF5F5F);

    private static Theme current = BLUE;
    /** ARGB пользовательского цвета (для {@link #CUSTOM}). */
    private static int customAccent = 0xFF6BFFB8;

    private final String displayName;
    private final int accent;
    private final int accentDim;

    Theme(String displayName, int accent) {
        this.displayName = displayName;
        this.accent = accent | 0xFF000000;
        // Dim variant: channels scaled towards black, like the original palette.
        int r = (int) (((this.accent >> 16) & 0xFF) * 0.72f);
        int g = (int) (((this.accent >> 8) & 0xFF) * 0.72f);
        int b = (int) ((this.accent & 0xFF) * 0.72f);
        this.accentDim = 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** The currently applied theme. */
    public static Theme current() {
        return current;
    }

    /** Switches the active theme (no-op for {@code null}). */
    public static void set(Theme theme) {
        if (theme != null) {
            current = theme;
        }
    }

    /** Restores a theme from its config name; unknown names are ignored. */
    public static void setByName(String name) {
        if (name == null) {
            return;
        }
        for (Theme t : values()) {
            if (t.name().equalsIgnoreCase(name)) {
                current = t;
                return;
            }
        }
    }

    /** Main accent color (opaque ARGB) of the current theme. */
    public static int accent() {
        return current == CUSTOM ? customAccent : current.accent;
    }

    /** Darker companion of {@link #accent()} for secondary accents. */
    public static int accentDim() {
        if (current == CUSTOM) {
            return dimOf(customAccent);
        }
        return current.accentDim;
    }

    /** Пользовательский цвет темы CUSTOM (opaque ARGB). */
    public static int customColor() {
        return customAccent;
    }

    /** Меняет пользовательский цвет (только для темы CUSTOM). */
    public static void setCustomColor(int argb) {
        customAccent = argb | 0xFF000000;
    }

    private static int dimOf(int accent) {
        int r = (int) (((accent >> 16) & 0xFF) * 0.72f);
        int g = (int) (((accent >> 8) & 0xFF) * 0.72f);
        int b = (int) ((accent & 0xFF) * 0.72f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public int getAccent() {
        return this.accent;
    }
}