package com.skrvisuals.ui.render;

import net.minecraft.client.font.TextRenderer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Entry point for the custom GUI/HUD font.
 *
 * Uses the fully custom {@link AwtFontRenderer}: JetBrains Mono is loaded via Java AWT
 * ({@code Font.createFont}), rasterized into our own texture atlas and drawn with our
 * own quads - the vanilla font pipeline is not involved at all.
 */
public final class Fonts {

    public static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals/Fonts");

    private static volatile TextRenderer renderer;

    private Fonts() {
    }

    /** Returns the shared custom JetBrains Mono text renderer (lazy). */
    public static TextRenderer get() {
        TextRenderer r = renderer;
        if (r == null) {
            synchronized (Fonts.class) {
                r = renderer;
                if (r == null) {
                    r = new AwtFontRenderer();
                    renderer = r;
                }
            }
        }
        return r;
    }

    /** Rounded pixel width of {@code s} in the custom font. */
    public static int width(String s) {
        return get().getWidth(s);
    }
}
