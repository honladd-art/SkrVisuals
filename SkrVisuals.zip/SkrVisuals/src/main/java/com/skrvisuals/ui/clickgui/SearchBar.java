package com.skrvisuals.ui.clickgui;

import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

/**
 * Современное поле поиска: скруглённое, с иконкой-лупой, акцентной рамкой
 * при фокусе, мигающим курсором и лимитом в 32 символа.
 * Поддерживает внешний множитель прозрачности (сворачивание рельса).
 */
public class SearchBar {
    private static final int MAX_CHARACTERS = 32;

    private final Animation focusAnimation = new Animation(Easing.EASE_IN_OUT_SINE, 200L);

    private float x;
    private float y;
    private float width;
    private float height;
    private float alphaMultiplier = 1.0F;

    private String searchText = "";
    private boolean focused = false;

    public SearchBar(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setX(float x) { this.x = x; }
    public void setY(float y) { this.y = y; }
    public void setWidth(float width) { this.width = width; }
    public void setHeight(float height) { this.height = height; }
    public void setAlphaMultiplier(float alphaMultiplier) { this.alphaMultiplier = alphaMultiplier; }

    public float getX() { return this.x; }
    public float getY() { return this.y; }
    public float getWidth() { return this.width; }
    public float getHeight() { return this.height; }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        ClickScreen gui = getClickGUI();
        float a = (gui != null ? gui.getAlpha() : 1.0F) * this.alphaMultiplier;
        if (a <= 0.01F) {
            return;
        }
        boolean hovered = isHovered(mouseX, mouseY);
        this.focusAnimation.run(this.focused ? 1.0F : 0.0F);
        float focus = this.focusAnimation.getValue();

        float radius = this.height / 2.0F;

        // Рамка (акцентная при фокусе).
        int borderUnfocused = Colors.searchBorderUnfocused();
        int borderColor = focus > 0.01F
                ? RenderUtil.lerpColor(borderUnfocused, Colors.clientColor(), focus)
                : borderUnfocused;
        RenderUtil.roundedRect(context, this.x - 0.5F, this.y - 0.5F, this.width + 1.0F, this.height + 1.0F,
                radius + 0.5F, RenderUtil.withAlpha(borderColor, a));
        // Фон.
        RenderUtil.roundedRect(context, this.x, this.y, this.width, this.height, radius,
                RenderUtil.withAlpha(Colors.searchBackground(), a));

        // Иконка-лупа: кружок + ручка.
        float iconCx = this.x + 10.0F;
        float iconCy = this.y + this.height / 2.0F - 0.5F;
        int iconColor = RenderUtil.withAlpha(
                hovered || focused ? Colors.textPrimary() : Colors.textMuted(), a);
        RenderUtil.circleOutline(context, iconCx, iconCy, 3.0F, 1.0F, iconColor);
        RenderUtil.fill(context, iconCx + 2.6F, iconCy + 2.6F, 2.0F, 1.0F, iconColor);

        // Текст / плейсхолдер.
        var font = Fonts.get();
        String displayText = this.searchText.isEmpty() ? "Поиск..." : this.searchText;
        int textColor = this.searchText.isEmpty() ? Colors.textPlaceholder() : Colors.textPrimary();
        float textX = this.x + 19.0F;
        float textY = this.y + this.height / 2.0F - font.fontHeight / 2.0F;
        float textWidth = this.width - (textX - this.x) - 8.0F;
        if (textWidth > 4.0F) {
            RenderUtil.pushScissor(context, textX, this.y + 1.0F, textWidth + 4.0F, this.height - 2.0F);
            try {
                RenderUtil.drawString(context, font, displayText, textX, textY,
                        RenderUtil.withAlpha(textColor, a));
            } finally {
                RenderUtil.popScissor();
            }
        }

        // Мигающий курсор.
        if (this.focused && System.currentTimeMillis() % 1000L < 500L) {
            float cursorX = textX + font.getWidth(this.searchText);
            if (cursorX < this.x + this.width - 6.0F) {
                RenderUtil.fill(context, cursorX, this.y + 5.0F, 1.0F, this.height - 10.0F,
                        RenderUtil.withAlpha(Colors.cursorColor(), a));
            }
        }
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            this.focused = isHovered((int) mouseX, (int) mouseY);
        }
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.focused) {
            return;
        }
        switch (keyCode) {
            case 259 -> { // BACKSPACE
                if (!this.searchText.isEmpty()) {
                    this.searchText = this.searchText.substring(0, this.searchText.length() - 1);
                }
            }
            case 257 -> this.focused = false; // ENTER
            case 256 -> { // ESC
                this.searchText = "";
                this.focused = false;
            }
            case 261 -> this.focused = false; // DELETE
            default -> {
            }
        }
    }

    public void charTyped(char codePoint, int modifiers) {
        if (!this.focused) {
            return;
        }
        if (codePoint >= ' ' && codePoint <= '~' && this.searchText.length() < MAX_CHARACTERS) {
            this.searchText += codePoint;
        }
    }

    private boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= this.x && mouseX <= this.x + this.width
                && mouseY >= this.y && mouseY <= this.y + this.height;
    }

    public boolean isEmpty() {
        return this.searchText.isEmpty();
    }

    public void clearSearch() {
        this.searchText = "";
    }

    public String getSearchText() {
        return this.searchText.toLowerCase();
    }

    public boolean isFocused() {
        return this.focused;
    }

    public void focus() {
        this.focused = true;
    }

    public void blur() {
        this.focused = false;
    }

    public boolean contains(double mx, double my) {
        return RenderUtil.hovered((float) mx, (float) my, x, y, width, height);
    }

    private ClickScreen getClickGUI() {
        return (ClickScreen) net.minecraft.client.MinecraftClient.getInstance().currentScreen;
    }
}
