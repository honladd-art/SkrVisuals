package com.skrvisuals.ui.clickgui;

import com.skrvisuals.Skr;
import com.skrvisuals.config.ConfigManager;
import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.ModuleSounds;
import com.skrvisuals.modules.impl.GuiBackground;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.GuiFx;
import com.skrvisuals.ui.render.GuiIcons;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Современный ClickGUI: крупная «стеклянная» панель со скруглением 12,
 * акцентной рамкой, мягкой тенью и лёгким свечением. Слева — навигационный
 * рельс с иконками категорий и поиском, справа — плавающая шапка секции
 * и контент (карточки модулей / списки / темы).
 */
public class ClickScreen extends Screen {

    /** Отступ от верха панели до начала контента (под шапку секции). */
    public static final float CONTENT_TOP_OFFSET = 44.0F;
    /** Нижний отступ контента внутри панели. */
    private static final float CONTENT_BOTTOM_PAD = 10.0F;

    private static ModuleCategory savedCategory = ModuleCategory.VISUALS;

    private float x;
    private float y;
    private float width;
    private float height;
    private float round = 12.0F;

    private final Animation alpha = new Animation(Easing.LINEAR, 150L);
    /** Прогресс появления панели (scale/slide) при открытии/закрытии. */
    private final Animation openProgress = new Animation(Easing.EASE_OUT_CUBIC, 300L);
    /** Плавное проявление затемнения фона под панелью. */
    private final Animation backdropFade = new Animation(Easing.EASE_OUT_CUBIC, 220L);
    /** Время открытия экрана (каскад появления сайдбара). */
    private long openedAt = 0L;
    /** Время последней смены контента (каскад появления карточек). */
    private long contentTime = 0L;

    private float sidebarWidth;
    private final float defaultSidebarWidth = 124.0F;
    private final float minSidebarWidth = 46.0F;
    private boolean closing = false;

    private Sidebar sidebar;
    private ModuleScreen moduleScreen;
    private ThemesPanel themesPanel;
    private FriendsPanel friendsPanel;
    private PointsPanel pointsPanel;
    private ModuleTooltip tooltip = new ModuleTooltip();

    private ModuleComponent hoveredModule;

    private long handCursor = 0L;
    private long currentHandledCursor = 0L;

    public ClickScreen() {
        super(Text.literal("SkrVisuals ClickGUI"));
    }

    @Override
    protected void init() {
        super.init();

        MinecraftClient mc = MinecraftClient.getInstance();
        // Панель адаптируется под экран: не выходит за его границы на малых разрешениях.
        this.width = Math.min(470.0F, mc.getWindow().getScaledWidth() - 24.0F);
        this.height = Math.min(308.0F, mc.getWindow().getScaledHeight() - 24.0F);
        this.x = (mc.getWindow().getScaledWidth() - width) / 2.0F;
        this.y = (mc.getWindow().getScaledHeight() - height) / 2.0F;
        this.sidebarWidth = defaultSidebarWidth;
        this.closing = false;
        this.alpha.setValue(0.0F);
        this.openProgress.setValue(0.0F);
        this.backdropFade.setValue(0.0F);
        this.openedAt = System.currentTimeMillis();
        this.contentTime = this.openedAt;
        GuiFx.clearRipples();

        this.sidebar = new Sidebar(this);
        this.moduleScreen = new ModuleScreen(this);
        this.themesPanel = new ThemesPanel(this);
        this.friendsPanel = new FriendsPanel(this);
        this.pointsPanel = new PointsPanel(this);
        this.tooltip = new ModuleTooltip();
        this.sidebar.init();
        this.moduleScreen.init();

        this.alpha.run(1.0F);
        this.openProgress.run(1.0F);
        this.backdropFade.run(1.0F);
        ModuleSounds.play(ModuleSounds.GUI_OPEN);
        if (this.handCursor == 0L) {
            this.handCursor = GLFW.glfwCreateStandardCursor(221188); // HAND
        }
    }

    @Override
    public void close() {
        ConfigManager.save();
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        if (this.closing) {
            this.alpha.run(0.0F);
            this.openProgress.run(0.0F);
            this.backdropFade.run(0.0F);
        } else {
            this.alpha.run(1.0F);
            this.openProgress.run(1.0F);
            this.backdropFade.run(1.0F);
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        float back = this.backdropFade.getValue();
        float sw = mc.getWindow().getScaledWidth();
        float sh = mc.getWindow().getScaledHeight();

        // Затемнение фона + виньетка сверху/снизу.
        RenderUtil.fill(context, 0, 0, sw, sh,
                RenderUtil.withAlpha(0x04060B, 0.66F * back));
        RenderUtil.fillGradient(context, 0, 0, (int) sw, 92,
                RenderUtil.multiplyAlpha(0x000000, 0.34F * back),
                RenderUtil.withAlpha(0x05070C, 0.0F));
        RenderUtil.fillGradient(context, 0, (int) sh - 92, (int) sw, 92,
                RenderUtil.withAlpha(0x05070C, 0.0F),
                RenderUtil.multiplyAlpha(0x000000, 0.34F * back));

        // Картинка GuiBackground (поверх затемнения, под панелью).
        GuiBackground.renderInGui(context);

        if (this.closing && this.alpha.getValue() <= 0.01F) {
            close();
            return;
        }

        float a = this.alpha.getValue();
        float p = this.openProgress.getValue();
        float scale = 0.965F + 0.035F * p;
        float slide = (1.0F - p) * 6.0F;
        float cx = this.x + this.width / 2.0F;
        float cy = this.y + this.height / 2.0F;

        // Акцентное свечение за панелью — «spill» света наружу.
        GuiFx.radialGlow(context, cx, cy, this.width * 0.60F,
                Colors.clientColor(), 0.075F, a * back);

        context.getMatrices().push();
        context.getMatrices().translate(cx, cy + slide, 0.0F);
        context.getMatrices().scale(scale, scale, 1.0F);
        context.getMatrices().translate(-cx, -cy, 0.0F);

        // Мягкая тень + стеклянная панель + акцентная рамка.
        RenderUtil.roundedShadow(context, this.x, this.y, this.width, this.height, this.round, 0.55F * a);
        RenderUtil.roundedGradient(context, this.x, this.y, this.width, this.height, this.round,
                RenderUtil.withAlpha(Colors.guiBackgroundTop(), a),
                RenderUtil.withAlpha(Colors.guiBackgroundBottom(), a));
        RenderUtil.roundedOutline(context, this.x, this.y, this.width, this.height, this.round, 1.0F,
                RenderUtil.withAlpha(RenderUtil.lerpColor(Colors.guiBorder(), Colors.clientColor(), 0.22F), a));

        // Ширина рельса (анимируется при сворачивании).
        if (this.sidebar.isCategoriesOpen()) {
            this.sidebarWidth = this.defaultSidebarWidth;
        } else {
            this.sidebarWidth = this.minSidebarWidth
                    + (this.defaultSidebarWidth - this.minSidebarWidth) * this.sidebar.getCollapseProgress();
        }

        // Навигационный рельс.
        this.sidebar.render(context, mouseX, mouseY, delta);

        // Плавающая шапка секции.
        renderContentHeader(context, a);

        // Мягкое свечение курсора внутри панели (дёшево имитирует blur).
        float glowP = this.backdropFade.getValue();
        if (glowP > 0.05F
                && RenderUtil.hovered(mouseX, mouseY, this.x, this.y, this.width, this.height)) {
            RenderUtil.pushScissor(context, this.x, this.y, this.width, this.height);
            GuiFx.radialGlow(context, mouseX, mouseY, 52.0F, Colors.clientColor(), 0.05F, a * glowP);
            RenderUtil.popScissor();
        }

        if (isThemesSection()) {
            this.themesPanel.render(context, mouseX, mouseY, delta);
        } else if (isFriendsSection()) {
            this.friendsPanel.render(context, mouseX, mouseY, delta);
        } else if (isPointsSection()) {
            this.pointsPanel.render(context, mouseX, mouseY, delta);
        } else {
            this.moduleScreen.render(context, mouseX, mouseY, delta);
        }

        // Тултип по наведённому модулю.
        if (this.hoveredModule != null) {
            this.tooltip.update(this.hoveredModule.getModule(), true,
                    this.hoveredModule.getX(), this.hoveredModule.getY(), this.hoveredModule.getWidth());
        } else {
            this.tooltip.update(null, false, 0.0F, 0.0F, 0.0F);
        }
        this.tooltip.render(context, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());

        // Рябь от кликов — поверх контента, строго внутри панели.
        RenderUtil.pushScissor(context, this.x, this.y, this.width, this.height);
        GuiFx.renderRipples(context, a);
        RenderUtil.popScissor();

        context.getMatrices().pop(); // закрываем матрицу появления панели
        updateCursor(mouseX, mouseY);
    }

    /** Плавающая шапка секции: иконка категории, название и подпись. */
    private void renderContentHeader(DrawContext context, float a) {
        float hx = getContentX() + 12.0F;
        float hy = this.y + 10.0F;
        float hw = getContentWidth() - 24.0F;
        float hh = 28.0F;

        RenderUtil.roundedRect(context, hx, hy, hw, hh, 8.0F,
                RenderUtil.withAlpha(Colors.headerBackground(), a * 0.92F));
        RenderUtil.roundedOutline(context, hx, hy, hw, hh, 8.0F, 1.0F,
                RenderUtil.withAlpha(Colors.guiBorder(), a * 0.55F));

        // Периодический блик по шапке.
        RenderUtil.pushScissor(context, hx, hy, hw, hh);
        GuiFx.shimmer(context, hx, hy, hw, hh, GuiFx.shimmerPhase(6400L), Colors.iconWhite(), 0.07F * a);
        RenderUtil.popScissor();

        ModuleCategory category = savedCategory;
        int accent = category.getAccentColor();

        float tile = 18.0F;
        float tx = hx + 8.0F;
        float ty = hy + (hh - tile) / 2.0F;
        // Плитка тёмная (с лёгким подмешиванием акцента), иконка — яркая.
        RenderUtil.roundedRect(context, tx, ty, tile, tile, 5.0F,
                RenderUtil.withAlpha(RenderUtil.lerpColor(Colors.moduleBackground(), accent, 0.20F), a));
        float glyph = tile - 5.0F;
        GuiIcons.draw(context, category, tx + (tile - glyph) / 2.0F, ty + (tile - glyph) / 2.0F,
                glyph, RenderUtil.withAlpha(accent, a));

        TextRenderer font = Fonts.get();
        RenderUtil.drawString(context, font, category.getDisplayName(), hx + 32.0F, hy + 6.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), a));
        RenderUtil.drawString(context, font, headerSubtitle(category), hx + 32.0F, hy + 17.0F,
                RenderUtil.withAlpha(Colors.textMuted(), a * 0.95F));

        // Подсказка закрытия.
        String hint = "ESC";
        float hintW = font.getWidth(hint) + 12.0F;
        float bx = hx + hw - hintW - 8.0F;
        RenderUtil.roundedRect(context, bx, hy + 7.0F, hintW, 14.0F, 4.0F,
                RenderUtil.withAlpha(Colors.keyBackground(), a * 0.85F));
        RenderUtil.roundedOutline(context, bx, hy + 7.0F, hintW, 14.0F, 4.0F, 1.0F,
                RenderUtil.withAlpha(Colors.keyBorder(), a * 0.8F));
        RenderUtil.drawCenteredString(context, font, hint, bx + hintW / 2.0F, hy + 10.5F,
                RenderUtil.withAlpha(Colors.keyText(), a));
    }

    private String headerSubtitle(ModuleCategory category) {
        return switch (category) {
            case THEMES -> "Акцент и оформление";
            case FRIENDS -> "Друзья и их подсветка";
            case POINTS -> "Метки и координаты";
            default -> moduleCount(category) + " " + plural(moduleCount(category));
        };
    }

    private static String plural(int count) {
        int mod10 = count % 10;
        int mod100 = count % 100;
        if (mod10 == 1 && mod100 != 11) {
            return "модуль";
        }
        if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
            return "модуля";
        }
        return "модулей";
    }

    private int moduleCount(ModuleCategory category) {
        int count = 0;
        for (Module module : Skr.INSTANCE.getModuleManager().getModules()) {
            if (module.getCategory() == category) {
                count++;
            }
        }
        return count;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            GuiFx.ripple((float) mouseX, (float) mouseY, Colors.clientColor(), 42.0F);
        }
        // Перетаскивание картинки GuiBackground — перехватываем клик.
        if (GuiBackground.tryStartDrag(mouseX, mouseY, button)) {
            return true;
        }
        this.sidebar.mouseClicked(mouseX, mouseY, button);
        if (isThemesSection()) {
            this.themesPanel.mouseClicked(mouseX, mouseY, button);
        } else if (isFriendsSection()) {
            this.friendsPanel.mouseClicked(mouseX, mouseY, button);
        } else if (isPointsSection()) {
            this.pointsPanel.mouseClicked(mouseX, mouseY, button);
        } else {
            this.moduleScreen.mouseClicked(mouseX, mouseY, button);
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (isThemesSection()) {
            this.themesPanel.mouseReleased(mouseX, mouseY, button);
        } else if (!isFriendsSection() && !isPointsSection()) {
            this.moduleScreen.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (isThemesSection()) {
            this.themesPanel.mouseDragged(mouseX, mouseY, button);
        } else if (!isFriendsSection() && !isPointsSection()) {
            this.moduleScreen.mouseDragged(mouseX, mouseY, button);
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (isFriendsSection()) {
            this.friendsPanel.mouseScrolled(vertical);
        } else if (isPointsSection()) {
            this.pointsPanel.mouseScrolled(vertical);
        } else if (!isThemesSection()) {
            this.moduleScreen.mouseScrolled(mouseX, mouseY, vertical);
        }
        return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (hasActiveFocus()) {
                this.sidebar.keyPressed(keyCode, scanCode, modifiers);
                if (isFriendsSection()) {
                    this.friendsPanel.keyPressed(keyCode, scanCode, modifiers);
                } else if (isPointsSection()) {
                    this.pointsPanel.keyPressed(keyCode, scanCode, modifiers);
                } else if (!isThemesSection()) {
                    this.moduleScreen.keyPressed(keyCode, scanCode, modifiers);
                }
                return true;
            }
            this.closing = true;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_F && (modifiers & 0x2) != 0) {
            this.sidebar.focusSearch();
            return true;
        }
        this.sidebar.keyPressed(keyCode, scanCode, modifiers);
        if (isFriendsSection()) {
            this.friendsPanel.keyPressed(keyCode, scanCode, modifiers);
        } else if (isPointsSection()) {
            this.pointsPanel.keyPressed(keyCode, scanCode, modifiers);
        } else if (!isThemesSection()) {
            this.moduleScreen.keyPressed(keyCode, scanCode, modifiers);
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private boolean hasActiveFocus() {
        boolean searchFocused = this.sidebar.isSearchFocused();
        if (searchFocused) {
            return true;
        }
        if (isFriendsSection()) {
            return this.friendsPanel.isInputFocused();
        }
        if (isPointsSection()) {
            return this.pointsPanel.isInputFocused();
        }
        for (ModuleComponent component : this.moduleScreen.moduleComponents) {
            if (component.isBinding()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        this.sidebar.charTyped(codePoint, modifiers);
        if (isFriendsSection()) {
            this.friendsPanel.charTyped(codePoint, modifiers);
        } else if (isPointsSection()) {
            this.pointsPanel.charTyped(codePoint, modifiers);
        } else if (!isThemesSection()) {
            this.moduleScreen.charTyped(codePoint, modifiers);
        }
        return super.charTyped(codePoint, modifiers);
    }

    private void updateCursor(int mouseX, int mouseY) {
        long target = 0L;
        if (this.sidebar.isSearchBarHovered(mouseX, mouseY)) {
            target = 2L;
        } else if (this.sidebar.isInteractableHovered(mouseX, mouseY) || contentHovered(mouseX, mouseY)) {
            target = 1L;
        }
        if (target != this.currentHandledCursor) {
            this.currentHandledCursor = target;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (target == 1L || target == 2L) {
                GLFW.glfwSetCursor(mc.getWindow().getHandle(), this.handCursor);
            } else {
                GLFW.glfwSetCursor(mc.getWindow().getHandle(), 0L);
            }
        }
    }

    private boolean contentHovered(int mouseX, int mouseY) {
        if (isThemesSection()) {
            return this.themesPanel.isSwatchHovered(mouseX, mouseY);
        }
        if (isFriendsSection()) {
            return this.friendsPanel.isHovered(mouseX, mouseY);
        }
        if (isPointsSection()) {
            return this.pointsPanel.isHovered(mouseX, mouseY);
        }
        return this.moduleScreen.isModuleHovered(mouseX, mouseY);
    }

    private boolean isThemesSection() {
        return savedCategory == ModuleCategory.THEMES;
    }

    private boolean isPointsSection() {
        return savedCategory == ModuleCategory.POINTS;
    }

    private boolean isFriendsSection() {
        return savedCategory == ModuleCategory.FRIENDS;
    }

    public void switchCategory(ModuleCategory category) {
        if (savedCategory != category) {
            savedCategory = category;
            this.hoveredModule = null;
            this.contentTime = System.currentTimeMillis(); // каскад карточек заново
            this.moduleScreen.init();
        }
    }

    public void setHoveredModule(ModuleComponent component) {
        this.hoveredModule = component;
    }

    public ModuleComponent getHoveredModule() {
        return this.hoveredModule;
    }

    // ---------------------------------------------------------------- getters
    public float getX() { return x; }
    public float getY() { return y; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    public float getRound() { return round; }
    public float getSidebarWidth() { return sidebarWidth; }
    public float getDefaultSidebarWidth() { return defaultSidebarWidth; }
    public boolean isClosing() { return closing; }
    public Animation getAlphaAnim() { return alpha; }
    public Sidebar getSidebar() { return sidebar; }
    public ModuleScreen getModuleScreen() { return moduleScreen; }
    public ModuleTooltip getTooltip() { return tooltip; }
    public float getAlpha() { return alpha.getValue(); }
    public long getOpenedAt() { return openedAt; }
    public long getContentTime() { return contentTime; }
    public void touchContentTime() { this.contentTime = System.currentTimeMillis(); }

    /** Левая граница области контента (справа от рельса). */
    public float getContentX() { return x + sidebarWidth; }
    /** Ширина области контента. */
    public float getContentWidth() { return width - sidebarWidth; }
    /** Верхняя граница скроллируемого контента (под шапкой секции). */
    public float getContentTop() { return y + CONTENT_TOP_OFFSET; }
    /** Высота скроллируемой области контента. */
    public float getContentHeight() { return height - CONTENT_TOP_OFFSET - CONTENT_BOTTOM_PAD; }

    public static ModuleCategory getSavedCategory() {
        return savedCategory;
    }
}
