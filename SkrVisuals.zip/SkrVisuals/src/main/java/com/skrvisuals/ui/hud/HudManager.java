package com.skrvisuals.ui.hud;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.skrvisuals.modules.impl.Hud;
import com.skrvisuals.modules.impl.MusicPlayer;
import com.skrvisuals.music.MediaTracker;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import org.lwjgl.glfw.GLFW;

/**
 * Holds every HUD element, draws them during gameplay (HudRenderCallback)
 * and again on top of open screens (chat), plus LMB drag handling.
 */
public final class HudManager {
    private static final List<HudElement> ELEMENTS = new ArrayList<>();

    private static HudElement dragging = null;
    private static float grabOffsetX;
    private static float grabOffsetY;
    private static boolean hooksRegistered = false;

    /** Where elements are currently being drawn: gameplay HUD or a screen (chat). */
    private enum DrawSource { GAME, SCREEN }

    private static DrawSource source = DrawSource.GAME;

    private static final Animation watermarkFade = new Animation(Easing.EASE_OUT_CUBIC, 350L);
    private static final Animation targetFade = new Animation(Easing.EASE_OUT_CUBIC, 200L);
    private static final Animation musicFade = new Animation(Easing.EASE_OUT_CUBIC, 350L);

    // ---- Fake FPS (purely visual, .fps command) ----
    private static int fakeFpsValue = 0;
    private static boolean fakeFpsEnabled = false;
    private static int cachedFps = 0;
    private static long lastUpdate = 0;

    /** LMB held state for the chat-screen drag poll. */
    private static boolean mouseWasPressed = false;
    private static boolean rmbWasPressed = false;

    // ---- Fake FPS (purely visual, .fps command) ----

    /**
     * Returns the FPS to display. When fake FPS is enabled via {@link #setFakeFps(int)},
     * returns a fluctuating value around the set target (looks like real FPS).
     * The value updates once per second. Otherwise returns the real client FPS.
     */
    public static int getDisplayFps() {
        if (fakeFpsEnabled && fakeFpsValue > 0) {
            long time = System.currentTimeMillis();
            if (time - lastUpdate >= 1000L) {
                lastUpdate = time;
                // Multiple sine waves для естественных колебаний ±~15%
                float noise = (float) Math.sin(time * 0.002) * 0.10f
                        + (float) Math.sin(time * 0.005) * 0.05f
                        + (float) Math.sin(time * 0.011) * 0.03f;
                cachedFps = Math.max(1, (int) (fakeFpsValue * (1.0f + noise)));
            }
            return cachedFps;
        }
        return MinecraftClient.getInstance().getCurrentFps();
    }

    /** Enable fake FPS display with the given target value. */
    public static void setFakeFps(int value) {
        fakeFpsValue = Math.max(1, value);
        fakeFpsEnabled = true;
        lastUpdate = 0; // принудительно пересчитать на следующем вызове
    }

    /** Disable fake FPS and return to real values. */
    public static void resetFakeFps() {
        fakeFpsEnabled = false;
        fakeFpsValue = 0;
    }

    // ------------------------------------------------------------ settings popup
    private static final Animation settingsAnim = new Animation(Easing.EASE_OUT_CUBIC, 220L);
    /** Element whose settings popup is currently open (chat only), or null. */
    private static HudElement settingsTarget = null;
    private static boolean editingSize = false;
    private static boolean editingOpacity = false;
    private static float popupX, popupY, popupW, popupH;
    /** Slider track rects (x, y, w, h), refreshed every popup frame. */
    private static final float[] SIZE_SLIDER = new float[4];
    private static final float[] OPACITY_SLIDER = new float[4];
    /** Checkbox row rects for the watermark popup (FPS / Ник / Пинг / Время / Роль). */
    private static final int WM_COUNT = 5;
    private static final float[][] WM_ROWS = new float[WM_COUNT][4];
    private static final String[] WM_LABELS = {"FPS", "Ник", "Пинг", "Время", "Роль"};
    private static final float SCALE_MIN = 0.5f;
    private static final float SCALE_MAX = 2f;

    private HudManager() {
    }

    public static void register(HudElement element) {
        ELEMENTS.add(element);
    }

    public static List<HudElement> getElements() {
        return ELEMENTS;
    }

    /** Registers Fabric callbacks once (called lazily from the Hud module). */
    public static void initHooks() {
        if (hooksRegistered) {
            return;
        }
        hooksRegistered = true;
        HudRenderCallback.EVENT.register(HudManager::onHudRender);

        // Register the chat HUD overlay via the official screen API (no mixin).
        // When the chat screen opens, hook its after-render event so the
        // elements stay visible there and can be dragged.
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof ChatScreen) {
                ScreenEvents.afterRender(screen).register((s, context, mx, my, delta) ->
                        HudManager.onScreenRender(context));
            }
        });
    }

    // ---------------------------------------------------------------- state
    private static boolean hudVisible() {
        Hud hud = Hud.getActive();
        return hud != null && hud.isEnabled() && hud.isWatermarkEnabled();
    }

    private static boolean draggingActive() {
        return dragging != null;
    }

    public static void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        source = DrawSource.GAME;
        drawAll(context);
    }

    /**
     * Called from the chat screen's after-render event (fabric-screen-api) so
     * elements stay visible over the chat and can be repositioned there with
     * the mouse. Dragging is polled inside the draw pass, independent of how
     * the screen routes mouse events.
     */
    public static void onScreenRender(DrawContext context) {
        if (!(MinecraftClient.getInstance().currentScreen instanceof ChatScreen)) {
            return;
        }
        source = DrawSource.SCREEN;
        updateDragFromPoll(MinecraftClient.getInstance());
        drawAll(context);
    }

    /**
     * Polls the raw mouse state every frame while a screen is open.
     * This bypasses screen event routing entirely, so dragging always works.
     */
    private static void updateDragFromPoll(MinecraftClient client) {
        long handle = client.getWindow().getHandle();
        double[] xPos = new double[1];
        double[] yPos = new double[1];
        GLFW.glfwGetCursorPos(handle, xPos, yPos);

        // Vanilla-style conversion: GLFW cursor coords are physical pixels,
        // divide by the GUI scale factor to get scaled GUI coords.
        double scale = client.getWindow().getScaleFactor();
        double mx = xPos[0] / scale;
        double my = yPos[0] / scale;

        boolean pressed = GLFW.glfwGetMouseButton(handle,
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        if (pressed && !mouseWasPressed) {
            boolean insidePopup = settingsTarget != null
                    && RenderUtil.hovered((float) mx, (float) my, popupX, popupY, popupW, popupH);
            if (insidePopup) {
                // Click landed on the popup: start editing a slider if hit.
                if (RenderUtil.hovered((float) mx, (float) my, SIZE_SLIDER[0], SIZE_SLIDER[1], SIZE_SLIDER[2], SIZE_SLIDER[3])) {
                    editingSize = true;
                } else if (RenderUtil.hovered((float) mx, (float) my, OPACITY_SLIDER[0], OPACITY_SLIDER[1],
                        OPACITY_SLIDER[2], OPACITY_SLIDER[3])) {
                    editingOpacity = true;
                } else if (settingsTarget.id.equals("watermark")) {
                    // Watermark sub-toggles: click flips the matching flag.
                    Hud hud = Hud.getActive();
                    for (int i = 0; i < WM_COUNT; i++) {
                        if (RenderUtil.hovered((float) mx, (float) my,
                                WM_ROWS[i][0], WM_ROWS[i][1], WM_ROWS[i][2], WM_ROWS[i][3])) {
                            switch (i) {
                                case 0 -> hud.toggleWatermarkFps();
                                case 1 -> hud.toggleWatermarkNick();
                                case 2 -> hud.toggleWatermarkPing();
                                case 3 -> hud.toggleWatermarkTime();
                                case 4 -> hud.toggleWatermarkRole();
                            }
                            break;
                        }
                    }
                }
            } else {
                if (settingsTarget != null) {
                    closeSettings();
                }
                HudElement hit = elementAt(mx, my);
                if (hit != null) {
                    if (hit.id.equals("musicplayer") && tryMusicButtonClick(hit, mx, my)) {
                        // Клик по кнопке плеера — не начинаем перетаскивание.
                    } else {
                        dragging = hit;
                        grabOffsetX = (float) (mx - hit.x);
                        grabOffsetY = (float) (my - hit.y);
                    }
                }
            }
        }
        // Live slider updates while the button is held.
        if (pressed && editingSize && settingsTarget != null) {
            settingsTarget.scale = sliderValue(SIZE_SLIDER, mx, SCALE_MIN, SCALE_MAX);
        }
        if (pressed && editingOpacity && settingsTarget != null) {
            settingsTarget.opacity = sliderValue(OPACITY_SLIDER, mx, 0f, 1f);
        }
        if (!pressed) {
            dragging = null;
            editingSize = false;
            editingOpacity = false;
        }
        if (dragging != null && pressed && source == DrawSource.SCREEN) {
            float scaledW = client.getWindow().getScaledWidth();
            float scaledH = client.getWindow().getScaledHeight();
            dragging.x = MathHelper.clamp((float) mx - grabOffsetX,
                    0f, Math.max(0f, scaledW - dragging.width));
            dragging.y = MathHelper.clamp((float) my - grabOffsetY,
                    0f, Math.max(0f, scaledH - dragging.height));
        }

        // RMB over an element toggles its settings popup.
        boolean rmb = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (rmb && !rmbWasPressed) {
            HudElement hit = elementAt(mx, my);
            if (hit != null) {
                if (settingsTarget == hit) {
                    closeSettings();
                } else {
                    openSettings(hit);
                }
            } else {
                closeSettings();
            }
        }
        rmbWasPressed = rmb;

        mouseWasPressed = pressed;
    }

    /** Topmost element under the mouse, or null. */
    private static HudElement elementAt(double mx, double my) {
        for (int i = ELEMENTS.size() - 1; i >= 0; i--) {
            HudElement element = ELEMENTS.get(i);
            if (element.contains(mx, my)) {
                return element;
            }
        }
        return null;
    }

    private static void openSettings(HudElement element) {
        settingsTarget = element;
        editingSize = false;
        editingOpacity = false;
        settingsAnim.setValue(0f);
    }

    private static void closeSettings() {
        settingsTarget = null;
        editingSize = false;
        editingOpacity = false;
    }

    /** Maps a slider mouse x to a value in [min, max]. */
    private static float sliderValue(float[] rect, double mx, float min, float max) {
        float t = MathHelper.clamp((float) ((mx - rect[0]) / Math.max(1f, rect[2])), 0f, 1f);
        return min + (max - min) * t;
    }

    private static void drawAll(DrawContext context) {
        Hud hud = Hud.getActive();
        if (hud == null || !hud.isEnabled()) {
            return;
        }
        for (HudElement element : ELEMENTS) {
            switch (element.id) {
                case "watermark" -> {
                    if (hud.isWatermarkEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "musicplayer" -> {
                    MusicPlayer mp = MusicPlayer.getActive();
                    if (mp != null && mp.isEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "targethud" -> {
                    if (hud.isTargetHudEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "potions" -> {
                    if (hud.isPotionsEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "keystrokes" -> {
                    if (hud.isKeystrokesEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "armorhud" -> {
                    if (hud.isArmorHudEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "coordinates" -> {
                    if (hud.isCoordinatesEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "notifications" -> {
                    if (hud.isNotificationsEnabled()) {
                        renderElement(context, element);
                    }
                }
                case "inventory" -> {
                    if (hud.isInventoryEnabled()) {
                        renderElement(context, element);
                    }
                }
                default -> renderElement(context, element);
            }
        }

        // Settings popup floats above everything (chat only).
        if (source == DrawSource.SCREEN && settingsTarget != null) {
            renderSettingsPopup(context);
        }
    }

    // ---------------------------------------------------- settings popup
    /**
     * Small panel below the element with Size and Opacity sliders.
     * Slides in from the top (top-down) with an eased animation.
     */
    private static void renderSettingsPopup(DrawContext context) {
        HudElement element = settingsTarget;
        if (element == null) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        settingsAnim.run(1f);
        float a = MathHelper.clamp(settingsAnim.getValue(), 0f, 1f);
        if (a <= 0.02f) {
            return;
        }

        float pad = 5f;
        int labelH = 9;
        int trackH = 8;
        popupW = 100;
        popupH = pad + labelH + 5
                + (labelH + 2 + trackH) + 6
                + (labelH + 2 + trackH) + pad;
        boolean wmPopup = element.id.equals("watermark");
        if (wmPopup) {
            popupH += WM_COUNT * (labelH + 4) + 2;
        }

        float screenW = client.getWindow().getScaledWidth();
        float screenH = client.getWindow().getScaledHeight();
        popupX = MathHelper.clamp(element.x, 0f, Math.max(0f, screenW - popupW));
        popupY = element.y + element.height * element.scale + 4f;
        popupY = MathHelper.clamp(popupY, 0f, Math.max(0f, screenH - popupH));

        // Top-down slide: starts above its final spot and drops into place.
        float slide = (popupH + 8f) * (1f - a);

        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(0f, slide, 0f);

        HudStyle.island(context, popupX, popupY, popupW, popupH, HudStyle.RADIUS, a);

        float cx = popupX + pad;
        float y = popupY + pad;
        drawText(context, "Настройки", cx, y, RenderUtil.withAlpha(Colors.clientColor(), a));
        y += labelH + 4;
        HudStyle.separator(context, cx, y - 2, popupX + popupW - pad - cx, a);
        y += 3;

        // Size row
        drawText(context, "Размер", cx, y, RenderUtil.withAlpha(Colors.textPrimary(), a));
        String sizeVal = String.format("x%.2f", element.scale);
        drawText(context, sizeVal, popupX + popupW - pad - textWidth(sizeVal), y,
                RenderUtil.withAlpha(Colors.textDescription(), a));
        y += labelH + 2;
        SIZE_SLIDER[0] = cx;
        SIZE_SLIDER[1] = y;
        SIZE_SLIDER[2] = popupW - pad * 2;
        SIZE_SLIDER[3] = trackH;
        drawSlider(context, SIZE_SLIDER, (element.scale - SCALE_MIN) / (SCALE_MAX - SCALE_MIN), a);
        y += trackH + 6;

        // Opacity row
        drawText(context, "Прозрачность", cx, y, RenderUtil.withAlpha(Colors.textPrimary(), a));
        String opVal = Math.round(MathHelper.clamp(element.opacity, 0f, 1f) * 100f) + "%";
        drawText(context, opVal, popupX + popupW - pad - textWidth(opVal), y,
                RenderUtil.withAlpha(Colors.textDescription(), a));
        y += labelH + 2;
        OPACITY_SLIDER[0] = cx;
        OPACITY_SLIDER[1] = y;
        OPACITY_SLIDER[2] = popupW - pad * 2;
        OPACITY_SLIDER[3] = trackH;
        drawSlider(context, OPACITY_SLIDER, element.opacity, a);

        // Watermark sub-toggles (checkbox rows).
        if (wmPopup) {
            Hud hud = Hud.getActive();
            boolean[] vals = {
                    hud.isWatermarkFpsEnabled(),
                    hud.isWatermarkNickEnabled(),
                    hud.isWatermarkPingEnabled(),
                    hud.isWatermarkTimeEnabled(),
                    hud.isWatermarkRoleEnabled()
            };
            y += trackH + 4;
            float boxS = 7f;
            for (int i = 0; i < WM_COUNT; i++) {
                WM_ROWS[i][0] = cx;
                WM_ROWS[i][1] = y + 1;
                WM_ROWS[i][2] = boxS;
                WM_ROWS[i][3] = boxS;
                RenderUtil.roundedRect(context, cx, y + 1, boxS, boxS, 2f,
                        RenderUtil.withAlpha(vals[i] ? Colors.clientColor() : Colors.toggleOff(), a));
                drawText(context, WM_LABELS[i], cx + boxS + 4, y,
                        RenderUtil.withAlpha(vals[i] ? Colors.textPrimary() : Colors.textDescription(), a));
                y += labelH + 4;
            }
        }

        matrices.pop();
    }

    /** Background track + accent fill for the given [x, y, w, h] slider rect. */
    private static void drawSlider(DrawContext context, float[] rect, float value, float a) {
        RenderUtil.roundedRect(context, rect[0], rect[1], rect[2], rect[3], 3f,
                RenderUtil.withAlpha(Colors.toggleOff(), a));
        float fill = rect[2] * MathHelper.clamp(value, 0f, 1f);
        if (fill >= 1f) {
            RenderUtil.roundedRect(context, rect[0], rect[1], fill, rect[3], 3f,
                    RenderUtil.withAlpha(Colors.clientColor(), a));
        }
    }

    // ---------------------------------------------------------------- input
    private static boolean moduleOn() {
        Hud hud = Hud.getActive();
        return hud != null && hud.isEnabled();
    }

    public static boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!moduleOn() || button != 0) {
            return false;
        }
        for (int i = ELEMENTS.size() - 1; i >= 0; i--) {
            HudElement element = ELEMENTS.get(i);
            if (element.contains(mouseX, mouseY)) {
                dragging = element;
                grabOffsetX = (float) (mouseX - element.x);
                grabOffsetY = (float) (mouseY - element.y);
                return true;
            }
        }
        return false;
    }

    public static boolean mouseDragged(double mouseX, double mouseY, int button) {
        if (dragging == null || button != 0) {
            return false;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        float scaledW = client.getWindow().getScaledWidth();
        float scaledH = client.getWindow().getScaledHeight();

        float newX = Math.max(0f, Math.min(scaledW - dragging.width, (float) mouseX - grabOffsetX));
        float newY = Math.max(0f, Math.min(scaledH - dragging.height, (float) mouseY - grabOffsetY));
        dragging.x = newX;
        dragging.y = newY;
        return true;
    }

    public static void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
    }

    // ------------------------------------------------------------ music player
    /** Текстура текущей обложки и версия, под которую она загружена. */
    private static Identifier coverTexture = null;
    private static long loadedCoverVersion = -1L;
    private static final int MUSIC_COVER = 28;

    /** Обложку перезагружаем только когда MediaTracker сообщил о новой. */
    private static void updateCoverTexture() {
        long version = MediaTracker.getCoverVersion();
        if (version == loadedCoverVersion) {
            return;
        }
        loadedCoverVersion = version;
        String path = MediaTracker.getCoverPath();
        if (path == null || path.isEmpty()) {
            coverTexture = null;
            return;
        }
        try (java.io.InputStream in = new java.io.FileInputStream(path)) {
            NativeImage image = NativeImage.read(in);
            Identifier id = Identifier.of("skrvisuals", "music_cover");
            MinecraftClient.getInstance().getTextureManager()
                    .registerTexture(id, new NativeImageBackedTexture(image));
            coverTexture = id;
        } catch (Exception e) {
            coverTexture = null;
        }
    }

    /** Обрезает строку под максимальную ширину, добавляя «…». */
    private static String ellipsize(String s, TextRenderer font, float maxW) {
        if (s == null || s.isEmpty() || font.getWidth(s) <= maxW) {
            return s == null ? "" : s;
        }
        while (s.length() > 1 && font.getWidth(s + "…") > maxW) {
            s = s.substring(0, s.length() - 1);
        }
        return s + "…";
    }

    public static void renderMusicPlayer(DrawContext context, HudElement element) {
        MusicPlayer module = MusicPlayer.getActive();
        boolean visible = module != null && module.isEnabled();
        musicFade.run(visible ? 1f : 0f);
        float fade = musicFade.getValue();
        if (fade <= 0.02f) {
            return;
        }

        updateCoverTexture();

        boolean hasTrack = MediaTracker.isAvailable() && MediaTracker.hasRecentTrack();
        String title = hasTrack ? MediaTracker.getTitle() : "Нет активного трека";
        String artist = hasTrack ? MediaTracker.getArtist() : "";

        TextRenderer font = Fonts.get();
        int pad = 6;
        int gap = 8;
        int textX = pad + MUSIC_COVER + gap;
        int maxTextW = 150;
        int minTextW = 120;
        int wTitle = font.getWidth(title);
        int wArtist = artist.isEmpty() ? 0 : font.getWidth(artist);
        int textW = Math.min(maxTextW, Math.max(minTextW, Math.max(wTitle, wArtist)));

        element.width = textX + textW + pad;
        element.height = MUSIC_COVER + pad * 2 + 12; // + строка прогресса

        float px = element.x;
        float py = element.y;

        // Панель в стиле остального HUD.
        HudStyle.island(context, px, py, element.width, element.height, HudStyle.RADIUS, fade);

        // Обложка.
        float cx = px + pad;
        float cy = py + pad;
        if (coverTexture != null && hasTrack) {
            RenderUtil.roundedTexture(context, coverTexture, cx, cy, MUSIC_COVER, MUSIC_COVER, 4f,
                    0f, 0f, 1f, 1f, RenderUtil.multiplyAlpha(0xFFFFFFFF, fade));
            RenderUtil.roundedOutline(context, cx, cy, MUSIC_COVER, MUSIC_COVER, 4f, 0.8f,
                    RenderUtil.withAlpha(Colors.guiBorder(), 0.8f * fade));
        } else {
            RenderUtil.roundedRect(context, cx, cy, MUSIC_COVER, MUSIC_COVER, 4f,
                    RenderUtil.withAlpha(Colors.clientColor(), 0.25f * fade));
            HudStyle.equalizer(context,
                    cx + MUSIC_COVER / 2f - HudStyle.equalizerWidth() / 2f,
                    cy + MUSIC_COVER / 2f, hasTrack, fade);
        }

        // Текст: название + артист (справа на строке артиста — время).
        float tx = px + textX;
        float titleY = py + pad + 2f;
        drawText(context, ellipsize(title, font, textW), tx, titleY,
                hasTrack ? Colors.textPrimary() : Colors.textDescription());
        if (hasTrack && !artist.isEmpty()) {
            String time = formatTime(MediaTracker.getElapsedSeconds())
                    + " / " + formatTime(MediaTracker.getDurationSeconds());
            int timeW = font.getWidth(time);
            drawText(context, ellipsize(artist, font, textW - timeW - 8), tx, titleY + 11f,
                    Colors.textDescription());
            drawText(context, time, tx + textW - timeW, titleY + 11f,
                    Colors.textDescription());
        }

        // Прогрессбар + кнопки управления (prev / toggle / next).
        float barY = py + pad + MUSIC_COVER + 3f;
        int btnW = 9;
        int btnGap = 4;
        float buttonsX = px + textX + textW - (btnW * 3 + btnGap * 2);
        float barW = buttonsX - tx - 7f;
        double elapsed = hasTrack ? MediaTracker.getElapsedSeconds() : 0d;
        double duration = hasTrack ? MediaTracker.getDurationSeconds() : 0d;
        float progress = duration > 0 ? (float) MathHelper.clamp(elapsed / duration, 0d, 1d) : 0f;

        RenderUtil.roundedRect(context, tx, barY, barW, 3f, 1.5f,
                RenderUtil.withAlpha(Colors.textPrimary(), 0.25f * fade));
        if (progress > 0f) {
            RenderUtil.roundedRect(context, tx, barY, Math.max(1.5f, barW * progress), 3f, 1.5f,
                    RenderUtil.withAlpha(Colors.clientColor(), fade));
        }

        boolean playing = hasTrack && MediaTracker.isPlaying();
        int iconColor = RenderUtil.withAlpha(Colors.textPrimary(), fade);
        drawPrevIcon(context, buttonsX, barY - 3f, btnW, iconColor);
        if (playing) {
            drawPauseIcon(context, buttonsX + btnW + btnGap, barY - 3f, btnW, iconColor);
        } else {
            drawPlayIcon(context, buttonsX + btnW + btnGap, barY - 3f, btnW, iconColor);
        }
        drawNextIcon(context, buttonsX + (btnW + btnGap) * 2, barY - 3f, btnW, iconColor);

        // Хитбоксы кнопок (в локальных координатах элемента, с запасом на скейл).
        float ly = barY - 4f - py;
        for (int i = 0; i < 3; i++) {
            MUSIC_BUTTONS[i][0] = buttonsX + i * (btnW + btnGap) - px - 1f;
            MUSIC_BUTTONS[i][1] = ly;
            MUSIC_BUTTONS[i][2] = btnW + 2f;
            MUSIC_BUTTONS[i][3] = btnW + 4f;
        }
    }

    /** Хитбоксы кнопок Music Player (prev / toggle / next) в координатах элемента. */
    private static final float[][] MUSIC_BUTTONS = new float[3][4];

    /** true — клик попал по кнопке плеера, команда отправлена (перетаскивание не начинать). */
    private static boolean tryMusicButtonClick(HudElement element, double mx, double my) {
        if (!MediaTracker.isAvailable()) {
            return false;
        }
        float scale = Math.max(0.01f, element.scale);
        float lx = (float) ((mx - element.x) / scale);
        float ly = (float) ((my - element.y) / scale);
        for (int i = 0; i < MUSIC_BUTTONS.length; i++) {
            if (RenderUtil.hovered(lx, ly, MUSIC_BUTTONS[i][0], MUSIC_BUTTONS[i][1],
                    MUSIC_BUTTONS[i][2], MUSIC_BUTTONS[i][3])) {
                MediaTracker.sendCommand(switch (i) {
                    case 0 -> "prev";
                    case 1 -> "toggle";
                    default -> "next";
                });
                return true;
            }
        }
        return false;
    }

    private static String formatTime(double seconds) {
        if (seconds <= 0) {
            return "0:00";
        }
        return (int) seconds / 60 + ":" + String.format("%02d", (int) seconds % 60);
    }

    private static void drawPlayIcon(DrawContext ctx, float x, float y, int s, int color) {
        RenderUtil.fillQuad(ctx, x + 2f, y, x + 2f, y + s, x + s, y + s / 2f, x + 2f, y + s / 2f, color);
        RenderUtil.fillQuad(ctx, x + 2f, y, x + s, y + s / 2f, x + s, y + s / 2f, x + 2f, y + s, color);
    }

    private static void drawPauseIcon(DrawContext ctx, float x, float y, int s, int color) {
        RenderUtil.fill(ctx, x + 1.5f, y, 2.5f, s, color);
        RenderUtil.fill(ctx, x + s - 4f, y, 2.5f, s, color);
    }

    private static void drawPrevIcon(DrawContext ctx, float x, float y, int s, int color) {
        RenderUtil.fill(ctx, x + 1f, y, 1.5f, s, color);
        RenderUtil.fillQuad(ctx, x + s - 1.5f, y, x + 3.5f, y + s / 2f, x + 3.5f, y + s / 2f,
                x + s - 1.5f, y + s, color);
    }

    private static void drawNextIcon(DrawContext ctx, float x, float y, int s, int color) {
        RenderUtil.fillQuad(ctx, x + 1.5f, y, x + s - 3.5f, y + s / 2f, x + s - 3.5f, y + s / 2f,
                x + 1.5f, y + s, color);
        RenderUtil.fill(ctx, x + s - 2.5f, y, 1.5f, s, color);
    }

    // ------------------------------------------------------------ watermark
    private static final float TARGET_TEXT_HEIGHT = 10f;

    /** Width of {@code s} rendered with the vanilla GUI text renderer (scaled px). */
    private static int textWidth(String s) {
        return Fonts.width(s);
    }

    /** Draws {@code s} at top-left (x, y) with the vanilla TextRenderer. */
    private static void drawText(DrawContext ctx, String s, float x, float y, int color) {
        ctx.drawText(Fonts.get(), s, (int) x, (int) y,
                RenderUtil.multiplyAlpha(color, RenderUtil.hudOpacity), true);
    }

    // Content state of the watermark island.
    private enum WmState {
        NORMAL,
        NOTIFICATION
    }

    private static final float WM_RADIUS = HudStyle.PILL;
    private static final float WM_HEIGHT = 20f;
    private static final float WM_HEIGHT_NOTIFY = 24f;
    private static final float WM_PAD = 9f;
    private static final float WM_HEAD = 14f;
    private static final float WM_SECTION_GAP = 4.5f;
    private static final float WM_DOT = 2f;
    private static final long WM_TRANSITION_MS = 260L;
    private static final float MARQUEE_SPEED = 0.06f;

    private static WmState wmState = WmState.NORMAL;
    private static WmState wmPrevState = WmState.NORMAL;
    private static long wmTransitionStart = 0L;
    private static String wmNotifyText = "";
    private static boolean wmNotifyPositive = true;
    private static long wmNotifyUntil = 0L;
    private static long wmMarqueeStart = 0L;
    private static Identifier wmSkinTexture = null;

    private static final Animation wmWidthAnim = new Animation(Easing.EASE_OUT_CUBIC, 220L);
    private static final Animation wmHeightAnim = new Animation(Easing.EASE_OUT_CUBIC, 220L);

    /**
     * Watermark: a "dynamic island" pill in the corner of the screen.
     *
     * <p>Two content states share one animated shell: NORMAL (avatar + nick +
     * metrics) and NOTIFICATION (module toggles, see {@link #pushNotification}).
     * Width/height tween between states and the content slides in, clipped to
     * the pill. The music player lives in its own HUD element.
     */
    public static void renderWatermark(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        Hud hud = Hud.getActive();

        boolean visible = moduleOn() && hud.isWatermarkEnabled();
        watermarkFade.run(visible ? 1f : 0f);
        float fade = watermarkFade.getValue();
        if (fade <= 0.02f) {
            return;
        }

        long now = System.currentTimeMillis();
        WmState next = now < wmNotifyUntil ? WmState.NOTIFICATION : WmState.NORMAL;
        if (next != wmState) {
            wmPrevState = wmState;
            wmState = next;
            wmTransitionStart = now;
            if (next == WmState.NOTIFICATION) {
                wmMarqueeStart = now;
            }
        }

        float targetW = wmTargetWidth(next);
        float targetH = wmTargetHeight(next);
        wmWidthAnim.run(targetW);
        wmHeightAnim.run(targetH);
        float w = wmWidthAnim.getValue();
        float h = wmHeightAnim.getValue();

        // The drag hit-box follows the *target* size so it never jitters mid-tween.
        element.width = Math.round(targetW);
        element.height = Math.round(targetH);

        float x = element.x;
        float y = element.y;
        float r = Math.min(WM_RADIUS, h / 2f);

        HudStyle.island(context, x, y, w, h, r, fade);

        // Content slide: the old state leaves to the left, the new one enters.
        float progress = MathHelper.clamp(
                (now - wmTransitionStart) / (float) WM_TRANSITION_MS, 0f, 1f);
        float slide = 1f - (float) Math.pow(1f - progress, 3f);
        boolean animating = progress < 1f && wmPrevState != wmState;

        RenderUtil.pushScissor(context, x, y, w, h);
        if (animating) {
            wmDrawState(context, wmPrevState, x - w * slide, y, w, h, fade, now);
            wmDrawState(context, wmState, x + w * (1f - slide), y, w, h, fade, now);
        } else {
            wmDrawState(context, wmState, x, y, w, h, fade, now);
        }
        RenderUtil.popScissor();
    }

    private static void wmDrawState(DrawContext ctx, WmState state, float x, float y,
            float w, float h, float alpha, long now) {
        switch (state) {
            case NOTIFICATION -> wmDrawNotification(ctx, x, y, w, h, alpha, now);
            case NORMAL -> wmDrawNormal(ctx, x, y, w, h, alpha);
        }
    }

    // ---------------------------------------------------- watermark: rendering

    /**
     * Renders one element with its personal scale (matrix transform anchored at
     * the element's top-left) and opacity (global multiplier for withAlpha/text).
     */
    private static void renderElement(DrawContext context, HudElement element) {
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        float s = element.scale;
        if (Math.abs(s - 1f) > 0.001f) {
            matrices.translate(element.x, element.y, 0f);
            matrices.scale(s, s, 1f);
            matrices.translate(-element.x, -element.y, 0f);
        }
        RenderUtil.hudOpacity = MathHelper.clamp(element.opacity, 0f, 1f);
        element.render(context);
        RenderUtil.hudOpacity = 1f;
        matrices.pop();
    }

    // ------------------------------------------------------- watermark: normal

    private static void wmDrawNormal(DrawContext ctx, float x, float y, float w, float h, float alpha) {
        MinecraftClient client = MinecraftClient.getInstance();
        Hud hud = Hud.getActive();

        float textY = y + (h - TARGET_TEXT_HEIGHT) / 2f;
        float cx = x + WM_PAD;

        // Avatar (falls back to an accent tile before the skin is known).
        float headY = y + (h - WM_HEAD) / 2f;
        wmDrawHead(ctx, cx, headY, alpha);
        cx += WM_HEAD + 4f;

        // Nick.
        if (hud.isWatermarkNickEnabled()) {
            String nick = client.getSession().getUsername();
            drawText(ctx, nick, cx, textY, RenderUtil.withAlpha(Colors.textPrimary(), alpha));
            cx += textWidth(nick) + WM_SECTION_GAP + WM_DOT;
        }

        // FPS.
        if (hud.isWatermarkFpsEnabled()) {
            int fps = getDisplayFps();
            int fpsColor = fps >= 60 ? Colors.textPrimary() : fps >= 30 ? 0xFFEDBA49 : 0xFFE85D5D;
            cx = wmMetric(ctx, cx, textY, fps + "", "fps", fpsColor, alpha);
        }

        // Ping.
        if (hud.isWatermarkPingEnabled()) {
            cx += WM_SECTION_GAP;
            HudStyle.dot(ctx, cx, y + h / 2f, alpha);
            cx += WM_DOT + WM_SECTION_GAP;
            int p = ping(client);
            int pingColor = p < 0 ? Colors.textPrimary() : p <= 80 ? Colors.textPrimary()
                    : p <= 200 ? 0xFFEDBA49 : 0xFFE85D5D;
            cx = wmMetric(ctx, cx, textY, p < 0 ? "--" : String.valueOf(p), "ms", pingColor, alpha);
        }

        // Time.
        if (hud.isWatermarkTimeEnabled()) {
            cx += WM_SECTION_GAP;
            HudStyle.dot(ctx, cx, y + h / 2f, alpha);
            cx += WM_DOT + WM_SECTION_GAP;
            cx = wmMetric(ctx, cx, textY, time(), "", Colors.textDescription(), alpha);
        }

        // Role badge (Developer / Tester / Media / Player), right-aligned.
        if (hud.isWatermarkRoleEnabled()) {
            String role = com.skrvisuals.util.ClientRole.get();
            float badgeW = textWidth(role) + 9f;
            float badgeH = 12f;
            float bx = x + w - WM_PAD - badgeW;
            float by = y + (h - badgeH) / 2f;
            RenderUtil.roundedRect(ctx, bx, by, badgeW, badgeH, badgeH / 2f,
                    RenderUtil.withAlpha(Colors.clientColor(), 0.18f * alpha));
            RenderUtil.roundedOutline(ctx, bx, by, badgeW, badgeH, badgeH / 2f, 0.8f,
                    RenderUtil.withAlpha(Colors.clientColor(), 0.45f * alpha));
            drawText(ctx, role, bx + 4.5f, by + (badgeH - TARGET_TEXT_HEIGHT) / 2f,
                    RenderUtil.withAlpha(Colors.lighten(Colors.clientColor(), 0.35f), alpha));
        }
    }

    /** One "value + dim unit" metric; returns the x right after it. */
    private static float wmMetric(DrawContext ctx, float x, float textY,
            String value, String unit, int valueColor, float alpha) {
        drawText(ctx, value, x, textY, RenderUtil.withAlpha(valueColor, alpha));
        x += textWidth(value);
        if (!unit.isEmpty()) {
            drawText(ctx, unit, x, textY, RenderUtil.withAlpha(Colors.textDescription(), 0.85f * alpha));
            x += textWidth(unit);
        }
        return x;
    }

    /** Rounded player head from the skin texture (falls back to an accent tile). */
    private static void wmDrawHead(DrawContext ctx, float x, float y, float alpha) {
        Identifier skin = wmSkinTexture();
        RenderUtil.roundedRect(ctx, x - 0.8f, y - 0.8f, WM_HEAD + 1.6f, WM_HEAD + 1.6f, 5f,
                RenderUtil.withAlpha(0xFF1B1E28, 0.95f * alpha));
        if (skin != null) {
            // Face region of the 64x64 skin layout.
            RenderUtil.roundedTexture(ctx, skin, x, y, WM_HEAD, WM_HEAD, 4f,
                    8f / 64f, 8f / 64f, 16f / 64f, 16f / 64f,
                    RenderUtil.withAlpha(0xFFFFFFFF, alpha));
        } else {
            RenderUtil.roundedRect(ctx, x, y, WM_HEAD, WM_HEAD, 4f,
                    RenderUtil.withAlpha(Colors.clientColor(), 0.55f * alpha));
        }
        RenderUtil.roundedOutline(ctx, x, y, WM_HEAD, WM_HEAD, 4f, 0.8f,
                RenderUtil.withAlpha(Colors.guiBorder(), 0.7f * alpha));
    }

    /** Cached skin texture of the local player. */
    private static Identifier wmSkinTexture() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return null;
        }
        if (client.getNetworkHandler() != null) {
            var entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null && entry.getSkinTextures() != null
                    && entry.getSkinTextures().texture() != null) {
                wmSkinTexture = entry.getSkinTextures().texture();
                return wmSkinTexture;
            }
        }
        if (client.player.getSkinTextures() != null && client.player.getSkinTextures().texture() != null) {
            wmSkinTexture = client.player.getSkinTextures().texture();
        }
        return wmSkinTexture;
    }

    // --------------------------------------------------- watermark: notification

    private static void wmDrawNotification(DrawContext ctx, float x, float y, float w, float h,
            float alpha, long now) {
        int statusColor = wmNotifyPositive ? Colors.clientColor() : 0xFFFF5262;
        float dotSize = 5f;
        float dotX = x + WM_PAD + 1f;
        float dotY = y + (h - dotSize) / 2f;
        RenderUtil.roundedRect(ctx, dotX, dotY, dotSize, dotSize, dotSize / 2f,
                RenderUtil.withAlpha(statusColor, alpha));
        RenderUtil.circleOutline(ctx, dotX + dotSize / 2f, dotY + dotSize / 2f,
                dotSize / 2f + 1.8f, 0.8f, RenderUtil.withAlpha(statusColor, 0.3f * alpha));

        float clipX = x + WM_PAD + dotSize + 8f;
        float clipW = w - (clipX - x) - WM_PAD;
        wmMarquee(ctx, wmNotifyText, clipX, y + (h - TARGET_TEXT_HEIGHT) / 2f, clipW,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha), now - wmMarqueeStart);
    }

    /** Scrolls {@code text} horizontally inside a clipped slot when it does not fit. */
    private static void wmMarquee(DrawContext ctx, String text, float x, float y, float maxW,
            int color, long elapsedMs) {
        if (text == null || text.isEmpty() || maxW <= 4f) {
            return;
        }
        int tw = Fonts.width(text);
        RenderUtil.pushScissor(ctx, x, y - 2f, maxW, TARGET_TEXT_HEIGHT + 4f);
        if (tw <= maxW) {
            drawText(ctx, text, x, y, color);
        } else {
            float offset = (elapsedMs * MARQUEE_SPEED) % (tw + 26f);
            drawText(ctx, text, x - offset, y, color);
            drawText(ctx, text, x - offset + tw + 26f, y, color);
        }
        RenderUtil.popScissor();
    }

    // ----------------------------------------------- watermark: state measuring

    private static float wmTargetHeight(WmState state) {
        return switch (state) {
            case NORMAL -> WM_HEIGHT;
            case NOTIFICATION -> WM_HEIGHT_NOTIFY;
        };
    }

    private static float wmTargetWidth(WmState state) {
        MinecraftClient client = MinecraftClient.getInstance();
        Hud hud = Hud.getActive();
        return switch (state) {
            case NORMAL -> {
                float w = WM_PAD * 2f + WM_HEAD + 4f;
                if (hud != null && hud.isWatermarkNickEnabled()) {
                    w += textWidth(client.getSession().getUsername()) + WM_SECTION_GAP + WM_DOT;
                }
                if (hud != null && hud.isWatermarkFpsEnabled()) {
                    w += textWidth(getDisplayFps() + "") + textWidth("fps");
                }
                if (hud != null && hud.isWatermarkPingEnabled()) {
                    int p = ping(client);
                    w += WM_SECTION_GAP + WM_DOT + WM_SECTION_GAP
                            + textWidth(p < 0 ? "--" : String.valueOf(p)) + textWidth("ms");
                }
                if (hud != null && hud.isWatermarkTimeEnabled()) {
                    w += WM_SECTION_GAP + WM_DOT + WM_SECTION_GAP + textWidth(time());
                }
                if (hud != null && hud.isWatermarkRoleEnabled()) {
                    w += WM_SECTION_GAP + textWidth(com.skrvisuals.util.ClientRole.get()) + 9f;
                }
                yield w;
            }
            case NOTIFICATION -> Math.max(150f,
                    WM_PAD * 2f + 5f + 8f + Fonts.width(wmNotifyText) + 6f);
        };
    }

    /** Local player latency in ms, or -1 when unknown (main menu / no server). */
    private static int ping(MinecraftClient client) {
        if (client.getNetworkHandler() == null || client.player == null) {
            return -1;
        }
        var entry = client.getNetworkHandler()
                .getPlayerListEntry(client.player.getUuid());
        return entry != null ? Math.max(0, entry.getLatency()) : -1;
    }

    /** Current local time as HH:mm. */
    private static String time() {
        return java.time.LocalTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
    }

    // ------------------------------------------------------------ coordinates
    /**
     * Coordinates HUD: X/Y/Z Координаты, а также эффекты (Potions).
     * Фон + цвет текста.
     */
    public static void renderCoordinates(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean preview = client.player == null && source == DrawSource.SCREEN;
        if (client.player == null && !preview) {
            return;
        }

        double x = preview ? 123.45D : client.player.getX();
        double y = preview ? 64.0D : client.player.getY();
        double z = preview ? -567.89D : client.player.getZ();

        String title = " Координаты";
        String[] labels = {
                String.format(" X: %.1f", x),
                String.format(" Y: %.1f", y),
                String.format(" Z: %.1f", z)
        };

        TextRenderer font = Fonts.get();
        int titleW = font.getWidth(title);
        int bodyW = 0;
        for (String label : labels) {
            bodyW = Math.max(bodyW, font.getWidth(label));
        }
        int width = Math.max(titleW, bodyW) + 8;
        int rowH = 10;
        int padTop = 6;
        int titleGap = 5;
        int padBottom = 6;
        element.width = width;
        element.height = padTop + 6 + titleGap + labels.length * rowH + padBottom;

        int px = (int) element.x;
        int py = (int) element.y;
        int contentX = px + 4;

        HudStyle.island(context, px, py, width, element.height, HudStyle.RADIUS, element.opacity);

        drawText(context, title, contentX, py + padTop, Colors.textPrimary());

        float sepY = py + padTop + 6 + titleGap - 2;
        HudStyle.separator(context, contentX, sepY, width - 8, element.opacity);

        int ry = py + padTop + 6 + titleGap;
        for (String label : labels) {
            drawText(context, label, contentX, ry, Colors.textDescription());
            ry += rowH;
        }
    }

    // ------------------------------------------------------------ target hud
    /** Сколько TargetHUD остаётся на экране после потери цели (мс). */
    private static final long TARGET_LINGER_MS = 3000L;
    private static PlayerEntity lastTargetShown = null;
    private static long lastTargetSeen = 0L;

    public static void renderTargetHud(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        PlayerEntity shown = null;
        if (source == DrawSource.SCREEN) {
            // Chat screen: preview with your own data so it can be positioned.
            shown = client.player;
        } else if (client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof PlayerEntity p
                && !p.isSpectator()
                && p.squaredDistanceTo(client.player) <= 64.0D) {
            shown = p;
            lastTargetShown = p;
            lastTargetSeen = System.currentTimeMillis();
        }

        // Linger: keep showing the last aimed-at player for 3 seconds after
        // losing sight (like TargetESP), then let it fade out.
        if (shown == null && lastTargetShown != null) {
            long since = System.currentTimeMillis() - lastTargetSeen;
            if (since <= TARGET_LINGER_MS && !lastTargetShown.isRemoved()
                    && lastTargetShown.deathTime <= 0
                    && lastTargetShown.squaredDistanceTo(client.player) <= 4096.0D) {
                shown = lastTargetShown;
            } else {
                lastTargetShown = null;
            }
        }

        boolean visible = shown != null;
        targetFade.run(visible ? 1f : 0f);
        float fade = targetFade.getValue();
        if (!visible && fade <= 0.02f) {
            return;
        }
        if (shown == null) {
            shown = client.player; // keep layout stable while fading out
        }

        String nick = shown.getGameProfile().getName();
        float maxHp = Math.max(1f, shown.getMaxHealth());
        float hp = MathHelper.clamp(shown.getHealth(), 0f, maxHp);
        float hpRatio = hp / maxHp;
        int armor = MathHelper.clamp(shown.getArmor(), 0, 20);

        int pad = 5;
        int barW = 70;
        int barH = 4;
        int barGap = 8;
        int numW = (int) Math.ceil(textWidth("20"));
        String nickText = nick;
        int headSize = 14;
        int nickW = (int) Math.ceil(textWidth(nickText));

        // Row of armor icons with durability instead of the old armor bar.
        int armorRowW = ARMOR_PAD * 2 + ARMOR_ICON * 4 + ARMOR_CELL_GAP * 3;
        int armorRowH = ARMOR_ICON + ARMOR_BAR_GAP + ARMOR_BAR_H;
        ItemStack[] armorPieces = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            armorPieces[i] = shown.getInventory().armor.get(3 - i); // helmet..boots
        }

        int headRowW = headSize + 5 + nickW;
        element.width = Math.max(Math.max(headRowW + pad * 2, pad * 2 + barW + 4 + numW), armorRowW);
        element.height = pad + Math.max(headSize, (int) TARGET_TEXT_HEIGHT) + 3 + barH + barGap
                + armorRowH + pad;

        float a = fade;
        HudStyle.island(context, element.x, element.y, element.width, element.height, HudStyle.RADIUS, a);

        // Avatar of the aimed-at player, same treatment as the watermark.
        float headX = element.x + pad;
        float headY = element.y + pad;
        Identifier skin = skinTextureOf(shown);
        RenderUtil.roundedRect(context, headX - 0.8f, headY - 0.8f, headSize + 1.6f, headSize + 1.6f, 5f,
                RenderUtil.withAlpha(0xFF1B1E28, 0.95f * a));
        if (skin != null) {
            RenderUtil.roundedTexture(context, skin, headX, headY, headSize, headSize, 4f,
                    8f / 64f, 8f / 64f, 16f / 64f, 16f / 64f, RenderUtil.withAlpha(0xFFFFFFFF, a));
        } else {
            RenderUtil.roundedRect(context, headX, headY, headSize, headSize, 4f,
                    RenderUtil.withAlpha(Colors.clientColor(), 0.5f * a));
        }
        RenderUtil.roundedOutline(context, headX, headY, headSize, headSize, 4f, 0.8f,
                RenderUtil.withAlpha(Colors.guiBorder(), 0.7f * a));

        drawText(context, nickText,
                headX + headSize + 5f, headY + (headSize - TARGET_TEXT_HEIGHT) / 2f,
                RenderUtil.withAlpha(Colors.textPrimary(), a));

        int barX = (int) (element.x + pad);
        int textTop = (int) (element.y + pad);
        int hpY = textTop + Math.max(headSize, (int) TARGET_TEXT_HEIGHT) + 3;
        int arY = hpY + barH + barGap;

        // HP bar: red -> green depending on how much is left.
        RenderUtil.roundedRect(context, barX, hpY, barW, barH, 1.5f,
                RenderUtil.withAlpha(Colors.toggleOff(), a));
        float hpFill = barW * hpRatio;
        if (hpFill >= 1f) {
            int cr = (int) (255 - 135 * hpRatio);
            int cg = (int) (80 + 175 * hpRatio);
            RenderUtil.roundedRect(context, barX, hpY, hpFill, barH, 1.5f,
                    RenderUtil.withAlpha((255 << 24) | (cr << 16) | (cg << 8) | 60, a));
        }
        String hpText = String.valueOf(Math.round(hp));
        drawText(context, hpText, barX + barW + 4,
                hpY + barH / 2 - TARGET_TEXT_HEIGHT / 2,
                RenderUtil.withAlpha(Colors.textPrimary(), a));

        // Armor: item icons with a durability bar under each (helmet..boots).
        RenderUtil.roundedRect(context, barX, arY, armorRowW, armorRowH, 4f,
                RenderUtil.withAlpha(0xFF0C0E15, 0.7f * a));
        RenderUtil.roundedOutline(context, barX, arY, armorRowW, armorRowH, 4f, 0.8f,
                RenderUtil.withAlpha(Colors.guiBorder(), 0.4f * a));

        for (int i = 0; i < 4; i++) {
            ItemStack piece = armorPieces[i];
            if (piece == null || piece.isEmpty()) {
                continue;
            }
            float cx = barX + ARMOR_PAD + i * (ARMOR_ICON + ARMOR_CELL_GAP);
            float cy = arY + ARMOR_PAD;
            context.drawItem(piece, (int) cx, (int) cy);

            int maxDamage = piece.getMaxDamage();
            if (maxDamage > 0) {
                float ratio = 1f - (float) piece.getDamage() / maxDamage;
                float barY = cy + ARMOR_ICON + ARMOR_BAR_GAP;
                RenderUtil.roundedRect(context, cx, barY, ARMOR_ICON, ARMOR_BAR_H, 1f,
                        RenderUtil.withAlpha(Colors.toggleOff(), 0.9f * a));
                float fill = ARMOR_ICON * ratio;
                if (fill >= 1f) {
                    int cr = (int) (255 - 135 * ratio);
                    int cg = (int) (80 + 175 * ratio);
                    RenderUtil.roundedRect(context, cx, barY, fill, ARMOR_BAR_H, 1f,
                            RenderUtil.withAlpha((255 << 24) | (cr << 16) | (cg << 8) | 60, a));
                }
            }
        }
    }

    /** Skin texture of any player (tab list first, then the entity itself). */
    private static Identifier skinTextureOf(PlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() != null) {
            var entry = client.getNetworkHandler().getPlayerListEntry(player.getUuid());
            if (entry != null && entry.getSkinTextures() != null
                    && entry.getSkinTextures().texture() != null) {
                return entry.getSkinTextures().texture();
            }
        }
        if (player instanceof net.minecraft.client.network.AbstractClientPlayerEntity acpe) {
            return acpe.getSkinTextures() != null ? acpe.getSkinTextures().texture() : null;
        }
        return null;
    }

    // ------------------------------------------------------------ keystrokes
    private static final int KEY_SIZE = 16;
    private static final int KEY_GAP = 2;
    private static final int KEY_TEXT_HEIGHT = 9;

    private static final int KEY_PAD = 4;

    private static void drawKey(DrawContext context, float x, float y, float w, float h,
                                String label, boolean pressed) {
        if (pressed) {
            RenderUtil.roundedGlow(context, x, y, w, h, 4f, Colors.clientColor(), 1f);
            RenderUtil.roundedGradient(context, x, y, w, h, 4f,
                    RenderUtil.withAlpha(Colors.lighten(Colors.clientColor(), 0.25f), 1f),
                    RenderUtil.withAlpha(Colors.darken(Colors.clientColor(), 0.2f), 1f));
            RenderUtil.roundedOutline(context, x, y, w, h, 4f, 1f,
                    RenderUtil.withAlpha(Colors.lighten(Colors.clientColor(), 0.5f), 0.9f));
        } else {
            RenderUtil.roundedRect(context, x, y, w, h, 4f,
                    RenderUtil.withAlpha(0xFF161923, 0.75f));
            RenderUtil.roundedOutline(context, x, y, w, h, 4f, 0.8f,
                    RenderUtil.withAlpha(Colors.guiBorder(), 0.55f));
        }
        int tw = textWidth(label);
        drawText(context, label, x + (w - tw) / 2f,
                y + (h - KEY_TEXT_HEIGHT) / 2f,
                RenderUtil.withAlpha(pressed ? 0xFF05060A : Colors.textPrimary(), pressed ? 1f : 0.7f));
    }

    /**
     * Keystrokes: WASD grid plus LMB/RMB buttons, highlighted while held.
     */
    public static void renderKeystrokes(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options == null) {
            return;
        }

        int rowW = KEY_SIZE * 3 + KEY_GAP * 2;
        int mbW = (rowW - KEY_GAP) / 2;
        element.width = rowW + KEY_PAD * 2;
        element.height = KEY_SIZE * 3 + KEY_GAP * 2 + KEY_PAD * 2;

        HudStyle.island(context, element.x, element.y, element.width, element.height,
                HudStyle.RADIUS, 1f);

        float x = element.x + KEY_PAD;
        float y = element.y + KEY_PAD;

        // Row 1: W
        drawKey(context, x + KEY_SIZE + KEY_GAP, y, KEY_SIZE, KEY_SIZE,
                "W", client.options.forwardKey.isPressed());
        // Row 2: A S D
        float row2 = y + KEY_SIZE + KEY_GAP;
        drawKey(context, x, row2, KEY_SIZE, KEY_SIZE,
                "A", client.options.leftKey.isPressed());
        drawKey(context, x + KEY_SIZE + KEY_GAP, row2, KEY_SIZE, KEY_SIZE,
                "S", client.options.backKey.isPressed());
        drawKey(context, x + (KEY_SIZE + KEY_GAP) * 2, row2, KEY_SIZE, KEY_SIZE,
                "D", client.options.rightKey.isPressed());
        // Row 3: mouse buttons
        float row3 = row2 + KEY_SIZE + KEY_GAP;
        drawKey(context, x, row3, mbW, KEY_SIZE,
                "ЛКМ", client.options.attackKey.isPressed());
        drawKey(context, x + mbW + KEY_GAP, row3, mbW, KEY_SIZE,
                "ПКМ", client.options.useKey.isPressed());
    }

    // ------------------------------------------------------------ armor hud
    private static final int ARMOR_ICON = 16;
    private static final int ARMOR_CELL_GAP = 3;
    private static final int ARMOR_BAR_H = 2;
    private static final int ARMOR_BAR_GAP = 2;
    private static final int ARMOR_PAD = 4;

    /**
     * ArmorHUD: every equipped armor piece as an item icon with a durability
     * bar under it (green -> red as it approaches breaking). While a screen is
     * open with empty armor, renders a preview so the element can be positioned.
     */
    public static void renderArmorHud(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        ItemStack[] pieces = new ItemStack[4];
        boolean any = false;
        for (int i = 0; i < 4; i++) {
            pieces[i] = client.player.getInventory().armor.get(3 - i); // helmet..boots
            any |= !pieces[i].isEmpty();
        }
        if (!any && source == DrawSource.SCREEN) {
            pieces[0] = new ItemStack(Items.DIAMOND_HELMET);
            pieces[1] = new ItemStack(Items.DIAMOND_CHESTPLATE);
            pieces[2] = new ItemStack(Items.DIAMOND_LEGGINGS);
            pieces[3] = new ItemStack(Items.DIAMOND_BOOTS);
        } else if (!any) {
            return;
        }

        int cellW = ARMOR_ICON + ARMOR_CELL_GAP;
        int cellH = ARMOR_ICON + ARMOR_BAR_GAP + ARMOR_BAR_H;
        int slots = pieces.length;
        element.width = ARMOR_PAD * 2 + cellW * slots - ARMOR_CELL_GAP;
        element.height = ARMOR_PAD * 2 + cellH;

        float x = element.x;
        float y = element.y;

        HudStyle.island(context, x, y, element.width, element.height, HudStyle.RADIUS, 1f);

        for (int i = 0; i < slots; i++) {
            ItemStack stack = pieces[i];
            if (stack == null || stack.isEmpty()) {
                continue;
            }
            float cx = x + ARMOR_PAD + i * cellW;
            float cy = y + ARMOR_PAD;

            context.drawItem(stack, (int) cx, (int) cy);

            int maxDamage = stack.getMaxDamage();
            if (maxDamage > 0) {
                int damage = stack.getDamage();
                float ratio = 1f - (float) damage / maxDamage;
                float barY = cy + ARMOR_ICON + ARMOR_BAR_GAP;
                RenderUtil.roundedRect(context, cx, barY, ARMOR_ICON, ARMOR_BAR_H, 1f,
                        RenderUtil.withAlpha(Colors.toggleOff(), 0.9f));
                float fill = ARMOR_ICON * ratio;
                if (fill >= 1f) {
                    int cr = (int) (255 - 135 * ratio);
                    int cg = (int) (80 + 175 * ratio);
                    RenderUtil.roundedRect(context, cx, barY, fill, ARMOR_BAR_H, 1f,
                            RenderUtil.withAlpha((255 << 24) | (cr << 16) | (cg << 8) | 60, 1f));
                }
            }
        }
    }

    // ------------------------------------------------------------ notifications
    /** Одно уведомление: имя функции + состояние (вкл/выкл). */
    private static final class Notification {
        final String text;
        final boolean state;
        final long born = System.currentTimeMillis();

        Notification(String text, boolean state) {
            this.text = text;
            this.state = state;
        }
    }

    private static final List<Notification> NOTIFICATIONS = new ArrayList<>();
    /** Сколько уведомление полностью видно (мс), затем фейд-аут. */
    private static final long NOTIFY_LIFE_MS = 2000L;
    /** Длительность фейд-ина и фейд-аута (мс). */
    private static final long NOTIFY_FADE_MS = 250L;

    /**
     * Добавляет уведомление «X Включен/Выключен». Вызывается из
     * {@link com.skrvisuals.modules.Module#setEnabled} при каждом переключении
     * функции (кроме восстановления из конфига). Сам факт показа фильтруется
     * настройкой Notifications модуля Hud.
     */
    public static void pushNotification(String moduleName, boolean enabled) {
        // Watermark island: show a short status pill for the same event.
        wmNotifyText = moduleName + (enabled ? "  Включён" : "  Выключен");
        wmNotifyPositive = enabled;
        wmMarqueeStart = System.currentTimeMillis();
        wmNotifyUntil = wmMarqueeStart + 1600L;

        Hud hud = Hud.getActive();
        if (hud == null || !hud.isEnabled() || !hud.isNotificationsEnabled()) {
            return;
        }
        NOTIFICATIONS.add(new Notification(moduleName, enabled));
        while (NOTIFICATIONS.size() > 6) {
            NOTIFICATIONS.remove(0);
        }
    }

    /**
     * Стопка уведомлений: панель с акцентной полосой, цветной точкой состояния
     * и текстом «Имя Включен/Выключен». Плавно появляется, держится 2 секунды
     * и растворяется.
     */
    public static void renderNotifications(DrawContext context, HudElement element) {
        long now = System.currentTimeMillis();
        NOTIFICATIONS.removeIf(n -> now - n.born > NOTIFY_LIFE_MS + NOTIFY_FADE_MS);

        TextRenderer font = Fonts.get();
        float pad = 5f;
        float rowH = 14f;
        float gap = 4f;

        int textW = 0;
        for (Notification n : NOTIFICATIONS) {
            textW = Math.max(textW, (int) Math.ceil(font.getWidth(n.text)));
        }
        element.width = textW + 30;
        element.height = (int) (pad * 2 + NOTIFICATIONS.size() * rowH
                + Math.max(0, NOTIFICATIONS.size() - 1) * gap);
        if (NOTIFICATIONS.isEmpty()) {
            return;
        }

        float x = element.x;
        float y = element.y;
        for (Notification n : NOTIFICATIONS) {
            long age = now - n.born;
            float alpha;
            if (age < NOTIFY_FADE_MS) {
                alpha = age / (float) NOTIFY_FADE_MS;          // фейд-ин + выезд
            } else if (age > NOTIFY_LIFE_MS) {
                alpha = 1f - (age - NOTIFY_LIFE_MS) / (float) NOTIFY_FADE_MS; // фейд-аут
            } else {
                alpha = 1f;
            }
            alpha = MathHelper.clamp(alpha, 0f, 1f);
            float slide = (1f - alpha) * 12f;

            float w = textW + 30;
            float h = rowH;
            float rx = x + slide;
            float ry = y;

            HudStyle.island(context, rx, ry, w, h, HudStyle.PILL, alpha);

            // Точка состояния: зелёная — включено, красная — выключено.
            int stateColor = n.state ? 0xFF68E08A : 0xFFFF5F5F;
            float dotC = rx + 12f;
            float dotY = ry + h / 2f;
            RenderUtil.circle(context, dotC, dotY, 2.6f,
                    RenderUtil.withAlpha(Colors.darken(stateColor, 0.45f), alpha));
            RenderUtil.circle(context, dotC, dotY, 1.7f, RenderUtil.withAlpha(stateColor, alpha));

            float ty = ry + (h - TARGET_TEXT_HEIGHT) / 2f;
            float tx = rx + 18f;
            String status = n.state ? " Включен" : " Выключен";
            drawText(context, n.text, tx, ty, RenderUtil.withAlpha(Colors.textPrimary(), alpha));
            tx += font.getWidth(n.text);
            drawText(context, status, tx, ty, RenderUtil.withAlpha(stateColor, alpha));

            y += rowH + gap;
        }
    }

    // ------------------------------------------------------------ inventory hud
    private static final int INV_ICON = 16;
    private static final int INV_GAP = 2;
    private static final int INV_PAD = 4;
    private static final int INV_COLS = 9;
    private static final int INV_ROWS = 3;

    /**
     * InventoryHUD: основной инвентарь (слоты 9..35 — три ряда по девять).
     * Хотбар, броня и левая рука не отображаются. Пока экран открыт и
     * инвентарь пуст — превью, чтобы элемент можно было расставить.
     */
    public static void renderInventory(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<ItemStack> items = new ArrayList<>(INV_COLS * INV_ROWS);
        boolean any = false;
        for (int i = 9; i <= 35; i++) {
            ItemStack stack = client.player.getInventory().main.get(i);
            items.add(stack);
            any |= !stack.isEmpty();
        }
        if (!any && source == DrawSource.SCREEN) {
            items.clear();
            items.add(new ItemStack(Items.DIAMOND, 12));
            items.add(new ItemStack(Items.GOLD_INGOT, 30));
            items.add(new ItemStack(Items.ENDER_PEARL, 5));
            items.add(new ItemStack(Items.COOKED_BEEF, 64));
            items.add(new ItemStack(Items.OAK_PLANKS, 41));
            while (items.size() < INV_COLS * INV_ROWS) {
                items.add(ItemStack.EMPTY);
            }
        } else if (!any) {
            return;
        }

        int cellW = INV_ICON + INV_GAP;
        int cellH = INV_ICON + INV_GAP;
        int width = INV_PAD * 2 + cellW * INV_COLS - INV_GAP;
        int height = INV_PAD * 2 + cellH * INV_ROWS - INV_GAP;
        element.width = width;
        element.height = height;

        float x = element.x;
        float y = element.y;

        HudStyle.island(context, x, y, width, height, HudStyle.RADIUS, 1f);

        TextRenderer font = Fonts.get();
        for (int r = 0; r < INV_ROWS; r++) {
            for (int c = 0; c < INV_COLS; c++) {
                ItemStack stack = items.get(r * INV_COLS + c);
                if (stack == null || stack.isEmpty()) {
                    continue;
                }
                float cx = x + INV_PAD + c * cellW;
                float cy = y + INV_PAD + r * cellH;
                context.drawItem(stack, (int) cx, (int) cy);
                // drawStackOverlay рисует счётчик поверх предмета (z=200)
                context.drawStackOverlay(font, stack, (int) cx, (int) cy, null);
            }
        }
    }

    // ------------------------------------------------------------ potions
    private static final int POTION_ROW_H = 13;
    private static final int POTION_PAD = 3;

    /**
     * Lists every status effect currently on the local player: effect icon
     * plus the time until it expires (soonest first, infinite last).
     * While a screen is open and there are no effects, renders preview rows
     * so the element can be positioned.
     */
    public static void renderPotions(DrawContext context, HudElement element) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }

        List<StatusEffectInstance> effects = new ArrayList<>(client.player.getStatusEffects());
        boolean preview = effects.isEmpty() && source == DrawSource.SCREEN;
        if (preview) {
            effects.add(new StatusEffectInstance(StatusEffects.SPEED, 20 * 32, 0));
            effects.add(new StatusEffectInstance(StatusEffects.STRENGTH, 20 * 95, 1));
        }
        if (!preview && effects.isEmpty()) {
            return;
        }
        // Soonest to expire first; infinite effects last.
        effects.sort(Comparator.comparingInt(e ->
                e.isInfinite() ? Integer.MAX_VALUE : e.getDuration()));

        TextRenderer font = Fonts.get();
        long now = System.currentTimeMillis();

        String title = " Эффекты";
        int titleW = (int) font.getWidth(title);
        List<String> labels = new ArrayList<>();
        for (StatusEffectInstance e : effects) {
            labels.add(labelOf(e));
        }
        int bodyW = 0;
        for (String label : labels) {
            bodyW = (int) Math.max(bodyW, font.getWidth(label));
        }
        int width = Math.max(titleW, bodyW) + 8;
        int rowH = POTION_ROW_H; // 10
        int padTop = 6;
        int padBottom = 6;
        int titleGap = 5;
        element.width = width;
        element.height = padTop + 6 + titleGap + labels.size() * rowH + padBottom;

        int x = (int) element.x;
        int y = (int) element.y;
        int contentX = x + 4;

        HudStyle.island(context, x, y, width, element.height, HudStyle.RADIUS, 1f);

        drawText(context, title, contentX, y + padTop, Colors.textPrimary());
        int afterTitleY = y + padTop + 6 + titleGap;

        float sepX1 = contentX;
        float sepX2 = contentX + width - 8;
        float sepY = afterTitleY - 2;
        HudStyle.separator(context, sepX1, sepY, sepX2 - sepX1, 1f);

        int ey = afterTitleY;
        for (int i = 0; i < labels.size(); i++) {
            StatusEffectInstance e = effects.get(i);
            String label = labels.get(i);
            float alpha = 1f;
            if (!preview && !e.isInfinite() && e.getDuration() <= 60) {
                alpha = 0.45f + 0.55f * (float) Math.abs(Math.sin(now / 150.0));
            }
            drawText(context, label, contentX, ey, RenderUtil.withAlpha(Colors.textPrimary(), alpha));
            ey += rowH;
        }
    }

    /** Full "Name [time]" label, or "Name [∞]" for infinite effects. */
    private static String labelOf(StatusEffectInstance e) {
        StringBuilder sb = new StringBuilder();
        Text text = Text.translatable(e.getEffectType().value().getTranslationKey());
        sb.append(text.getString());
        if (e.isInfinite()) {
            sb.append(" ∞");
        } else {
            int seconds = Math.max(0, (int) Math.ceil(e.getDuration() / 20.0f));
            sb.append(" ").append((seconds / 60)).append(":").append(String.format("%02d", seconds % 60));
        }
        int amp = e.getAmplifier();
        if (amp > 0) {
            sb.append(" ").append(roman(amp + 1));
        }
        return sb.toString();
    }

    private static String roman(int level) {
        String[] numerals = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return level >= 1 && level <= numerals.length ? numerals[level - 1] : "x" + level;
    }
}
