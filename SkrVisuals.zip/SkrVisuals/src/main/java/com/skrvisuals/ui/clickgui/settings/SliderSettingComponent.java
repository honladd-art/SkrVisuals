package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

/**
 * Точь-в-точь порт референсного SliderSettingComponent:
 * имя над слайдером, трек 2.5px на y+8, ручка 4.5x4.5, высота строки 15.
 */
public class SliderSettingComponent extends SettingComponent {
    private SliderSetting sliderSetting;

    private boolean dragging;

    private float sliderWidth = 80.0F;

    private float sliderHeight = 4.0F;

    public SliderSettingComponent(Setting setting, ModuleComponent moduleComponent) {
        super(setting, moduleComponent);
    }

    @Override
    public void init() {
        this.sliderSetting = (SliderSetting) getSetting();
        this.width = 119.5F;
        this.height = 15.0F;
        super.init();
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        super.render(context, x, y, mouseX, mouseY, delta);
        float alpha = alpha();
        this.height = 15.0F;
        this.sliderHeight = 2.5F;
        this.sliderWidth = this.width - 10.0F;
        float sliderX = x + 5.0F;
        float sliderY = y + 8.0F;
        float progress = (sliderSetting.getValue() - sliderSetting.getMin())
                / (sliderSetting.getMax() - sliderSetting.getMin());
        float handleX = sliderX + progress * this.sliderWidth;
        int sliderBg = Colors.moduleBackground();
        int sliderActive = Colors.clientColor();

        RenderUtil.roundedRect(context, sliderX, sliderY, sliderWidth, sliderHeight, 2.0F,
                RenderUtil.withAlpha(sliderBg, alpha));
        RenderUtil.roundedRect(context, sliderX, sliderY, progress * sliderWidth, sliderHeight, 2.0F,
                RenderUtil.withAlpha(sliderActive, alpha));
        RenderUtil.roundedRect(context, handleX - 2.0F, sliderY - 1.0F, 4.5F, 4.5F, 2.25F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
        RenderUtil.roundedOutline(context, handleX - 2.0F, sliderY - 1.0F, 4.5F, 4.5F, 2.25F, 1.0F,
                RenderUtil.withAlpha(sliderActive, alpha));

        var font = Fonts.get();
        RenderUtil.drawString(context, font, setting.getName(), x + 5.0F, sliderY - 8.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
        String displayText2 = String.format("%.1f", (double) sliderSetting.getValue()).replace(',', '.');
        RenderUtil.drawCenteredString(context, font, displayText2, x + sliderWidth - 2.5F, sliderY - 5.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            float sliderX = this.x + 5.0F;
            float sliderY = this.y + 8.0F;
            if (mouseX >= sliderX && mouseX <= sliderX + this.sliderWidth
                    && mouseY >= sliderY && mouseY <= sliderY + this.sliderHeight) {
                this.dragging = true;
                updateValue(mouseX);
            }
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0)
            this.dragging = false;
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button) {
        if (this.dragging && button == 0)
            updateValue(mouseX);
    }

    public void updateValue(double mouseX) {
        if (this.dragging) {
            float sliderX = this.x + 5.0F;
            float progress = (float) Math.max(0.0D, Math.min(1.0D, (mouseX - sliderX) / this.sliderWidth));
            float value = sliderSetting.getMin() + progress * (sliderSetting.getMax() - sliderSetting.getMin());
            value = Math.max(sliderSetting.getMin(), Math.min(sliderSetting.getMax(), value));
            sliderSetting.setValue(value);
        }
    }
}
