package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.ui.clickgui.api.CustomElement;

import java.util.Locale;

/**
 * Точь-в-точь порт референсного ModeComponent: отдельная «плашка» режима.
 * Ширина = ширина текста + 8, высота 9, скругление 2.
 */
public class ModeComponent extends CustomElement {
    private final String mode;

    private final ModeSettingComponent parent;

    public ModeComponent(String mode, ModeSettingComponent parent) {
        this.mode = mode;
        this.parent = parent;
    }

    @Override
    public void init() {
        this.width = com.skrvisuals.ui.render.Fonts.get().getWidth(this.mode) + 8.0F;
        this.height = 9.0F;
        super.init();
    }

    @Override
    public void render(net.minecraft.client.gui.DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        this.x = x;
        this.y = y;
        float alpha = parent.alpha();
        boolean hovering = mouseX >= x && mouseX <= x + this.width && mouseY >= y && mouseY <= y + this.height;
        boolean isCurrentMode = this.mode.equals(parent.getModeSetting().getValue());

        int fill = isCurrentMode ? com.skrvisuals.ui.theme.Colors.clientColor()
                : com.skrvisuals.ui.theme.Colors.guiBackground();
        if (hovering && !isCurrentMode) {
            fill = com.skrvisuals.ui.theme.Colors.moduleBackground();
        }
        com.skrvisuals.ui.render.RenderUtil.roundedRect(context, x, y, this.width, this.height, 2.0F,
                com.skrvisuals.ui.render.RenderUtil.withAlpha(fill, isCurrentMode ? alpha : alpha * 0.8F));

        var font = com.skrvisuals.ui.render.Fonts.get();
        com.skrvisuals.ui.render.RenderUtil.drawCenteredString(context, font, this.mode.toUpperCase(Locale.ROOT),
                x + this.width / 2.0F, y + 3.0F,
                com.skrvisuals.ui.render.RenderUtil.withAlpha(com.skrvisuals.ui.theme.Colors.textPrimary(), alpha));
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        boolean hovering = mouseX >= this.x && mouseX <= this.x + this.width
                && mouseY >= this.y && mouseY <= this.y + this.height;
        if (hovering && button == 0) {
            parent.getModeSetting().setValue(this.mode);
        }
    }
}
