package com.skrvisuals.ui.render;

import java.util.ArrayDeque;
import java.util.Deque;

import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.Window;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * Custom float-accurate renderer for the GUI and HUD.
 *
 * Everything is emitted as raw {@code POSITION_COLOR} vertices into the vanilla
 * gui layer ({@link RenderLayer#getGui()}), exactly like vanilla primitives,
 * but with true float coordinates, real curved rounded corners (triangle
 * fans), per-vertex gradients, outlines, circles, soft shadows and
 * float-accurate text.
 */
public final class RenderUtil {
    /** Global opacity multiplier applied inside {@link #withAlpha} while HUD elements render. */
    public static float hudOpacity = 1f;

    private RenderUtil() {
    }

    // ------------------------------------------------------------ core plumbing

    /** Emits raw gui-layer geometry and flushes it. */
    private static void draw(DrawContext ctx, Geometry geometry) {
        ctx.draw((VertexConsumerProvider providers) -> {
            VertexConsumer buffer = providers.getBuffer(RenderLayer.getGui());
            Matrix4f matrix = ctx.getMatrices().peek().getPositionMatrix();
            geometry.emit(buffer, matrix);
        });
    }

    @FunctionalInterface
    private interface Geometry {
        void emit(VertexConsumer buffer, Matrix4f matrix);
    }

    /** One flat-color quad, vanilla vertex order (TL, BL, BR, TR). */
    private static void quad(VertexConsumer v, Matrix4f m, float x0, float y0, float x1, float y1, int color) {
        v.vertex(m, x0, y0, 0f).color(color);
        v.vertex(m, x0, y1, 0f).color(color);
        v.vertex(m, x1, y1, 0f).color(color);
        v.vertex(m, x1, y0, 0f).color(color);
    }

    /** Arbitrary quad (a=TL, b=BL, c=BR, d=TR) with per-point colors. */
    private static void quad4(VertexConsumer v, Matrix4f m,
            float ax, float ay, int ca,
            float bx, float by, int cb,
            float cx, float cy, int cc,
            float dx, float dy, int cd) {
        v.vertex(m, ax, ay, 0f).color(ca);
        v.vertex(m, bx, by, 0f).color(cb);
        v.vertex(m, cx, cy, 0f).color(cc);
        v.vertex(m, dx, dy, 0f).color(cd);
    }

    /** Flat gradient quad (a=TL, b=BL, c=BR, d=TR) — used by the color picker. */
    public static void fill4(DrawContext ctx, float x0, float y0, float x1, float y1,
            int topLeft, int bottomLeft, int bottomRight, int topRight) {
        draw(ctx, (v, m) -> quad4(v, m, x0, y0, topLeft, x0, y1, bottomLeft, x1, y1, bottomRight, x1, y0, topRight));
    }

    /**
     * Произвольный четырёхугольник одним цветом (экранные координаты).
     * Порядок вершин автоматически разворачивается, чтобы quad не был
     * отсечён backface-culling'ом gui-слоя.
     */
    public static void fillQuad(DrawContext ctx,
            float ax, float ay, float bx, float by,
            float cx, float cy, float dx, float dy, int color) {
        // Знаковая площадь (shoelace): ванильный порядок вершин даёт отрицательную.
        float area = (bx - ax) * (by + ay)
                + (cx - bx) * (cy + by)
                + (dx - cx) * (dy + cy)
                + (ax - dx) * (ay + dy);
        float ax2, ay2, bx2, by2, cx2, cy2, dx2, dy2;
        if (area < 0f) {
            // Разворачиваем обход: (a,b,c,d) -> (d,c,b,a)
            ax2 = dx; ay2 = dy;
            bx2 = cx; by2 = cy;
            cx2 = bx; cy2 = by;
            dx2 = ax; dy2 = ay;
        } else {
            ax2 = ax; ay2 = ay;
            bx2 = bx; by2 = by;
            cx2 = cx; cy2 = cy;
            dx2 = dx; dy2 = dy;
        }
        draw(ctx, (v, m) -> quad4(v, m, ax2, ay2, color, bx2, by2, color, cx2, cy2, color, dx2, dy2, color));
    }

    /** One triangle, emitted as a degenerate quad (gui layer draws quads). */
    private static void tri(VertexConsumer v, Matrix4f m,
            float ax, float ay, float bx, float by, float cx, float cy, int color) {
        // NOTE: vertex order matters — the gui layer has back-face culling
        // enabled, so triangles must wind the same way as vanilla quads
        // (screen-clockwise). (a, c, b) instead of (a, b, c).
        v.vertex(m, ax, ay, 0f).color(color);
        v.vertex(m, cx, cy, 0f).color(color);
        v.vertex(m, bx, by, 0f).color(color);
        v.vertex(m, bx, by, 0f).color(color);
    }

    /** Triangle with per-vertex gradient (center color + two rim colors). */
    private static void triGrad(VertexConsumer v, Matrix4f m,
            float ax, float ay, int ca,
            float bx, float by, int cb,
            float cx, float cy, int cc) {
        v.vertex(m, ax, ay, 0f).color(ca);
        v.vertex(m, cx, cy, 0f).color(cc);
        v.vertex(m, bx, by, 0f).color(cb);
        v.vertex(m, bx, by, 0f).color(cb);
    }

    private static int segments(float radius) {
        return MathHelper.clamp((int) (radius * 2.2f), 4, 28);
    }

    // ------------------------------------------------------------ flat shapes

    /** Float-accurate filled rectangle. */
    public static void fill(DrawContext ctx, float x, float y, float w, float h, int color) {
        if (w <= 0 || h <= 0 || (color >>> 24) == 0) {
            return;
        }
        draw(ctx, (v, m) -> quad(v, m, x, y, x + w, y + h, color));
    }

    /** Vertical linear gradient (top -> bottom). */
    public static void fillGradient(DrawContext ctx, float x, float y, float w, float h, int top, int bottom) {
        if (w <= 0 || h <= 0) {
            return;
        }
        draw(ctx, (v, m) -> quad4(v, m,
                x, y, top,
                x, y + h, bottom,
                x + w, y + h, bottom,
                x + w, y, top));
    }

    /** Horizontal linear gradient (left -> right). */
    public static void fillGradientH(DrawContext ctx, float x, float y, float w, float h, int left, int right) {
        if (w <= 0 || h <= 0) {
            return;
        }
        draw(ctx, (v, m) -> quad4(v, m,
                x, y, left,
                x, y + h, left,
                x + w, y + h, right,
                x + w, y, right));
    }

    /** Filled circle. */
    public static void circle(DrawContext ctx, float cx, float cy, float radius, int color) {
        if (radius <= 0 || (color >>> 24) == 0) {
            return;
        }
        int seg = segments(radius);
        draw(ctx, (v, m) -> {
            float prevX = cx + radius;
            float prevY = cy;
            for (int i = 1; i <= seg; i++) {
                double a = (Math.PI * 2d) * i / seg;
                float px = cx + radius * (float) Math.cos(a);
                float py = cy + radius * (float) Math.sin(a);
                tri(v, m, cx, cy, prevX, prevY, px, py, color);
                prevX = px;
                prevY = py;
            }
        });
    }

    /** Circle outline with the given thickness. */
    public static void circleOutline(DrawContext ctx, float cx, float cy, float radius, float thickness, int color) {
        if (radius <= 0 || thickness <= 0 || (color >>> 24) == 0) {
            return;
        }
        float outer = radius;
        float inner = Math.max(0f, radius - thickness);
        int seg = segments(radius);
        draw(ctx, (v, m) -> {
            float pox = cx + outer, poy = cy, pix = cx + inner, piy = cy;
            for (int i = 1; i <= seg; i++) {
                double a = (Math.PI * 2d) * i / seg;
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                float nox = cx + outer * ca, noy = cy + outer * sa;
                float nix = cx + inner * ca, niy = cy + inner * sa;
                quad4(v, m, pox, poy, color, pix, piy, color, nix, niy, color, nox, noy, color);
                pox = nox;
                poy = noy;
                pix = nix;
                piy = niy;
            }
        });
    }

    /** Soft shadow: a few concentric translucent rounded rects around (x, y). */
    public static void roundedShadow(DrawContext ctx, float x, float y, float w, float h, float radius, float strength) {
        if (w <= 0 || h <= 0) {
            return;
        }
        int layers = 4;
        for (int i = layers; i >= 1; i--) {
            float off = i * 1.25f;
            float a = strength * (1f - i / (float) (layers + 1)) * 0.16f;
            roundedRect(ctx, x - off, y - off + off * 0.4f, w + off * 2f, h + off * 2f, radius + off,
                    withAlpha(0x0A0A10, a));
        }
    }


    /** Soft colored glow: concentric translucent rounded rects around (x, y). */
    public static void roundedGlow(DrawContext ctx, float x, float y, float w, float h, float radius,
            int color, float strength) {
        if (w <= 0 || h <= 0 || strength <= 0f) {
            return;
        }
        int layers = 5;
        for (int i = layers; i >= 1; i--) {
            float off = i * 1.7f;
            float a = strength * (1f - i / (float) (layers + 1)) * 0.16f;
            roundedRect(ctx, x - off, y - off * 0.55f, w + off * 2f, h + off * 1.1f, radius + off,
                    withAlpha(color, a));
        }
    }

    /**
     * Short glowing accent line centered under a panel — the signature detail of
     * the HUD style (see {@code HudStyle#island}).
     */
    public static void accentUnderline(DrawContext ctx, float x, float y, float w, float h, int color, float alpha) {
        float lineW = Math.min(22f, Math.max(4f, w * 0.32f));
        roundedRect(ctx, x + (w - lineW) / 2f, y + h - 1f, lineW, 0.9f, 0.45f, withAlpha(color, alpha));
    }

    /** Textured rounded rectangle (real curved corners) with an explicit UV region. */
    public static void roundedTexture(DrawContext ctx, Identifier texture, float x, float y, float w, float h,
            float radius, float u0, float v0, float u1, float v1, int color) {
        if (texture == null || w <= 0 || h <= 0 || (color >>> 24) == 0) {
            return;
        }
        float r = MathHelper.clamp(radius, 0f, Math.min(w, h) / 2f);
        ctx.draw((providers) -> {
            VertexConsumer buffer = providers.getBuffer(RenderLayer.getGuiTextured(texture));
            Matrix4f matrix = ctx.getMatrices().peek().getPositionMatrix();
            // Middle rectangle (inset by the radius) plus four corner fans.
            float ix = r > 0.01f ? r : 0f;
            texQuad(buffer, matrix,
                    x + ix, y + ix, x + ix, y + h - ix, x + w - ix, y + h - ix, x + w - ix, y + ix,
                    u0, v0, u1, v1, color);
            if (r <= 0.01f) {
                return;
            }
            int seg = segments(r);
            texCorner(buffer, matrix, x + r, y + r, r, 180f, 270f, seg, x, y, w, h, u0, v0, u1, v1, color);
            texCorner(buffer, matrix, x + w - r, y + r, r, 270f, 360f, seg, x, y, w, h, u0, v0, u1, v1, color);
            texCorner(buffer, matrix, x + w - r, y + h - r, r, 0f, 90f, seg, x, y, w, h, u0, v0, u1, v1, color);
            texCorner(buffer, matrix, x + r, y + h - r, r, 90f, 180f, seg, x, y, w, h, u0, v0, u1, v1, color);
        });
    }

    /** One textured quad in screen space with its UV region (a..d = TL, BL, BR, TR). */
    private static void texQuad(VertexConsumer v, Matrix4f m,
            float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy,
            float u0, float v0, float u1, float v1, int color) {
        v.vertex(m, ax, ay, 0f).texture(u0, v0).color(color);
        v.vertex(m, bx, by, 0f).texture(u0, v1).color(color);
        v.vertex(m, cx, cy, 0f).texture(u1, v1).color(color);
        v.vertex(m, dx, dy, 0f).texture(u1, v0).color(color);
    }

    /** Quarter-circle fan of textured triangles; UVs follow the screen->UV mapping. */
    private static void texCorner(VertexConsumer v, Matrix4f m, float cx, float cy, float r,
            float fromDeg, float toDeg, int seg,
            float x, float y, float w, float h, float u0, float v0, float u1, float v1, int color) {
        float span = toDeg - fromDeg;
        double a0 = Math.toRadians(fromDeg);
        float px = cx + r * (float) Math.cos(a0);
        float py = cy + r * (float) Math.sin(a0);
        float cu = u0 + (cx - x) / w * (u1 - u0);
        float cv = v0 + (cy - y) / h * (v1 - v0);
        for (int i = 1; i <= seg; i++) {
            double a = Math.toRadians(fromDeg + span * i / seg);
            float qx = cx + r * (float) Math.cos(a);
            float qy = cy + r * (float) Math.sin(a);
            float qu = u0 + (qx - x) / w * (u1 - u0);
            float qv = v0 + (qy - y) / h * (v1 - v0);
            float pu = u0 + (px - x) / w * (u1 - u0);
            float pv = v0 + (py - y) / h * (v1 - v0);
            // Screen-clockwise winding, same as the flat gui layer.
            v.vertex(m, cx, cy, 0f).texture(cu, cv).color(color);
            v.vertex(m, qx, qy, 0f).texture(qu, qv).color(color);
            v.vertex(m, px, py, 0f).texture(pu, pv).color(color);
            v.vertex(m, px, py, 0f).texture(pu, pv).color(color);
            px = qx;
            py = qy;
        }
    }

    // ------------------------------------------------------------ rounded rects

    /** Rounded rectangle with real curved corners. */
    public static void roundedRect(DrawContext ctx, float x, float y, float w, float h, float radius, int color) {
        roundedGradient(ctx, x, y, w, h, radius, color, color);
    }

    /** Rounded rectangle with a vertical gradient (top -> bottom). */
    public static void roundedGradient(DrawContext ctx, float x, float y, float w, float h, float radius,
            int top, int bottom) {
        if (w <= 0 || h <= 0 || ((top >>> 24) == 0 && (bottom >>> 24) == 0)) {
            return;
        }
        float r = MathHelper.clamp(radius, 0f, Math.min(w, h) / 2f);
        if (r <= 0.01f) {
            fillGradient(ctx, x, y, w, h, top, bottom);
            return;
        }

        final int seg = segments(r);
        final float topY = y, botY = y + h;

        draw(ctx, (v, m) -> {
            // Middle band (covers between the corner arcs, full height).
            quad4(v, m,
                    x + r, topY, top,
                    x + r, botY, bottom,
                    x + w - r, botY, bottom,
                    x + w - r, topY, top);

            // Left / right edge strips between the corner arcs (without them
            // the silhouette looks "pinched": corners stick out, sides cut).
            int stripTop = colorAtY(topY + r, top, bottom, topY, botY);
            int stripBot = colorAtY(botY - r, top, bottom, topY, botY);
            quad4(v, m,
                    x, topY + r, stripTop,
                    x, botY - r, stripBot,
                    x + r, botY - r, stripBot,
                    x + r, topY + r, stripTop);
            quad4(v, m,
                    x + w - r, topY + r, stripTop,
                    x + w - r, botY - r, stripBot,
                    x + w, botY - r, stripBot,
                    x + w, topY + r, stripTop);

            // Corner fans with gradient matched to their vertical position.
            cornerFan(v, m, x + r, topY + r, r, 180f, 270f, seg, top, bottom, topY, botY);
            cornerFan(v, m, x + w - r, topY + r, r, 270f, 360f, seg, top, bottom, topY, botY);
            cornerFan(v, m, x + w - r, botY - r, r, 0f, 90f, seg, top, bottom, topY, botY);
            cornerFan(v, m, x + r, botY - r, r, 90f, 180f, seg, top, bottom, topY, botY);
        });
    }

    /** Quarter-circle fan; colors interpolated vertically across the whole rect. */
    private static void cornerFan(VertexConsumer v, Matrix4f m, float cx, float cy, float r,
            float fromDeg, float toDeg, int seg, int topColor, int bottomColor, float topY, float botY) {
        float span = toDeg - fromDeg;
        double a0 = Math.toRadians(fromDeg);
        float px = cx + r * (float) Math.cos(a0);
        float py = cy + r * (float) Math.sin(a0);
        for (int i = 1; i <= seg; i++) {
            double a = Math.toRadians(fromDeg + span * i / seg);
            float qx = cx + r * (float) Math.cos(a);
            float qy = cy + r * (float) Math.sin(a);
            int cpx = colorAtY(py, topColor, bottomColor, topY, botY);
            int cqx = colorAtY(qy, topColor, bottomColor, topY, botY);
            int cc = colorAtY(cy, topColor, bottomColor, topY, botY);
            triGrad(v, m, cx, cy, cc, px, py, cpx, qx, qy, cqx);
            px = qx;
            py = qy;
        }
    }

    private static int colorAtY(float y, int topColor, int bottomColor, float topY, float botY) {
        float t = (botY - topY) <= 0f ? 0f : MathHelper.clamp((y - topY) / (botY - topY), 0f, 1f);
        return lerpColor(topColor, bottomColor, t);
    }

    /** Rounded rectangle outline (border) with real curved corners. */
    public static void roundedOutline(DrawContext ctx, float x, float y, float w, float h, float radius,
            float thickness, int color) {
        if (w <= 0 || h <= 0 || thickness <= 0 || (color >>> 24) == 0) {
            return;
        }
        float r = MathHelper.clamp(radius, 0f, Math.min(w, h) / 2f);
        float t = Math.min(thickness, Math.min(w, h) / 2f);

        draw(ctx, (v, m) -> {
            float left = x, topY = y, right = x + w, botY = y + h;
            // Straight edges.
            quad(v, m, left + r, topY, right - r, topY + t, color);              // top
            quad(v, m, left + r, botY - t, right - r, botY, color);              // bottom
            quad(v, m, left, topY + r, left + t, botY - r, color);               // left
            quad(v, m, right - t, topY + r, right, botY - r, color);             // right

            if (r > 0.01f) {
                int seg = segments(r);
                cornerRing(v, m, left + r, topY + r, r, t, 180f, 270f, seg, color);
                cornerRing(v, m, right - r, topY + r, r, t, 270f, 360f, seg, color);
                cornerRing(v, m, right - r, botY - r, r, t, 0f, 90f, seg, color);
                cornerRing(v, m, left + r, botY - r, r, t, 90f, 180f, seg, color);
            }
        });
    }

    private static void cornerRing(VertexConsumer v, Matrix4f m, float cx, float cy, float r, float t,
            float fromDeg, float toDeg, int seg, int color) {
        float span = toDeg - fromDeg;
        double a0 = Math.toRadians(fromDeg);
        float pox = cx + r * (float) Math.cos(a0), poy = cy + r * (float) Math.sin(a0);
        float pix = cx + (r - t) * (float) Math.cos(a0), piy = cy + (r - t) * (float) Math.sin(a0);
        for (int i = 1; i <= seg; i++) {
            double a = Math.toRadians(fromDeg + span * i / seg);
            float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
            float nox = cx + r * ca, noy = cy + r * sa;
            float nix = cx + (r - t) * ca, niy = cy + (r - t) * sa;
            quad4(v, m, pox, poy, color, pix, piy, color, nix, niy, color, nox, noy, color);
            pox = nox;
            poy = noy;
            pix = nix;
            piy = niy;
        }
    }

    // ------------------------------------------------------------ text

    /** Float-accurate text with shadow. */
    public static void drawString(DrawContext ctx, TextRenderer font, String text, float x, float y, int color) {
        if (text == null || text.isEmpty()) {
            return;
        }
        ctx.draw((VertexConsumerProvider providers) -> {
            Matrix4f matrix = ctx.getMatrices().peek().getPositionMatrix();
            font.draw(text, x, y, color, true, matrix, providers, TextLayerType.NORMAL, 0, 0xF000F0);
        });
    }

    /** Float-accurate text without shadow. */
    public static void drawStringFlat(DrawContext ctx, TextRenderer font, String text, float x, float y, int color) {
        if (text == null || text.isEmpty()) {
            return;
        }
        ctx.draw((VertexConsumerProvider providers) -> {
            Matrix4f matrix = ctx.getMatrices().peek().getPositionMatrix();
            font.draw(text, x, y, color, false, matrix, providers, TextLayerType.NORMAL, 0, 0xF000F0);
        });
    }

    /** Centered horizontally on the given center x. */
    public static void drawCenteredString(DrawContext ctx, TextRenderer font, String text, float centerX, float y, int color) {
        drawString(ctx, font, text, centerX - font.getWidth(text) / 2f, y, color);
    }

    // ------------------------------------------------------------ scissor

    private static final Deque<DrawContext> SCISSOR_CTX = new ArrayDeque<>();

    /**
     * Клип в GUI-координатах через ванильный ScissorStack DrawContext —
     * он применяется в момент реального флаша геометрии, поэтому работает
     * и с отложенным рендером DrawContext. Must be popped with
     * {@link #popScissor()} in a {@code finally} block.
     */
    public static void pushScissor(DrawContext ctx, float x, float y, float w, float h) {
        SCISSOR_CTX.push(ctx);
        ctx.enableScissor(
                (int) Math.floor(x),
                (int) Math.floor(y),
                (int) Math.ceil(x + w),
                (int) Math.ceil(y + h));
    }

    public static void popScissor() {
        DrawContext ctx = SCISSOR_CTX.pop();
        if (ctx != null) {
            ctx.disableScissor();
        }
    }

    // ------------------------------------------------------------ helpers

    public static boolean hovered(float mx, float my, float x, float y, float w, float h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    /** Alpha-multiplied color from an ARGB int (respects {@link #hudOpacity}). */
    public static int withAlpha(int rgba, float alpha) {
        int a = (int) (255 * alpha * hudOpacity);
        return ((rgba & 0xFFFFFF)) | (MathHelper.clamp(a, 0, 255) << 24);
    }

    /** Returns the same color with its alpha multiplied, ignoring the parsed alpha. */
    public static int multiplyAlpha(int rgba, float factor) {
        int a = (int) (((rgba >>> 24) & 0xFF) * factor);
        return ((rgba & 0xFFFFFF)) | (MathHelper.clamp(a, 0, 255) << 24);
    }

    /** Per-channel ARGB lerp, t in 0..1. */
    public static int lerpColor(int from, int to, float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        int a = (int) MathHelper.lerp(t, (from >>> 24) & 0xFF, (to >>> 24) & 0xFF);
        int r = (int) MathHelper.lerp(t, (from >> 16) & 0xFF, (to >> 16) & 0xFF);
        int g = (int) MathHelper.lerp(t, (from >> 8) & 0xFF, (to >> 8) & 0xFF);
        int b = (int) MathHelper.lerp(t, from & 0xFF, to & 0xFF);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
