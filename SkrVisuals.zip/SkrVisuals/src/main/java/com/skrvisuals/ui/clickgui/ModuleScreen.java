package com.skrvisuals.ui.clickgui;

import com.skrvisuals.Skr;
import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.GuiFx;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;

/**
 * Адаптивная двухколоночная сетка карточек модулей под шапкой секции:
 * ширина карточек считается из ширины области контента, есть клип,
 * инерционный скролл и тонкий акцентный скролл-бар.
 */
public class ModuleScreen {
    private static final float MARGIN = 14.0F;
    private static final float COLUMN_GAP = 12.0F;
    private static final float ROW_GAP = 10.0F;

    private final ClickScreen gui;

    public ArrayList<ModuleComponent> moduleComponents = new ArrayList<>();

    private float scroll = 0.0F;
    private float scrollTarget = 0.0F;
    private float scrollMax = 0.0F;
    private float scrollVis = 0.0F;
    private long lastScrollMs = 0L;
    /** Активное перетаскивание скроллбара (зажали и ведём). */
    private boolean draggingScrollbar = false;
    /** Хитбокс ползунка: [x, y, w, h, areaTop, usableH, thumbH, travel]. */
    private float[] scrollbarBox = null;
    /** Кнопка «Сбросить поиск» в пустом состоянии (x, y, w, h). */
    private float[] resetBox = null;

    /** Кеш условий построения: пересобираем компоненты только когда они меняются. */
    private String lastSearch = null;
    private ModuleCategory lastCategory = null;

    public ModuleScreen(ClickScreen gui) {
        this.gui = gui;
    }

    public void init() {
        this.lastSearch = null;
        this.lastCategory = null;
        this.scroll = 0.0F;
        this.scrollTarget = 0.0F;
        updateModuleComponents();
    }

    private void updateModuleComponents() {
        String searchText = gui.getSidebar().getSearchText();
        ModuleCategory category = ClickScreen.getSavedCategory();
        if (searchText.equals(this.lastSearch) && category == this.lastCategory) {
            return; // компоненты уже актуальны — сохраняем состояние (expanded, dragging…)
        }
        this.lastSearch = searchText;
        this.lastCategory = category;
        gui.touchContentTime(); // каскад карточек после смены фильтра
        List<Module> source = Skr.INSTANCE.getModuleManager().getModules();
        List<Module> sorted = new ArrayList<>(source);
        sorted.sort((o1, o2) -> Collator.getInstance().compare(o1.getName(), o2.getName()));
        this.moduleComponents = new ArrayList<>();
        for (Module module : sorted) {
            if (searchText.isEmpty()) {
                if (module.getCategory() == category) {
                    this.moduleComponents.add(new ModuleComponent(module, gui));
                }
            } else {
                String moduleName = module.getName().toLowerCase();
                String moduleDescription = module.getDescription().toLowerCase();
                if (moduleName.contains(searchText) || moduleDescription.contains(searchText)) {
                    this.moduleComponents.add(new ModuleComponent(module, gui));
                }
            }
        }
        for (ModuleComponent component : this.moduleComponents) {
            component.init();
        }
    }

    public void render(DrawContext context, int mouseX, int mouseY, float partialTicks) {
        updateModuleComponents();

        float contentX = gui.getContentX();
        float contentTop = gui.getContentTop();
        float areaW = gui.getContentWidth();
        float areaH = gui.getContentHeight();
        float cardW = Math.max(96.0F, (areaW - MARGIN * 2.0F - COLUMN_GAP) / 2.0F);

        RenderUtil.pushScissor(context, contentX - 1.0F, contentTop - 2.0F, areaW + 1.0F, areaH + 4.0F);
        try {
            float leftHeight = 0.0F;
            float rightHeight = 0.0F;
            float overallHeight = 0.0F;
            for (ModuleComponent component : this.moduleComponents) {
                component.setCardWidth(cardW);
                overallHeight += component.getTotalHeight() + ROW_GAP;
            }

            this.scrollMax = Math.max(0.0F, overallHeight - areaH);
            if (this.scrollMax <= 0.0F) {
                this.scrollTarget = 0.0F;
            }
            this.scrollTarget = Math.max(-this.scrollMax, Math.min(0.0F, this.scrollTarget));
            this.scroll += (this.scrollTarget - this.scroll) * 0.35F;
            if (Math.abs(this.scrollTarget - this.scroll) < 0.05F) {
                this.scroll = this.scrollTarget;
            }

            float startY = contentTop + 2.0F + this.scroll;
            float leftX = contentX + MARGIN;
            float rightX = contentX + MARGIN + cardW + COLUMN_GAP;
            int count = 0;
            int index = 0;
            gui.setHoveredModule(null);
            for (ModuleComponent component : this.moduleComponents) {
                boolean rightSide = (count % 2 == 1);
                float moduleX = rightSide ? rightX : leftX;
                float moduleY = startY + (rightSide ? rightHeight : leftHeight);
                float entrance = GuiFx.stagger(gui.getContentTime(), index, 40L, 300L);
                component.setEntrance(entrance);
                component.render(context, moduleX, moduleY, mouseX, mouseY, partialTicks);
                if (rightSide) {
                    rightHeight += component.getTotalHeight() + ROW_GAP;
                } else {
                    leftHeight += component.getTotalHeight() + ROW_GAP;
                }
                count++;
                index++;
            }

            renderEmpty(context, mouseX, mouseY, contentX, contentTop, areaW, areaH);
            drawScrollbar(context, areaH, overallHeight, contentTop);
        } finally {
            RenderUtil.popScissor();
        }

        // Если курсор вне области контента — модуль не считается наведённым.
        if (mouseX < contentX || mouseX > gui.getX() + gui.getWidth()
                || mouseY < contentTop || mouseY > gui.getY() + gui.getHeight()) {
            gui.setHoveredModule(null);
        }
    }

    /** Пустое состояние секции: подсказка и кнопка сброса поиска. */
    private void renderEmpty(DrawContext ctx, int mouseX, int mouseY,
                             float contentX, float contentTop, float areaW, float areaH) {
        this.resetBox = null;
        if (!this.moduleComponents.isEmpty()) {
            return;
        }
        float alpha = GuiFx.clamp01(gui.getAlpha());
        float entrance = GuiFx.stagger(gui.getContentTime(), 0, 0L, 320L);
        TextRenderer font = Fonts.get();
        float cx = contentX + areaW / 2.0F;
        float cy = contentTop + areaH * 0.42F;

        boolean hasSearch = !gui.getSidebar().getSearchText().isEmpty();
        String msg = hasSearch ? "Ничего не найдено" : "Здесь пока пусто";
        RenderUtil.drawCenteredString(ctx, font, msg, cx, cy,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha * entrance));
        String subtitle = hasSearch ? "Попробуй другой запрос" : "Модули этой категории появятся здесь";
        RenderUtil.drawCenteredString(ctx, font, subtitle, cx, cy + 13.0F,
                RenderUtil.withAlpha(Colors.textMuted(), alpha * entrance));

        if (hasSearch) {
            String label = "Сбросить поиск";
            float bw = font.getWidth(label) + 22.0F;
            float bh = 18.0F;
            float bx = cx - bw / 2.0F;
            float by = cy + 28.0F;
            boolean hovered = RenderUtil.hovered(mouseX, mouseY, bx, by, bw, bh);
            RenderUtil.roundedRect(ctx, bx, by, bw, bh, 6.0F,
                    RenderUtil.withAlpha(hovered ? Colors.settingHover() : Colors.keyBackground(), alpha * 0.9F));
            RenderUtil.roundedOutline(ctx, bx, by, bw, bh, 6.0F, 1.0F,
                    RenderUtil.withAlpha(hovered ? Colors.clientColor() : Colors.guiBorder(), alpha * 0.85F));
            RenderUtil.drawCenteredString(ctx, font, label, cx, by + (bh - font.fontHeight) / 2.0F,
                    RenderUtil.withAlpha(Colors.textPrimary(), alpha));
            this.resetBox = new float[]{bx, by, bw, bh};
        }
    }

    /** Тонкий скролл-бар справа: виден при скролле, плавно гаснет. */
    private void drawScrollbar(DrawContext ctx, float areaH, float overallHeight, float contentTop) {
        boolean active = this.draggingScrollbar || (this.scrollMax > 1.0F
                && (Math.abs(this.scrollTarget - this.scroll) > 0.3F
                || System.currentTimeMillis() - this.lastScrollMs < 1200L));
        float target = active ? 0.65F : 0.0F;
        this.scrollVis += (target - this.scrollVis) * 0.12F;
        if (this.scrollVis <= 0.02F) {
            this.scrollbarBox = null;
            return;
        }
        float areaTop = contentTop + 4.0F;
        float usableH = areaH - 8.0F;
        float barX = gui.getX() + gui.getWidth() - 6.5F;
        float thumbH = Math.max(20.0F, usableH * (areaH / Math.max(1.0F, overallHeight)));
        float travel = usableH - thumbH;
        float t = this.scrollMax > 0.0F ? GuiFx.clamp01(-this.scroll / this.scrollMax) : 0.0F;
        float thumbY = areaTop + travel * t;
        float a = GuiFx.clamp01(gui.getAlpha()) * this.scrollVis;
        this.scrollbarBox = new float[]{barX, thumbY, 3.0F, thumbH, areaTop, usableH, thumbH, travel};
        RenderUtil.roundedRect(ctx, barX, thumbY, 3.0F, thumbH, 1.5F,
                RenderUtil.withAlpha(Colors.clientColor(), a));
    }

    /** Переводит позицию мыши в целевой скролл по геометрии ползунка. */
    private void scrollThumbTo(double mouseY, float[] sb) {
        float travel = sb[7];
        this.lastScrollMs = System.currentTimeMillis();
        if (travel <= 0.0F || this.scrollMax <= 0.0F) {
            this.scrollTarget = 0.0F;
            return;
        }
        float t = GuiFx.clamp01(((float) mouseY - sb[4] - sb[6] / 2.0F) / travel);
        this.scrollTarget = -t * this.scrollMax;
    }

    private boolean scrollbarGrabbed(float mx, float my) {
        if (this.scrollbarBox == null || this.scrollMax <= 0.0F) {
            return false;
        }
        float[] sb = this.scrollbarBox;
        return RenderUtil.hovered(mx, my, sb[0] - 5.0F, sb[1] - 3.0F, sb[2] + 10.0F, sb[3] + 6.0F);
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && this.resetBox != null
                && RenderUtil.hovered((float) mouseX, (float) mouseY,
                this.resetBox[0], this.resetBox[1], this.resetBox[2], this.resetBox[3])) {
            gui.getSidebar().clearSearch();
            return;
        }
        // Захват ползунка прокрутки — дальше его можно тянуть мышью.
        if (button == 0 && scrollbarGrabbed((float) mouseX, (float) mouseY)) {
            this.draggingScrollbar = true;
            scrollThumbTo(mouseY, this.scrollbarBox);
            return;
        }
        for (int i = this.moduleComponents.size() - 1; i >= 0; i--) {
            this.moduleComponents.get(i).mouseClicked(mouseX, mouseY, button);
        }
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        for (ModuleComponent component : this.moduleComponents) {
            component.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (this.draggingScrollbar) {
            this.draggingScrollbar = false;
            return;
        }
        for (int i = this.moduleComponents.size() - 1; i >= 0; i--) {
            this.moduleComponents.get(i).mouseReleased(mouseX, mouseY, button);
        }
    }

    public void mouseDragged(double mouseX, double mouseY, int button) {
        if (button == 0 && this.draggingScrollbar && this.scrollbarBox != null) {
            scrollThumbTo(mouseY, this.scrollbarBox);
            return;
        }
        for (int i = this.moduleComponents.size() - 1; i >= 0; i--) {
            this.moduleComponents.get(i).mouseDragged(mouseX, mouseY, button);
        }
    }

    public void mouseScrolled(double mouseX, double mouseY, double delta) {
        if (delta == 0.0D || this.scrollMax <= 0.0F) {
            return;
        }
        this.scrollTarget += (float) delta * 10.0F;
        this.lastScrollMs = System.currentTimeMillis();
    }

    public void charTyped(char codePoint, int modifiers) {
        for (ModuleComponent component : this.moduleComponents) {
            component.charTyped(codePoint, modifiers);
        }
    }

    public boolean isModuleHovered(int mouseX, int mouseY) {
        if (scrollbarGrabbed(mouseX, mouseY)) {
            return true;
        }
        for (ModuleComponent component : this.moduleComponents) {
            if (component.isHovered()) {
                return true;
            }
        }
        return false;
    }
}
