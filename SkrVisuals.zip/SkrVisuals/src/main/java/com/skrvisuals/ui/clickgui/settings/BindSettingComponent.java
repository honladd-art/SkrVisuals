package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.BindSetting;
import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import com.skrvisuals.util.KeyUtil;
import net.minecraft.client.gui.DrawContext;

/**
 * Точь-в-точь порт референсного BindSettingComponent: строка высотой 10,
 * кнопка бинда справа (ширина = текст + 8, высота 16).
 * GLFW-кнопки мыши хранятся как -100 - button (ЛКМ=-100, Mouse4=-103).
 */
public class BindSettingComponent extends SettingComponent {
    private BindSetting bindSetting;

    private boolean binding;

    public BindSettingComponent(Setting setting, ModuleComponent moduleComponent) {
        super(setting, moduleComponent);
    }

    @Override
    public void init() {
        this.bindSetting = (BindSetting) getSetting();
        this.width = 119.5F;
        this.height = 14.0F;
        super.init();
    }

    public boolean isBinding() {
        return this.binding;
    }

    private static String label(int code) {
        if (code == -1)
            return "NONE";
        if (code <= -100)
            return "MOUSE" + (-code - 100 + 1);
        return KeyUtil.name(code);
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        super.render(context, x, y, mouseX, mouseY, delta);
        float alpha = alpha();
        String keyName = label(bindSetting.getKeyCode());
        var font = Fonts.get();
        float keyTextWidth = font.getWidth(keyName);
        float bindButtonWidth = keyTextWidth + 10.0F;
        float bindButtonHeight = 14.0F;
        float bindButtonX = x + this.width - bindButtonWidth - 5.0F;
        float bindButtonY = y;
        int fill = this.binding ? Colors.clientColor() : Colors.moduleBackground();
        int border = this.binding ? Colors.clientColor() : Colors.keyBorder();
        RenderUtil.roundedRect(context, bindButtonX, bindButtonY, bindButtonWidth, bindButtonHeight, 4.0F,
                RenderUtil.withAlpha(fill, alpha));
        RenderUtil.roundedOutline(context, bindButtonX, bindButtonY, bindButtonWidth, bindButtonHeight, 4.0F, 1.0F,
                RenderUtil.withAlpha(border, alpha));
        RenderUtil.drawCenteredString(context, font, keyName, bindButtonX + bindButtonWidth / 2.0F,
                bindButtonY + (bindButtonHeight - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
        RenderUtil.drawString(context, font, setting.getName(), x + 5.0F,
                y + (bindButtonHeight - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        String keyName = label(bindSetting.getKeyCode());
        var font = Fonts.get();
        float keyTextWidth = font.getWidth(keyName);
        float bindButtonWidth = keyTextWidth + 10.0F;
        float bindButtonHeight = 14.0F;
        float bindButtonX = this.x + this.width - bindButtonWidth - 5.0F;
        float bindButtonY = this.y;
        boolean clickedOnBind = mouseX >= bindButtonX && mouseX <= bindButtonX + bindButtonWidth
                && mouseY >= bindButtonY && mouseY <= bindButtonY + bindButtonHeight;
        if (clickedOnBind && button == 0)
            this.binding = true;
        if (this.binding && button != 0) {
            // GLFW-кнопка мыши сохраняется как -100 - button.
            bindSetting.setKeyCode(button == 1 ? -101 : -100 - button);
            this.binding = false;
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.binding) {
            if (keyCode == 256 || keyCode == 261) {
                bindSetting.setKeyCode(-1);
            } else {
                bindSetting.setKeyCode(keyCode);
            }
            this.binding = false;
        }
    }
}
