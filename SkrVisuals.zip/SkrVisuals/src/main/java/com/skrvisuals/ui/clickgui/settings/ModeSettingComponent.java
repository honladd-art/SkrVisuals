package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Точь-в-точь порт референсного ModeSettingComponent: имя + сетка плашек
 * режимов (максимальная ширина 110, зазор 3, высота строки 15).
 */
public class ModeSettingComponent extends SettingComponent {
    private ModeSetting modeSetting;

    private final List<ModeComponent> modeComponents = new ArrayList<>();

    private float notExpandedHeight = 15.0F;

    public ModeSettingComponent(Setting setting, ModuleComponent moduleComponent) {
        super(setting, moduleComponent);
    }

    public ModeSetting getModeSetting() {
        return this.modeSetting;
    }

    @Override
    public void init() {
        this.width = 119.5F;
        this.modeComponents.clear();
        if (!(getSetting() instanceof ModeSetting)) {
            throw new IllegalArgumentException("ModeSettingComponent only supports ModeSetting, got: "
                    + getSetting().getClass().getSimpleName());
        }
        this.modeSetting = (ModeSetting) getSetting();
        for (String mode : modeSetting.getModes()) {
            ModeComponent component = new ModeComponent(mode, this);
            this.modeComponents.add(component);
            component.init();
        }
        float offsetX = 0.0F;
        float offsetY = 0.0F;
        float maxWidth = this.width - 10.0F;
        float gap = 3.0F;
        for (ModeComponent component : this.modeComponents) {
            if (offsetX + component.getWidth() > maxWidth) {
                offsetX = 0.0F;
                offsetY += component.getHeight() + gap;
            }
            offsetX += component.getWidth() + gap;
        }
        if (!this.modeComponents.isEmpty())
            offsetY += 9.0F;
        this.height = this.notExpandedHeight + offsetY - 3.0F;
        super.init();
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        float alpha = alpha();
        float offsetX = 0.0F;
        float offsetY = 0.0F;
        float maxWidth = this.width - 10.0F;
        float gap = 3.0F;
        float startY = y + 11.0F;
        RenderUtil.drawString(context, Fonts.get(), setting.getName(), x + 5.0F, y,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
        for (ModeComponent component : this.modeComponents) {
            if (offsetX + component.getWidth() > maxWidth) {
                offsetX = 0.0F;
                offsetY += component.getHeight() + gap;
            }
            component.render(context, x + 5.0F + offsetX, startY + offsetY, mouseX, mouseY, delta);
            offsetX += component.getWidth() + gap;
        }
        this.height = this.notExpandedHeight + offsetY + 5.0F;
        super.render(context, x, y, mouseX, mouseY, delta);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        for (ModeComponent component : this.modeComponents)
            component.mouseClicked(mouseX, mouseY, button);
    }
}
