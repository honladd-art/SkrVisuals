package com.skrvisuals.ui.mainmenu;

import com.skrvisuals.ui.render.GuiFx;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import com.skrvisuals.ui.theme.Theme;
import com.skrvisuals.ui.theme.UiStyle;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Общие примитивы оформления экранов меню клиента (кнопки, панели, свечение,
 * затемнение) — чтобы кастомные экраны выглядели единообразно.
 */
public final class MenuStyle {

    private MenuStyle() {
    }

    /** Кнопка: {@code accentStyle=true} — залита акцентным цветом темы. */
    public static void button(DrawContext ctx, TextRenderer font, float x, float y, float w, float h,
            String label, boolean hover, boolean accentStyle, float alpha) {
        int accent = Theme.accent();
        int bg = accentStyle
                ? RenderUtil.lerpColor((0x55 << 24) | (accent & 0xFFFFFF), (0xA8 << 24) | (accent & 0xFFFFFF), hover ? 1.0F : 0.0F)
                : RenderUtil.lerpColor(Colors.moduleBackground(), Colors.settingHover(), hover ? 1.0F : 0.0F);
        int border = accentStyle
                ? RenderUtil.lerpColor(RenderUtil.multiplyAlpha(accent, 0.75F), accent, hover ? 1.0F : 0.0F)
                : RenderUtil.lerpColor(Colors.moduleBorder(), accent, hover ? 1.0F : 0.0F);
        RenderUtil.roundedShadow(ctx, x, y, w, h, 8.0F, 0.22F + (hover ? 0.25F : 0.0F));
        RenderUtil.roundedRect(ctx, x, y, w, h, 8.0F, RenderUtil.withAlpha(bg, alpha));
        RenderUtil.roundedOutline(ctx, x, y, w, h, 8.0F, 1.1F, RenderUtil.withAlpha(border, alpha));
        if (hover) {
            RenderUtil.pushScissor(ctx, x, y, w, h);
            GuiFx.shimmer(ctx, x, y, w, h, GuiFx.shimmerPhase(2800L), 0xFFFFFF, 0.16F * alpha);
            RenderUtil.popScissor();
        }
        RenderUtil.drawCenteredString(ctx, font, label, x + w / 2.0F, y + (h - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
    }

    /** Узкая кнопка шапки (назад / обновить): текст слева, рамка акцентится при ховере. */
    public static void headerButton(DrawContext ctx, TextRenderer font, float x, float y, float w, float h,
            String label, boolean hover, float alpha) {
        RenderUtil.roundedRect(ctx, x, y, w, h, 7.0F,
                RenderUtil.withAlpha(RenderUtil.lerpColor(Colors.moduleBackground(), Colors.settingHover(), hover ? 1.0F : 0.0F), alpha));
        RenderUtil.roundedOutline(ctx, x, y, w, h, 7.0F, 1.0F,
                RenderUtil.withAlpha(RenderUtil.lerpColor(Colors.moduleBorder(), Theme.accent(), hover ? 1.0F : 0.0F), alpha));
        RenderUtil.drawString(ctx, font, label, x + 12.0F, y + (h - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
    }

    /** Панель: фон активного стиля, бордер и акцентная полоска сверху. */
    public static void panel(DrawContext ctx, float x, float y, float w, float h, float radius, float alpha) {
        RenderUtil.roundedShadow(ctx, x, y, w, h, radius, 0.5F);
        RenderUtil.roundedRect(ctx, x, y, w, h, radius, RenderUtil.withAlpha(UiStyle.current().guiBackground(), 0.98F * alpha));
        RenderUtil.roundedOutline(ctx, x, y, w, h, radius, 1.0F, RenderUtil.withAlpha(Colors.guiBorder(), alpha));
        RenderUtil.roundedRect(ctx, x + 1.5F, y + 1.5F, w - 3.0F, 2.6F, 2.0F, RenderUtil.withAlpha(Theme.accent(), alpha));
    }

    /** Мягкое радиальное свечение из концентрических кругов. */
    public static void glow(DrawContext ctx, float cx, float cy, float radius, int color, int steps) {
        float a0 = ((color >>> 24) & 0xFF) / 255.0F;
        if (a0 <= 0.001F) {
            return;
        }
        for (int i = steps; i >= 1; i--) {
            float t = 1.0F - i / (float) steps;
            RenderUtil.circle(ctx, cx, cy, radius * (i / (float) steps), RenderUtil.withAlpha(color & 0xFFFFFF, a0 * t));
        }
    }

    /** Фон полноэкранного экрана меню: градиент стиля + мягкое акцентное свечение. */
    public static void backdrop(DrawContext ctx, int width, int height, float time, float alpha) {
        int base = UiStyle.current().screenBackground();
        RenderUtil.fill4(ctx, 0, 0, width, height,
                Colors.lighten(base, 0.03F), base, base, Colors.lighten(base, 0.03F));
        int glowColor = RenderUtil.withAlpha(Theme.accent(), (0.05F + 0.02F * (float) Math.sin(time * 0.9F)) * alpha);
        glow(ctx, width * 0.5F, -80.0F, height * 0.55F, glowColor, 14);
    }

    public static void setRect(float[] rect, float x, float y, float w, float h) {
        rect[0] = x;
        rect[1] = y;
        rect[2] = w;
        rect[3] = h;
    }

    public static float clamp01(float v) {
        return Math.max(0.0F, Math.min(1.0F, v));
    }
}