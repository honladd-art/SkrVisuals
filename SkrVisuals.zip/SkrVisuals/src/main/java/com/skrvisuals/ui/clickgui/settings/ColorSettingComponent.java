package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.ColorSetting;
import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

/**
 * Точь-в-точь порт референсного ColorSettingComponent: строка с превью-точкой
 * справа, по клику раскрывается SV-пикер (109.5x70) + hue-бар (8px).
 */
public class ColorSettingComponent extends SettingComponent {
    private ColorSetting colorSetting;

    private boolean expanded = false;
    private boolean draggingHue = false;
    private boolean draggingSV = false;
    private boolean interacting = false;

    private float hue = 0.0F;
    private float saturation = 1.0F;
    private float brightness = 1.0F;

    private final Animation hueAnimation = new Animation(Easing.EASE_OUT_CUBIC, 200L);
    private final Animation saturationAnimation = new Animation(Easing.EASE_OUT_CUBIC, 200L);
    private final Animation brightnessAnimation = new Animation(Easing.EASE_OUT_CUBIC, 200L);

    private float pickerWidth = 109.5F;
    private float pickerHeight = 70.0F;
    private float hueBarHeight = 8.0F;

    public ColorSettingComponent(Setting setting, ModuleComponent moduleComponent) {
        super(setting, moduleComponent);
    }

    @Override
    public void init() {
        this.colorSetting = (ColorSetting) getSetting();
        this.width = 119.5F;
        this.height = 15.0F;
        if (!this.interacting) {
            int rgb = colorSetting.getValue();
            float[] hsb = Color.RGBtoHSB((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, null);
            this.hue = hsb[0];
            this.saturation = hsb[1];
            this.brightness = hsb[2];
            this.hueAnimation.setValue(hue);
            this.saturationAnimation.setValue(saturation);
            this.brightnessAnimation.setValue(brightness);
        }
        super.init();
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        super.render(context, x, y, mouseX, mouseY, delta);
        float alpha = alpha();
        if (!draggingSV) {
            saturationAnimation.run(saturation);
            brightnessAnimation.run(brightness);
        }
        if (!draggingHue)
            hueAnimation.run(hue);

        float previewSize = 8.0F;
        float previewX = x + this.width - previewSize - 5.0F;
        float previewY = y + 3.5F;
        this.height = 15.0F;
        this.pickerWidth = this.width - 10.0F;
        int currentColor = colorSetting.getValue();
        RenderUtil.circle(context, previewX + previewSize / 2F, previewY + previewSize / 2F, previewSize / 2F + 1.5F,
                RenderUtil.withAlpha(Colors.keyBorder(), alpha));
        RenderUtil.circle(context, previewX + previewSize / 2F, previewY + previewSize / 2F, previewSize / 2F,
                RenderUtil.withAlpha(currentColor, alpha));

        RenderUtil.drawString(context, Fonts.get(), setting.getName(), x + 5.0F, y + 4.0F,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));

        float pickerX = x + 5.0F;
        float pickerY = y + 18.0F;
        this.height = expanded ? 18.0F + this.pickerHeight + 5.0F + this.hueBarHeight + 5.0F : 15.0F;
        if (!expanded)
            return;

        // --- SV-область.
        float sat = saturationAnimation.getValue();
        float bri = brightnessAnimation.getValue();
        int baseHue = Color.HSBtoRGB(hue, 1.0F, 1.0F) | 0xFF000000;
        int steps = 14;
        for (int i = 0; i < steps; i++) {
            float t0 = i / (float) steps;
            float t1 = (i + 1) / (float) steps;
            int c0 = svGradient(baseHue, t0);
            int c1 = svGradient(baseHue, t1);
            RenderUtil.fill4(context, pickerX + t0 * pickerWidth, pickerY,
                    pickerX + t1 * pickerWidth, pickerY + pickerHeight, c0, c1, c1, c0);
        }
        // Затемнение к чёрному снизу.
        for (int i = 0; i < steps; i++) {
            float t0 = i / (float) steps;
            RenderUtil.fill(context, pickerX, pickerY + t0 * pickerHeight, pickerWidth,
                    pickerHeight / steps + 0.5F, RenderUtil.withAlpha(0xFF000000, t0));
        }
        float svX = pickerX + sat * pickerWidth;
        float svY = pickerY + (1.0F - bri) * pickerHeight;
        RenderUtil.circleOutline(context, svX, svY, 3.0F, 1.5F, RenderUtil.withAlpha(0xFFFFFFFF, alpha));

        // --- Hue-бар.
        float hueBarY = pickerY + this.pickerHeight + 5.0F;
        for (int i = 0; i < steps; i++) {
            float t0 = i / (float) steps;
            float t1 = (i + 1) / (float) steps;
            int c0 = Color.HSBtoRGB(t0, 1.0F, 1.0F) | 0xFF000000;
            int c1 = Color.HSBtoRGB(t1, 1.0F, 1.0F) | 0xFF000000;
            RenderUtil.fill4(context, pickerX + t0 * pickerWidth, hueBarY,
                    pickerX + t1 * pickerWidth, hueBarY + this.hueBarHeight, c0, c1, c1, c0);
        }
        float handleX = pickerX + hueAnimation.getValue() * pickerWidth;
        handleX = Math.max(pickerX, Math.min(pickerX + pickerWidth, handleX));
        RenderUtil.roundedRect(context, handleX - 4.0F, hueBarY - 1.0F, 8.0F, hueBarHeight + 2.0F, 4.0F,
                RenderUtil.withAlpha(0xFF000000, alpha));
        RenderUtil.roundedOutline(context, handleX - 4.0F, hueBarY - 1.0F, 8.0F, hueBarHeight + 2.0F, 4.0F, 1.5F,
                RenderUtil.withAlpha(0xFFFFFFFF, alpha));
        this.hoveringClickableArea = RenderUtil.hovered(mouseX, mouseY, pickerX, pickerY,
                pickerWidth, pickerHeight + 5.0F + hueBarHeight);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            float previewSize = 8.0F;
            float previewX = this.x + this.width - previewSize - 5.0F;
            float previewY = this.y + 3.5F;
            if (mouseX >= previewX && mouseX <= previewX + previewSize
                    && mouseY >= previewY && mouseY <= previewY + previewSize) {
                this.expanded = !this.expanded;
                return;
            }
            if (this.expanded) {
                float pickerX = this.x + 5.0F;
                float pickerY = this.y + 18.0F;
                if (mouseX >= pickerX && mouseX <= pickerX + this.pickerWidth
                        && mouseY >= pickerY && mouseY <= pickerY + this.pickerHeight) {
                    this.draggingSV = true;
                    this.interacting = true;
                    this.saturation = Math.max(0.0F, Math.min(1.0F, (float) (mouseX - pickerX) / this.pickerWidth));
                    this.brightness = 1.0F - Math.max(0.0F,
                            Math.min(1.0F, (float) (mouseY - pickerY) / this.pickerHeight));
                    this.saturationAnimation.setValue(this.saturation);
                    this.brightnessAnimation.setValue(this.brightness);
                    updateColor();
                    return;
                }
                float hueBarY = pickerY + this.pickerHeight + 5.0F;
                if (mouseX >= pickerX && mouseX <= pickerX + this.pickerWidth
                        && mouseY >= hueBarY && mouseY <= hueBarY + this.hueBarHeight) {
                    this.draggingHue = true;
                    this.interacting = true;
                    this.hue = Math.max(0.0F, Math.min(1.0F, (float) (mouseX - pickerX) / this.pickerWidth));
                    this.hueAnimation.setValue(this.hue);
                    updateColor();
                }
            }
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && (this.draggingHue || this.draggingSV)) {
            this.draggingHue = false;
            this.draggingSV = false;
            this.interacting = false;
        }
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button) {
        if (button != 0)
            return;
        float pickerX = this.x + 5.0F;
        float pickerY = this.y + 18.0F;
        if (this.draggingSV) {
            this.saturation = Math.max(0.0F, Math.min(1.0F, (float) (mouseX - pickerX) / this.pickerWidth));
            this.brightness = 1.0F - Math.max(0.0F, Math.min(1.0F, (float) (mouseY - pickerY) / this.pickerHeight));
            this.saturationAnimation.setValue(this.saturation);
            this.brightnessAnimation.setValue(this.brightness);
            updateColor();
        } else if (this.draggingHue) {
            this.hue = Math.max(0.0F, Math.min(1.0F, (float) (mouseX - pickerX) / this.pickerWidth));
            this.hueAnimation.setValue(this.hue);
            updateColor();
        }
    }

    private void updateColor() {
        int rgb = Color.HSBtoRGB(this.hue, this.saturation, this.brightness);
        this.colorSetting.setValue(0xFF000000 | rgb);
    }

    /** Цвет SV-градиента: hue базовый, насыщенность по X, яркость 1. */
    private static int svGradient(int baseHue, float t) {
        Color base = new Color(baseHue);
        float[] hsb = Color.RGBtoHSB(base.getRed(), base.getGreen(), base.getBlue(), null);
        return Color.HSBtoRGB(hsb[0], t, 1.0F) | 0xFF000000;
    }
}
