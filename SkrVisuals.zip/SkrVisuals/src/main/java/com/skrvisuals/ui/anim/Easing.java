package com.skrvisuals.ui.anim;

/**
 * Easing functions used by {@link Animation}.
 */
public enum Easing {
    LINEAR,
    EASE_OUT_CUBIC,
    EASE_IN_OUT_CUBIC,
    EASE_IN_OUT_SINE,
    EASE_OUT_BACK,
    EASE_IN_OUT_QUINT;

    /** Evaluate the easing curve for progress {@code t} in [0, 1]. */
    public double ease(double t) {
        t = clamp01(t);
        switch (this) {
            case LINEAR:
                return t;
            case EASE_OUT_CUBIC: {
                double x = 1.0 - t;
                return 1.0 - x * x * x;
            }
            case EASE_IN_OUT_CUBIC: {
                double x;
                if (t < 0.5) {
                    x = 2.0 * t;
                    return 0.5 * x * x * x;
                }
                x = 1.0 - (2.0 * t - 1.0);
                return 0.5 + 0.5 * (1.0 - x * x * x);
            }
            case EASE_IN_OUT_SINE:
                return 0.5 - 0.5 * Math.cos(Math.PI * t);
            case EASE_OUT_BACK: {
                double c1 = 1.70158;
                double c3 = c1 + 1.0;
                double x = t - 1.0;
                return 1.0 + c3 * x * x * x + c1 * x * x;
            }
            case EASE_IN_OUT_QUINT: {
                double x;
                if (t < 0.5) {
                    x = 2.0 * t;
                    return 0.5 * x * x * x * x * x;
                }
                x = 2.0 * (1.0 - t);
                return 1.0 - 0.5 * x * x * x * x * x;
            }
            default:
                return t;
        }
    }

    public float ease(float t) {
        return (float) ease((double) t);
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}