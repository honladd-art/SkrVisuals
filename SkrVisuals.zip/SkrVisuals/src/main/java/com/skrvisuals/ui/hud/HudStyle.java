package com.skrvisuals.ui.hud;

import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;

import net.minecraft.client.gui.DrawContext;

/**
 * Single source of truth for the HUD look: a dark "glass island" pill with an
 * accent glow, a hairline border and a short glowing accent line underneath.
 *
 * <p>Every HUD element (watermark, target HUD, keystrokes, coordinates, potions,
 * armor, inventory, notifications, music player) draws through {@link #island}
 * so the whole interface reads as one set.
 */
public final class HudStyle {
    /** Default corner radius of a HUD panel. */
    public static final float RADIUS = 6f;
    /** Corner radius for pill-shaped elements (watermark). */
    public static final float PILL = 11f;

    private HudStyle() {
    }

    /**
     * Draws the standard HUD panel: soft shadow, accent glow, dark glass body,
     * hairline border and the accent underline.
     *
     * @param alpha 0..1 combined with {@link RenderUtil#hudOpacity}
     */
    public static void island(DrawContext ctx, float x, float y, float w, float h, float radius, float alpha) {
        if (w <= 0 || h <= 0 || alpha <= 0.004f) {
            return;
        }
        int accent = Colors.clientColor();

        RenderUtil.roundedShadow(ctx, x, y, w, h, radius, 0.55f * alpha);
        RenderUtil.roundedGlow(ctx, x, y, w, h, radius, accent, 0.75f * alpha);

        // Dark glass body, slightly lighter at the top.
        RenderUtil.roundedGradient(ctx, x, y, w, h, radius,
                RenderUtil.withAlpha(0xFF12141C, 0.82f * alpha),
                RenderUtil.withAlpha(0xFF0A0B11, 0.88f * alpha));

        // Top inner highlight — sells the "glass" look.
        RenderUtil.roundedRect(ctx, x + radius * 0.6f, y + 0.7f, w - radius * 1.2f, 0.8f, 0.4f,
                RenderUtil.withAlpha(0xFFFFFFFF, 0.07f * alpha));

        RenderUtil.roundedOutline(ctx, x, y, w, h, radius, 1f,
                RenderUtil.withAlpha(Colors.guiBorder(), 0.85f * alpha));

        RenderUtil.accentUnderline(ctx, x, y, w, h, accent, 0.75f * alpha);
    }

    /** Panel without the accent underline (used by list-like panels). */
    public static void islandPlain(DrawContext ctx, float x, float y, float w, float h, float alpha) {
        island(ctx, x, y, w, h, RADIUS, alpha);
    }

    /** Small vertical accent bar on the left edge of a panel. */
    public static void accentBar(DrawContext ctx, float x, float y, float h, float alpha) {
        RenderUtil.roundedRect(ctx, x + 2.5f, y + 4f, 1.6f, h - 8f, 0.8f,
                RenderUtil.withAlpha(Colors.clientColor(), alpha));
    }

    /** Dim round separator used between HUD sections. */
    public static void dot(DrawContext ctx, float cx, float cy, float alpha) {
        RenderUtil.circle(ctx, cx, cy, 0.9f,
                RenderUtil.withAlpha(Colors.textDescription(), 0.55f * alpha));
    }

    /** Horizontal hairline separator inside a panel. */
    public static void separator(DrawContext ctx, float x, float y, float w, float alpha) {
        RenderUtil.fill(ctx, x, y, w, 0.7f,
                RenderUtil.withAlpha(Colors.textPrimary(), 0.16f * alpha));
    }

    /**
     * Animated 5-bar equalizer used as a live "something is playing" indicator.
     *
     * @param playing whether the bars should dance (otherwise they sit flat)
     */
    public static void equalizer(DrawContext ctx, float x, float centerY, boolean playing, float alpha) {
        int accent = Colors.clientColor();
        float gap = 2.4f;
        float barW = 1.6f;
        long now = System.currentTimeMillis();
        for (int i = 0; i < 5; i++) {
            float wave = playing ? (float) Math.sin(now / 145.0 + i * 1.2) : 0f;
            float barH = 4.2f + (wave + 1f) * 2.1f;
            RenderUtil.roundedRect(ctx, x + i * gap, centerY - barH / 2f, barW, barH, barW / 2f,
                    RenderUtil.withAlpha(accent, (playing ? 0.95f : 0.5f) * alpha));
        }
    }

    /** Width of the equalizer produced by {@link #equalizer}. */
    public static float equalizerWidth() {
        return 5 * 2.4f;
    }
}