package com.skrvisuals.ui.clickgui;

import com.skrvisuals.modules.Module;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Точь-в-точь порт референсного ModuleTooltip: появляется после 300мс ховера,
 * центрируется над карточкой, обводка акцентом с альфой 0.3.
 */
public class ModuleTooltip {
    private Module module;

    private float guiX;
    private float guiY;
    private float guiWidth;

    private final Animation alphaAnimation = new Animation(Easing.EASE_OUT_CUBIC, 150L);

    private long hoverStartTime = 0L;

    private boolean shouldShow = false;

    private static final long HOVER_DELAY = 300L;
    private static final float PADDING = 10.0F;
    private static final float LINE_HEIGHT = 14.0F;

    public void setModule(Module module) { this.module = module; }
    public Module getModule() { return this.module; }

    public void update(Module module, boolean hovered, float guiX, float guiY, float guiWidth) {
        if (hovered && module != null && module.getDescription() != null && !module.getDescription().isEmpty()) {
            if (this.module != module) {
                this.module = module;
                this.hoverStartTime = System.currentTimeMillis();
                this.shouldShow = false;
            }
            if (System.currentTimeMillis() - this.hoverStartTime >= HOVER_DELAY) {
                this.shouldShow = true;
            }
            this.guiX = guiX;
            this.guiY = guiY;
            this.guiWidth = guiWidth;
        } else {
            this.shouldShow = false;
            if (this.alphaAnimation.getValue() < 0.01F) {
                this.module = null;
                this.hoverStartTime = 0L;
            }
        }
        this.alphaAnimation.run(this.shouldShow ? 1.0F : 0.0F);
    }

    public void render(DrawContext context, int screenWidth, int screenHeight) {
        if (this.module == null || this.alphaAnimation.getValue() < 0.01F) {
            return;
        }
        String description = this.module.getDescription();
        if (description == null || description.isEmpty()) {
            return;
        }
        float alpha = this.alphaAnimation.getValue();
        float maxWidth = 220.0F;
        List<String> lines = wrapText(description, maxWidth - 20.0F);
        var font = Fonts.get();
        float lineHeight = LINE_HEIGHT;
        float textHeight = lines.size() * lineHeight;
        float maxLineWidth = 0.0F;
        for (String line : lines) {
            float lineWidth = font.getWidth(line);
            if (lineWidth > maxLineWidth) {
                maxLineWidth = lineWidth;
            }
        }
        float tooltipWidth = maxLineWidth + 20.0F;
        float tooltipHeight = textHeight + 20.0F;
        float tooltipX = this.guiX + (this.guiWidth - tooltipWidth) / 2.0F;
        float offset = (1.0F - alpha) * 8.0F;
        float tooltipY = this.guiY - tooltipHeight - 10.0F + offset;
        if (tooltipX < 10.0F) {
            tooltipX = 10.0F;
        }
        if (tooltipX + tooltipWidth > screenWidth - 10) {
            tooltipX = screenWidth - tooltipWidth - 10.0F;
        }
        // Если сверху места нет — показываем подсказку под карточкой.
        if (tooltipY < 10.0F) {
            float below = this.guiY + 38.0F + offset;
            tooltipY = (below + tooltipHeight <= screenHeight - 10.0F) ? below : 10.0F;
        }

        RenderUtil.roundedOutline(context, tooltipX, tooltipY, tooltipWidth, tooltipHeight, 6.0F, 1.5F,
                RenderUtil.withAlpha(Colors.clientColor(), alpha * 0.3F));
        RenderUtil.roundedRect(context, tooltipX, tooltipY, tooltipWidth, tooltipHeight, 6.0F,
                RenderUtil.withAlpha(Colors.moduleBackground(), alpha * 0.95F));
        // Акцентная полоса слева.
        RenderUtil.roundedRect(context, tooltipX + 1.5F, tooltipY + 1.5F, 2.0F, tooltipHeight - 3.0F, 1.0F,
                RenderUtil.withAlpha(Colors.clientColor(), alpha * 0.85F));
        float startY = tooltipY + (tooltipHeight - textHeight) / 2.0F + 2.0F;
        for (String line : lines) {
            float lineWidth = font.getWidth(line);
            float lineX = tooltipX + (tooltipWidth - lineWidth) / 2.0F;
            RenderUtil.drawString(context, font, line, lineX, startY,
                    RenderUtil.withAlpha(Colors.textPrimary(), alpha));
            startY += lineHeight;
        }
    }

    private List<String> wrapText(String text, float maxWidth) {
        List<String> lines = new ArrayList<>();
        var font = Fonts.get();
        String[] words = text.split(" ");
        StringBuilder currentLine = new StringBuilder();
        for (String word : words) {
            String testLine = currentLine.length() == 0 ? word : currentLine + " " + word;
            float testWidth = font.getWidth(testLine);
            if (testWidth > maxWidth && currentLine.length() > 0) {
                lines.add(currentLine.toString());
                currentLine = new StringBuilder(word);
            } else {
                if (currentLine.length() > 0) {
                    currentLine.append(" ");
                }
                currentLine.append(word);
            }
        }
        if (currentLine.length() > 0) {
            lines.add(currentLine.toString());
        }
        return lines;
    }

    public void reset() {
        this.module = null;
        this.shouldShow = false;
        this.hoverStartTime = 0L;
        this.alphaAnimation.setValue(0.0F);
    }
}
