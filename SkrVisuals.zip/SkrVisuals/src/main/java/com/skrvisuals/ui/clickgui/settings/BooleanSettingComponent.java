package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

/**
 * Точь-в-точь порт референсного BooleanSettingComponent:
 * квадратный тумблер 9x9 в позиции (x+5, y-3), высота строки 10.
 */
public class BooleanSettingComponent extends SettingComponent {
    private BooleanSetting booleanSetting;

    private boolean hoveringToggle;

    public BooleanSettingComponent(Setting setting, ModuleComponent moduleComponent) {
        super(setting, moduleComponent);
    }

    @Override
    public void init() {
        this.booleanSetting = (BooleanSetting) getSetting();
        this.width = 119.5F;
        this.height = 10.0F;
        super.init();
    }

    @Override
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        super.render(context, x, y, mouseX, mouseY, delta);
        float toggleX = x + 5.0F;
        float toggleY = y + 0.5F;
        float toggleWidth = 9.0F;
        float toggleHeight = 9.0F;
        this.hoveringToggle = mouseX >= toggleX && mouseX <= toggleX + toggleWidth
                && mouseY >= toggleY && mouseY <= toggleY + toggleHeight;
        float alpha = alpha();
        int fill = booleanSetting.getValue() ? Colors.clientColor() : Colors.moduleBackground();
        int border = booleanSetting.getValue() ? Colors.clientColor() : Colors.keyBorder();
        RenderUtil.roundedRect(context, toggleX, toggleY, toggleWidth, toggleHeight, 2.0F,
                RenderUtil.withAlpha(fill, alpha));
        RenderUtil.roundedOutline(context, toggleX, toggleY, toggleWidth, toggleHeight, 2.0F, 1.0F,
                RenderUtil.withAlpha(border, alpha));

        // Галочка внутри включённого тумблера.
        if (booleanSetting.getValue()) {
            int check = RenderUtil.withAlpha(0xFF000000, alpha);
            float cx = toggleX + 4.5F;
            float cy = toggleY + 4.5F;
            RenderUtil.fill(context, cx - 2.0F, cy, 1.5F, 1.5F, check);
            RenderUtil.fill(context, cx - 1.0F, cy + 1.0F, 1.5F, 1.5F, check);
            RenderUtil.fill(context, cx + 0.5F, cy, 1.5F, 1.5F, check);
            RenderUtil.fill(context, cx + 1.5F, cy - 1.0F, 1.5F, 1.5F, check);
        }

        var font = Fonts.get();
        RenderUtil.drawString(context, font, setting.getName(), x + 9.0F + 5.0F + 3.0F, y,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        float toggleX = this.x + 5.0F;
        float toggleY = this.y + 0.5F;
        boolean clickedOnToggle = mouseX >= toggleX && mouseX <= toggleX + 9.0F
                && mouseY >= toggleY && mouseY <= toggleY + 9.0F;
        if (clickedOnToggle && button == 0) {
            booleanSetting.toggle();
        }
    }
}
