package com.skrvisuals.ui.clickgui.settings;

import com.skrvisuals.modules.settings.Setting;
import com.skrvisuals.ui.clickgui.ClickScreen;
import com.skrvisuals.ui.clickgui.ModuleComponent;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.gui.DrawContext;

/**
 * Точь-в-точь порт референсного SettingComponent: базовый класс строки
 * настройки внутри модуля (x/y/width/height=20, hoveringClickableArea).
 */
public abstract class SettingComponent {
    protected float x;
    protected float y;
    protected float width;
    protected float height = 20.0F;

    protected boolean hoveringClickableArea;

    protected Setting setting;

    protected final ModuleComponent moduleComponent;

    public float getX() { return this.x; }
    public float getY() { return this.y; }
    public float getWidth() { return this.width; }
    public float getHeight() { return this.height; }
    public boolean isHoveringClickableArea() { return this.hoveringClickableArea; }

    public void setX(float x) { this.x = x; }
    public void setY(float y) { this.y = y; }
    public void setWidth(float width) { this.width = width; }
    public void setHeight(float height) { this.height = height; }

    public Setting getSetting() { return this.setting; }
    public ModuleComponent getModuleComponent() { return this.moduleComponent; }

    public SettingComponent(Setting setting, ModuleComponent moduleComponent) {
        this.setting = setting;
        this.moduleComponent = moduleComponent;
    }

    public void init() {
    }

    /** Референсная сигнатура: координаты приходят извне каждый кадр. */
    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        this.x = x;
        this.y = y;
        this.width = this.moduleComponent.getWidth();
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    public void mouseDragged(double mouseX, double mouseY, int button) {
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
    }

    public void charTyped(char codePoint, int modifiers) {
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height;
    }

    /** Альфа текущего GUI. */
    protected float alpha() {
        ClickScreen gui = getClickGUI();
        return gui != null ? gui.getAlpha() : 1.0F;
    }

    protected ClickScreen getClickGUI() {
        return (ClickScreen) net.minecraft.client.MinecraftClient.getInstance().currentScreen;
    }
}
