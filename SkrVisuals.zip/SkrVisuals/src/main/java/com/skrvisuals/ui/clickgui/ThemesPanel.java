package com.skrvisuals.ui.clickgui;

import java.util.ArrayList;
import java.util.List;

import com.skrvisuals.config.ConfigManager;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.GuiFx;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import com.skrvisuals.ui.theme.Theme;
import com.skrvisuals.ui.theme.UiStyle;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/**
 * Секция «Themes»: переключатель стиля интерфейса, сетка 3×N акцентных
 * пресетов и компактный SV-пикер для пользовательского цвета.
 */
public class ThemesPanel {
    private static final float MARGIN = 14.0F;
    private static final float GAP = 8.0F;
    private static final float CARD_H = 26.0F;

    private final ClickScreen gui;

    /** Хитбоксы карточек, пересобираются каждый кадр. */
    private final List<Card> cards = new ArrayList<>();
    private final java.util.Map<Theme, Animation> hoverAnims = new java.util.HashMap<>();

    /** Кружки переключателя стилей интерфейса (тёмная / фиолетовая / светлая). */
    private final List<float[]> styleDots = new ArrayList<>();

    // --- Пикер пользовательского цвета (SV-градиент + hue-бар) ---
    private final float[] svRect = new float[4];
    private final float[] hueRect = new float[4];
    private float hue = 0f;
    private float sat = 1f;
    private float bri = 1f;
    /** Активное перетаскивание в пикере (можно зажать и вести мышь). */
    private boolean draggingSV = false;
    private boolean draggingHue = false;

    public ThemesPanel(ClickScreen gui) {
        this.gui = gui;
    }

    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.cards.clear();
        float alpha = gui.getAlpha();
        TextRenderer font = Fonts.get();

        float contentX = gui.getContentX();
        float contentW = gui.getContentWidth();
        float left = contentX + MARGIN;
        float top = gui.getContentTop() + 2.0F;

        // Переключатель стилей интерфейса.
        renderStyleSwitcher(ctx, font, left, top, alpha, mouseX, mouseY);
        float gridTop = top + 44.0F;

        int columns = 3;
        float cardW = (contentW - MARGIN * 2.0F - GAP * (columns - 1)) / columns;
        int cardIndex = 0;
        for (Theme theme : Theme.values()) {
            int col = cardIndex % columns;
            int row = cardIndex / columns;
            float cardX = left + col * (cardW + GAP);
            float cardY = gridTop + row * (CARD_H + GAP);
            boolean hovered = RenderUtil.hovered(mouseX, mouseY, cardX, cardY, cardW, CARD_H);
            Card card = new Card(cardX, cardY, cardW, CARD_H, theme, hovered);
            this.cards.add(card);

            Animation hov = this.hoverAnims.computeIfAbsent(theme,
                    k -> new Animation(Easing.EASE_OUT_CUBIC, 160L));
            hov.run(hovered ? 1.0F : 0.0F);
            float hv = hov.getValue();
            float entrance = GuiFx.stagger(gui.getContentTime(), cardIndex, 35L, 300L);
            float a = alpha * entrance;
            boolean active = Theme.current() == theme;
            int preview = previewColor(theme);

            int bg = Colors.moduleBackground();
            if (active) {
                bg = RenderUtil.lerpColor(Colors.moduleBackground(), preview, 0.22F);
            } else if (hv > 0.01F) {
                bg = RenderUtil.lerpColor(Colors.moduleBackground(), Colors.settingHover(), hv);
            }
            RenderUtil.roundedRect(ctx, cardX, cardY - hv * 1.5F, cardW, CARD_H, 7.0F,
                    RenderUtil.withAlpha(bg, a));
            RenderUtil.roundedOutline(ctx, cardX, cardY - hv * 1.5F, cardW, CARD_H, 7.0F, 1.0F,
                    RenderUtil.withAlpha(active ? Colors.clientColor()
                            : RenderUtil.lerpColor(Colors.moduleBorder(), Colors.moduleBorderHover(), hv), a));

            // Кружок-превью акцентного цвета.
            float dotR = 5.0F;
            float dotCx = cardX + 14.0F;
            float dotCy = cardY - hv * 1.5F + CARD_H / 2.0F;
            RenderUtil.circle(ctx, dotCx, dotCy, dotR + 1.2F,
                    RenderUtil.withAlpha(Colors.guiBorder(), a));
            RenderUtil.circle(ctx, dotCx, dotCy, dotR, RenderUtil.withAlpha(preview, a));

            String label = theme == Theme.CUSTOM ? "Свой" : theme.getDisplayName();
            RenderUtil.pushScissor(ctx, cardX, cardY, cardW, CARD_H);
            RenderUtil.drawString(ctx, font, label, cardX + 26.0F,
                    cardY - hv * 1.5F + (CARD_H - font.fontHeight) / 2.0F,
                    RenderUtil.withAlpha(active ? Colors.textPrimary() : Colors.textDescription(), a));
            RenderUtil.popScissor();
            cardIndex++;
        }

        // Пикер пользовательского цвета.
        if (Theme.current() == Theme.CUSTOM) {
            float pickerTop = gridTop + 3.0F * (CARD_H + GAP) + 8.0F;
            renderCustomPicker(ctx, font, left, pickerTop, contentW - MARGIN * 2.0F, alpha, mouseX, mouseY);
        }
    }

    /** Переключатель стиля интерфейса: подпись + три плитки-палитры. */
    private void renderStyleSwitcher(DrawContext ctx, TextRenderer font, float left, float top,
                                     float alpha, int mouseX, int mouseY) {
        this.styleDots.clear();
        RenderUtil.drawString(ctx, font, "Стиль интерфейса", left, top,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));

        float dotsY = top + 16.0F;
        float size = 18.0F;
        float gap = 8.0F;
        UiStyle[] styles = UiStyle.values();
        for (int i = 0; i < styles.length; i++) {
            UiStyle style = styles[i];
            float dx = left + i * (size + gap);
            boolean hovered = RenderUtil.hovered(mouseX, mouseY, dx, dotsY, size, size);
            boolean active = UiStyle.current() == style;
            int swatch = style.swatch();
            RenderUtil.roundedRect(ctx, dx, dotsY, size, size, 6.0F,
                    RenderUtil.withAlpha(RenderUtil.lerpColor(Colors.moduleBackground(), swatch, 0.85F), alpha));
            RenderUtil.roundedOutline(ctx, dx, dotsY, size, size, 6.0F, 1.0F,
                    RenderUtil.withAlpha(active ? Colors.clientColor()
                            : RenderUtil.lerpColor(Colors.moduleBorder(), Colors.moduleBorderHover(),
                            hovered ? 1.0F : 0.0F), alpha * (active ? 1.0F : 0.8F)));
            this.styleDots.add(new float[]{dx, dotsY, size, size, i});
        }
    }

    /** Компактный SV-пикер: квадрат насыщенность/яркость + hue-полоса + превью. */
    private void renderCustomPicker(DrawContext ctx, TextRenderer font, float left, float top,
                                    float width, float alpha, int mouseX, int mouseY) {
        RenderUtil.drawString(ctx, font, "Свой цвет", left, top,
                RenderUtil.withAlpha(Colors.textPrimary(), alpha));

        float svY = top + 14.0F;
        float svH = 42.0F;
        this.svRect[0] = left;
        this.svRect[1] = svY;
        this.svRect[2] = width;
        this.svRect[3] = svH;

        // Насыщенность по X (белый -> чистый hue), затем яркость по Y (прозрачный -> чёрный).
        RenderUtil.fillGradientH(ctx, left, svY, width, svH,
                RenderUtil.withAlpha(0xFFFFFFFF, alpha), RenderUtil.withAlpha(hueColor(hue), alpha));
        RenderUtil.fillGradient(ctx, left, svY, width, svH,
                RenderUtil.multiplyAlpha(0x000000, alpha), RenderUtil.withAlpha(0xFF000000, alpha));
        RenderUtil.roundedOutline(ctx, left, svY, width, svH, 5.0F, 1.0F,
                RenderUtil.withAlpha(Colors.guiBorder(), alpha * 0.8F));

        // Маркер выбранного цвета.
        float markerX = left + MathHelper.clamp(sat, 0f, 1f) * width;
        float markerY = svY + (1.0F - MathHelper.clamp(bri, 0f, 1f)) * svH;
        RenderUtil.circleOutline(ctx, markerX, markerY, 4.0F, 1.5F,
                RenderUtil.withAlpha(0xFFFFFFFF, alpha));
        RenderUtil.circleOutline(ctx, markerX, markerY, 5.5F, 1.0F,
                RenderUtil.withAlpha(0x80000000, alpha));

        // Hue-полоса.
        float hueY = svY + svH + 8.0F;
        float hueH = 8.0F;
        this.hueRect[0] = left;
        this.hueRect[1] = hueY;
        this.hueRect[2] = width;
        this.hueRect[3] = hueH;

        int steps = 24;
        float radius = hueH / 2.0F;
        for (int i = 0; i < steps; i++) {
            float t0 = i / (float) steps;
            float t1 = (i + 1) / (float) steps;
            float sx = left + t0 * width;
            float ex = left + t1 * width;
            RenderUtil.fill4(ctx, sx, hueY, ex, hueY + hueH,
                    RenderUtil.withAlpha(hueColor(t0), alpha), RenderUtil.withAlpha(hueColor(t0), alpha),
                    RenderUtil.withAlpha(hueColor(t1), alpha), RenderUtil.withAlpha(hueColor(t1), alpha));
        }
        RenderUtil.roundedOutline(ctx, left, hueY, width, hueH, radius, 1.0F,
                RenderUtil.withAlpha(Colors.guiBorder(), alpha * 0.8F));
        float hueMarkerX = left + MathHelper.clamp(hue, 0f, 1f) * width;
        RenderUtil.roundedRect(ctx, hueMarkerX - 1.5F, hueY - 1.5F, 3.0F, hueH + 3.0F, 1.5F,
                RenderUtil.withAlpha(0xFFFFFFFF, alpha));

        // Превью выбранного цвета слева-снизу.
        float previewY = hueY + hueH + 10.0F;
        float previewSize = 14.0F;
        RenderUtil.roundedRect(ctx, left, previewY, previewSize, previewSize, 4.0F,
                RenderUtil.withAlpha(Theme.customColor(), alpha));
        RenderUtil.roundedOutline(ctx, left, previewY, previewSize, previewSize, 4.0F, 1.0F,
                RenderUtil.withAlpha(Colors.guiBorder(), alpha * 0.8F));
        String hex = String.format("#%06X", Theme.customColor() & 0xFFFFFF);
        RenderUtil.drawString(ctx, font, hex, left + previewSize + 8.0F,
                previewY + (previewSize - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(Colors.textMuted(), alpha));
    }

    /** Чистый цвет по hue (S=1, V=1). */
    private static int hueColor(float hue) {
        return 0xFF000000 | java.awt.Color.HSBtoRGB(MathHelper.clamp(hue, 0f, 1f), 1.0F, 1.0F);
    }

    // ---------------------------------------------------------------- input
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return;
        }
        float mx = (float) mouseX;
        float my = (float) mouseY;

        // Пикер пользовательского цвета.
        if (Theme.current() == Theme.CUSTOM) {
            if (RenderUtil.hovered(mx, my, svRect[0], svRect[1], svRect[2], svRect[3])) {
                this.draggingSV = true;
                this.draggingHue = false;
                updateFromPicker(mx, my);
                return;
            }
            if (RenderUtil.hovered(mx, my, hueRect[0], hueRect[1], hueRect[2], hueRect[3])) {
                this.draggingHue = true;
                this.draggingSV = false;
                updateFromPicker(mx, my);
                return;
            }
        }
        this.draggingSV = false;
        this.draggingHue = false;
        // Кружки стилей интерфейса.
        for (float[] dot : styleDots) {
            if (RenderUtil.hovered(mx, my, dot[0], dot[1], dot[2], dot[3])) {
                UiStyle.set(UiStyle.values()[(int) dot[4]]);
                ConfigManager.save();
                return;
            }
        }
        // Карточки акцентных пресетов.
        for (Card card : this.cards) {
            if (card.hovered && Theme.current() != card.theme) {
                Theme.set(card.theme);
                if (card.theme == Theme.CUSTOM) {
                    int rgb = Theme.customColor();
                    float[] hsb = java.awt.Color.RGBtoHSB(
                            (rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, null);
                    hue = hsb[0];
                    sat = hsb[1];
                    bri = hsb[2];
                }
                ConfigManager.save();
                return;
            }
        }
    }

    /** Обновляет HSB по позиции мыши и применяет цвет (без записи конфига). */
    private void updateFromPicker(float mx, float my) {
        if (this.draggingSV && svRect[2] > 0.0F && svRect[3] > 0.0F) {
            sat = MathHelper.clamp((mx - svRect[0]) / svRect[2], 0f, 1f);
            bri = 1f - MathHelper.clamp((my - svRect[1]) / svRect[3], 0f, 1f);
        } else if (this.draggingHue && hueRect[2] > 0.0F) {
            hue = MathHelper.clamp((mx - hueRect[0]) / hueRect[2], 0f, 1f);
        }
        Theme.setCustomColor(0xFF000000 | java.awt.Color.HSBtoRGB(hue, sat, bri));
    }

    /** Зажатая мышь: непрерывное перетаскивание по SV-квадрату или hue-полосе. */
    public void mouseDragged(double mouseX, double mouseY, int button) {
        if (button != 0 || (!this.draggingSV && !this.draggingHue)) {
            return;
        }
        updateFromPicker((float) mouseX, (float) mouseY);
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
        if (this.draggingSV || this.draggingHue) {
            this.draggingSV = false;
            this.draggingHue = false;
            ConfigManager.save();
        }
    }

    public boolean isSwatchHovered(int mouseX, int mouseY) {
        float mx = (float) mouseX;
        float my = (float) mouseY;
        for (float[] dot : styleDots) {
            if (RenderUtil.hovered(mx, my, dot[0], dot[1], dot[2], dot[3])) {
                return true;
            }
        }
        for (Card card : this.cards) {
            if (RenderUtil.hovered(mx, my, card.x, card.y, card.w, card.h)) {
                return true;
            }
        }
        return Theme.current() == Theme.CUSTOM
                && (RenderUtil.hovered(mx, my, svRect[0], svRect[1], svRect[2], svRect[3])
                || RenderUtil.hovered(mx, my, hueRect[0], hueRect[1], hueRect[2], hueRect[3]));
    }

    /** Цвет-превью пресета (для CUSTOM — пользовательский цвет). */
    private static int previewColor(Theme theme) {
        return theme == Theme.CUSTOM ? Theme.customColor() : theme.getAccent();
    }

    private static final class Card {
        final float x;
        final float y;
        final float w;
        final float h;
        final Theme theme;
        final boolean hovered;

        Card(float x, float y, float w, float h, Theme theme, boolean hovered) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.theme = theme;
            this.hovered = hovered;
        }
    }
}
