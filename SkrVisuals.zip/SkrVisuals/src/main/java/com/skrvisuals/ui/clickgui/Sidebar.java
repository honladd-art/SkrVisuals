package com.skrvisuals.ui.clickgui;

import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.clickgui.api.MenuComponent;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.GuiFx;
import com.skrvisuals.ui.render.GuiIcons;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Современный навигационный рельс: плавающая карточка со «стеклянным» фоном,
 * бренд-шапкой, скруглённым полем поиска и вкладками-пилюлями с иконками,
 * левым акцентным маркером и анимированным активным состоянием.
 * При сворачивании остаётся узкий рельс только с иконками.
 */
public class Sidebar extends MenuComponent {
    private static final float PAD = 8.0F;
    private static final float ITEM_H = 22.0F;
    private static final float ITEM_GAP = 3.0F;
    private static final float CARD_RADIUS = 10.0F;
    private static final float ICON_SIZE = 14.0F;

    private final ClickScreen gui;

    private final List<ModuleCategory> categories = new ArrayList<>();

    private SearchBar searchBar;

    private boolean categoriesOpen = true;

    private final Animation sidebarWidthAnimation = new Animation(Easing.EASE_OUT_CUBIC, 200L);

    private final Map<ModuleCategory, Animation> hoverAnims = new HashMap<>();
    private final Map<ModuleCategory, Animation> activeAnims = new HashMap<>();

    private float[] collapseBox;

    public Sidebar(ClickScreen gui) {
        this.gui = gui;
        this.categories.addAll(List.of(ModuleCategory.values()));
        for (ModuleCategory category : this.categories) {
            hoverAnims.put(category, new Animation(Easing.EASE_OUT_CUBIC, 180L));
            activeAnims.put(category, new Animation(Easing.EASE_OUT_CUBIC, 220L));
        }
    }

    public void init() {
        this.x = gui.getX();
        this.y = gui.getY();
        this.width = gui.getSidebarWidth();
        this.height = gui.getHeight();
        this.searchBar = new SearchBar(cardX() + 10.0F, cardY() + 40.0F, cardW() - 20.0F, 18.0F);
        super.init();
    }

    // ------------------------------------------------------------- geometry
    private float cardX() { return gui.getX() + PAD; }
    private float cardY() { return gui.getY() + PAD; }
    private float cardW() { return gui.getSidebarWidth() - PAD * 2.0F; }
    private float cardH() { return gui.getHeight() - PAD * 2.0F; }

    private float itemX() { return cardX() + 8.0F; }
    private float itemW() { return cardW() - 16.0F; }

    /** Высота одной вкладки: подстраивается под доступную высоту рельса. */
    private float itemH() {
        float reservedBelow = 36.0F; // кнопка сворачивания + отступы
        float avail = cardH() - (navTop() - cardY()) - reservedBelow;
        float h = avail / Math.max(1, this.categories.size()) - ITEM_GAP;
        return Math.max(13.0F, Math.min(ITEM_H, h));
    }

    /** Размер иконки-плитки (сжимается вместе с вкладкой). */
    private float iconSize() {
        return Math.max(10.0F, Math.min(ICON_SIZE, itemH() - 4.0F));
    }

    private float navTop() {
        return cardY() + 56.0F + 16.0F * this.sidebarWidthAnimation.getValue();
    }

    private float itemY(ModuleCategory category) {
        int index = Math.max(0, this.categories.indexOf(category));
        return navTop() + index * (itemH() + ITEM_GAP);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public List<ModuleCategory> getCategories() {
        return this.categories;
    }

    public SearchBar getSearchBar() {
        return this.searchBar;
    }

    public boolean isCategoriesOpen() {
        return this.categoriesOpen;
    }

    public void toggleCategories() {
        this.categoriesOpen = !this.categoriesOpen;
        if (!this.categoriesOpen && this.searchBar != null) {
            this.searchBar.blur();
        }
    }

    public float getCollapseProgress() {
        return this.sidebarWidthAnimation.getValue();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float partialTicks) {
        this.sidebarWidthAnimation.run(this.categoriesOpen ? 1.0F : 0.0F);
        this.width = gui.getSidebarWidth();
        float alpha = gui.getAlpha();

        renderBackground(context, alpha);
        renderBrand(context, alpha);
        renderSearch(context, mouseX, mouseY, partialTicks, alpha);
        renderTabs(context, mouseX, mouseY, alpha);
        renderCollapseButton(context, mouseX, mouseY, alpha);
    }

    /** Плавающая карточка рельса: тень, градиент и тонкая рамка. */
    private void renderBackground(DrawContext context, float alpha) {
        if (alpha <= 0.01F) {
            return;
        }
        float cx = cardX();
        float cy = cardY();
        float cw = cardW();
        float ch = cardH();
        RenderUtil.roundedShadow(context, cx, cy, cw, ch, CARD_RADIUS, 0.40F * alpha);
        RenderUtil.roundedGradient(context, cx, cy, cw, ch, CARD_RADIUS,
                RenderUtil.withAlpha(Colors.sidebarBackground(), alpha),
                RenderUtil.withAlpha(Colors.darken(Colors.sidebarBackground(), 0.18F), alpha));
        RenderUtil.roundedOutline(context, cx, cy, cw, ch, CARD_RADIUS, 1.0F,
                RenderUtil.withAlpha(Colors.guiBorder(), alpha * 0.70F));
    }

    /** Бренд-шапка: акцентный логотип-плитка + название клиента. */
    private void renderBrand(DrawContext context, float alpha) {
        float collapse = this.sidebarWidthAnimation.getValue();
        float logo = 18.0F;
        float logoX = cardX() + lerp((cardW() - logo) / 2.0F, 10.0F, collapse);
        float logoY = cardY() + 10.0F;

        RenderUtil.roundedRect(context, logoX, logoY, logo, logo, 6.0F,
                RenderUtil.withAlpha(RenderUtil.multiplyAlpha(Colors.clientColor(), 0.18F), alpha));
        RenderUtil.roundedOutline(context, logoX, logoY, logo, logo, 6.0F, 1.0F,
                RenderUtil.withAlpha(Colors.clientColor(), alpha * 0.55F));

        TextRenderer font = Fonts.get();
        RenderUtil.drawCenteredString(context, font, "S", logoX + logo / 2.0F, logoY + 4.5F,
                RenderUtil.withAlpha(Colors.clientColor(), alpha));

        if (collapse > 0.02F) {
            RenderUtil.pushScissor(context, cardX(), cardY(), cardW(), 30.0F);
            RenderUtil.drawString(context, font, "SkrVisuals", logoX + logo + 8.0F, cardY() + 9.0F,
                    RenderUtil.withAlpha(Colors.textPrimary(), collapse * alpha));
            RenderUtil.drawString(context, font, "ClickGUI", logoX + logo + 8.0F, cardY() + 20.0F,
                    RenderUtil.withAlpha(Colors.textMuted(), collapse * alpha * 0.95F));
            RenderUtil.popScissor();
        }
    }

    private void renderSearch(DrawContext context, int mouseX, int mouseY, float partialTicks, float alpha) {
        if (this.searchBar == null) {
            return;
        }
        float collapse = this.sidebarWidthAnimation.getValue();
        // Пока рельс свёрнут — поле поиска полностью отключено (и по хитбоксу).
        if (collapse < 0.35F) {
            this.searchBar.setY(-1000.0F);
            this.searchBar.setWidth(0.0F);
            this.searchBar.setAlphaMultiplier(0.0F);
            return;
        }
        this.searchBar.setX(cardX() + 10.0F);
        this.searchBar.setY(cardY() + 40.0F);
        this.searchBar.setWidth(cardW() - 20.0F);
        this.searchBar.setHeight(18.0F);
        this.searchBar.setAlphaMultiplier(collapse);
        this.searchBar.render(context, mouseX, mouseY, partialTicks);
    }

    /** Вкладки-пилюли категорий с иконками и активным состоянием. */
    private void renderTabs(DrawContext context, int mouseX, int mouseY, float alpha) {
        float collapse = this.sidebarWidthAnimation.getValue();
        TextRenderer font = Fonts.get();
        int index = 0;
        for (ModuleCategory category : this.categories) {
            float entrance = GuiFx.stagger(gui.getOpenedAt(), index, 40L, 280L);
            index++;
            float a = alpha * entrance;
            if (a <= 0.01F) {
                continue;
            }
            boolean active = ClickScreen.getSavedCategory() == category;
            float itemY = itemY(category);
            float rowH = itemH();
            boolean hovered = RenderUtil.hovered(mouseX, mouseY, itemX(), itemY, itemW(), rowH);

            Animation hoverAnim = this.hoverAnims.computeIfAbsent(category,
                    k -> new Animation(Easing.EASE_OUT_CUBIC, 180L));
            hoverAnim.run(hovered ? 1.0F : 0.0F);
            Animation activeAnim = this.activeAnims.computeIfAbsent(category,
                    k -> new Animation(Easing.EASE_OUT_CUBIC, 220L));
            activeAnim.run(active ? 1.0F : 0.0F);
            float hover = hoverAnim.getValue();
            float on = activeAnim.getValue();

            // Фон пилюли: ховер + акцент при активности.
            float itemRadius = Math.min(8.0F, rowH / 2.4F);
            int bg = RenderUtil.lerpColor(Colors.hoverOverlay(),
                    RenderUtil.multiplyAlpha(Colors.clientColor(), 0.16F), on);
            float bgA = Math.max(hover * 0.6F, on) * a;
            if (bgA > 0.01F) {
                RenderUtil.roundedRect(context, itemX(), itemY, itemW(), rowH, itemRadius,
                        RenderUtil.withAlpha(bg, bgA));
            }
            if (on > 0.01F) {
                RenderUtil.roundedOutline(context, itemX(), itemY, itemW(), rowH, itemRadius, 1.0F,
                        RenderUtil.withAlpha(Colors.clientColor(), on * 0.5F * a));
                float markerH = Math.max(8.0F, rowH - 10.0F);
                RenderUtil.roundedRect(context, itemX() + 2.0F, itemY + (rowH - markerH) / 2.0F,
                        3.0F, markerH, 1.5F,
                        RenderUtil.withAlpha(Colors.clientColor(), on * a));
            }

            // Иконка-плитка с пиктограммой категории.
            // Плитка остаётся тёмной (с лёгким подмешиванием цвета категории),
            // иначе сплошная заливка «съедает» однотонную иконку.
            float icon = iconSize();
            float iconX = itemX() + lerp((itemW() - icon) / 2.0F, 12.0F, collapse);
            float iconY = itemY + (rowH - icon) / 2.0F;
            int catColor = category.getAccentColor();
            int tileBg = RenderUtil.lerpColor(Colors.iconTile(), catColor, 0.18F * on + 0.10F * hover);
            RenderUtil.roundedRect(context, iconX, iconY, icon, icon, Math.min(4.5F, icon * 0.33F),
                    RenderUtil.withAlpha(tileBg, (0.75F + 0.25F * on) * a));
            float glyph = icon * 0.72F;
            int glyphColor = RenderUtil.lerpColor(Colors.textMuted(), catColor, on);
            GuiIcons.draw(context, category, iconX + (icon - glyph) / 2.0F, iconY + (icon - glyph) / 2.0F,
                    glyph, RenderUtil.withAlpha(glyphColor, a));

            // Подпись категории.
            if (collapse > 0.02F) {
                int labelColor = RenderUtil.lerpColor(Colors.textDescription(), Colors.textPrimary(), on);
                RenderUtil.pushScissor(context, itemX(), itemY, itemW(), rowH);
                RenderUtil.drawString(context, font, category.getDisplayName(),
                        itemX() + 26.0F, itemY + (rowH - font.fontHeight) / 2.0F,
                        RenderUtil.withAlpha(labelColor, collapse * a));
                RenderUtil.popScissor();
            }
        }
    }

    /** Кнопка сворачивания рельса внизу карточки. */
    private void renderCollapseButton(DrawContext context, int mouseX, int mouseY, float alpha) {
        float size = 20.0F;
        float bx = cardX() + (cardW() - size) / 2.0F;
        float by = cardY() + cardH() - 10.0F - size;
        this.collapseBox = new float[]{bx, by, size, size};

        boolean hovered = RenderUtil.hovered(mouseX, mouseY, bx, by, size, size);
        RenderUtil.roundedRect(context, bx, by, size, size, 6.0F,
                RenderUtil.withAlpha(hovered ? Colors.settingHover() : Colors.keyBackground(), alpha * 0.90F));
        RenderUtil.roundedOutline(context, bx, by, size, size, 6.0F, 1.0F,
                RenderUtil.withAlpha(Colors.keyBorder(), alpha * 0.80F));
        RenderUtil.drawCenteredString(context, Fonts.get(), this.categoriesOpen ? "<" : ">",
                bx + size / 2.0F, by + 5.5F,
                RenderUtil.withAlpha(hovered ? Colors.textPrimary() : Colors.textDescription(), alpha));
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        if (button != 0) {
            return;
        }
        if (this.searchBar != null && this.searchBar.contains(mouseX, mouseY)) {
            this.searchBar.mouseClicked(mouseX, mouseY, button);
            return;
        }
        if (this.collapseBox != null && RenderUtil.hovered((float) mouseX, (float) mouseY,
                this.collapseBox[0], this.collapseBox[1], this.collapseBox[2], this.collapseBox[3])) {
            toggleCategories();
            return;
        }
        for (ModuleCategory category : this.categories) {
            float itemY = itemY(category);
            if (RenderUtil.hovered((float) mouseX, (float) mouseY, itemX(), itemY, itemW(), itemH())) {
                gui.switchCategory(category);
                return;
            }
        }
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        super.keyPressed(keyCode, scanCode, modifiers);
        if (this.searchBar != null) {
            this.searchBar.keyPressed(keyCode, scanCode, modifiers);
        }
    }

    @Override
    public void charTyped(char codePoint, int modifiers) {
        super.charTyped(codePoint, modifiers);
        if (this.searchBar != null) {
            this.searchBar.charTyped(codePoint, modifiers);
        }
    }

    public void focusSearch() {
        if (this.searchBar != null) {
            this.searchBar.focus();
        }
    }

    public boolean isSearchFocused() {
        return this.searchBar != null && this.searchBar.isFocused();
    }

    public boolean isSearchBarHovered(int mouseX, int mouseY) {
        return this.searchBar != null && this.searchBar.contains(mouseX, mouseY);
    }

    /** Курсор-рука над любым интерактивным элементом рельса. */
    public boolean isInteractableHovered(int mouseX, int mouseY) {
        if (isSearchBarHovered(mouseX, mouseY)) {
            return true;
        }
        if (this.collapseBox != null && RenderUtil.hovered(mouseX, mouseY,
                this.collapseBox[0], this.collapseBox[1], this.collapseBox[2], this.collapseBox[3])) {
            return true;
        }
        for (ModuleCategory category : this.categories) {
            float itemY = itemY(category);
            if (RenderUtil.hovered(mouseX, mouseY, itemX(), itemY, itemW(), itemH())) {
                return true;
            }
        }
        return false;
    }

    public String getSearchText() {
        return this.searchBar != null ? this.searchBar.getSearchText() : "";
    }

    public void clearSearch() {
        if (this.searchBar != null) {
            this.searchBar.clearSearch();
        }
    }
}
