package com.skrvisuals.ui.clickgui;

import java.util.ArrayList;
import java.util.List;

import com.skrvisuals.modules.impl.Friends;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/**
 * Content of the "Friends" tab (as Themes): управление списком друзей напрямую —
 * ввод ника + Enter, удаление крестиком, кнопка "Очистить" и переключатели
 * "ChinaHat на друзьях" / "Trails на друзьях".
 */
public class FriendsPanel {
    private static final float ROW_HEIGHT = 12.0F;
    private static final float FIELD_HEIGHT = 16.0F;
    private static final float TOGGLE_HEIGHT = 16.0F;
    private static final float GAP = 6.0F;

    private final ClickScreen gui;

    private String input = "";
    private boolean inputFocused = false;
    private long lastCursorBlink = 0L;
    private boolean cursorVisible = false;

    private float scroll = 0.0F;
    private float contentHeight = 0.0F;
    private float scrollTarget = 0.0F;
    private final java.util.Map<Integer, com.skrvisuals.ui.anim.Animation> knobAnims = new java.util.HashMap<>();
    private int toggleCounter = 0;

    private float contentX;
    private float contentW;

    private final List<float[]> toggleBoxes = new ArrayList<>();
    private final List<float[]> removeBoxes = new ArrayList<>();
    private float[] clearBox = null;
    private float[] fieldBox = null;

    public FriendsPanel(ClickScreen gui) {
        this.gui = gui;
    }

    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float alpha = gui.getAlpha();
        TextRenderer font = Fonts.get();

        float x = gui.getX() + gui.getSidebarWidth();
        float panelW = gui.getWidth() - gui.getSidebarWidth();
        this.contentW = Math.min(262.0F, panelW - 40.0F);
        this.contentX = x + (panelW - this.contentW) / 2.0F;

        float y = gui.getContentTop() + 6.0F + this.scroll;

        // Переключатели эффектов.
        this.toggleBoxes.clear();
        this.toggleCounter = 0;
        y = drawToggle(ctx, font, "ChinaHat на друзьях", Friends.isChinaHatOnFriends(), y, mouseX, mouseY, alpha);
        y = drawToggle(ctx, font, "Trails на друзьях", Friends.isTrailsOnFriends(), y, mouseX, mouseY, alpha);
        y += GAP;

        // Поле ввода ника.
        this.fieldBox = new float[]{this.contentX, y, this.contentW, FIELD_HEIGHT};
        drawInput(ctx, font, this.fieldBox, mouseX, mouseY, alpha);
        y += FIELD_HEIGHT + GAP;

        // Строки друзей.
        this.removeBoxes.clear();
        for (String friend : Friends.getFriends()) {
            y = drawFriendRow(ctx, font, friend, y, mouseX, mouseY, alpha);
        }

        // Кнопка "Очистить".
        this.clearBox = null;
        if (!Friends.getFriends().isEmpty()) {
            RenderUtil.roundedRect(ctx, this.contentX, y, this.contentW, ROW_HEIGHT, 3.0F,
                    RenderUtil.withAlpha(Colors.keyBackground(), alpha));
            boolean hovered = RenderUtil.hovered(mouseX, mouseY, this.contentX, y, this.contentW, ROW_HEIGHT);
            RenderUtil.drawString(ctx, font, "Очистить", this.contentX + 6.0F, y + 2.0F,
                    RenderUtil.withAlpha(hovered ? 0xFFFF6B6B : Colors.textMuted(), alpha));
            this.clearBox = new float[]{this.contentX, y, this.contentW, ROW_HEIGHT};
            y += ROW_HEIGHT + GAP;
        }

        // Скролл-клампинг.
        this.contentHeight = y - (gui.getContentTop() + 6.0F) - this.scroll;
        float availH = gui.getContentHeight() - 6.0F;
        float minScroll = this.contentHeight > availH ? (availH - this.contentHeight) : 0.0F;
        this.scrollTarget = Math.max(minScroll, Math.min(0.0F, this.scrollTarget));
        this.scroll += (this.scrollTarget - this.scroll) * 0.35F;
        if (Math.abs(this.scrollTarget - this.scroll) < 0.05F) {
            this.scroll = this.scrollTarget;
        }
    }

    // ---------------------------------------------------------------- input
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return;
        }
        for (int i = 0; i < this.toggleBoxes.size(); i++) {
            float[] box = this.toggleBoxes.get(i);
            if (RenderUtil.hovered((float) mouseX, (float) mouseY, box[0], box[1], box[2], box[3])) {
                boolean value = box[4] > 0.5F;
                if (i == 0) {
                    Friends.setChinaHatOnFriends(!value);
                } else {
                    Friends.setTrailsOnFriends(!value);
                }
                com.skrvisuals.config.ConfigManager.save();
                return;
            }
        }

        float[] field = this.fieldBox;
        if (field != null && RenderUtil.hovered((float) mouseX, (float) mouseY, field[0], field[1], field[2], field[3])) {
            this.inputFocused = true;
            return;
        }

        for (int i = 0; i < this.removeBoxes.size(); i++) {
            float[] box = this.removeBoxes.get(i);
            if (mouseX >= box[0] && mouseX <= box[0] + box[2]
                    && mouseY >= box[1] && mouseY <= box[1] + box[3]) {
                if (i < Friends.getFriends().size()) {
                    Friends.remove(Friends.getFriends().get(i));
                }
                return;
            }
        }

        if (this.clearBox != null && RenderUtil.hovered((float) mouseX, (float) mouseY,
                this.clearBox[0], this.clearBox[1], this.clearBox[2], this.clearBox[3])) {
            Friends.clear();
            return;
        }

        this.inputFocused = false;
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.inputFocused) {
            return;
        }
        switch (keyCode) {
            case 256 -> this.inputFocused = false;
            case 257 -> { // Enter — добавить друга
                if (!this.input.isBlank()) {
                    Friends.add(this.input);
                    this.input = "";
                }
                this.inputFocused = false;
            }
            case 259 -> { // Backspace
                if (!this.input.isEmpty()) {
                    this.input = this.input.substring(0, this.input.length() - 1);
                }
            }
            default -> {
            }
        }
    }

    public void charTyped(char codePoint, int modifiers) {
        if (!this.inputFocused) {
            return;
        }
        // Все печатные символы, включая "_" и заглавные буквы.
        if (codePoint >= ' ' && codePoint != 127 && this.input.length() < 16) {
            this.input += codePoint;
        }
    }

    public void mouseScrolled(double delta) {
        this.scrollTarget += (float) delta * 10.0F;
    }

    public boolean isInputFocused() {
        return this.inputFocused;
    }

    public boolean isHovered(int mouseX, int mouseY) {
        float x = gui.getX() + gui.getSidebarWidth();
        return mouseX >= x && mouseX <= gui.getX() + gui.getWidth()
                && mouseY >= gui.getContentTop() && mouseY <= gui.getY() + gui.getHeight();
    }

    // --------------------------------------------------------------- helpers
    /** @return новая нижняя координата. */
    private float drawToggle(DrawContext ctx, TextRenderer font, String label, boolean value,
                             float y, int mouseX, int mouseY, float alpha) {
        boolean hovered = RenderUtil.hovered(mouseX, mouseY, this.contentX, y, this.contentW, TOGGLE_HEIGHT);
        RenderUtil.roundedRect(ctx, this.contentX, y, this.contentW, TOGGLE_HEIGHT, 3.0F,
                RenderUtil.withAlpha(hovered ? Colors.settingHover() : Colors.moduleBackground(), alpha));
        if (hovered) {
            RenderUtil.roundedRect(ctx, this.contentX + 1.5F, y + 3.0F, 1.5F, TOGGLE_HEIGHT - 6.0F, 0.75F,
                    RenderUtil.withAlpha(Colors.clientColor(), alpha * 0.9F));
        }
        RenderUtil.drawString(ctx, font, label, this.contentX + 6.0F, y + (TOGGLE_HEIGHT - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(value ? Colors.textPrimary() : Colors.textDescription(), alpha));

        // Свитч.
        com.skrvisuals.ui.anim.Animation knobAnim = this.knobAnims.computeIfAbsent(this.toggleCounter,
                k -> new com.skrvisuals.ui.anim.Animation(com.skrvisuals.ui.anim.Easing.EASE_OUT_CUBIC, 220L));
        knobAnim.run(value ? 1.0F : 0.0F);
        float kv = knobAnim.getValue();
        this.toggleCounter++;
        float trackW = 18.0F, trackH = 8.0F;
        float trackX = this.contentX + this.contentW - trackW - 6.0F;
        float trackY = y + (TOGGLE_HEIGHT - trackH) / 2.0F;
        int trackColor = RenderUtil.lerpColor(Colors.toggleOff(), Colors.clientColor(), kv);
        RenderUtil.roundedRect(ctx, trackX, trackY, trackW, trackH, trackH / 2.0F,
                RenderUtil.withAlpha(trackColor, alpha));
        float knobX = trackX + 0.5F + kv * (trackW - 8.0F);
        RenderUtil.circle(ctx, knobX + 3.5F, trackY + trackH / 2.0F, 3.5F,
                RenderUtil.withAlpha(Colors.toggleKnob(), alpha));

        this.toggleBoxes.add(new float[]{this.contentX, y, this.contentW, TOGGLE_HEIGHT, value ? 1.0F : 0.0F});
        return y + TOGGLE_HEIGHT;
    }

    private void drawInput(DrawContext ctx, TextRenderer font, float[] box, int mouseX, int mouseY, float alpha) {
        float x = box[0], y = box[1], w = box[2], h = box[3];
        int fill = this.inputFocused ? Colors.moduleBackground() : Colors.guiBackground();
        int border = this.inputFocused ? Colors.clientColor() : Colors.keyBorder();
        RenderUtil.roundedRect(ctx, x, y, w, h, 3.0F, RenderUtil.withAlpha(fill, alpha * 0.8F));
        RenderUtil.roundedOutline(ctx, x, y, w, h, 3.0F, 1.0F, RenderUtil.withAlpha(border, alpha));

        String shown = this.input.isEmpty() ? "Ник + Enter" : this.input;
        RenderUtil.drawString(ctx, font, shown, x + 6.0F, y + (h - font.fontHeight) / 2.0F,
                RenderUtil.withAlpha(this.input.isEmpty() ? Colors.textPlaceholder() : Colors.textPrimary(), alpha));

        updateCursorBlink();
        if (this.inputFocused && this.cursorVisible) {
            float cursorX = x + 6.0F + font.getWidth(this.input);
            if (cursorX < x + w - 4.0F) {
                RenderUtil.fill(ctx, cursorX, y + 3.0F, 1.0F, h - 6.0F,
                        RenderUtil.withAlpha(Colors.cursorColor(), alpha));
            }
        }
    }

    private float drawFriendRow(DrawContext ctx, TextRenderer font, String friend,
                                float y, int mouseX, int mouseY, float alpha) {
        boolean rowHovered = RenderUtil.hovered(mouseX, mouseY, this.contentX, y, this.contentW, ROW_HEIGHT);
        if (rowHovered) {
            RenderUtil.roundedRect(ctx, this.contentX, y, this.contentW, ROW_HEIGHT, 2.0F,
                    RenderUtil.withAlpha(Colors.hoverOverlay(), alpha));
        }
        RenderUtil.drawString(ctx, font, friend, this.contentX + 6.0F, y + 2.0F,
                RenderUtil.withAlpha(Colors.textDescription(), alpha));

        float[] box = new float[]{this.contentX + this.contentW - 12.0F, y + 2.0F, 8.0F, 8.0F};
        this.removeBoxes.add(box);
        boolean xHovered = mouseX >= box[0] && mouseX <= box[0] + box[2]
                && mouseY >= box[1] && mouseY <= box[1] + box[3];
        RenderUtil.drawString(ctx, font, "x", box[0] + 1.0F, box[1] + 1.0F,
                RenderUtil.withAlpha(xHovered ? 0xFFFF6B6B : Colors.textMuted(), alpha));
        return y + ROW_HEIGHT;
    }

    private void updateCursorBlink() {
        long now = System.currentTimeMillis();
        if (now - this.lastCursorBlink > 500L) {
            this.cursorVisible = !this.cursorVisible;
            this.lastCursorBlink = now;
        }
    }
}