package com.skrvisuals.ui.theme;

/**
 * Central color palette for the click GUI and HUD.
 * Premium "glass-dark" scheme: layered deep slate-blue panels, soft borders
 * and text shades. Accent colors follow the selectable {@link Theme}.
 */
public final class Colors {
    private Colors() {
    }

    // ---- Accent / client color -----------------------------------------
    // Follows the selectable theme (see Theme enum).
    public static int clientColor() { return Theme.accent(); }
    public static int clientColorDim() { return Theme.accentDim(); }

    // ---- Palettes (delegate to the active UiStyle) ----------------------
    public static int guiBackground()      { return UiStyle.current().guiBackground(); }
    /** Top end of vertical panel gradients (lighter). */
    public static int guiBackgroundTop()   { return UiStyle.current().guiBackgroundTop(); }
    /** Bottom end of vertical panel gradients (darker). */
    public static int guiBackgroundBottom(){ return UiStyle.current().guiBackgroundBottom(); }
    public static int guiBorder()          { return UiStyle.current().guiBorder(); }
    public static int sidebarBackground()  { return UiStyle.current().sidebarBackground(); }
    public static int headerBackground()   { return UiStyle.current().headerBackground(); }

    // ---- Separators ------------------------------------------------------
    public static int separatorHorizontal() { return UiStyle.current().separatorHorizontal(); }
    public static int separatorVertical()   { return UiStyle.current().separatorVertical(); }

    // ---- Tabs / icons ---------------------------------------------------
    public static int iconUnselected()  { return UiStyle.current().iconUnselected(); }
    public static int iconWhite()       { return 0xFFFFFFFF; }
    /** Fill of an inactive category icon tile. */
    public static int iconTile()        { return UiStyle.current().iconTile(); }

    // ---- Search bar -----------------------------------------------------
    public static int searchBackground()      { return UiStyle.current().searchBackground(); }
    public static int searchBorderUnfocused() { return UiStyle.current().searchBorderUnfocused(); }
    public static int cursorColor()           { return UiStyle.current().textPrimary(); }

    // ---- Modules / cards -------------------------------------------------
    public static int moduleBackground()       { return UiStyle.current().moduleBackground(); }
    public static int moduleBackgroundTop()    { return UiStyle.current().moduleBackgroundTop(); }
    public static int moduleBackgroundBottom() { return UiStyle.current().moduleBackgroundBottom(); }
    public static int moduleBorder()           { return UiStyle.current().moduleBorder(); }
    public static int moduleBorderHover()      { return UiStyle.current().moduleBorderHover(); }

    // ---- Settings --------------------------------------------------------
    public static int settingBackground()       { return UiStyle.current().settingBackground(); }
    public static int settingBackgroundTop()    { return UiStyle.current().settingBackgroundTop(); }
    public static int settingBackgroundBottom() { return UiStyle.current().settingBackgroundBottom(); }
    public static int settingHover()            { return UiStyle.current().settingHover(); }

    // ---- Text ------------------------------------------------------------
    public static int textPrimary()      { return UiStyle.current().textPrimary(); }
    public static int textPlaceholder()  { return UiStyle.current().textPlaceholder(); }
    public static int textDescription()  { return UiStyle.current().textDescription(); }
    /** Dimmer secondary text (tags, inactive labels). */
    public static int textMuted()        { return UiStyle.current().textMuted(); }
    public static int keyText()          { return UiStyle.current().keyText(); }
    public static int keyBackground()    { return UiStyle.current().keyBackground(); }
    public static int keyBorder()        { return UiStyle.current().keyBorder(); }

    // ---- Toggle switch ----------------------------------------------------
    public static int toggleOff()        { return UiStyle.current().toggleOff(); }
    public static int toggleKnob()       { return UiStyle.current().toggleKnob(); }

    // ---- Overlays / states -------------------------------------------------
    public static int dimOverlay()      { return UiStyle.current().dimOverlay(); }
    /** Semi-transparent white used for hover highlights. */
    public static int hoverOverlay()    { return UiStyle.current().hoverOverlay(); }

    // ---- Category accents -------------------------------------------------
    public static int categoryVisuals()    { return 0xFFFFD26B; }
    public static int categoryCombat()     { return 0xFFFF6B6B; }
    public static int categoryUtility()    { return 0xFFC08BFF; }
    public static int categoryPoints()     { return 0xFF6BFFB8; }
    public static int categoryFriends()    { return 0xFFFF8FB8; }

    // ---- Helpers ----------------------------------------------------------

    /** Lightens {@code argb} towards white by amount t (0..1), alpha preserved. */
    public static int lighten(int argb, float t) {
        if (t <= 0f) {
            return argb;
        }
        if (t >= 1f) {
            t = 1f;
        }
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        r = Math.round(r + (255 - r) * t);
        g = Math.round(g + (255 - g) * t);
        b = Math.round(b + (255 - b) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Darkens {@code argb} towards black by amount t (0..1), alpha preserved. */
    public static int darken(int argb, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        r = Math.round(r * (1f - t));
        g = Math.round(g * (1f - t));
        b = Math.round(b * (1f - t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Per-channel blend between two colors (opaque result). */
    public static int tint(int base, int tint, float amount) {
        amount = Math.max(0f, Math.min(1f, amount));
        int br = (base >> 16) & 0xFF, bg = (base >> 8) & 0xFF, bb = base & 0xFF;
        int tr = (tint >> 16) & 0xFF, tg = (tint >> 8) & 0xFF, tb = tint & 0xFF;
        return 0xFF000000
                | (((int) (br + (tr - br) * amount)) << 16)
                | (((int) (bg + (tg - bg) * amount)) << 8)
                | ((int) (bb + (tb - bb) * amount));
    }
}