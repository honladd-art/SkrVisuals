package com.skrvisuals.ui.render;

import com.skrvisuals.modules.ModuleCategory;
import net.minecraft.client.gui.DrawContext;
import org.joml.Quaternionf;

/**
 * Иконки категорий ClickGUI. Рисуются векторно теми же примитивами, что и
 * остальной интерфейс ({@link RenderUtil}), поэтому работают на любом
 * GUI-масштабе и не зависят от загрузки текстур.
 *
 * <p>Каждая иконка строится в системе координат {@code -6..6} с центром в
 * (0, 0) и масштабируется под нужный размер.
 */
public final class GuiIcons {
    /** Половина размера иконки в «единицах» (см. док-блок). */
    private static final float EXTENT = 6.0F;

    private GuiIcons() {
    }

    /** Рисует иконку категории в квадрате со стороной {@code size}, угол (x, y). */
    public static void draw(DrawContext context, ModuleCategory category, float x, float y,
                            float size, int color) {
        if (size <= 0.5F) {
            return;
        }
        float k = size / (EXTENT * 2.0F);
        context.getMatrices().push();
        context.getMatrices().translate(x + size / 2.0F, y + size / 2.0F, 0.0F);
        context.getMatrices().scale(k, k, 1.0F);

        switch (category) {
            case VISUALS -> monitor(context, color);
            case COMBAT -> sword(context, color);
            case UTILITY -> gear(context, color);
            case POINTS -> pin(context, color);
            case FRIENDS -> people(context, color);
            case THEMES -> droplet(context, color);
            default -> monitor(context, color);
        }

        context.getMatrices().pop();
    }

    // ------------------------------------------------------------------ shapes

    /** Четырёхугольник-треугольник (четвёртая точка дублирует третью). */
    private static void tri(DrawContext ctx, float ax, float ay, float bx, float by,
                            float cx, float cy, int color) {
        RenderUtil.fillQuad(ctx, ax, ay, bx, by, cx, cy, cx, cy, color);
    }

    /** Visuals — экран монитора. */
    private static void monitor(DrawContext ctx, int color) {
        RenderUtil.roundedRect(ctx, -5.3F, -4.9F, 10.6F, 7.4F, 1.6F, color);
        RenderUtil.roundedRect(ctx, -1.5F, 2.5F, 3.0F, 1.5F, 0.75F, color);
        RenderUtil.roundedRect(ctx, -3.7F, 4.0F, 7.4F, 1.5F, 0.75F, color);
    }

    /** Combat — меч по диагонали. */
    private static void sword(DrawContext ctx, int color) {
        ctx.getMatrices().multiply(new Quaternionf().rotationZ((float) Math.toRadians(45.0)));
        RenderUtil.roundedRect(ctx, -1.3F, -4.9F, 2.6F, 7.1F, 1.0F, color);
        tri(ctx, 0.0F, -6.0F, 1.3F, -4.2F, -1.3F, -4.2F, color);   // остриё
        RenderUtil.roundedRect(ctx, -4.2F, 2.2F, 8.4F, 1.8F, 0.9F, color); // гарда
        RenderUtil.roundedRect(ctx, -1.0F, 4.0F, 2.0F, 2.8F, 1.0F, color); // рукоять
        RenderUtil.circle(ctx, 0.0F, 6.4F, 1.25F, color);                // навершие
    }

    /** Utility — шестерёнка. */
    private static void gear(DrawContext ctx, int color) {
        for (int i = 0; i < 8; i++) {
            ctx.getMatrices().push();
            ctx.getMatrices().multiply(new Quaternionf().rotationZ((float) Math.toRadians(i * 45.0)));
            RenderUtil.roundedRect(ctx, -1.1F, -6.0F, 2.2F, 3.0F, 0.7F, color);
            ctx.getMatrices().pop();
        }
        RenderUtil.circleOutline(ctx, 0.0F, 0.0F, 4.1F, 1.7F, color);
        RenderUtil.circle(ctx, 0.0F, 0.0F, 1.1F, color);
    }

    /** Points — метка на карте. */
    private static void pin(DrawContext ctx, int color) {
        RenderUtil.circleOutline(ctx, 0.0F, -1.5F, 3.5F, 1.8F, color);
        tri(ctx, -3.3F, 0.3F, 3.3F, 0.3F, 0.0F, 6.1F, color);
    }

    /** Friends — две фигурки. */
    private static void people(DrawContext ctx, int color) {
        RenderUtil.circle(ctx, 2.7F, -3.1F, 1.7F, color);
        RenderUtil.roundedRect(ctx, 1.2F, -1.0F, 3.0F, 2.9F, 1.3F, color);
        RenderUtil.circle(ctx, -1.7F, -2.0F, 2.2F, color);
        RenderUtil.roundedRect(ctx, -4.0F, 0.8F, 4.2F, 3.4F, 1.7F, color);
    }

    /** Themes — капля цвета. */
    private static void droplet(DrawContext ctx, int color) {
        RenderUtil.circle(ctx, 0.0F, 1.7F, 3.9F, color);
        tri(ctx, 0.0F, -5.8F, 3.6F, 1.9F, -3.6F, 1.9F, color);
    }
}
