package com.skrvisuals.ui.clickgui.api;

import net.minecraft.client.gui.DrawContext;

/**
 * Точь-в-точь порт референсного CustomElement: элемент с флагом отображения.
 */
public class CustomElement {
    public float x;
    public float y;
    public float width;
    public float height;

    private boolean isDisplayingElement;

    public void setX(float x) { this.x = x; }
    public void setY(float y) { this.y = y; }
    public void setWidth(float width) { this.width = width; }
    public void setHeight(float height) { this.height = height; }
    public void setDisplayingElement(boolean isDisplayingElement) { this.isDisplayingElement = isDisplayingElement; }

    public float getX() { return this.x; }
    public float getY() { return this.y; }
    public float getWidth() { return this.width; }
    public float getHeight() { return this.height; }
    public boolean isDisplayingElement() { return this.isDisplayingElement; }

    public void init() {
    }

    public void render(DrawContext context, float x, float y, int mouseX, int mouseY, float delta) {
        this.x = x;
        this.y = y;
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
    }

    public void charTyped(char codePoint, int modifiers) {
    }

    protected boolean isHovered(double mouseX, double mouseY) {
        return mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height;
    }

    protected boolean isHovered(float x, float y, float width, float height, double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
