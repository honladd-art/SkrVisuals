package com.skrvisuals.ui.anim;

/**
 * A small tween animation based on frames (via millisecond timestamps).
 */
public final class Animation {
    private final Easing easing;
    private final long duration;

    private float from;
    private float to;
    private long startTime = -1L;

    public Animation(Easing easing, long duration) {
        this.easing = easing;
        this.duration = Math.max(1L, duration);
    }

    /** Feed the target value every frame. Starting a new direction resets the origin. */
    public void run(float target) {
        if (this.startTime < 0L || Math.abs(target - this.to) > 0.0001f) {
            this.from = getValue();
            this.to = target;
            this.startTime = System.currentTimeMillis();
        }
    }

    public float getValue() {
        if (this.startTime < 0L) {
            return this.to;
        }
        float progress = (System.currentTimeMillis() - this.startTime) / (float) this.duration;
        if (progress >= 1.0f) {
            progress = 1.0f;
            this.startTime = -1L;
            return this.to;
        }
        float eased = this.easing.ease(progress);
        return this.from + (this.to - this.from) * eased;
    }

    public float getProgress() {
        if (this.startTime < 0L) {
            return this.to > 0.5f ? 1.0f : 0.0f;
        }
        return (System.currentTimeMillis() - this.startTime) / (float) this.duration;
    }

    public void setValue(float value) {
        this.from = value;
        this.to = value;
        this.startTime = -1L;
    }

    public void reset() {
        setValue(this.to);
    }
}