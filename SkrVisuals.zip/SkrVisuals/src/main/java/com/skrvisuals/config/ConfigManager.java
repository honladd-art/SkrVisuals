package com.skrvisuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.skrvisuals.Skr;
import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.impl.Points;
import com.skrvisuals.modules.impl.Friends;
import com.skrvisuals.modules.settings.BindSetting;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ColorSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.modules.settings.StringSetting;
import com.skrvisuals.ui.hud.HudElement;
import com.skrvisuals.ui.hud.HudManager;
import com.skrvisuals.ui.theme.Theme;
import com.skrvisuals.ui.theme.UiStyle;

import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * JSON config stored in config/skrvisuals.json.
 * Holds module enabled states, every setting value and HUD element positions.
 */
public final class ConfigManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals/Config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ConfigManager() {
    }

    private static Path path() {
        String version = FabricLoader.getInstance().getModContainer("minecraft")
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("minecraft");
        return FabricLoader.getInstance().getGameDir()
                .resolve(version)
                .resolve("SkrVisuals")
                .resolve("skrvisuals.cfg");
    }

    public static void save() {
        Path path = path();
        try {
            Files.createDirectories(path.getParent());

            JsonObject root = new JsonObject();

            JsonArray modules = new JsonArray();
            for (Module module : Skr.INSTANCE.getModuleManager().getModules()) {
                JsonObject mo = new JsonObject();
                mo.addProperty("name", module.getName());
                mo.addProperty("enabled", module.isEnabled());
                mo.addProperty("key", module.getKey());

                JsonObject settings = new JsonObject();
                for (var setting : module.getAllSettings()) {
                    String n = setting.getName();
                    if (setting instanceof BooleanSetting s) {
                        settings.addProperty(n, s.getValue());
                    } else if (setting instanceof SliderSetting s) {
                        settings.addProperty(n, s.getValue());
                    } else if (setting instanceof ModeSetting s) {
                        settings.addProperty(n, s.getValue());
                    } else if (setting instanceof ColorSetting s) {
                        settings.addProperty(n, s.getValue());
                    } else if (setting instanceof BindSetting s) {
                        settings.addProperty(n, s.getKeyCode());
                    } else if (setting instanceof StringSetting s) {
                        settings.addProperty(n, s.getValue());
                    }
                }
                mo.add("settings", settings);
                modules.add(mo);
            }
            root.add("modules", modules);

            root.add("friends", com.skrvisuals.modules.impl.Friends.saveJson());

            JsonObject hud = new JsonObject();
            for (HudElement element : HudManager.getElements()) {
                JsonObject eo = new JsonObject();
                eo.addProperty("x", element.x);
                eo.addProperty("y", element.y);
                eo.addProperty("scale", element.scale);
                eo.addProperty("opacity", element.opacity);
                hud.add(element.id, eo);
            }
            root.add("hud", hud);

            root.addProperty("theme", Theme.current().name());
            root.addProperty("customColor", Theme.customColor());
            root.addProperty("uiStyle", UiStyle.current().name());

            root.add("points", Points.saveJson());

            Files.writeString(path, GSON.toJson(root));
        } catch (Exception e) {
            LOGGER.error("Failed to save config to {}", path, e);
        }
    }

    public static void load() {
        Path path = path();
        if (!Files.exists(path)) {
            LOGGER.info("Config not found at {}, starting with defaults", path);
            return;
        }
        JsonObject root;
        try {
            root = JsonParser.parseString(Files.readString(path)).getAsJsonObject();
        } catch (Exception e) {
            LOGGER.error("Failed to parse config {}", path, e);
            return;
        }

        if (root.has("modules")) {
            try {
                for (JsonElement el : root.getAsJsonArray("modules")) {
                    try {
                        JsonObject mo = el.getAsJsonObject();
                        Module module = findModule(mo.get("name").getAsString());
                        if (module == null) {
                            continue;
                        }
                        if (mo.has("enabled")) {
                            // Silent: no toggle sound during config restore.
                            module.setEnabled(mo.get("enabled").getAsBoolean(), true);
                        }
                        if (mo.has("key")) {
                            module.setKey(mo.get("key").getAsInt());
                        }
                        if (mo.has("settings")) {
                            JsonObject settings = mo.getAsJsonObject("settings");
                            for (var setting : module.getAllSettings()) {
                                String n = setting.getName();
                                if (!settings.has(n)) {
                                    continue;
                                }
                                JsonElement settingEl = settings.get(n);
                                try {
                                    JsonPrimitive prim = settingEl.getAsJsonPrimitive();
                                    if (setting instanceof BooleanSetting s && prim.isBoolean()) {
                                        s.setValue(prim.getAsBoolean());
                                    } else if (setting instanceof SliderSetting s && prim.isNumber()) {
                                        s.setValue(prim.getAsFloat());
                                    } else if (setting instanceof ModeSetting s) {
                                        s.setValue(prim.getAsString());
                                    } else if (setting instanceof ColorSetting s && prim.isNumber()) {
                                        s.setValue(prim.getAsInt());
                                    } else if (setting instanceof BindSetting s && prim.isNumber()) {
                                        s.setKeyCode(prim.getAsInt());
                                    } else if (setting instanceof StringSetting s) {
                                        s.setValue(prim.getAsString());
                                    }
                                } catch (Exception e) {
                                    LOGGER.warn("Failed to load setting '{}' of module '{}'", n, module.getName(), e);
                                }
                            }
                        }
                    } catch (Exception e) {
                        LOGGER.error("Failed to load a module entry, skipping it", e);
                    }
                }
            } catch (Exception e) {
                LOGGER.error("Failed to load 'modules' section", e);
            }
        }

        if (root.has("hud")) {
            try {
                JsonObject hud = root.getAsJsonObject("hud");
                for (HudElement element : HudManager.getElements()) {
                    if (hud.has(element.id)) {
                        JsonObject eo = hud.getAsJsonObject(element.id);
                        if (eo.has("x")) {
                            element.x = eo.get("x").getAsFloat();
                        }
                        if (eo.has("y")) {
                            element.y = eo.get("y").getAsFloat();
                        }
                        if (eo.has("scale")) {
                            element.scale = Math.max(0.25f, Math.min(3f, eo.get("scale").getAsFloat()));
                        }
                        if (eo.has("opacity")) {
                            element.opacity = Math.max(0f, Math.min(1f, eo.get("opacity").getAsFloat()));
                        }
                    }
                }
            } catch (Exception e) {
                LOGGER.error("Failed to load 'hud' section", e);
            }
        }

        if (root.has("theme")) {
            try {
                Theme.setByName(root.get("theme").getAsString());
            } catch (Exception e) {
                LOGGER.warn("Failed to load theme", e);
            }
        }

        if (root.has("customColor")) {
            try {
                Theme.setCustomColor(root.get("customColor").getAsInt());
            } catch (Exception e) {
                LOGGER.warn("Failed to load custom color", e);
            }
        }

        if (root.has("uiStyle")) {
            try {
                UiStyle.setByName(root.get("uiStyle").getAsString());
            } catch (Exception e) {
                LOGGER.warn("Failed to load ui style", e);
            }
        }

        if (root.has("points")) {
            try {
                Points.loadJson(root.getAsJsonArray("points"));
            } catch (Exception e) {
                LOGGER.warn("Failed to load points", e);
            }
        }

        if (root.has("friends")) {
            try {
                Friends.loadJson(root.getAsJsonObject("friends"));
            } catch (Exception e) {
                LOGGER.warn("Failed to load friends", e);
            }
        }

        LOGGER.info("Config loaded from {}", path);
    }

    private static Module findModule(String name) {
        for (Module module : Skr.INSTANCE.getModuleManager().getModules()) {
            if (module.getName().equals(name)) {
                return module;
            }
        }
        return null;
    }
}