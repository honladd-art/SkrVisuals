package com.skrvisuals.discord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.util.Random;

final class DiscordIpcClient {

    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals-DiscordIPC");

    private static final int OPCODE_HANDSHAKE = 0;
    private static final int OPCODE_FRAME = 1;
    private static final int OPCODE_PING = 3;
    private static final int OPCODE_PONG = 4;

    private ReadableByteChannel input;
    private WritableByteChannel output;
    private final Random random = new Random();

    boolean connect() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            for (int i = 0; i < 10; i++) {
                String pipeName = "\\\\.\\pipe\\discord-ipc-" + i;
                if (tryConnect(pipeName)) {
                    return true;
                }
            }
        } else {
            String runtimeDir = System.getenv("XDG_RUNTIME_DIR");
            String[] dirs = runtimeDir != null ? new String[]{runtimeDir, "/tmp"} : new String[]{"/tmp"};
            for (String dir : dirs) {
                for (int i = 0; i < 10; i++) {
                    String socketPath = dir + "/discord-ipc-" + i;
                    if (tryConnect(socketPath)) {
                        return true;
                    }
                }
            }
        }
        LOGGER.warn("Could not connect to Discord IPC. Is Discord running?");
        return false;
    }

    private boolean tryConnect(String path) {
        try {
            FileInputStream fis = new FileInputStream(path);
            FileOutputStream fos = new FileOutputStream(path);
            this.input = Channels.newChannel(fis);
            this.output = Channels.newChannel(fos);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    void sendHandshake(String clientId) {
        String payload = "{\"v\":1,\"client_id\":\"" + clientId + "\"}";
        sendFrame(OPCODE_HANDSHAKE, payload);
    }

    void sendActivity(String json) {
        String payload = "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" + getPid()
                + ",\"activity\":" + json + "},\"nonce\":\"" + Math.abs(random.nextInt()) + "\"}";
        sendFrame(OPCODE_FRAME, payload);
    }

    void sendPong() {
        sendFrame(OPCODE_PONG, "{}");
    }

    private void sendFrame(int opcode, String payload) {
        try {
            byte[] data = payload.getBytes("UTF-8");
            ByteBuffer buffer = ByteBuffer.allocate(8 + data.length);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            buffer.putInt(opcode);
            buffer.putInt(data.length);
            buffer.put(data);
            buffer.flip();
            output.write(buffer);
        } catch (IOException e) {
            LOGGER.error("Failed to send IPC frame", e);
        }
    }

    int readFrame(ByteBuffer payloadBuffer) {
        try {
            ByteBuffer header = ByteBuffer.allocate(8);
            header.order(ByteOrder.LITTLE_ENDIAN);
            int read = input.read(header);
            if (read < 8) {
                return -1;
            }
            header.flip();
            int opcode = header.getInt();
            int length = header.getInt();

            if (length > payloadBuffer.capacity()) {
                payloadBuffer = ByteBuffer.allocate(length);
            }
            payloadBuffer.clear();
            payloadBuffer.limit(length);

            int totalRead = 0;
            while (totalRead < length) {
                int r = input.read(payloadBuffer);
                if (r == -1) {
                    return -1;
                }
                totalRead += r;
            }
            return opcode;
        } catch (IOException e) {
            return -1;
        }
    }

    void close() {
        try {
            if (input != null) input.close();
            if (output != null) output.close();
        } catch (IOException e) {
            LOGGER.error("Error closing IPC connection", e);
        }
    }

    private long getPid() {
        try {
            return ProcessHandle.current().pid();
        } catch (Exception e) {
            String name = java.lang.management.ManagementFactory.getRuntimeMXBean().getName();
            return Long.parseLong(name.split("@")[0]);
        }
    }
}