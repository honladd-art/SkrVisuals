package com.skrvisuals.discord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.ByteBuffer;

public final class DiscordRpcManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals-DiscordRPC");

    private static final String CLIENT_ID = "1545654165718695936";
    private static final String LARGE_IMAGE_KEY = "skrvisuals-logo";
    private static final String LARGE_IMAGE_TEXT = "SkrVisuals v0.2.0";

    private static volatile boolean running = false;
    private static volatile boolean inSingleplayer = false;
    private static volatile boolean inMultiplayer = false;
    private static volatile String serverName = "";
    private static volatile String worldName = "";
    private static volatile long startTime = System.currentTimeMillis() / 1000L;

    private static DiscordIpcClient ipcClient;
    private static Thread ipcThread;
    private static ByteBuffer readBuffer = ByteBuffer.allocate(65536);

    private DiscordRpcManager() {
    }

    public static void start() {
        if (running) {
            return;
        }

        ipcClient = new DiscordIpcClient();
        if (!ipcClient.connect()) {
            LOGGER.warn("Discord IPC connection failed. Rich Presence will not be available.");
            return;
        }

        ipcClient.sendHandshake(CLIENT_ID);
        running = true;

        ipcThread = new Thread(DiscordRpcManager::ipcLoop, "SkrVisuals-DiscordRPC");
        ipcThread.setDaemon(true);
        ipcThread.start();

        updatePresence();
        LOGGER.info("Discord RPC started.");
    }

    private static void ipcLoop() {
        while (running) {
            try {
                int opcode = ipcClient.readFrame(readBuffer);
                if (opcode == -1) {
                    break;
                }
                if (opcode == 3) {
                    ipcClient.sendPong();
                }
            } catch (Exception e) {
                if (running) {
                    LOGGER.error("Error in IPC loop", e);
                }
                break;
            }
        }
        running = false;
    }

    public static void stop() {
        if (!running && ipcClient == null) {
            return;
        }
        running = false;
        try {
            if (ipcClient != null) {
                ipcClient.close();
            }
        } catch (Exception e) {
            LOGGER.error("Error while shutting down Discord RPC", e);
        }
        if (ipcThread != null) {
            ipcThread.interrupt();
            ipcThread = null;
        }
        ipcClient = null;
        LOGGER.info("Discord RPC stopped.");
    }

    public static void setGameState(boolean singleplayer, boolean multiplayer, String serverOrWorldName) {
        inSingleplayer = singleplayer;
        inMultiplayer = multiplayer;
        if (multiplayer) {
            serverName = serverOrWorldName != null ? serverOrWorldName : "";
            worldName = "";
        } else if (singleplayer) {
            worldName = serverOrWorldName != null ? serverOrWorldName : "";
            serverName = "";
        } else {
            serverName = "";
            worldName = "";
        }
        updatePresence();
    }

    public static void updatePresence() {
        if (!running || ipcClient == null) {
            return;
        }

        String details;
        String state;

        if (inMultiplayer) {
            details = "Playing on " + (serverName.isEmpty() ? "a server" : serverName);
            state = "Multiplayer";
        } else if (inSingleplayer) {
            details = "Singleplayer";
            state = worldName.isEmpty() ? "In a world" : "World: " + worldName;
        } else {
            details = "Playing SkrVisuals";
            state = "In the main menu";
        }

        String json = "{"
                + "\"details\":\"" + escapeJson(details) + "\","
                + "\"state\":\"" + escapeJson(state) + "\","
                + "\"timestamps\":{\"start\":" + startTime + "},"
                + "\"assets\":{"
                + "\"large_image\":\"" + LARGE_IMAGE_KEY + "\","
                + "\"large_text\":\"" + LARGE_IMAGE_TEXT + "\""
                + "}"
                + "}";

        ipcClient.sendActivity(json);
    }

    public static boolean isRunning() {
        return running;
    }

    private static String escapeJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
