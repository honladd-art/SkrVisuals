package com.skrvisuals.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * ClientRole: role baked into the jar at build time (assets/skrvisuals/role.txt).
 * Built with: gradlew build -Pbuild_nick=Nick -Pmod_role=Developer|Tester|Media|Player
 */
public final class ClientRole {
    private static final String ROLE = load();

    private ClientRole() {
    }

    private static String load() {
        try (InputStream in = ClientRole.class
                .getResourceAsStream("/assets/skrvisuals/role.txt")) {
            if (in != null) {
                String s = new String(in.readAllBytes(), StandardCharsets.UTF_8).trim();
                if (!s.isEmpty()) {
                    return s;
                }
            }
        } catch (IOException ignored) {
        }
        return "Player";
    }

    public static String get() {
        return ROLE;
    }
}