package com.skrvisuals.util;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.skrvisuals.mixin.MinecraftClientAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Менеджер офлайн-аккаунтов: меняет ник прямо в игре (без перезапуска),
 * запоминает список сохранённых аккаунтов в config/skrvisuals_accounts.json.
 */
public final class AccountManager {

    private static final Gson GSON = new Gson();
    private static final Type LIST_TYPE = new TypeToken<List<String>>() {}.getType();
    private static final List<String> savedAccounts = new ArrayList<>();
    private static boolean loaded = false;

    private AccountManager() {
    }

    /** Применяет офлайн-аккаунт с указанным ником немедленно. */
    public static boolean applyOfflineAccount(String nickname) {
        String name = nickname.trim();
        if (name.isEmpty() || name.length() > 16) return false;
        MinecraftClient client = MinecraftClient.getInstance();
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        Session session = new Session(name, uuid, "0",
                Optional.empty(), Optional.empty(), Session.AccountType.LEGACY);
        ((MinecraftClientAccessor) client).skr$setSession(session);
        // сбрасываем кэш GameProfile, чтобы новый ник подхватился при следующем входе в мир
        ((MinecraftClientAccessor) client).skr$setGameProfileFuture(CompletableFuture.completedFuture(null));
        rememberAccount(name);
        return true;
    }

    /** Текущий ник игрока. */
    public static String currentName() {
        MinecraftClient client = MinecraftClient.getInstance();
        return client != null && client.getSession() != null ? client.getSession().getUsername() : "";
    }

    /** Сохранённые аккаунты (последний применённый — первым). */
    public static List<String> getSavedAccounts() {
        ensureLoaded();
        return new ArrayList<>(savedAccounts);
    }

    /** Удаляет аккаунт из списка сохранённых (текущая сессия не меняется). */
    public static void removeAccount(String name) {
        ensureLoaded();
        if (savedAccounts.remove(name)) {
            save();
        }
    }

    /** Полностью очищает список сохранённых аккаунтов. */
    public static void clearAccounts() {
        ensureLoaded();
        savedAccounts.clear();
        save();
    }

    private static void rememberAccount(String name) {
        ensureLoaded();
        savedAccounts.remove(name);
        savedAccounts.add(0, name);
        while (savedAccounts.size() > 15) savedAccounts.remove(savedAccounts.size() - 1);
        save();
    }

    private static void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        Path file = getConfigFile();
        if (!Files.exists(file)) return;
        try {
            List<String> list = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), LIST_TYPE);
            if (list != null) savedAccounts.addAll(list);
        } catch (Exception ignored) {
        }
    }

    private static void save() {
        try {
            Files.writeString(getConfigFile(), GSON.toJson(savedAccounts), StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }

    private static Path getConfigFile() {
        return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("skrvisuals_accounts.json");
    }
}
