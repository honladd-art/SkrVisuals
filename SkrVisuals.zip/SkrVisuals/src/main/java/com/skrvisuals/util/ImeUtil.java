package com.skrvisuals.util;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFWNativeWin32;
import org.lwjgl.system.JNI;
import org.lwjgl.system.windows.WindowsLibrary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Отключает системный IME (окно-подсказка ввода, которое вылезает поверх GUI
 * при наборе текста в MC 1.20.5+/GLFW 3.4) на время работы текстового экрана.
 * Вызывает Imm32!ImmGetContext/ImmAssociateContext через JNI-трамплины LWJGL —
 * без внешних зависимостей и preview-API. На не-Windows или при ошибке — no-op.
 *
 * Важно: Window.getHandle() возвращает указатель на GLFWwindow, а не Win32 HWND,
 * поэтому хэндл окна получается через GLFWNativeWin32.glfwGetWin32Window(...).
 */
public final class ImeUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals/IME");

    /** ImmAssociateContextEx(hwnd, NULL, IACE_DEFAULT) — вернуть ассоциацию по умолчанию. */
    private static final int IACE_DEFAULT = 0x0010;

    private static long immGetContext = 0;
    private static long immAssociateContext = 0;
    private static long immAssociateContextEx = 0;
    private static boolean initialized = false;
    private static boolean disabled = false;
    private static boolean logged = false;
    private static long savedContext = 0;

    private ImeUtil() {
    }

    /**
     * Отключает IME для окна игры. Идемпотентно: повторный вызов лишь
     * повторно снимает ассоциацию (полезно при вводе — GLFW/система могут
     * переассоциировать IME после смены фокуса окна).
     */
    public static void disable() {
        try {
            if (!isWindows()) return;
            if (!ensureInit()) return;
            long hwnd = hwnd();
            if (hwnd == 0) {
                if (!logged) LOGGER.warn("[SkrVisuals] IME: не удалось получить HWND окна игры");
                return;
            }
            // Сохраняем контекст только один раз, чтобы не потерять исходный.
            if (!disabled) {
                savedContext = JNI.callPP(hwnd, immGetContext);
            }
            // Снимаем ассоциацию на уровне TSF (IME Windows 8+: японский, китайский и т.п.)
            // dwFlags = 0 + hIMC = NULL документированно убирает ассоциацию по умолчанию.
            if (immAssociateContextEx != 0) {
                JNI.callPPI(hwnd, 0L, 0, immAssociateContextEx);
            }
            // Снимаем IMM-контекст (классические IME) — окно кандидатов перестаёт появляться.
            JNI.callPPP(hwnd, 0L, immAssociateContext);
            disabled = true;
            logOnce(hwnd);
        } catch (Throwable t) {
            LOGGER.warn("[SkrVisuals] IME disable failed", t);
        }
    }

    /** Восстанавливает IME (вызывать при закрытии экрана). */
    public static void restore() {
        try {
            if (!disabled) return;
            long hwnd = hwnd();
            if (hwnd != 0) {
                if (immAssociateContextEx != 0) {
                    JNI.callPPI(hwnd, 0L, IACE_DEFAULT, immAssociateContextEx);
                }
                if (savedContext != 0) {
                    JNI.callPPP(hwnd, savedContext, immAssociateContext);
                }
            }
            savedContext = 0;
            disabled = false;
        } catch (Throwable ignored) {
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT).contains("win");
    }

    /**
     * Win32 HWND окна игры.
     * Window.getHandle() возвращает GLFWwindow*, поэтому хэндл окна Win32
     * берётся через GLFWNativeWin32.glfwGetWin32Window(...).
     */
    private static long hwnd() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getWindow() == null) return 0;
        long glfwWindow = client.getWindow().getHandle();
        if (glfwWindow == 0) return 0;
        return GLFWNativeWin32.glfwGetWin32Window(glfwWindow);
    }

    private static void logOnce(long hwnd) {
        if (logged) return;
        logged = true;
        LOGGER.info("[SkrVisuals] IME отключён для ввода: hwnd=0x{}, prevContext=0x{}, imm32={}, imm32Ex={}",
                Long.toHexString(hwnd), Long.toHexString(savedContext),
                immAssociateContext != 0, immAssociateContextEx != 0);
    }

    private static boolean ensureInit() {
        if (initialized) return immAssociateContext != 0;
        initialized = true;
        try {
            WindowsLibrary imm32 = new WindowsLibrary("imm32.dll");
            immGetContext = imm32.getFunctionAddress("ImmGetContext");
            immAssociateContext = imm32.getFunctionAddress("ImmAssociateContext");
            immAssociateContextEx = imm32.getFunctionAddress("ImmAssociateContextEx");
            return immGetContext != 0 && immAssociateContext != 0;
        } catch (Throwable t) {
            LOGGER.warn("[SkrVisuals] imm32.dll недоступен, IME не трогаем", t);
            return false;
        }
    }
}
