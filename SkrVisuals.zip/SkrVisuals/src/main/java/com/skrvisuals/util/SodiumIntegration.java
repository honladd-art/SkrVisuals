package com.skrvisuals.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.screen.Screen;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Рефлективное открытие экранных настроек Sodium из нашего кастомного меню.
 *
 * Sodium 0.5+/0.6 не объявляет entrypoint'ов для сторонних модов и патчит только
 * кнопку «Видео настройки» ванильного OptionsScreen (своим OptionsScreenMixin).
 * Наш SettingsScreen создаёт VideoOptionsScreen напрямую, поэтому без явной
 * интеграции Sodium-гуи там никогда не показывается.
 *
 * Точка входа Sodium — статический метод
 * {@code SodiumOptionsGUI.createScreen(Screen parent)} (возвращает готовый Screen:
 * сам экран настроек либо ConfigCorruptedScreen при битом конфиге). Для старых
 * сборок (Sodium 0.4 / Embeddium) запасной вариант — конструктор {@code (Screen)}.
 * Всё делается рефлексией, чтобы SkrVisuals не зависел от Sodium в compile time.
 */
public final class SodiumIntegration {

    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals/Sodium");

    /** Классы гуи настроек: новый пакет Sodium 0.5+ и старый пакет (0.4/Embeddium). */
    private static final String[] GUI_CLASSES = {
            "net.caffeinemc.mods.sodium.client.gui.SodiumOptionsGUI",
            "me.jellysquid.mods.sodium.client.gui.SodiumOptionsGUI",
    };

    private static final Object LOCK = new Object();
    private static boolean resolved = false;
    private static Method factoryMethod;   // static Screen createScreen(Screen)
    private static Constructor<?> factoryCtor; // SodiumOptionsGUI(Screen)

    private SodiumIntegration() {
    }

    /**
     * Создаёт экран настроек Sodium, родителем которого является {@code parent}
     * (туда экран вернётся по «Закрыть»). Возвращает null, если Sodium не установлен
     * или его гуи недоступно — вызывающий должен открыть ванильный экран.
     */
    public static Screen createOptionsScreen(Screen parent) {
        if (!resolved) {
            synchronized (LOCK) {
                if (!resolved) {
                    resolve();
                    resolved = true;
                }
            }
        }
        try {
            if (factoryMethod != null) {
                Object screen = factoryMethod.invoke(null, parent);
                return (screen instanceof Screen s) ? s : null;
            }
            if (factoryCtor != null) {
                Object screen = factoryCtor.newInstance(parent);
                return (screen instanceof Screen s) ? s : null;
            }
        } catch (Throwable t) {
            LOGGER.warn("[SkrVisuals] Не удалось открыть экран настроек Sodium — открываю ванильный", t);
        }
        return null;
    }

    /** Ищет доступную точку входа гуи Sodium (один раз, результат кэшируется). */
    private static void resolve() {
        FabricLoader loader = FabricLoader.getInstance();
        if (!loader.isModLoaded("sodium") && !loader.isModLoaded("embeddium")) {
            return; // Sodium нет — рефлексией заниматься незачем
        }
        for (String className : GUI_CLASSES) {
            try {
                Class<?> guiClass = Class.forName(className);
                if (!Screen.class.isAssignableFrom(guiClass)) {
                    continue;
                }
                try {
                    Method m = guiClass.getDeclaredMethod("createScreen", Screen.class);
                    m.setAccessible(true);
                    factoryMethod = m;
                    LOGGER.info("[SkrVisuals] Найден экран настроек Sodium: {}.createScreen", className);
                    return;
                } catch (NoSuchMethodException ignored) {
                    // нет фабрики — пробуем конструктор
                }
                try {
                    Constructor<?> c = guiClass.getDeclaredConstructor(Screen.class);
                    c.setAccessible(true);
                    factoryCtor = c;
                    LOGGER.info("[SkrVisuals] Найден экран настроек Sodium: new {}", className);
                    return;
                } catch (NoSuchMethodException ignored) {
                    // нет и конструктора — пробуем следующий класс
                }
            } catch (Throwable ignored) {
                // класс недоступен — пробуем следующий
            }
        }
        LOGGER.info("[SkrVisuals] Экран настроек Sodium не найден — «Видео» откроет ванильный экран.");
    }
}
