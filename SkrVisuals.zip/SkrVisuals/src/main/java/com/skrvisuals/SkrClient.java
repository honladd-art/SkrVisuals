package com.skrvisuals;

import com.skrvisuals.config.ConfigManager;
import com.skrvisuals.discord.DiscordRpcManager;
import com.skrvisuals.modules.Module;
import com.skrvisuals.particle.SkrParticles;
import com.skrvisuals.ui.clickgui.ClickScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Client entry point. Registers the key binding that opens the click GUI.
 */
public final class SkrClient implements ClientModInitializer {

    private static KeyBinding clickGuiKey;
    private static int autosaveCounter = 0;

    @Override
    public void onInitializeClient() {
        // Custom particle type must be registered before registries freeze.
        SkrParticles.registerClient();

        // Force module registration, then restore the saved config.
        Skr.INSTANCE.getModuleManager();
        ConfigManager.load();

        // Start Discord Rich Presence.
        DiscordRpcManager.start();

        clickGuiKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding(
                        "key.skrvisuals.openclickgui",
                        InputUtil.Type.KEYSYM,
                        GLFW.GLFW_KEY_RIGHT_SHIFT,
                        "category.skrvisuals"));

        // Auto-save when the game closes.
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ConfigManager.save();
            DiscordRpcManager.stop();
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (clickGuiKey.wasPressed() && client.currentScreen == null) {
                client.setScreen(new ClickScreen());
            }
            // Tick every module (FullBright effect, AutoSprint, ...).
            for (Module module : Skr.INSTANCE.getModuleManager().getModules()) {
                module.onTick(client);
            }

            // Update Discord presence based on game state.
            updateDiscordPresence(client);

            // Auto-save config every 30 seconds.
            if (++autosaveCounter >= 600) {
                autosaveCounter = 0;
                ConfigManager.save();
            }
        });
    }

    /**
     * Checks the current world / server status and pushes the matching presence to Discord.
     * Presence is only refreshed when something actually changes to avoid flooding the IPC.
     */
    private static boolean wasSingleplayer = false;
    private static boolean wasMultiplayer = false;
    private static String lastServer = "";

    private static void updateDiscordPresence(MinecraftClient client) {
        if (!DiscordRpcManager.isRunning()) {
            return;
        }

        boolean singleplayer = client.isInSingleplayer();
        boolean multiplayer = client.getCurrentServerEntry() != null;
        String server = "";

        if (multiplayer && client.getCurrentServerEntry() != null) {
            server = client.getCurrentServerEntry().name;
            if (server == null || server.isBlank()) {
                server = client.getCurrentServerEntry().address;
            }
        } else if (singleplayer && client.world != null && client.world.getRegistryKey() != null) {
            // Use the level name (folder name) as a human-readable identifier.
            var path = client.world.getRegistryKey().getValue().getPath();
            server = path.isEmpty() ? "World" : path;
        }

        if (singleplayer != wasSingleplayer || multiplayer != wasMultiplayer || !server.equals(lastServer)) {
            wasSingleplayer = singleplayer;
            wasMultiplayer = multiplayer;
            lastServer = server;
            DiscordRpcManager.setGameState(singleplayer, multiplayer, server);
        }
    }

    public static void open() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.currentScreen == null) {
            client.setScreen(new ClickScreen());
        }
    }
}