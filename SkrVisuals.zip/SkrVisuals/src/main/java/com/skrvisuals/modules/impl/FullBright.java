package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/**
 * FullBright: applies a real night-vision visual effect while enabled.
 * The effect is added client-side only and refreshed every tick so it never
 * runs out; disabling removes it again.
 *
 * Note: the old approach of raising the gamma option did nothing visible,
 * because vanilla clamps gamma to 0..1 (1.0 is just the normal max slider).
 */
public class FullBright extends Module {

    private static final int REFRESH_DURATION = 240;
    private static final int REFRESH_THRESHOLD = 210;

    public FullBright() {
        super(ModuleCategory.VISUALS, "FullBright", "Night vision: lets you see in the dark.");
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            return;
        }

        boolean hasEffect = client.player.hasStatusEffect(StatusEffects.NIGHT_VISION);

        if (this.isEnabled()) {
            if (!hasEffect
                    || client.player.getStatusEffect(StatusEffects.NIGHT_VISION).getDuration() < REFRESH_THRESHOLD) {
                client.player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION,
                        REFRESH_DURATION,
                        0,
                        false,  // ambient
                        false,  // particles
                        false)); // icon
            }
        } else if (hasEffect) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}