package com.skrvisuals.modules.impl;

import java.util.ArrayList;
import java.util.List;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * ChinaHat: an effect floating above the player's head, tinted with the theme
 * color. Three selectable modes:
 * - «Орбы»: three glowing orbs orbiting the head with fading spiral trails.
 * - «Конус»: a plain translucent cone above the head.
 * - «Нимб»: a flat ring (halo) hovering above the player.
 */
public class ChinaHat extends Module {
    private static final Identifier GLOW_TEXTURE =
            Identifier.of("skrvisuals", "textures/particles/bloom.png");
    /** Full brightness for the glow sprites: LightmapTextureManager.pack(15, 15). */
    private static final int MAX_LIGHT = 15728880;
    /** Число сегментов у конуса и кольца нимба. */
    private static final int SEGMENTS = 48;
    /** Прозрачность конуса. */
    private static final int CONE_ALPHA = 150;
    /** Прозрачность нимба. */
    private static final int HALO_ALPHA = 170;

    private static ChinaHat active;
    private static boolean hookRegistered = false;

    private final ModeSetting mode = new ModeSetting(
            "Режим",
            "Орбы — вращающиеся орбы, Конус — конус над головой, Нимб — круг над игроком.",
            List.of("Орбы", "Конус", "Нимб"),
            "Орбы");
    private final SliderSetting radius =
            new SliderSetting("Радиус", "Радиус орбиты, основание конуса или размер нимба.", 0.2f, 1.5f, 0.5f);
    private final SliderSetting speed =
            new SliderSetting("Скорость", "Скорость вращения орбов.", 10f, 50f, 25f);
    private final SliderSetting orbSize =
            new SliderSetting("Размер орба", "Размер светящегося шара.", 0.1f, 0.6f, 0.25f);
    private final SliderSetting trailLength =
            new SliderSetting("Длина следа", "Количество сегментов хвоста.", 5f, 40f, 15f);
    private final SliderSetting heightOffset =
            new SliderSetting("Высота", "Смещение орбит по вертикали.", 0f, 1f, 0f);
    private final SliderSetting coneHeight =
            new SliderSetting("Высота конуса", "Высота конуса над головой.", 0.2f, 1.5f, 0.6f);
    private final SliderSetting haloThickness =
            new SliderSetting("Толщина нимба", "Толщина кольца нимба.", 0.05f, 0.4f, 0.15f);
    private final BooleanSetting onlyThirdPerson =
            new BooleanSetting("Только от 3 лица", "Скрывать орбы в первом лице.", false);

    private final long startTime = System.currentTimeMillis();

    public ChinaHat() {
        super(ModuleCategory.VISUALS, "ChinaHat", "Орбы, конус или нимб над головой.");
        setting(mode);
        // «Радиус» общий для всех режимов, остальные настройки — по режиму:
        // «Орбы» — скорость/размер/след, «Конус» — высота, «Нимб» — толщина.
        speed.setHideCondition(() -> !"Орбы".equals(mode.getValue()));
        orbSize.setHideCondition(() -> !"Орбы".equals(mode.getValue()));
        trailLength.setHideCondition(() -> !"Орбы".equals(mode.getValue()));
        coneHeight.setHideCondition(() -> !"Конус".equals(mode.getValue()));
        haloThickness.setHideCondition(() -> !"Нимб".equals(mode.getValue()));
        setting(radius);
        setting(speed);
        setting(orbSize);
        setting(trailLength);
        setting(coneHeight);
        setting(haloThickness);
        setting(heightOffset);
        setting(onlyThirdPerson);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) {
            return;
        }
        hookRegistered = true;
        WorldRenderEvents.LAST.register(ChinaHat::onWorldRender);
    }

    private static float tickDelta(WorldRenderContext context) {
        return context.tickCounter().getTickDelta(false);
    }

    // ---------------------------------------------------------------- rendering
    private static void onWorldRender(WorldRenderContext context) {
        ChinaHat module = active;
        if (module == null || !module.isEnabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {
            return;
        }
        float delta = tickDelta(context);
        long now = System.currentTimeMillis();

        // Орбы над собой. "Только от 3 лица" скрывает их лишь у себя —
        // на друзьях орбы видны и от первого лица.
        boolean hideSelf = module.onlyThirdPerson.getValue()
                && client.options.getPerspective().isFirstPerson();
        if (!hideSelf) {
            module.renderFor(context, player, delta, now);
        }

        // Орбы над друзьями — каждый рендерится полностью изолированно
        // (свой push/translate/buffer/draw/pop), как в Trails.
        if (Friends.isChinaHatOnFriends()) {
            for (var entity : client.world.getPlayers()) {
                if (entity == player) {
                    continue;
                }
                if (!Friends.isFriend(entity)) {
                    continue;
                }
                module.renderFor(context, entity, delta, now);
            }
        }
    }

    /** Рисует эффект над головой данного игрока — изолированный рендер-блок (как в Trails). */
    private void renderFor(WorldRenderContext context,
                           net.minecraft.entity.player.PlayerEntity target, float delta, long now) {
        MinecraftClient client = MinecraftClient.getInstance();

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camera = context.camera().getPos();

        // Интерполированная позиция — как в Trails, работает и для удалённых игроков.
        Vec3d lerped = target.getLerpedPos(delta);
        double headY = lerped.getY() + target.getHeight() + 0.3D + this.heightOffset.getValue();
        Vec3d head = new Vec3d(lerped.getX(), headY, lerped.getZ());

        int baseColor = Colors.clientColor();
        int r0 = (baseColor >> 16) & 0xFF;
        int g0 = (baseColor >> 8) & 0xFF;
        int b0 = baseColor & 0xFF;

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();
        var entry = matrices.peek();
        var matrix = entry.getPositionMatrix();

        String current = this.mode.getValue();
        if ("Конус".equals(current)) {
            // Плоский конус цветом темы: debug_quads без back-face culling.
            VertexConsumer buffer = consumers.getBuffer(RenderLayer.getDebugQuads());
            renderCone(buffer, matrix, head, r0, g0, b0);
            consumers.draw(RenderLayer.getDebugQuads());
        } else if ("Нимб".equals(current)) {
            // Плоское кольцо (круг) над игроком цветом темы.
            VertexConsumer buffer = consumers.getBuffer(RenderLayer.getDebugQuads());
            renderHalo(buffer, matrix, head, r0, g0, b0);
            consumers.draw(RenderLayer.getDebugQuads());
        } else {
            float camYaw = context.camera().getYaw();
            float camPitch = context.camera().getPitch();
            VertexConsumer buffer =
                    consumers.getBuffer(RenderLayer.getEntityTranslucent(GLOW_TEXTURE));

            renderOrbTrail(buffer, entry, matrix, head, r0, g0, b0, 0.0F, camYaw, camPitch, now);
            renderOrbTrail(buffer, entry, matrix, head, r0, g0, b0, 120.0F, camYaw, camPitch, now);
            renderOrbTrail(buffer, entry, matrix, head, r0, g0, b0, 240.0F, camYaw, camPitch, now);

            consumers.draw(RenderLayer.getEntityTranslucent(GLOW_TEXTURE));
        }
        matrices.pop();
    }

    /**
     * «Конус»: обычный конус над головой — основание радиуса «Радиус» лежит
     * над головой, вершина поднята на «Высота конуса». Цвет темы.
     */
    private void renderCone(VertexConsumer buffer, org.joml.Matrix4f matrix, Vec3d head,
                            int r, int g, int b) {
        float baseRadius = this.radius.getValue();
        float coneH = this.coneHeight.getValue();

        float cx = (float) head.x;
        float baseY = (float) head.y;
        float cz = (float) head.z;
        float apexY = (float) (head.y + coneH);

        for (int i = 0; i < SEGMENTS; i++) {
            double a0 = Math.PI * 2.0D * i / SEGMENTS;
            double a1 = Math.PI * 2.0D * (i + 1) / SEGMENTS;

            float x0 = (float) (head.x + Math.sin(a0) * baseRadius);
            float z0 = (float) (head.z + Math.cos(a0) * baseRadius);
            float x1 = (float) (head.x + Math.sin(a1) * baseRadius);
            float z1 = (float) (head.z + Math.cos(a1) * baseRadius);

            // Боковая грань (вершина задаётся дважды — получается треугольник).
            face(buffer, matrix, x0, baseY, z0, x1, baseY, z1,
                    cx, apexY, cz, cx, apexY, cz, r, g, b, CONE_ALPHA);
            // Дно конуса, чтобы он выглядел объёмным снизу.
            face(buffer, matrix, cx, baseY, cz, x1, baseY, z1,
                    x0, baseY, z0, x0, baseY, z0, r, g, b, CONE_ALPHA);
        }
    }

    /**
     * «Нимб»: плоское кольцо (круг) над игроком — внешний радиус «Радиус»,
     * толщина «Толщина нимба». Цвет темы.
     */
    private void renderHalo(VertexConsumer buffer, org.joml.Matrix4f matrix, Vec3d head,
                            int r, int g, int b) {
        float outer = this.radius.getValue();
        float thickness = Math.min(this.haloThickness.getValue(), outer * 0.9F);
        float inner = Math.max(0.01F, outer - thickness);
        float y = (float) head.y;

        for (int i = 0; i < SEGMENTS; i++) {
            double a0 = Math.PI * 2.0D * i / SEGMENTS;
            double a1 = Math.PI * 2.0D * (i + 1) / SEGMENTS;

            float ox0 = (float) (head.x + Math.sin(a0) * outer);
            float oz0 = (float) (head.z + Math.cos(a0) * outer);
            float ox1 = (float) (head.x + Math.sin(a1) * outer);
            float oz1 = (float) (head.z + Math.cos(a1) * outer);
            float ix0 = (float) (head.x + Math.sin(a0) * inner);
            float iz0 = (float) (head.z + Math.cos(a0) * inner);
            float ix1 = (float) (head.x + Math.sin(a1) * inner);
            float iz1 = (float) (head.z + Math.cos(a1) * inner);

            // debug_quads рисуется без отсечения задних граней — видно с обеих сторон.
            face(buffer, matrix, ox0, y, oz0, ox1, y, oz1,
                    ix1, y, iz1, ix0, y, iz0, r, g, b, HALO_ALPHA);
        }
    }

    /** Один четырёхугольник в мировых координатах для цветового слоя (debug_quads). */
    private static void face(VertexConsumer buffer, org.joml.Matrix4f matrix,
                             float ax, float ay, float az,
                             float bx, float by, float bz,
                             float cx, float cy, float cz,
                             float dx, float dy, float dz,
                             int r, int g, int b, int a) {
        buffer.vertex(matrix, ax, ay, az).color(r, g, b, a);
        buffer.vertex(matrix, bx, by, bz).color(r, g, b, a);
        buffer.vertex(matrix, cx, cy, cz).color(r, g, b, a);
        buffer.vertex(matrix, dx, dy, dz).color(r, g, b, a);
    }

    /** One orbiting orb plus its fading spiral trail of billboard sprites. */
    private void renderOrbTrail(VertexConsumer buffer, MatrixStack.Entry entry,
                                org.joml.Matrix4f matrix, Vec3d center,
                                int r0, int g0, int b0, float angleOffsetDeg,
                                float camYaw, float camPitch, long now) {
        float rad = this.radius.getValue();
        float spd = Math.max(1.0F, this.speed.getValue());
        float size = this.orbSize.getValue();
        int length = Math.max(1, (int) this.trailLength.getValue());
        float alphaFactor = 255.0F / length;

        float elapsed = (now - this.startTime) / (float) spd;
        // Полный билборд: базис камеры (yaw + pitch), чтобы спрайты не
        // схлопывались в линию при взгляде сверху/снизу.
        float yawRad = (float) Math.toRadians(camYaw);
        float pitchRad = (float) Math.toRadians(camPitch);
        float rx = -MathHelper.cos(yawRad);
        float rz = -MathHelper.sin(yawRad);
        float ux = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uy = MathHelper.cos(pitchRad);
        float uz = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        for (int i = 0; i < length; i++) {
            double angle = Math.toRadians(angleOffsetDeg) + 0.15F * (elapsed - i * 15.0F);
            double x = center.x + Math.sin(angle) * rad;
            double y = center.y;
            double z = center.z + Math.cos(angle) * rad;

            // Gentle brightness pulse per segment.
            double timeProgress = now / 1000.0D + i * 0.1D + angleOffsetDeg;
            float blend = (float) Math.abs(Math.sin(timeProgress * Math.PI));
            int cr = lerp(r0, Math.min(255, r0 + 80), blend);
            int cg = lerp(g0, Math.min(255, g0 + 80), blend);
            int cb = lerp(b0, Math.min(255, b0 + 80), blend);

            int alpha = MathHelper.clamp((int) (255.0F - i * alphaFactor), 0, 255);
            if (alpha <= 4) {
                continue;
            }

            float trailSize = size * (1.0F - i / (float) length * 0.5F);
            float half = trailSize / 2.0F;

            float px = (float) x;
            float py = (float) y;
            float pz = (float) z;

            float rXh = rx * half, rZh = rz * half;
            float uXh = ux * half, uYh = uy * half, uZh = uz * half;

            // Билборд по полному базису камеры (right x up).
            corner(buffer, entry, matrix, px - rXh - uXh, py - uYh, pz - rZh - uZh, cr, cg, cb, alpha, 0.0F, 1.0F);
            corner(buffer, entry, matrix, px + rXh - uXh, py - uYh, pz + rZh - uZh, cr, cg, cb, alpha, 1.0F, 1.0F);
            corner(buffer, entry, matrix, px + rXh + uXh, py + uYh, pz + rZh + uZh, cr, cg, cb, alpha, 1.0F, 0.0F);
            corner(buffer, entry, matrix, px - rXh + uXh, py + uYh, pz - rZh + uZh, cr, cg, cb, alpha, 0.0F, 0.0F);

            // Reversed winding so the sprite is visible from any side.
            corner(buffer, entry, matrix, px - rXh - uXh, py - uYh, pz - rZh - uZh, cr, cg, cb, alpha, 0.0F, 1.0F);
            corner(buffer, entry, matrix, px - rXh + uXh, py + uYh, pz - rZh + uZh, cr, cg, cb, alpha, 0.0F, 0.0F);
            corner(buffer, entry, matrix, px + rXh + uXh, py + uYh, pz + rZh + uZh, cr, cg, cb, alpha, 1.0F, 0.0F);
            corner(buffer, entry, matrix, px + rXh - uXh, py - uYh, pz + rZh - uZh, cr, cg, cb, alpha, 1.0F, 1.0F);
        }
    }

    private static void corner(VertexConsumer buffer, MatrixStack.Entry entry,
                               org.joml.Matrix4f matrix, float x, float y, float z,
                               int r, int g, int b, int a, float u, float v) {
        buffer.vertex(matrix, x, y, z)
                .color(r, g, b, a)
                .texture(u, v)
                .overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV)
                .light(MAX_LIGHT)
                .normal(entry, 0.0F, 1.0F, 0.0F);
    }

    private static int lerp(int from, int to, float t) {
        return Math.round(from + (to - from) * t);
    }
}