package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import net.minecraft.client.MinecraftClient;

/**
 * AutoSprint: keeps the player sprinting whenever they move forward.
 * Purely client-side (sets the sprint flag on the local player).
 */
public class AutoSprint extends Module {

    public AutoSprint() {
        super(ModuleCategory.UTILITY, "AutoSprint", "Automatically sprints when moving forward.");
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (!this.isEnabled() || client.player == null || client.world == null) {
            return;
        }
        // Only sprint when actually moving forward.
        if (!client.options.forwardKey.isPressed()) {
            return;
        }
        if (client.player.isSneaking() || client.player.isUsingItem()) {
            return;
        }
        // Vanilla stops sprinting below 6 food points.
        if (client.player.getHungerManager().getFoodLevel() <= 6) {
            return;
        }
        client.player.setSprinting(true);
    }
}