package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * SuperOptimize: СУПЕР МЕГА оптимизация в категории Utility.
 *
 * В отличие от модуля Optimize (который задвигает ванильные опции — облака,
 * частицы, графику, AO, тени, дальность), этот модуль ничего не меняет
 * в настройках игры. Вся оптимизация делается на уровне рендера через миксины:
 *
 *  - Куллинг чанков за спиной (WorldRendererMixin): чанки позади камеры не
 *    рендерятся — снижение нагрузки на GPU/CPU без правки ванильных опций.
 *  - Куллинг сущностей за спиной (EntityCullingMixin): мобы/игроки позади
 *    камеры не рендерятся — дополнительный прирост FPS на плотных серверах.
 *
 * Настройки включают/выключают каждую функцию и задают дистанцию куллинга.
 */
public class SuperOptimize extends Module {

    /** Куллинг чанков за спиной камеры. */
    private final BooleanSetting chunkCulling =
            new BooleanSetting("Куллинг чанков", "Не рендерит чанки за спиной камеры (через WorldRenderer). Автоматически отключается при установленном Sodium.", true);

    /** Куллинг сущностей за спиной камеры. */
    private final BooleanSetting entityCulling =
            new BooleanSetting("Куллинг сущностей", "Не рендерит сущности за спиной камеры (через EntityRenderDispatcher).", true);

    /** Куллинг частиц за спиной камеры. */
    private final BooleanSetting particleCulling =
            new BooleanSetting("Куллинг частиц", "Не спавнит частицы за спиной камеры (через ParticleManager).", true);

    /** Куллинг блок-энтити (сундуки, таблички и т.п.) за спиной камеры. */
    private final BooleanSetting blockEntityCulling =
            new BooleanSetting("Куллинг блок-энтити", "Не рендерит блок-энтити за спиной камеры (через BlockEntityRenderDispatcher).", true);

    /** Полное отключение рендера дождя и снега (WeatherRendering). */
    private final BooleanSetting disableWeather =
            new BooleanSetting("Без дождя/снега", "Отключает рендер осадков — заметный прирост FPS в плохую погоду.", false);

    /**
     * Дистанция куллинга в блоках. Объекты ближе этого расстояния не куллится,
     * чтобы избежать мерцания при резких поворотах камеры.
     */
    private final SliderSetting cullDistance =
            new SliderSetting("Дистанция куллинга", "Мин. дистанция (блоки) — ближе не куллится.", 0.0f, 48.0f, 12.0f);

    /**
     * Максимальная дистанция рендера частиц. Частицы дальше этого расстояния
     * не спавнятся. Меньше — меньше частиц на экране, выше FPS.
     */
    private final SliderSetting particleDistance =
            new SliderSetting("Дистанция частиц", "Макс. дистанция спавна частиц (блоки). Меньше — больше FPS.", 4.0f, 64.0f, 32.0f);

    /**
     * Множитель дистанции рендера сущностей (1.0 = ваниль, 0.5 = вдвое ближе).
     * Сущности за пределами уменьшенной дистанции не рендерятся — заметный прирост
     * FPS на серверах с большим количеством мобов.
     */
    private final SliderSetting entityDistance =
            new SliderSetting("Дистанция сущностей", "Множитель дальности рендера сущностей (0.1–1.0). Меньше — больше FPS.", 0.1f, 1.0f, 1.0f);

    /** Единственный экземпляр модуля (для доступа из статических методов куллинга). */
    private static SuperOptimize instance;

    public SuperOptimize() {
        super(ModuleCategory.UTILITY, "SuperOptimize",
                "СУПЕР МЕГА оптимизация: куллинг чанков, сущностей, частиц и блок-энтити за спиной. Не трогает настройки игры.");
        instance = this;
        setting(chunkCulling);
        setting(entityCulling);
        setting(particleCulling);
        setting(blockEntityCulling);
        setting(disableWeather);
        setting(cullDistance);
        setting(particleDistance);
        setting(entityDistance);
    }

    public static SuperOptimize getInstance() {
        return instance;
    }

    /**
     * Установлен ли Sodium/форк Sodium (патчит рендер чанков). Кэшируется:
     * запрос только к FabricLoader, без тяжёлых операций.
     */
    private static Boolean sodiumPresent;

    private static boolean isSodiumPresent() {
        if (sodiumPresent == null) {
            FabricLoader loader = FabricLoader.getInstance();
            sodiumPresent = loader.isModLoaded("sodium") || loader.isModLoaded("embeddium");
        }
        return sodiumPresent;
    }

    public static boolean isChunkCullingEnabled() {
        // WorldRendererMixin не применяется при наличии Sodium (см. SkrMixinPlugin) —
        // точка инъекции перезаписана, поэтому функция недоступна.
        if (isSodiumPresent()) {
            return false;
        }
        return instance != null && instance.isEnabled() && instance.chunkCulling.getValue();
    }

    public static boolean isEntityCullingEnabled() {
        return instance != null && instance.isEnabled() && instance.entityCulling.getValue();
    }

    public static boolean isParticleCullingEnabled() {
        return instance != null && instance.isEnabled() && instance.particleCulling.getValue();
    }

    public static boolean isBlockEntityCullingEnabled() {
        return instance != null && instance.isEnabled() && instance.blockEntityCulling.getValue();
    }

    public static boolean isWeatherDisabled() {
        return instance != null && instance.isEnabled() && instance.disableWeather.getValue();
    }

    public static float getCullDistance() {
        return instance != null ? instance.cullDistance.getValue() : 12.0f;
    }

    public static float getParticleDistance() {
        return instance != null ? instance.particleDistance.getValue() : 32.0f;
    }

    public static float getEntityDistanceMultiplier() {
        return instance != null ? instance.entityDistance.getValue() : 1.0f;
    }

    /**
     * Проверяет, находится ли частица в допустимой дистанции для спавна.
     * Используется в миксине ParticleManager#addParticle.
     *
     * @param x мировая X-координата частицы
     * @param y мировая Y-координата частицы
     * @param z мировая Z-координата частицы
     * @return true, если частица дальше допустимой дистанции (надо пропустить)
     */
    public static boolean isParticleTooFar(double x, double y, double z) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.gameRenderer == null) {
            return false;
        }
        Vec3d camPos = client.gameRenderer.getCamera().getPos();
        double dx = x - camPos.x;
        double dy = y - camPos.y;
        double dz = z - camPos.z;
        double distSq = dx * dx + dy * dy + dz * dz;
        float maxDist = getParticleDistance();
        return distSq > maxDist * maxDist;
    }

    /**
     * Определяет, находится ли абсолютная точка (мировая координата) за спиной камеры.
     * Использует вектор взгляда игрока и позицию камеры.
     *
     * @param absX мировая X-координата центра объекта
     * @param absY мировая Y-координата центра объекта
     * @param absZ мировая Z-координата центра объекта
     * @return true, если объект за спиной и дальше дистанции куллинга
     */
    public static boolean isBehindCamera(double absX, double absY, double absZ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.gameRenderer == null) {
            return false;
        }

        Vec3d camPos = client.gameRenderer.getCamera().getPos();
        double relX = absX - camPos.x;
        double relY = absY - camPos.y;
        double relZ = absZ - camPos.z;

        return isBehindCameraRel(relX, relY, relZ);
    }

    /**
     * То же, что {@link #isBehindCamera(double, double, double)}, но для координат,
     * уже выраженных относительно камеры (entity.pos - camera.pos). Используется
     * в миксине EntityRenderDispatcher#render, где x/y/z — именно такие относительные
     * координаты.
     */
    public static boolean isBehindCameraRel(double relX, double relY, double relZ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) {
            return false;
        }

        double distSq = relX * relX + relY * relY + relZ * relZ;
        float dist = getCullDistance();
        if (distSq < dist * dist) {
            return false;
        }

        Vec3d forward = client.player.getRotationVec(1.0f);
        double dot = relX * forward.x + relY * forward.y + relZ * forward.z;
        return dot < 0.0;
    }
}
