package com.skrvisuals.modules.impl;

import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/**
 * KillEffect: визуальный эффект на месте смерти убитой тобой сущности.
 *
 * - «Душа»: полупрозрачный скин Стива поднимается вверх и растворяется (2 с).
 * - «Молния»: визуальная молния в точке смерти (урона не наносит).
 * - «Блоки»: блоки в радиусе 5 подсвечиваются цветом темы, эффект живёт 2 с.
 *
 * Определение убийства — как в KillSounds: запоминаем последнюю атакованную
 * клиентскую сущность; если она начала анимацию смерти или удалена из мира —
 * засчитываем убийство и спавним эффект.
 */
public class KillEffect extends Module {

    private static KillEffect active;
    private static boolean hooksRegistered = false;

    /** Общее время жизни эффекта. */
    private static final long DURATION_MS = 2000L;
    /** Полная яркость эффектов: LightmapTextureManager.pack(15, 15). */
    private static final int MAX_LIGHT = 15728880;
    /** Текстура стандартного скина Стива (64x64). */
    private static final Identifier STEVE_SKIN =
            Identifier.of("minecraft", "textures/entity/player/wide/steve.png");
    /** Радиус подсветки блоков (по ТЗ — 5). */
    private static final int BLOCK_RADIUS = 5;
    /** Сколько миллисекунд после удара смерть цели засчитывается как твоё убийство. */
    private static final long KILL_WINDOW_MS = 5000L;

    private final ModeSetting effect = new ModeSetting(
            "Эффект",
            "Душа, Молния или Блоки.",
            List.of("Душа", "Молния", "Блоки"),
            "Душа"
    );

    private final BooleanSetting players =
            new BooleanSetting("Игроки", "Эффект при убийстве игроков.", true);

    private final BooleanSetting mobs =
            new BooleanSetting("Мобы", "Эффект при убийстве мобов и животных.", true);

    /** Последняя сущность, по которой ударил, и время удара. */
    private Entity lastTarget;
    private long lastHitTime;

    private final CopyOnWriteArrayList<KillFx> effects = new CopyOnWriteArrayList<>();

    public KillEffect() {
        super(ModuleCategory.COMBAT, "KillEffect", "Визуальный эффект на месте убийства.");
        setting(effect);
        setting(players);
        setting(mobs);
        active = this;
        registerHooks();
    }

    private static void registerHooks() {
        if (hooksRegistered) {
            return;
        }
        hooksRegistered = true;

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            KillEffect module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
            // Интересует только клиентский мир (серверные копии сущностей не считаем).
            if (!(world instanceof ClientWorld)) {
                return ActionResult.PASS;
            }
            if (entity instanceof FakePlayerEntity) {
                return ActionResult.PASS;
            }
            if (!module.targetAllowed(entity)) {
                return ActionResult.PASS;
            }
            module.lastTarget = entity;
            module.lastHitTime = System.currentTimeMillis();
            return ActionResult.PASS;
        });

        WorldRenderEvents.LAST.register(KillEffect::onWorldRender);
    }
    @Override
    public void onTick(MinecraftClient client) {
        if (!isEnabled()) {
            effects.clear();
            reset();
            return;
        }
        Entity target = lastTarget;
        if (target == null) {
            return;
        }
        if (client.world == null || target.getWorld() != client.world) {
            reset();
            return;
        }
        if (System.currentTimeMillis() - lastHitTime > KILL_WINDOW_MS) {
            reset();
            return;
        }

        boolean died;
        if (target instanceof LivingEntity living) {
            died = living.deathTime > 0 || living.isRemoved();
        } else {
            died = target.isRemoved();
        }

        if (died) {
            if ("Молния".equals(effect.getValue())) {
                // Ванильная молния: спавним настоящую клиентскую LightningEntity.
                spawnLightning(target.getPos());
            } else {
                effects.add(new KillFx(target.getPos()));
            }
            reset();
        }
    }

    /** Ванильная молния в точке смерти (только на клиенте, урона не наносит). */
    private static void spawnLightning(Vec3d pos) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }
        LightningEntity bolt = new LightningEntity(EntityType.LIGHTNING_BOLT, client.world);
        bolt.refreshPositionAfterTeleport(pos.x, pos.y, pos.z);
        client.world.addEntity(bolt);
    }

    private boolean targetAllowed(Entity target) {
        return target instanceof PlayerEntity ? players.getValue() : mobs.getValue();
    }

    private void reset() {
        lastTarget = null;
        lastHitTime = 0L;
    }

    // ---------------------------------------------------------------- rendering
    private static void onWorldRender(WorldRenderContext context) {
        KillEffect module = active;
        if (module == null || !module.isEnabled() || module.effects.isEmpty()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        long now = System.currentTimeMillis();
        module.effects.removeIf(fx -> now - fx.time > DURATION_MS);
        if (module.effects.isEmpty()) {
            return;
        }

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camera = context.camera().getPos();
        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();

        switch (module.effect.getValue()) {
            case "Блоки" -> drawBlocks(module, client, matrices, consumers, now);
            default -> drawSoul(module, matrices, consumers, now);
        }

        matrices.pop();
    }

    /** ease-out-cubic. */
    private static float easeOut(float t) {
        return 1.0F - (float) Math.pow(1.0D - MathHelper.clamp(t, 0.0F, 1.0F), 3.0D);
    }


    /**
     * «Душа»: полупрозрачный скин Стива (билборд) медленно поднимается и растворяется.
     */
    private static void drawSoul(KillEffect module, MatrixStack matrices,
                                 VertexConsumerProvider.Immediate consumers, long now) {
        Vec3d camera = MinecraftClient.getInstance().gameRenderer.getCamera().getPos();
        VertexConsumer buffer =
                consumers.getBuffer(RenderLayer.getEntityTranslucent(STEVE_SKIN));

        for (KillFx fx : module.effects) {
            float t = MathHelper.clamp((now - fx.time) / (float) DURATION_MS, 0.0F, 1.0F);
            // Быстрое появление + плавный уход по прозрачности со временем.
            float fadeIn = Math.min(1.0F, (now - fx.time) / 200.0F);
            int alpha = Math.max(0, (int) (200.0F * (1.0F - t) * fadeIn));
            if (alpha <= 0) {
                continue;
            }

            float rise = easeOut(t) * 1.25F;
            // Билборд: всегда повёрнут лицом к камере.
            float yaw = (float) Math.toDegrees(
                    Math.atan2(camera.x - fx.pos.x, camera.z - fx.pos.z));

            matrices.push();
            matrices.translate(fx.pos.x, fx.pos.y + rise, fx.pos.z);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
            var entry = matrices.peek();
            var matrix = entry.getPositionMatrix();

            // Билборд собирается из прямоугольников скина (UV из steve.png, 64x64).
            quad(buffer, matrix, entry, -0.25F, 1.50F, 0.25F, 2.00F, 8, 8, 16, 16, alpha);    // голова
            quad(buffer, matrix, entry, -0.25F, 0.75F, 0.25F, 1.50F, 20, 20, 28, 32, alpha);  // тело
            quad(buffer, matrix, entry, -0.50F, 0.75F, -0.25F, 1.50F, 44, 20, 48, 32, alpha); // левая рука
            quad(buffer, matrix, entry, 0.25F, 0.75F, 0.50F, 1.50F, 36, 48, 40, 60, alpha);   // правая рука
            quad(buffer, matrix, entry, -0.25F, 0.00F, 0.00F, 0.75F, 4, 20, 8, 32, alpha);    // левая нога
            quad(buffer, matrix, entry, 0.00F, 0.00F, 0.25F, 0.75F, 20, 52, 24, 64, alpha);   // правая нога
            matrices.pop();
        }
        consumers.draw(RenderLayer.getEntityTranslucent(STEVE_SKIN));
    }

    /** Textured billboard quad: (x0..x1) по горизонтали, (y0..y1) по вертикали. */
    private static void quad(VertexConsumer buffer, org.joml.Matrix4f matrix,
                             MatrixStack.Entry entry,
                             float x0, float y0, float x1, float y1,
                             int u0, int v0, int u1, int v1, int alpha) {
        buffer.vertex(matrix, x1, y1, 0.0F).color(255, 255, 255, alpha)
                .texture(u1 / 64.0F, v0 / 64.0F)
                .overlay(OverlayTexture.DEFAULT_UV).light(MAX_LIGHT)
                .normal(entry, 0.0F, 0.0F, 1.0F);
        buffer.vertex(matrix, x0, y1, 0.0F).color(255, 255, 255, alpha)
                .texture(u0 / 64.0F, v0 / 64.0F)
                .overlay(OverlayTexture.DEFAULT_UV).light(MAX_LIGHT)
                .normal(entry, 0.0F, 0.0F, 1.0F);
        buffer.vertex(matrix, x0, y0, 0.0F).color(255, 255, 255, alpha)
                .texture(u0 / 64.0F, v1 / 64.0F)
                .overlay(OverlayTexture.DEFAULT_UV).light(MAX_LIGHT)
                .normal(entry, 0.0F, 0.0F, 1.0F);
        buffer.vertex(matrix, x1, y0, 0.0F).color(255, 255, 255, alpha)
                .texture(u1 / 64.0F, v1 / 64.0F)
                .overlay(OverlayTexture.DEFAULT_UV).light(MAX_LIGHT)
                .normal(entry, 0.0F, 0.0F, 1.0F);
    }


    /**
     * «Блоки»: блоки подсвечиваются цветом темы ТОЛЬКО на уровне ног противника
     * и ниже. Сначала появляются блоки прямо под ногами, затем волна плавно
     * расходится к радиусу 5. Эффект живёт 2 секунды и плавно исчезает.
     * Трава, цветы и прочие растения (и всё без коллизии) игнорируются.
     */
    private static void drawBlocks(KillEffect module, MinecraftClient client, MatrixStack matrices,
                                   VertexConsumerProvider.Immediate consumers, long now) {
        int base = Colors.clientColor();
        int r = (base >> 16) & 0xFF;
        int g = (base >> 8) & 0xFF;
        int b = base & 0xFF;

        // debug_quads без back-face culling — грани не срезаются «треугольниками».
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getDebugQuads());
        var matrix = matrices.peek().getPositionMatrix();

        for (KillFx fx : module.effects) {
            float t = MathHelper.clamp((now - fx.time) / (float) DURATION_MS, 0.0F, 1.0F);
            float fadeIn = Math.min(1.0F, (now - fx.time) / 200.0F);
            // Волна роста: за первые 1.2 с радиус доходит от 0 до BLOCK_RADIUS.
            float grow = easeOut(MathHelper.clamp((now - fx.time) / 1200.0F, 0.0F, 1.0F));
            float growRadius = grow * BLOCK_RADIUS;
            // Постоянная интенсивность, затем плавное угасание в конце.
            float fadeOut = 1.0F - easeOut(MathHelper.clamp((t - 0.65F) / 0.35F, 0.0F, 1.0F));
            int alpha = Math.max(0, (int) (80.0F * fadeIn * fadeOut));
            if (alpha <= 0) {
                continue;
            }

            BlockPos center = BlockPos.ofFloored(fx.pos);
            ClientWorld world = client.world;
            // Ноги противника — верхняя граница: выше этого уровня блоки не трогаем.
            int feetY = center.getY();
            int drawn = 0;
            for (BlockPos p : BlockPos.iterateOutwards(center, BLOCK_RADIUS, BLOCK_RADIUS, BLOCK_RADIUS)) {
                if (p.getY() > feetY) {
                    continue;
                }
                // Рост: сначала блоки под ногами, затем дальше по радиусу.
                double dx = (p.getX() + 0.5D) - fx.pos.x;
                double dy = (p.getY() + 0.5D) - fx.pos.y;
                double dz = (p.getZ() + 0.5D) - fx.pos.z;
                if (Math.sqrt(dx * dx + dy * dy + dz * dz) > growRadius) {
                    continue;
                }
                var state = world.getBlockState(p);
                // Игнорируем траву, цветы, папоротники и прочие растения / нематериальные блоки.
                if (state.isAir() || state.isReplaceable()
                        || state.getCollisionShape(world, p).isEmpty()) {
                    continue;
                }
                if (++drawn > 600) {
                    break;
                }
                float x0 = p.getX() - 0.002F;
                float y0 = p.getY() - 0.002F;
                float z0 = p.getZ() - 0.002F;
                float x1 = p.getX() + 1.002F;
                float y1 = p.getY() + 1.002F;
                float z1 = p.getZ() + 1.002F;

                // Рисуем только грани, выходящие наружу (в воздух/прозрачный блок),
                // чтобы заполнение не наслаивалось и выглядело аккуратно.
                if (isFaceExposed(world, p, x0, y1, z0, x1, y1, z1)) { // top
                    face(buffer, matrix, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, r, g, b, alpha);
                }
                if (isFaceExposed(world, p, x0, y0, z1, x1, y0, z1)) { // bottom
                    face(buffer, matrix, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, r, g, b, alpha);
                }
                if (isFaceExposed(world, p, x0, y0, z0, x0, y1, z0, x0, y1, z1)) { // west
                    face(buffer, matrix, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, r, g, b, alpha);
                }
                if (isFaceExposed(world, p, x1, y0, z0, x1, y1, z0, x1, y1, z1)) { // east
                    face(buffer, matrix, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, r, g, b, alpha);
                }
                if (isFaceExposed(world, p, x0, y0, z0, x1, y0, z0, x1, y1, z0)) { // north
                    face(buffer, matrix, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, r, g, b, alpha);
                }
                if (isFaceExposed(world, p, x0, y0, z1, x1, y0, z1, x0, y1, z1)) { // south
                    face(buffer, matrix, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, r, g, b, alpha);
                }
            }
        }
        consumers.draw(RenderLayer.getDebugQuads());
    }


    /** true, если хотя бы одна точка грани открыта (воздух/растение/прозрачный блок по ту сторону). */
    private static boolean isFaceExposed(ClientWorld world, BlockPos pos,
                                         float... samples) {
        for (int i = 0; i + 2 < samples.length; i += 3) {
            float fx = samples[i];
            float fy = samples[i + 1];
            float fz = samples[i + 2];
            int dx = fx < pos.getX() ? -1 : (fx > pos.getX() + 1.0F ? 1 : 0);
            int dy = fy < pos.getY() ? -1 : (fy > pos.getY() + 1.0F ? 1 : 0);
            int dz = fz < pos.getZ() ? -1 : (fz > pos.getZ() + 1.0F ? 1 : 0);
            BlockPos n = pos.add(dx, dy, dz);
            var ns = world.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable()
                    || !ns.isOpaqueFullCube()) {
                return true;
            }
        }
        return false;
    }

    private static void face(VertexConsumer buffer, org.joml.Matrix4f matrix,
                             float ax, float ay, float az,
                             float bx, float by, float bz,
                             float cx, float cy, float cz,
                             float dx, float dy, float dz,
                             int r, int g, int b, int a) {
        buffer.vertex(matrix, ax, ay, az).color(r, g, b, a);
        buffer.vertex(matrix, bx, by, bz).color(r, g, b, a);
        buffer.vertex(matrix, cx, cy, cz).color(r, g, b, a);
        buffer.vertex(matrix, dx, dy, dz).color(r, g, b, a);
    }

    // ------------------------------------------------------------------ data
    /** Один активный эффект: точка смерти, время появления, seed молнии. */
    private static final class KillFx {
        final Vec3d pos;
        final long time;
        final long seed;

        KillFx(Vec3d pos) {
            this.pos = pos;
            this.time = System.currentTimeMillis();
            this.seed = new Random().nextLong();
        }
    }
}
