package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.ui.theme.Theme;

/**
 * CustomFog: заменяет туман в мире на акцентный цвет выбранной темы
 * ({@link Theme#accent()}). Без настроек — просто вкл/выкл.
 * Туман в воде и лаве не изменяется.
 */
public class CustomFog extends Module {

    private static CustomFog active;

    public CustomFog() {
        super(ModuleCategory.VISUALS, "CustomFog", "Красит туман в цвет выбранной темы.");
        active = this;
    }

    public static CustomFog getActive() {
        return active;
    }

    /** Цвет тумана — всегда акцентный цвет текущей темы. */
    public int getColor() {
        return Theme.accent();
    }
}
