package com.skrvisuals.modules.settings;

import java.util.List;

public class ModeSetting extends Setting {
    private final List<String> modes;
    private int index;

    public ModeSetting(String name, String description, List<String> modes, String defaultValue) {
        super(name, description);
        this.modes = List.copyOf(modes);
        int i = this.modes.indexOf(defaultValue);
        this.index = i >= 0 ? i : 0;
    }

    public String getValue() {
        return this.modes.get(this.index);
    }

    public void setValue(String value) {
        int i = this.modes.indexOf(value);
        if (i >= 0) {
            this.index = i;
        }
    }

    public List<String> getModes() {
        return this.modes;
    }

    public void cycle(boolean forward) {
        if (this.modes.isEmpty()) {
            return;
        }
        this.index = (this.index + (forward ? 1 : -1) + this.modes.size()) % this.modes.size();
    }
}