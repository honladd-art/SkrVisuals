package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Theme;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

/**
 * CustomScreen: перекрашивает весь мир в акцентный цвет текущей темы
 * ({@link Theme#accent()}). Реализовано как полупрозрачная заливка всего
 * экрана в экранных координатах — инжект в начало InGameHud.render:
 * мировой кадр уже отрисован, а HUD ещё нет, поэтому HUD и GUI не
 * затрагиваются. Заливка всегда ровно на весь экран при любом FOV/повороте.
 *
 * Настройка "Прозрачность" (0-100%) управляет силой заливки.
 * Настройка "Темнота" (0-100%) затемняет цвет заливки до чёрного.
 */
public class CustomScreen extends Module {

    private static CustomScreen active;

    private final SliderSetting opacity =
            new SliderSetting("Прозрачность", "Сила перекраски мира (0% — выкл, 100% — сплошной цвет).",
                    0.0f, 100.0f, 30.0f);

    private final SliderSetting darkness =
            new SliderSetting("Темнота", "Затемняет цвет заливки до чёрного (0% — цвет темы, 100% — чёрный).",
                    0.0f, 100.0f, 0.0f);

    public CustomScreen() {
        super(ModuleCategory.VISUALS, "CustomScreen", "Перекрашивает мир в цвет выбранной темы.");
        setting(opacity);
        setting(darkness);
        active = this;
    }

    public static CustomScreen getActive() {
        return active;
    }

    /** Сила заливки 0..1. */
    public float getOpacity() {
        return opacity.getValue() / 100.0f;
    }

    /** Сила затемнения 0..1. */
    public float getDarkness() {
        return darkness.getValue() / 100.0f;
    }

    /**
     * Вызывается из InGameHudMixin в начале InGameHud.render.
     * Рисует ровно один прямоугольник на весь экран — никаких матриц мира.
     */
    public static void render(DrawContext context) {
        CustomScreen module = active;
        if (module == null || !module.isEnabled() || module.getOpacity() <= 0.0f) {
            return;
        }

        int argb = Theme.accent();
        float dark = MathHelper.clamp(module.getDarkness(), 0.0f, 1.0f);
        if (dark > 0.0f) {
            // Затемняем в сторону чёрного: (r,g,b) * (1 - dark)
            int r = (int) (((argb >> 16) & 0xFF) * (1.0f - dark));
            int g = (int) (((argb >> 8) & 0xFF) * (1.0f - dark));
            int b = (int) ((argb & 0xFF) * (1.0f - dark));
            argb = 0xFF000000 | (r << 16) | (g << 8) | b;
        }

        int alpha = (int) (MathHelper.clamp(module.getOpacity(), 0.0f, 1.0f) * 255.0f);
        if (alpha <= 0) {
            return;
        }

        int color = (alpha << 24) | (argb & 0x00FFFFFF);
        RenderUtil.fill(context, 0, 0, context.getScaledWindowWidth(), context.getScaledWindowHeight(), color);
    }
}
