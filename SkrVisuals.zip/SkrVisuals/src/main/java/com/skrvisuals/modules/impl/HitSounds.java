package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * HitSounds: проигрывает выбранный звук при ударе по сущности.
 *
 * - «Игроки» / «Мобы» — на кого звук реагирует.
 * - «Только крит» — звук играет только при критическом ударе.
 * - По фейковому игроку звук запускается из FakePlayer.tryInterceptAttack:
 *   фейк считается «игроком» и подчиняется настройке «Игроки».
 */
public class HitSounds extends Module {

    private static HitSounds active;

    /** Защита от повторной регистрации события. */
    private static boolean hookRegistered = false;

    private static SoundEvent sound(String name) {
        return SoundEvent.of(Identifier.of("skrvisuals", name));
    }

    private static final SoundEvent BELL   = sound("hitsounds.bell");
    private static final SoundEvent BONK   = sound("hitsounds.bonk");
    private static final SoundEvent BUBBLE = sound("hitsounds.bubble");
    private static final SoundEvent UWU    = sound("hitsounds.uwu");
    private static final SoundEvent MOAN   = sound("hitsounds.moan");

    private final ModeSetting sound = new ModeSetting(
            "Звук",
            "Какой звук играть при ударе. Moan — случайный из четырёх.",
            List.of("Bell", "Bonk", "Bubble", "UwU", "Moan"),
            "Moan"
    );

    private final BooleanSetting players =
            new BooleanSetting("Игроки", "Звук при ударе по игрокам.", true);

    private final BooleanSetting mobs =
            new BooleanSetting("Мобы", "Звук при ударе по мобам и животным.", true);

    private final BooleanSetting critOnly =
            new BooleanSetting("Только крит", "Звук играет только при критическом ударе.", false);

    private final SliderSetting volume =
            new SliderSetting("Громкость", "Громкость хитсаунда.", 0.0f, 1.0f, 1.0f);

    public HitSounds() {
        super(ModuleCategory.COMBAT, "HitSounds", "Проигрывает звук при ударе по сущности.");
        setting(sound);
        setting(players);
        setting(mobs);
        setting(critOnly);
        setting(volume);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) return;
        hookRegistered = true;

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            HitSounds module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
                        // Только клиентская сторона (в синглплеере событие приходит и с сервера)
            if (!(world instanceof net.minecraft.client.world.ClientWorld)) {
                return ActionResult.PASS;
            }
            // Фейка обслуживает FakePlayer.tryInterceptAttack (onFakeAttacked)
            if (entity instanceof FakePlayerEntity) {
                return ActionResult.PASS;
            }
            if (!module.targetAllowed(entity)) {
                return ActionResult.PASS;
            }
            if (module.critOnly.getValue() && !isCriticalHit(player, entity)) {
                return ActionResult.PASS;
            }
            module.playHitSound();
            return ActionResult.PASS;
        });
    }

    /**
     * Удар по фейковому игроку. Вызывается из FakePlayer.tryInterceptAttack.
     * Фейк — это игрок, поэтому реагирует на настройку «Игроки».
     */
    public static void onFakeAttacked(PlayerEntity attacker, Entity target) {
        HitSounds module = active;
        if (module == null || !module.isEnabled() || !module.players.getValue()) {
            return;
        }
        if (module.critOnly.getValue() && !isCriticalHit(attacker, target)) {
            return;
        }
        module.playHitSound();
    }

    /** Фильтр цели: игроки и мобы переключаются отдельно. */
    private boolean targetAllowed(Entity target) {
        return target instanceof PlayerEntity ? players.getValue() : mobs.getValue();
    }

    /**
     * Предсказание крита — те же условия, что в ванильном PlayerEntity.attack().
     */
    private static boolean isCriticalHit(PlayerEntity attacker, Entity target) {
        return attacker.getVelocity().y < 0.0
                && !attacker.isOnGround()
                && !attacker.isClimbing()
                && !attacker.isTouchingWater()
                && !attacker.hasStatusEffect(StatusEffects.BLINDNESS)
                && !attacker.hasVehicle()
                && !attacker.isSprinting()
                && target instanceof LivingEntity;
    }

    private SoundEvent pickSound() {
        return switch (sound.getValue()) {
            case "Bell"   -> BELL;
            case "Bonk"   -> BONK;
            case "Bubble" -> BUBBLE;
            case "UwU"    -> UWU;
            default       -> MOAN;
        };
    }

    private void playHitSound() {
        float vol = volume.getValue();
        if (vol <= 0.0f) {
            return;
        }
        MinecraftClient.getInstance().getSoundManager().play(
                PositionedSoundInstance.master(pickSound(), 1.0f, vol)
        );
    }
}