package com.skrvisuals.modules.settings;

import java.util.function.Supplier;

/**
 * Abstract placeholder setting. Stores a name/description and an optional
 * hide-condition so logic can be wired up later.
 */
public abstract class Setting {
    private final String name;
    private final String description;
    private Supplier<Boolean> hideCondition = null;

    protected Setting(String name, String description) {
        this.name = name;
        this.description = description == null ? "" : description;
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Supplier<Boolean> getHideCondition() {
        return this.hideCondition;
    }

    public void setHideCondition(Supplier<Boolean> condition) {
        this.hideCondition = condition;
    }

    /** Whether this setting should currently be shown (false when hidden). */
    public boolean isVisible() {
        return this.hideCondition == null || !Boolean.TRUE.equals(this.hideCondition.get());
    }
}