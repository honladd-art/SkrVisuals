package com.skrvisuals.modules.impl;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.UUID;

/**
 * Локальная сущность игрока: живёт только на клиенте, поэтому весь урон
 * и логика тотема считаются вручную — сервер о ней ничего не знает.
 *
 * Копирует твой профиль (скин) и опционально снаряжение.
 * Тотемы бесконечные: при обнулении ХП тотем срабатывает всегда и
 * восстанавливает здоровье полностью.
 */
public class FakePlayerEntity extends OtherClientPlayerEntity {

    /**
     * Клиентские идентификаторы сущностей: берём очень большие числа,
     * чтобы никогда не пересечься с настоящими серверными id.
     */
    private static int nextEntityId = 500_000_000;

    private final FakePlayer module;

    public FakePlayerEntity(FakePlayer module, ClientWorld world, ClientPlayerEntity template) {
        super(world, forgeUniqueProfile(template.getGameProfile()));

        this.module = module;

        // Уникальный клиентский id — важно при респавне фейков
        this.setId(nextEntityId++);

        copyFrom(template);
        refreshPositionAndAngles(template.getX(), template.getY(), template.getZ(),
                template.getYaw(), template.getPitch());
        this.bodyYaw = template.bodyYaw;
        this.headYaw = template.headYaw;
        alignPrevRotations();

        setVelocity(Vec3d.ZERO);

        this.setHealth(this.getMaxHealth()); // фейк всегда стартует с полным ХП

        if (module.isEquipmentCopied()) {
            copyEquipmentFrom(template);
        }

        // Тотем всегда в левой руке — он бесконечный
        ItemStack offhand = this.getEquippedStack(EquipmentSlot.OFFHAND);
        if (!offhand.isOf(Items.TOTEM_OF_UNDYING)) {
            this.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TOTEM_OF_UNDYING));
        }

        // Стоит ровно там, где поставили, не падает и никуда не двигается
        noClip = true;
    }

    /**
     * Тик сущности идёт всегда, даже когда модуль выключен — поэтому
     * именно здесь удобнее всего проверять состояние модуля: если его
     * выключили, фейк тихо исчезает (без звуков, партиклов и сообщений).
     */
    @Override
    public void tick() {
        super.tick();

        if (!module.isEnabled()) {
            this.discard();
        }
    }

    /* ============================ Урон ============================ */

    /**
     * Обработка удара (вызывается из AttackEntityCallback вместо отправки
     * пакета). Возвращает true, если удар обработан (ванильную атаку нужно
     * отменить).
     */
    public boolean receiveAttack(PlayerEntity attacker) {
        if (this.isRemoved() || !module.isEnabled()) return false;

        // Кулдаун атаки, как в ванили: урон растёт от прогресса перезарядки
        float progress = MathHelper.clamp(attacker.getAttackCooldownProgress(0.0f), 0.0f, 1.0f);

        float baseDamage = (float) attacker.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
        float damage = baseDamage * (0.2f + progress * progress * 0.8f);

        boolean crit = damage > 0.0f && canCriticalHit(attacker);
        if (crit) damage *= 1.5f;

        attacker.resetLastAttackedTicks();
        attacker.swingHand(Hand.MAIN_HAND);

        // Хитсаунд по фейку: передаём флаг крита, HitSounds сам решит,
        // играть ли (зависит от его режима «Только крит»)

        if (damage > 0.0f) {
            applyLocalDamage(damage, crit);
        }
        return true;
    }

    private boolean canCriticalHit(PlayerEntity attacker) {
        return attacker.getVelocity().y < 0.0
                && !attacker.isOnGround()
                && !attacker.isClimbing()
                && !attacker.isTouchingWater()
                && !attacker.hasStatusEffect(StatusEffects.BLINDNESS)
                && !attacker.hasVehicle()
                && !attacker.isSprinting(); // в ваниле спринт отменяет крит
    }

    private void applyLocalDamage(float damage, boolean crit) {
        float resultingHealth = this.getHealth() - damage;

        // Здоровья больше нет — тотем срабатывает всегда (он бесконечный)
        if (resultingHealth <= 0.01f) {
            useTotem();
            return;
        }

        this.setHealth(resultingHealth);

        // Красная вспышка урона
        this.hurtTime = 10;
        this.maxHurtTime = 10;

        ClientWorld world = (ClientWorld) this.getWorld();

        world.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 1.0f, 1.0f);

        if (crit) {
            Random rnd = this.getRandom();
            for (int i = 0; i < 14; i++) {
                world.addParticle(ParticleTypes.CRIT,
                        getX() + (rnd.nextDouble() - 0.5) * getWidth() * 1.5,
                        getY() + rnd.nextDouble() * getHeight(),
                        getZ() + (rnd.nextDouble() - 0.5) * getWidth() * 1.5,
                        (rnd.nextDouble() - 0.5) * 0.3,
                        rnd.nextDouble() * 0.2 + 0.1,
                        (rnd.nextDouble() - 0.5) * 0.3);
            }
        }
    }

    /* ============================ Тотем ============================ */

    /**
     * Тотем бесконечный: полное восстановление ХП + эффекты, как у
     * настоящего тотема бессмертия.
     */
    private void useTotem() {
        this.setHealth(this.getMaxHealth());
        this.hurtTime = 0;
        this.maxHurtTime = 0;

        playTotemFx();
        this.swingHand(Hand.OFF_HAND);
    }

    private void playTotemFx() {
        ClientWorld world = (ClientWorld) this.getWorld();
        Random rnd = this.getRandom();

        world.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ITEM_TOTEM_USE, SoundCategory.PLAYERS, 1.0f, 1.0f);

        // Золотые партиклы, как при активации настоящего тотема
        for (int i = 0; i < 35; i++) {
            world.addParticle(ParticleTypes.TOTEM_OF_UNDYING,
                    getX() + (rnd.nextDouble() - 0.5) * getWidth() * 2.0,
                    getY() + rnd.nextDouble() * getHeight(),
                    getZ() + (rnd.nextDouble() - 0.5) * getWidth() * 2.0,
                    (rnd.nextDouble() - 0.5) * 0.08,
                    rnd.nextDouble() * 0.12 + 0.05,
                    (rnd.nextDouble() - 0.5) * 0.08);
        }
    }

    /* ====================== Вспомогательное ======================== */

    /** Возрождение в сохранённой точке (тот же вид, что и при спавне). */
    public void teleportTo(Vec3d pos, float yaw, float pitch, float bodyYaw, float headYaw) {
        refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, pitch);
        this.bodyYaw = bodyYaw;
        this.headYaw = headYaw;
        alignPrevRotations();
        setVelocity(Vec3d.ZERO);
    }

    private void alignPrevRotations() {
        this.prevYaw = this.getYaw();
        this.prevPitch = this.getPitch();
        this.prevBodyYaw = this.bodyYaw;
        this.prevHeadYaw = this.headYaw;
    }

    private void copyEquipmentFrom(ClientPlayerEntity source) {
        PlayerInventory srcInv = source.getInventory();
        PlayerInventory dstInv = this.getInventory();
        for (int i = 0; i < srcInv.size(); i++) {
            dstInv.setStack(i, srcInv.getStack(i).copy());
        }
        dstInv.selectedSlot = srcInv.selectedSlot;
    }

    /**
     * Копия профиля со случайным UUID, чтобы клиентский реестр сущностей
     * не путал нас с настоящим игроком. Текстуры переносятся из свойств,
     * так что скин остаётся.
     */
    private static GameProfile forgeUniqueProfile(GameProfile original) {
        GameProfile forged = new GameProfile(UUID.randomUUID(), original.getName());
        forged.getProperties().putAll(original.getProperties());
        return forged;
    }

    /** Показывает ХП над головой — удобно видеть работу тотема. */
    @Override
    public Text getDisplayName() {
        String hp = String.format("%.1f", this.getHealth());
        return super.getDisplayName().copy()
                .append(Text.literal(" [").formatted(Formatting.GRAY))
                .append(Text.literal(hp).formatted(this.getHealth() > this.getMaxHealth() * 0.5f ? Formatting.GREEN : Formatting.RED))
                .append(Text.literal("]").formatted(Formatting.GRAY));
    }
}