package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

/**
 * FakePlayer: спавнит локального «фейкового» игрока, по которому можно бить.
 * Атаки перехватываются через Fabric API (AttackEntityCallback) — пакет на
 * сервер не уходит, урон считается на клиенте. Когда здоровье кончается —
 * фейк тратит тотем и полностью восстанавливает ХП (тотемы бесконечные).
 *
 * Хитсаунд по фейку запускается здесь, в tryInterceptAttack: обработчик
 * HitSounds пропускает фейка (PASS), а FakePlayer возвращает FAIL и обрывает
 * цепочку событий — поэтому звук должен запускаться до return.
 */
public class FakePlayer extends Module {

    private static FakePlayer active;

    /** Защита от повторной регистрации события, если модуль пересоздаётся. */
    private static boolean hookRegistered = false;

    private final BooleanSetting copyEquipment =
            new BooleanSetting("Коп. снаряжение", "При спавне фейк получает копию твоей брони и предметов.", true);

    private FakePlayerEntity fake;

    // Точка последнего спавна — чтобы возрождать фейка там же, где он стоял
    private ClientWorld spotWorld;
    private Vec3d spotPos;
    private float spotYaw, spotPitch, spotBodyYaw, spotHeadYaw;
    private boolean hasSpot;

    private boolean pendingRespawn;

    public FakePlayer() {
        // Поменяй категорию на COMBAT, если она у тебя есть
        super(ModuleCategory.UTILITY, "FakePlayer", "Фейковый игрок для отработки PvP: получает урон и жмёт тотем.");
        setting(copyEquipment);
        active = this;
        registerAttackHook();
    }

    /**
     * Fabric API вызывает это событие в начале ванильной обработки удара.
     * Возврат FAIL отменяет и отправку пакета на сервер, и ванильную атаку.
     */
    private static void registerAttackHook() {
        if (hookRegistered) return;
        hookRegistered = true;

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (entity instanceof FakePlayerEntity fakeTarget && FakePlayer.tryInterceptAttack(player, fakeTarget)) {
                return ActionResult.FAIL; // удар обработан локально, сервер ничего не получает
            }
            return ActionResult.PASS;
        });
    }

    /**
     * Вызывается из registerAttackHook при ударе по фейку.
     * Хитсаунд играем именно здесь — HitSounds возвращает по фейку PASS,
     * а наш FAIL обрывает цепочку, так что другого места просто нет.
     */
    public static boolean tryInterceptAttack(PlayerEntity attacker, FakePlayerEntity fake) {
        FakePlayer module = active;
        if (module == null || !module.isEnabled()) {
            System.out.println("[SKR] fake hit: модуль выключен -> PASS");
            return false;
        }
        System.out.println("[SKR] fake hit: перехватил удар, зову HitSounds...");
        HitSounds.onFakeAttacked(attacker, fake);
        HitColor.onFakeAttacked(attacker, fake);
        return fake.receiveAttack(attacker);
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Страховка на случай, если базовый класс вызывает onTick даже при выключенном модуле
        if (!isEnabled()) {
            return;
        }

        // Мир закрыт / вышли на меню — просто забываем фейка
        if (client.world == null || client.player == null) {
            fake = null;
            return;
        }

        FakePlayerEntity current = fake;
        if (current != null && (current.isRemoved() || current.getWorld() != client.world)) {
            fake = null; // мир сменился (измерение) или сущность удалена
        }

        if (pendingRespawn) {
            pendingRespawn = false;
            spawnAt(client.player);
        } else if (fake == null) {
            spawnAt(client.player);
        }
    }

    private void spawnAt(ClientPlayerEntity template) {
        ClientWorld world = (ClientWorld) template.getWorld();

        FakePlayerEntity created = new FakePlayerEntity(this, world, template);

        // Восстанавливаем прежнюю точку, если мы в том же мире и она рядом
        boolean canRestore = hasSpot
                && spotWorld == world
                && spotPos != null
                && spotPos.squaredDistanceTo(template.getPos()) < 64 * 64;

        if (canRestore) {
            created.teleportTo(spotPos, spotYaw, spotPitch, spotBodyYaw, spotHeadYaw);
        }

        world.addEntity(created);
        fake = created;
        captureSpot(created);
    }

    private void captureSpot(FakePlayerEntity entity) {
        spotWorld = (ClientWorld) entity.getWorld();
        spotPos = entity.getPos();
        spotYaw = entity.getYaw();
        spotPitch = entity.getPitch();
        spotBodyYaw = entity.bodyYaw;
        spotHeadYaw = entity.headYaw;
        hasSpot = true;
    }

    /* ----- Колбэки для FakePlayerEntity ----- */

    boolean isEquipmentCopied() {
        return copyEquipment.getValue();
    }

    /**
     * Страховка: с бесконечными тотемами смерть невозможна,
     * но если каким-то чудом случилась — просто возрождаем фейка.
     */
    void onFakeDied(FakePlayerEntity entity) {
        pendingRespawn = true;
    }
}