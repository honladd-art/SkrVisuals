package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BindSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallbackI;

/**
 * Zoom: плавный зум мира при удержании назначенной кнопки
 *
 * Зум реализован через FOV (GameRendererMixin модифицирует результат
 * getFov): FOV — единый источник проекции для террейна, сущностей и
 * партиклов, поэтому всё зумится консистентно и мобы не отрываются от блоков.
 *
 * - Бинд — BindSetting: СКМ по строке в GUI -> нажми клавишу/кнопку мыши.
 *   ЛКМ в режиме привязки — снять бинд, Esc — отмена, ПКМ по строке — сброс.
 * - Колесо мыши при ЗАЖАТОМ бинде меняет кратность (x1.5..x30).
 * - Анимация — экспоненциальное сглаживание; «Скорость» задаёт темп.
 * - Чувствительность мыши временно масштабируется (мягкая камера на зуме).
 */
public class Zoom extends Module {

    private static Zoom active;
    private static boolean hooksRegistered = false;

    private final BindSetting bind =
            new BindSetting("Бинд", "Кнопка зума. СКМ по строке — привязать, ЛКМ — сброс.", GLFW.GLFW_KEY_C);

    private final SliderSetting speed =
            new SliderSetting("Скорость", "Скорость анимации зума (больше — быстрее).", 1.0f, 20.0f, 8.0f);

    // ----- состояние -----
    private double zoomLevel = 4.0D;      // кратность, меняется колесом
    private float currentFactor = 1.0F;   // анимированный текущий множитель
    private long lastFrameMs = -1L;
    private double savedSensitivity = -1.0D;

    // ----- хук колеса -----
    private boolean scrollHooked = false;
    private GLFWScrollCallbackI vanillaScroll;

    public Zoom() {
        super(ModuleCategory.UTILITY, "Zoom", "Плавный зум. Колесо мыши при зажатом бинде меняет кратность.");
        setting(bind);
        setting(speed);
        active = this;
        registerHooks();
    }

    private static void registerHooks() {
        if (hooksRegistered) return;
        hooksRegistered = true;

        WorldRenderEvents.START.register(Zoom::onWorldStart);
        HudRenderCallback.EVENT.register(Zoom::onHud);
    }

    /* ======================== FOV (миксин) ======================== */

    /**
     * Вызывается и· GameRendererMixin прирасчёте FOV када.
     * worldPass=true — основнойпроходмёра; рука (false) не зумися.
     */
    public static float modifyFov(float fovDeg, boolean worldPass) {
        Zoom module = active;
        if (!worldPass || module == null || !module.isEnabled() || module.currentFactor <= 1.001F) {
            return fovDeg;
        }
        return fovDeg / module.currentFactor;
    }

    /**
     * Для дуги… модлей true, пока зум фактиескиактиен.
     * Эффекты укамеры (орбы ChinaHat итп) вэтот момент разрастаются
     * на весь экран — и… стои‚ прятать.
     */
    public static boolean isZooming() {
        Zoom module = active;
        return module != null && module.isEnabled() && module.currentFactor > 1.05F;
    }

    /** Текущий множитель зума (1.0 = не зумим). */
    public static float getZoomFactor() {
        Zoom module = active;
        return module != null && module.isEnabled() ? module.currentFactor : 1.0F;
    }

    /* ============================ кадр ============================ */

    private static void onWorldStart(WorldRenderContext context) {
        Zoom module = active;
        if (module == null) return;
        MinecraftClient client = MinecraftClient.getInstance();

        module.ensureScrollHook(client);
        module.updateAnimation(client);
        module.updateSensitivity(client);
    }

    private void updateAnimation(MinecraftClient client) {
        long now = System.currentTimeMillis();
        float dt = lastFrameMs < 0L ? 0.0F
                : MathHelper.clamp((now - lastFrameMs) / 1000.0F, 0.0F, 0.1F);
        lastFrameMs = now;

        boolean held = isEnabled()
                && client.player != null
                && client.currentScreen == null
                && isBindPressed();

        float target = held ? (float) zoomLevel : 1.0F;

        // Экспоненциальное сглаживание: плавный вход и выход
        float t = MathHelper.clamp(dt * speed.getValue(), 0.0F, 1.0F);
        currentFactor += (target - currentFactor) * t;
        if (Math.abs(target - currentFactor) < 0.002F) {
            currentFactor = target; // отсечка, чтобы не дожало на 1.0001
        }
    }

    /* ====================== чувствиельность ====================== */

    private void updateSensitivity(MinecraftClient client) {
        SimpleOption<Double> opt = client.options.getMouseSensitivity();

        if (currentFactor > 1.01F) {
            // Запоминаем исходную один раз, дальше масштабируем от неё.
            // Корень — мягче, чем деление на кратность, но эффект заметный.
            if (savedSensitivity < 0.0D) {
                savedSensitivity = opt.getValue();
            }
            double scaled = savedSensitivity / Math.sqrt(currentFactor);
            opt.setValue(MathHelper.clamp(scaled, 0.0D, 1.0D));
        } else if (savedSensitivity >= 0.0D) {
            opt.setValue(savedSensitivity); // вернуть ровно один раз
            savedSensitivity = -1.0D;
        }
    }

    /* ============================ бинд ============================ */

    private boolean isBindPressed() {
        MinecraftClient client = MinecraftClient.getInstance();
        long handle = client.getWindow().getHandle();
        int code = bind.getKeyCode();
        if (code == -1) {
            return false; // бинд не назначен
        }
        if (code <= -100) { // кнопка мыши -100 - glfwButton
            int button = -code - 100;
            return GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS;
        }
        return InputUtil.isKeyPressed(handle, code);
    }

    /* =========================== колесо =========================== */

    /**
     * Ставиј свойscroll-колбэк поверх ваниьного: glfwSetScrollCallback
     * возвращает ПРЕДЫДУЩИ™ колбэк — сохраняем его ивызываем после нашей
     * логики, чтобы хотбар/интерфейсы работали как обычно. Ставим один раз.
     */
    private void ensureScrollHook(MinecraftClient client) {
        if (scrollHooked) {
            return;
        }
        scrollHooked = true;
        vanillaScroll = GLFW.glfwSetScrollCallback(
                client.getWindow().getHandle(), this::onGlfwScroll);
    }

    private void onGlfwScroll(long window, double xoff, double yoff) {
        if (yoff != 0.0D) {
            onScroll(yoff);
        }
        if (vanillaScroll != null) {
            vanillaScroll.invoke(window, xoff, yoff);
        }
    }

    private void onScroll(double yoff) {
        MinecraftClient client = MinecraftClient.getInstance();
        // Кратность меняется ТОЛЬКО при зажатом бинде и без открытого экрана —
        // иначе мешал бы скроллу хотбара/интерфейсов
        if (client.currentScreen != null) return;
        if (!isEnabled() || !isBindPressed()) return;

        double mult = yoff > 0.0D ? 1.15D : 1.0D / 1.15D;
        zoomLevel = MathHelper.clamp(zoomLevel * mult, 1.5D, 30.0D);
    }

    /* ========================= индикатор ========================== */

    private static void onHud(DrawContext context, net.minecraft.client.render.RenderTickCounter tick) {
        Zoom module = active;
        if (module == null || !module.isEnabled() || module.currentFactor <= 1.01F) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        String text = String.format("Zoom x%.1f", module.currentFactor);
        float textWidth = Fonts.get().getWidth(text);
        float x = (client.getWindow().getScaledWidth() - textWidth) / 2f;
        float y = client.getWindow().getScaledHeight() / 2f + 20f;
        context.drawText(Fonts.get(), text, (int)x, (int)y, 0xFFFFFFFF, true);
    }
}
