package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.render.GuiFx;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.util.math.MatrixStack;

import java.util.List;

/**
 * Animations: плавное ПОЯВЛЕНИЕ Tab (список игроков), чата и инвентаря.
 *
 * Анимируется только появление — закрытие всегда мгновенное (ванильное
 * поведение), чтобы элементы не «улетали» при закрытии.
 *
 * Как отслеживается появление:
 * - Tab: ванильный PlayerListHud рисуется только пока зажат Tab. Список
 *   считается «появившимся заново», если между кадрами прошло больше
 *   {@link #TAB_GAP_MS}.
 * - Чат: анимируется ТОЛЬКО новая строка (перезапуск по addMessage).
 * - Инвентарь: перезапуск, когда открыт новый экран (смена экземпляра
 *   HandledScreen).
 *
 * Сама анимация — трансформация матрицы (масштаб + сдвиг) вокруг «якоря»
 * элемента: верх-центр для Tab, центр экрана для инвентаря, а для чата —
 * левый нижний угол самой новой строки.
 */
public class Animations extends Module {

    /** Что именно анимируем. */
    public enum Target {
        TAB,
        INVENTORY
    }

    private static Animations active;

    /** Пауза в рендере Tab больше этого времени = список появился заново. */
    private static final long TAB_GAP_MS = 250L;

    // ------------------------------ настройки ------------------------------

    private final BooleanSetting tabSetting =
            new BooleanSetting("Таблица игроков", "Анимирует появление списка игроков (Tab).", true);

    private final BooleanSetting chatSetting =
            new BooleanSetting("Чат", "Анимирует появление ТОЛЬКО новой строки чата (старые не трогаются).", true);

    private final BooleanSetting inventorySetting =
            new BooleanSetting("Инвентарь", "Анимирует появление инвентаря (и любого контейнерного GUI).", true);

    private final ModeSetting mode = new ModeSetting(
            "Тип анимации",
            "Как элемент появляется: Масштаб / Сдвиг / Масштаб + сдвиг.",
            List.of("Масштаб", "Сдвиг", "Масштаб + сдвиг"),
            "Масштаб");

    private final SliderSetting speed =
            new SliderSetting("Скорость", "Длительность анимации в миллисекундах (меньше — быстрее).",
                    50.0f, 600.0f, 200.0f);

    private final SliderSetting startScale =
            new SliderSetting("Масштаб", "Размер элемента в начале анимации (1.0 — без масштаба).",
                    0.50f, 1.00f, 0.85f);

    private final SliderSetting slideOffset =
            new SliderSetting("Сдвиг", "На сколько пикселей элемент смещается при появлении.",
                    0.0f, 150.0f, 30.0f);

    // ------------------------------ состояние ------------------------------

    private long startTab;
    private long startChat;
    private long startInv;

    /** Время последнего кадра, на котором ваниль отрисовала список игроков. */
    private long lastTabRender;

    /** Экран, для которого уже запущена анимация появления (null — GUI не отслеживается). */
    private Screen trackedScreen;

    public Animations() {
        super(ModuleCategory.UTILITY, "Animations",
                "Плавное появление Tab, чата и инвентаря. Закрытие — мгновенное.");
        setting(tabSetting);
        setting(chatSetting);
        setting(inventorySetting);
        setting(mode);
        setting(speed);
        setting(startScale);
        setting(slideOffset);
        active = this;
    }

    public static Animations getActive() {
        return active;
    }

    @Override
    protected void onEnabledChange() {
        if (!isEnabled()) {
            resetAll();
        }
    }

    private void resetAll() {
        this.startTab = 0L;
        this.startChat = 0L;
        this.startInv = 0L;
        this.lastTabRender = 0L;
        this.trackedScreen = null;
    }

    /* ======================= отслеживание появления ======================= */

    @Override
    public void onTick(MinecraftClient client) {
        if (!isEnabled()) {
            if (this.trackedScreen != null) {
                resetAll();
            }
            return;
        }

        Screen screen = client.currentScreen;

        if (screen instanceof HandledScreen) {
            // Новый экземпляр экрана = новое «появление» инвентаря.
            if (screen != this.trackedScreen) {
                this.trackedScreen = screen;
                this.startInv = System.currentTimeMillis();
            }
        } else {
            this.trackedScreen = null;
        }
    }

    /** Вызывается из хука добавления сообщения в чат. */
    public static void onChatMessage() {
        Animations module = active;
        if (module != null && module.isEnabled() && module.chatSetting.getValue()) {
            module.restartChat();
        }
    }

    private void restartChat() {
        this.startChat = System.currentTimeMillis();
    }

    /* ========================== прогресс анимации ========================== */

    /**
     * Прогресс 0..1 с ease-out. Возвращает 1, если анимация не запущена или
     * уже завершена — тогда элемент рисуется без трансформации.
     */
    private float progress(long start) {
        if (start == 0L) {
            return 1.0F;
        }
        long duration = Math.max(1L, Math.round(speed.getValue()));
        float p = (System.currentTimeMillis() - start) / (float) duration;
        if (p >= 1.0F) {
            return 1.0F;
        }
        return GuiFx.easeOut(p);
    }

    /* ====================== точки входа из миксинов ======================= */

    /** Обёртка для PlayerListHud.render. */
    public static boolean pushTab(DrawContext context) {
        Animations module = active;
        if (module == null || !module.isEnabled() || !module.tabSetting.getValue()) {
            return false;
        }
        long now = System.currentTimeMillis();
        // В прошлом кадре список не рисовался — значит его только что открыли.
        if (module.lastTabRender == 0L || now - module.lastTabRender > TAB_GAP_MS) {
            module.startTab = now;
        }
        module.lastTabRender = now;
        return module.applyTransform(context, Target.TAB, module.progress(module.startTab));
    }

    /**
     * Обёртка для отрисовки ОДНОЙ строки чата (vanilla рисует их в цикле).
     * Вызывается только для последней (свежей) строки.
     *
     * Якорь — левый нижний угол самой строки ({@code x}, {@code y + fontHeight}),
     * поэтому строка «выезжает» из своего места, а не от угла экрана. Старые
     * строки не трогаются и остаются на месте.
     *
     * @return true, если трансформация применена и её надо снять.
     */
    public static boolean pushChatLine(DrawContext context, float x, float y) {
        Animations module = active;
        if (module == null || !module.isEnabled() || !module.chatSetting.getValue()) {
            return false;
        }
        float progress = module.progress(module.startChat);
        if (progress >= 1.0F) {
            return false;
        }

        String modeValue = module.mode.getValue();
        boolean useScale = !"Сдвиг".equals(modeValue);
        boolean useSlide = !"Масштаб".equals(modeValue);
        if (!useScale && !useSlide) {
            return false;
        }

        float rest = 1.0F - progress;
        int fontHeight = MinecraftClient.getInstance().textRenderer.fontHeight;

        // Якорь — левый нижний угол строки.
        float anchorX = x;
        float anchorY = y + fontHeight;

        float scale = 1.0F;
        if (useScale) {
            scale = 1.0F + (module.startScale.getValue() - 1.0F) * rest;
        }

        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(anchorX, anchorY, 0.0F);
        if (useScale && Math.abs(scale - 1.0F) > 0.0001F) {
            matrices.scale(scale, scale, 1.0F);
        }
        if (useSlide) {
            // Выезжает слева и снизу — как новая строка, «всплывающая» на место.
            matrices.translate(-module.slideOffset.getValue() * rest,
                    module.slideOffset.getValue() * 0.5F * rest, 0.0F);
        }
        matrices.translate(-anchorX, -anchorY, 0.0F);
        return true;
    }

    /** Обёртка для HandledScreen.render. */
    public static boolean pushInventory(DrawContext context) {
        Animations module = active;
        if (module == null || !module.isEnabled() || !module.inventorySetting.getValue()) {
            return false;
        }
        return module.applyTransform(context, Target.INVENTORY, module.progress(module.startInv));
    }

    /* ============ общее состояние трансформации экрана (для миксинов) ============
     * Трансформация навешивается в Screen#renderWithTooltip (он оборачивает
     * ВЕСЬ рендер экрана, включая панель, которую рисует подкласс уже ПОСЛЕ
     * super.render()), а затем на время renderBackground снимается, чтобы
     * затемнение не масштабировалось. Состояние живёт в статике, потому что
     * затрагиваются два разных миксина.
     */

    /** Трансформация применена прямо сейчас. */
    private static boolean screenTransformActive;

    /** Трансформация была снята на время отрисовки фона. */
    private static boolean screenTransformSuspended;

    /**
     * Навесить трансформацию на весь экран. Вызывается из
     * {@code Screen#renderWithTooltip} только для экранов-наследников
     * {@link HandledScreen} — остальные экраны не трогаем.
     */
    public static boolean pushScreen(DrawContext context) {
        screenTransformSuspended = false;
        boolean applied = pushInventory(context);
        screenTransformActive = applied;
        return applied;
    }

    /** Снять трансформацию в конце рендера экрана. */
    public static void popScreen(DrawContext context) {
        if (screenTransformActive) {
            popTransform(context, true);
        }
        screenTransformActive = false;
        screenTransformSuspended = false;
    }

    /** Снять трансформацию перед {@code renderBackground} (затемнение не анимируем). */
    public static void suspendScreenTransform(DrawContext context) {
        if (screenTransformActive) {
            popTransform(context, true);
            screenTransformActive = false;
            screenTransformSuspended = true;
        }
    }

    /** Вернуть трансформацию сразу после фона, до панели и слотов. */
    public static void resumeScreenTransform(DrawContext context) {
        if (screenTransformSuspended) {
            screenTransformSuspended = false;
            screenTransformActive = pushInventory(context);
        }
    }

    /** Снимает трансформацию, если push* её действительно применил. */
    public static void popTransform(DrawContext context, boolean applied) {
        if (applied && context != null) {
            context.getMatrices().pop();
        }
    }

    /* ========================= трансформация GUI ========================== */

    /**
     * Кладёт матрицу и применяет масштаб/сдвиг. Возвращает true, если матрица
     * была изменена и её обязательно нужно снять.
     */
    private boolean applyTransform(DrawContext context, Target target, float progress) {
        if (context == null || progress >= 1.0F) {
            return false;
        }

        String modeValue = mode.getValue();
        boolean useScale = !"Сдвиг".equals(modeValue);
        boolean useSlide = !"Масштаб".equals(modeValue);
        if (!useScale && !useSlide) {
            return false;
        }

        // Насколько ещё «не доехал» элемент: 1 в начале, 0 в конце.
        float rest = 1.0F - progress;

        float width = context.getScaledWindowWidth();
        float height = context.getScaledWindowHeight();

        float anchorX;
        float anchorY;
        float slideX = 0.0F;
        float slideY = 0.0F;
        float offset = slideOffset.getValue();

        switch (target) {
            case TAB -> {
                anchorX = width / 2.0F;
                anchorY = 0.0F;
                slideY = -offset;
            }
            default -> {
                anchorX = width / 2.0F;
                anchorY = height / 2.0F;
                slideY = offset;
            }
        }

        float scale = 1.0F;
        if (useScale) {
            scale = 1.0F + (startScale.getValue() - 1.0F) * rest;
        }

        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(anchorX, anchorY, 0.0F);
        if (useScale && Math.abs(scale - 1.0F) > 0.0001F) {
            matrices.scale(scale, scale, 1.0F);
        }
        if (useSlide && (slideX != 0.0F || slideY != 0.0F)) {
            matrices.translate(slideX * rest, slideY * rest, 0.0F);
        }
        matrices.translate(-anchorX, -anchorY, 0.0F);
        return true;
    }
}
