package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.HitResult;

/**
 * CustomCrosshair: заменяет ванильный прицел на полностью настраиваемый.
 *
 * - Ванильный прицел гасится в InGameHudMixin (renderCrosshair);
 * - Свой рисуется в HUD-проходе экранными quads:
 *   4 полоски (лево/право/верх/низ) с настраиваемыми длиной, толщиной
 *   и отступом от центра, плюс опциональная точка и обводка.
 * - Как и ваниль, прицел скрыт в третьем лице и при открытом экране.
 */
public class CustomCrosshair extends Module {

    private static CustomCrosshair active;
    private static boolean hookRegistered = false;

    private final SliderSetting thickness =
            new SliderSetting("Толщина", "Толщина полосок в пикселях.", 1.0f, 8.0f, 2.0f);

    private final SliderSetting length =
            new SliderSetting("Длина", "Длина каждой полоски в пикселях.", 1.0f, 30.0f, 6.0f);

    private final SliderSetting gap =
            new SliderSetting("Отступ", "Отступ полосок от центра в пикселях.", 0.0f, 15.0f, 3.0f);

    private final BooleanSetting dot =
            new BooleanSetting("Точка", "Точка в центре прицела.", false);

    private final SliderSetting dotSize =
            new SliderSetting("Размер точки", "Сторона квадратной точки в пикселях.", 1.0f, 8.0f, 2.0f);

    private final BooleanSetting outline =
            new BooleanSetting("Обводка", "Чёрная обводка вокруг элементов прицела.", true);

    private final BooleanSetting redOnEntity =
            new BooleanSetting("Краснеть при наведении", "Прицел краснеет, когда наведён на сущность.", true);

    public CustomCrosshair() {
        super(ModuleCategory.VISUALS, "CustomCrosshair", "Кастомный прицел вместо ванильного.");
        setting(thickness);
        setting(length);
        setting(gap);
        setting(dot);
        setting(dotSize);
        setting(outline);
        setting(redOnEntity);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) return;
        hookRegistered = true;
        HudRenderCallback.EVENT.register(CustomCrosshair::onHud);
    }

    /** Вызывается из InGameHudMixin: прятать ли ванильный прицел. */
    public static boolean shouldHideVanilla() {
        CustomCrosshair module = active;
        return module != null && module.isEnabled();
    }

    private static void onHud(DrawContext context, net.minecraft.client.render.RenderTickCounter tick) {
        CustomCrosshair module = active;
        if (module == null || !module.isEnabled()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        // Как ваниль: не рисуем в третьем лице и с открытым экраном.
        if (client.player == null || client.currentScreen != null
                || !client.options.getPerspective().isFirstPerson()) {
            return;
        }

        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();
        float cx = w / 2f;
        float cy = h / 2f;

        // Цвет темы; при наведении на сущность (если включено) — красный.
        int color = Colors.clientColor();
        if (module.redOnEntity.getValue()
                && client.crosshairTarget != null
                && client.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            color = 0xFFFF5252;
        }
        float halfT = module.thickness.getValue() / 2f;
        float len = module.length.getValue();
        float gap = module.gap.getValue();

        // Обводка (чёрная, на 1px шире вокруг каждого элемента)
        if (module.outline.getValue()) {
            int black = 0xFF000000;
            float o = 1f;
            // левая
            RenderUtil.fill(context, cx - gap - len - o, cy - halfT - o, len + o * 2, halfT * 2 + o * 2, black);
            // правая
            RenderUtil.fill(context, cx + gap - o, cy - halfT - o, len + o * 2, halfT * 2 + o * 2, black);
            // верхняя
            RenderUtil.fill(context, cx - halfT - o, cy - gap - len - o, halfT * 2 + o * 2, len + o * 2, black);
            // нижняя
            RenderUtil.fill(context, cx - halfT - o, cy + gap - o, halfT * 2 + o * 2, len + o * 2, black);
            if (module.dot.getValue()) {
                float ds = module.dotSize.getValue();
                RenderUtil.fill(context, cx - ds / 2f - o, cy - ds / 2f - o, ds + o * 2, ds + o * 2, black);
            }
        }

        // Полоски
        RenderUtil.fill(context, cx - gap - len, cy - halfT, len, halfT * 2, color); // левая
        RenderUtil.fill(context, cx + gap, cy - halfT, len, halfT * 2, color);       // правая
        RenderUtil.fill(context, cx - halfT, cy - gap - len, halfT * 2, len, color); // верхняя
        RenderUtil.fill(context, cx - halfT, cy + gap, halfT * 2, len, color);       // нижняя

        // Точка
        if (module.dot.getValue()) {
            float ds = module.dotSize.getValue();
            RenderUtil.fill(context, cx - ds / 2f, cy - ds / 2f, ds, ds, color);
        }
    }
}
