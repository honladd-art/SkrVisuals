package com.skrvisuals.modules;

import com.skrvisuals.modules.settings.Setting;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * Placeholder module. Actual behaviour is stubbed; the GUI only needs the
 * metadata and the list of settings for now.
 */
public class Module {
    private final String name;
    private final String description;
    private final ModuleCategory category;
    private boolean enabled;
    private int key;
    private boolean hidden;

    private final List<Setting> settings = new ArrayList<>();
    private final List<Setting> registeredSettings = new ArrayList<>();

    public Module(ModuleCategory category, String name, String description) {
        this.category = category;
        this.name = name;
        this.description = description == null ? "" : description;
        this.key = -1;
        registerDefaults();
    }

    /** Override to add settings in subclasses (or use addSetting). */
    protected void registerDefaults() {
    }

    protected void addSetting(Setting setting) {
        if (setting != null && !this.registeredSettings.contains(setting)) {
            this.registeredSettings.add(setting);
            refreshSettings();
        }
    }

    private void refreshSettings() {
        this.settings.clear();
        for (Setting s : this.registeredSettings) {
            if (s.isVisible()) {
                this.settings.add(s);
            }
        }
    }

    // ---- Getters / stubbed behaviour ------------------------------------

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public ModuleCategory getCategory() {
        return this.category;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        setEnabled(enabled, true);
    }

    /** {@code silent} disables the toggle sound (used when restoring saved config). */
    public void setEnabled(boolean enabled, boolean silent) {
        if (this.enabled == enabled) {
            return;
        }
        this.enabled = enabled;
        if (!silent) {
            ModuleSounds.play(enabled ? ModuleSounds.MODULE_ON : ModuleSounds.MODULE_OFF);
            // Уведомление в HUD (если Notifications включён в модуле Hud).
            com.skrvisuals.ui.hud.HudManager.pushNotification(this.name, enabled);
        }
        onEnabledChange();
    }

    public void toggle() {
        setEnabled(!this.enabled);
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public List<Setting> getSettings() {
        return this.settings;
    }

    /** Every registered setting, including ones currently hidden. Used for config persistence. */
    public List<Setting> getAllSettings() {
        return Collections.unmodifiableList(this.registeredSettings);
    }

    /** Verify visibility conditions each frame and refresh the list. */
    public void updateSettings() {
        refreshSettings();
    }

    /** Fluent registration helper used by the stub registry. */
    public Module setting(Setting setting) {
        addSetting(setting);
        return this;
    }

    /** Stub: perform the module's effect. overridden later. */
    protected void onEnabledChange() {
    }

    /**
     * Called on every client tick, whether enabled or not — implementations
     * decide what to do (e.g. apply an effect while enabled, clean up when not).
     */
    public void onTick(MinecraftClient client) {
    }
}