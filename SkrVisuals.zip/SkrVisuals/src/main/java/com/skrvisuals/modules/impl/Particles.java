package com.skrvisuals.modules.impl;

import java.util.Random;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.particle.SkrParticles;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

/**
 * Particles: spawns the custom textured particle (skrvisuals:glow) at
 * whatever player/mob you hit. Hooked through {@link AttackEntityCallback}
 * so it fires exactly on attacks, client side only.
 * Configurable size and count. The color follows the client theme.
 */
public class Particles extends Module {
    private static Particles active;
    private static boolean hookRegistered = false;

    private final SliderSetting size =
            new SliderSetting("Размер", "Разброс и размер частиц.", 0.1f, 2.0f, 0.6f);
    private final SliderSetting count =
            new SliderSetting("Количество", "Частиц за один удар.", 1f, 30f, 8f);

    private final Random random = new Random();

    public Particles() {
        super(ModuleCategory.COMBAT, "Particles", "Партиклы при ударе игрока/моба.");
        setting(size);
        setting(count);
        active = this;
        registerHook();
    }

    public static Particles getActive() {
        return active;
    }

    public float getSizeValue() {
        return this.size.getValue();
    }

    private static void registerHook() {
        if (hookRegistered) {
            return;
        }
        hookRegistered = true;
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            Particles module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
            if (!world.isClient) {
                return ActionResult.PASS;
            }
            if (entity instanceof LivingEntity living) {
                module.spawn(living);
            }
            return ActionResult.PASS;
        });
    }

    private void spawn(LivingEntity target) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            return;
        }

        Vec3d center = target.getBoundingBox().getCenter();
        int n = Math.max(1, (int) this.count.getValue());
        float spread = this.size.getValue();

        for (int i = 0; i < n; i++) {
            double ox = (this.random.nextDouble() - 0.5D) * spread;
            double oy = (this.random.nextDouble() - 0.5D) * spread;
            double oz = (this.random.nextDouble() - 0.5D) * spread;
            double vx = (this.random.nextDouble() - 0.5D) * 0.10D;
            double vy = this.random.nextDouble() * 0.08D + 0.01D;
            double vz = (this.random.nextDouble() - 0.5D) * 0.10D;

            // Custom textured particle: color/size are applied inside the particle.
            client.world.addParticle(SkrParticles.GLOW,
                    center.x + ox, center.y + oy, center.z + oz, vx, vy, vz);
        }
    }
}