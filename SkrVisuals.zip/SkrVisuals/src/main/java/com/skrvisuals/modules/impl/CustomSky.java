package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.ui.theme.Theme;

import net.minecraft.util.math.MathHelper;

/**
 * CustomSky: перекрашивает небо в акцентный цвет выбранной темы
 * ({@link Theme#accent()}), но чуть светлее. Без настроек — просто вкл/выкл.
 * Реализовано перехватом {@code SkyRendering.renderSky} — цвет самого небесного
 * купола (рендер купола) заменяется на светлый тон темы. Затрагивается только
 * обычное небо (Overworld), в Незере/Энде рендер купола не используется.
 */
public class CustomSky extends Module {

    /** Насколько светлее темы делать небо (смешение в сторону белого), 0..1. */
    private static final float LIGHTEN = 0.30f;

    private static CustomSky active;

    public CustomSky() {
        super(ModuleCategory.VISUALS, "CustomSky", "Красит небо в цвет выбранной темы.");
        active = this;
    }

    public static CustomSky getActive() {
        return active;
    }

    /** Цвет неба — акцентный цвет темы, только чуть светлее. */
    public int getColor() {
        int argb = Theme.accent();
        int r0 = (argb >> 16) & 0xFF;
        int g0 = (argb >> 8) & 0xFF;
        int b0 = argb & 0xFF;
        float t = MathHelper.clamp(LIGHTEN, 0.0f, 1.0f);
        int r = (int) MathHelper.lerp(t, r0, 255.0f);
        int g = (int) MathHelper.lerp(t, g0, 255.0f);
        int bl = (int) MathHelper.lerp(t, b0, 255.0f);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}