package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.theme.Colors;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.util.List;

/**
 * CustomHitbox: заменяет ванильный рендер хитбоксов (F3+B) на свой,
 * окрашенный в цвет активной темы.
 *
 * - ванильные хитбоксы гасятся миксином (EntityRenderDispatcherMixin);
 * - рисование — в проходе AFTER_ENTITIES линиями (RenderLayer.getLines)
 *   и при желании заливкой (RenderLayer.getDebugFilledBox).
 *
 * Настройки:
 * - вкл/выкл заполнение;
 * - прозрачность заполнения;
 * - прозрачность линий/углов;
 * - тип: «Углы» (только уголки) и «Обычные» (полная коробка).
 */
public class CustomHitbox extends Module {

    private static CustomHitbox active;

    /**
     * Слой заливки с depth-test: у ванильного debug_filled_box тест глубины
     * отсутствует, поэтому заливка рисовалась поверх игрока и «прятала» его.
     * Здесь — LEQUAL depth-test (игрок виден сквозь заливку), без culling,
     * только цвет в framebuffer (без записи глубины).
     */
    private static final RenderLayer.MultiPhase HITBOX_FILL = RenderLayer.of(
            "skr_hitbox_fill",
            VertexFormats.POSITION_COLOR,
            VertexFormat.DrawMode.TRIANGLE_STRIP,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(RenderPhase.POSITION_COLOR_PROGRAM)
                    .cull(RenderPhase.DISABLE_CULLING)
                    .depthTest(RenderPhase.LEQUAL_DEPTH_TEST)
                    .writeMaskState(RenderPhase.COLOR_MASK)
                    .layering(RenderPhase.VIEW_OFFSET_Z_LAYERING)
                    .transparency(RenderPhase.TRANSLUCENT_TRANSPARENCY)
                    .build(false)
    );

    private final ModeSetting type = new ModeSetting(
            "Тип",
            "Углы — только уголки, Обычные — вся коробка.",
            List.of("Углы", "Обычные"),
            "Углы"
    );

    private final BooleanSetting fill =
            new BooleanSetting("Заполнение", "Заливать хитбокс цветом темы.", true);

    private final SliderSetting fillOpacity =
            new SliderSetting("Прозрачность заполнения", "Непрозрачность заливки, %.", 0.0f, 100.0f, 25.0f);

    private final SliderSetting lineOpacity =
            new SliderSetting("Прозрачность линий", "Непрозрачность линий/углов, %.", 0.0f, 100.0f, 100.0f);

    private final SliderSetting cornerLength =
            new SliderSetting("Длина углов", "Длина сегментов уголка (доля ребра).", 0.05f, 0.5f, 0.25f);

    public CustomHitbox() {
        super(ModuleCategory.VISUALS, "CustomHitbox", "Кастомные хитбоксы в цвет темы (вместо F3+B).");
        setting(type);
        setting(fill);
        // «Прозрачность заполнения» нужна только при включённом заполнении.
        fillOpacity.setHideCondition(() -> !fill.getValue());
        setting(fillOpacity);
        setting(lineOpacity);
        // «Длина углов» нужна только в режиме «Углы».
        cornerLength.setHideCondition(() -> !"Углы".equals(type.getValue()));
        setting(cornerLength);
        active = this;
    }

    public static CustomHitbox getActive() {
        return active;
    }

    /** Вызывается из миксина: true — ванильный хитбокс не рисуем (рисуем свой). */
    public static boolean shouldCancelVanilla() {
        CustomHitbox module = active;
        return module != null && module.isEnabled();
    }

    /**
     * Рисует хитбокс вместо ванильного — прямо в точке вызова ванильного рендера
     * (EntityRenderDispatcher#renderHitbox), поэтому матрицы и координаты
     * полностью совпадают с ванильными (бокс локален позиции сущности).
     */
    public static void renderHitbox(MatrixStack matrices, VertexConsumer vanillaLines,
                                    Entity entity, float tickDelta) {
        CustomHitbox module = active;
        if (module == null || !module.isEnabled()) {
            return;
        }

        float lineAlpha = module.lineOpacity.getValue() / 100.0f;
        float fillAlpha = module.fillOpacity.getValue() / 100.0f;
        if (lineAlpha <= 0.0f && (!module.fill.getValue() || fillAlpha <= 0.0f)) {
            return;
        }

        int argb = Colors.clientColor();
        float r = ((argb >> 16) & 0xFF) / 255.0f;
        float g = ((argb >> 8) & 0xFF) / 255.0f;
        float b = (argb & 0xFF) / 255.0f;

        // Точно как в ванилле: бокс со смещением на позицию сущности.
        Box box = entity.getBoundingBox().offset(-entity.getX(), -entity.getY(), -entity.getZ());

        boolean corners = "Углы".equals(module.type.getValue());
        float frac = module.cornerLength.getValue();

        // Важно: Immediate.getBuffer() нового слоя СБРАСЫВАЕТ предыдущий слой.
        // Порядок: 1) буфер линий (уже текущий от ваниллы — рисуем линии сразу),
        // 2) заливка (этот запрос сам закроет и отрисует слой линий),
        // 3) заново берём буфер линий (заливка закроется сама) и рисуем остальное.

        VertexConsumerProvider.Immediate consumers =
                MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();

        // 1) Линии-основа — пишем в уже открытый ваниллой слой линий.
        if (lineAlpha > 0.0f) {
            if (corners) {
                drawCorners(matrices, vanillaLines, box, r, g, b, lineAlpha, frac);
            } else {
                VertexRendering.drawBox(matrices, vanillaLines, box, r, g, b, lineAlpha);
            }
        }

        // 2) Заливка — ванильным методом, чтобы порядок вершин
        // соответствовал слою debug_filled_box.
        if (module.fill.getValue() && fillAlpha > 0.0f) {
            VertexConsumer quads = consumers.getBuffer(HITBOX_FILL);
            VertexRendering.drawFilledBox(matrices, quads,
                    box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ,
                    r, g, b, fillAlpha);

            // 3) Углы рисуем после заливки — заново открываем слой линий.
            if (lineAlpha > 0.0f && corners) {
                VertexConsumer lines = consumers.getBuffer(RenderLayer.getLines());
                drawCorners(matrices, lines, box, r, g, b, lineAlpha, frac);
            }
        }
    }

    /** Уголки: по 3 сегмента от каждой из 8 вершин. */
    private static void drawCorners(MatrixStack matrices, VertexConsumer vertices, Box box,
                                    float r, float g, float b, float a, float frac) {
        MatrixStack.Entry entry = matrices.peek();
        double x1 = box.minX, y1 = box.minY, z1 = box.minZ;
        double x2 = box.maxX, y2 = box.maxY, z2 = box.maxZ;
        double lx = (x2 - x1) * frac;
        double ly = (y2 - y1) * frac;
        double lz = (z2 - z1) * frac;

        for (int sx = 0; sx < 2; sx++) {
            for (int sy = 0; sy < 2; sy++) {
                for (int sz = 0; sz < 2; sz++) {
                    double x = sx == 0 ? x1 : x2;
                    double y = sy == 0 ? y1 : y2;
                    double z = sz == 0 ? z1 : z2;
                    int dirX = sx == 0 ? 1 : -1;
                    int dirY = sy == 0 ? 1 : -1;
                    int dirZ = sz == 0 ? 1 : -1;

                    segment(vertices, entry, x, y, z,
                            x + dirX * lx, y, z, r, g, b, a);
                    segment(vertices, entry, x, y, z,
                            x, y + dirY * ly, z, r, g, b, a);
                    segment(vertices, entry, x, y, z,
                            x, y, z + dirZ * lz, r, g, b, a);
                }
            }
        }
    }

    private static void segment(VertexConsumer vertices, MatrixStack.Entry entry,
                                double ax, double ay, double az,
                                double bx, double by, double bz,
                                float r, float g, float b, float a) {
        float nx = (float) (bx - ax);
        float ny = (float) (by - ay);
        float nz = (float) (bz - az);
        float len = MathHelper.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0E-4F) {
            return;
        }
        nx /= len;
        ny /= len;
        nz /= len;
        vertices.vertex(entry, (float) ax, (float) ay, (float) az).color(r, g, b, a).normal(entry, nx, ny, nz);
        vertices.vertex(entry, (float) bx, (float) by, (float) bz).color(r, g, b, a).normal(entry, nx, ny, nz);
    }
}
