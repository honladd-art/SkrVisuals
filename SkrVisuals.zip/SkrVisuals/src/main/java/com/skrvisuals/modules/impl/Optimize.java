package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.particle.ParticlesMode;

import java.util.List;
import java.util.Objects;

/**
 * Optimize: модуль производительности в категории Utility.
 *
 * Снижает нагрузку на GPU/CPU, задвигая тяжёлые ванильные опции на тыльной
 * стороне {@link MinecraftClient#getOptions()}.
 *
 * Пока модуль активен и применяется, значения опций временно изменяются;
 * при выключении всё возвращается к исходным значениям.
 */
public class Optimize extends Module {

    /** Облака: OFF сильно снижает нагрузку на небо и дальние чанки. */
    private final BooleanSetting cloudsOff =
            new BooleanSetting("Без облаков", "Отключает облака (CloudRenderMode OFF).", true);

    /** Партиклы: минимум почти не рисует частицы. */
    private final ModeSetting particleMode =
            new ModeSetting("Партиклы", "Качество частиц: Минимум / Уменьшено / Все.",
                    List.of("Минимум", "Уменьшено", "Все"), "Минимум");

    /** Графика: FAST убирает прозрачности/детализацию листвы. */
    private final ModeSetting graphicsMode =
            new ModeSetting("Графика", "Режим графики: Быстро (FAST) или Красиво (FANCY).",
                    List.of("Быстро", "Красиво"), "Быстро");

    /** AO (гладкое освещение) — дорогой в растеризации, выключаем. */
    private final BooleanSetting noAo =
            new BooleanSetting("Гладкое освещение", "Выключает AO (ambient occlusion) для ускорения пересветов.", true);

    /** Тени сущностей — отдельный проход рендера, можно отключить. */
    private final BooleanSetting noEntityShadows =
            new BooleanSetting("Тени сущностей", "Отключает тени мобов и игроков.", true);

    /** Дальность прорисовки чанков (меньше — меньше геометрии на кадр). */
    private final SliderSetting viewDistance =
            new SliderSetting("Дальность чанков", "Дальность прорисовки (2-20 чанков).",
                    2.0f, 20.0f, 8.0f);

    // ----- запомненные исходные значения ванильных опций -----
    private boolean captured = false;
    private CloudRenderMode origCloud;
    private ParticlesMode origParticles;
    private GraphicsMode origGraphics;
    private boolean origAo;
    private boolean origShadows;
    private int origViewDistance;

    // ----- состояние применения -----
    private boolean applied = false;
    private String lastSignature = "";

    public Optimize() {
        super(ModuleCategory.UTILITY, "Optimize", "Оптимизация: снижает нагрузку, особенно с тяжёлыми модулями.");
        setting(cloudsOff);
        setting(particleMode);
        setting(graphicsMode);
        setting(noAo);
        setting(noEntityShadows);
        setting(viewDistance);
    }

    /** Подпись текущих настроек — чтобы переприменять только при реальных изменениях. */
    private String signature() {
        return cloudsOff.getValue()
                + "|" + particleMode.getValue()
                + "|" + graphicsMode.getValue()
                + "|" + noAo.getValue()
                + "|" + noEntityShadows.getValue()
                + "|" + viewDistance.getValue();
    }

    /* ======================== применение / восстановление ======================== */

    private static <T> void setIfChanged(SimpleOption<T> option, T value) {
        if (!Objects.equals(option.getValue(), value)) {
            option.setValue(value);
        }
    }

    private void captureOriginals(MinecraftClient client) {
        if (captured) {
            return;
        }
        var options = client.options;
        this.origCloud = options.getCloudRenderMode().getValue();
        this.origParticles = options.getParticles().getValue();
        this.origGraphics = options.getGraphicsMode().getValue();
        this.origAo = options.getAo().getValue();
        this.origShadows = options.getEntityShadows().getValue();
        this.origViewDistance = options.getViewDistance().getValue();
        this.captured = true;
    }

    private void applyOptions(MinecraftClient client) {
        var options = client.options;
        captureOriginals(client);

        setIfChanged(options.getCloudRenderMode(), cloudsOff.getValue() ? CloudRenderMode.OFF : origCloud);
        setIfChanged(options.getParticles(), mapParticles(particleMode.getValue()));
        setIfChanged(options.getGraphicsMode(), mapGraphics(graphicsMode.getValue()));
        setIfChanged(options.getAo(), !noAo.getValue());
        setIfChanged(options.getEntityShadows(), !noEntityShadows.getValue());
        setIfChanged(options.getViewDistance(), (int) viewDistance.getValue());
    }

    private void restoreOptions(MinecraftClient client) {
        if (!captured) {
            return;
        }
        var options = client.options;
        setIfChanged(options.getCloudRenderMode(), origCloud);
        setIfChanged(options.getParticles(), origParticles);
        setIfChanged(options.getGraphicsMode(), origGraphics);
        setIfChanged(options.getAo(), origAo);
        setIfChanged(options.getEntityShadows(), origShadows);
        setIfChanged(options.getViewDistance(), origViewDistance);

        this.captured = false;
        this.applied = false;
        this.lastSignature = "";
    }

    /* ======================== маппинг режимов ======================== */

    private static ParticlesMode mapParticles(String mode) {
        return switch (mode) {
            case "Минимум" -> ParticlesMode.MINIMAL;
            case "Уменьшено" -> ParticlesMode.DECREASED;
            default -> ParticlesMode.ALL;
        };
    }

    private static GraphicsMode mapGraphics(String mode) {
        return "Быстро".equals(mode) ? GraphicsMode.FAST : GraphicsMode.FANCY;
    }

    /* ======================== тик ======================== */

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null) {
            return;
        }

        boolean should = isEnabled();
        String sig = signature();

        if (should) {
            if (!applied || !sig.equals(lastSignature)) {
                applyOptions(client);
                this.applied = true;
                this.lastSignature = sig;
            }
        } else if (applied || !lastSignature.isEmpty()) {
            restoreOptions(client);
        }
    }

    @Override
    protected void onEnabledChange() {
        // Мгновенно возвращаем опции при выключении модуля.
        if (!isEnabled()) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client != null && client.world != null) {
                restoreOptions(client);
            }
        }
    }
}