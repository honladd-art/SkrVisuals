package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ColorSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import java.util.List;

public class Vignette extends Module {

    private static Vignette active;

    private final SliderSetting threshold =
            new SliderSetting("Порог", "Процент прочности брони для активации.", 5.0f, 50.0f, 20.0f);

    private final ModeSetting colorMode = new ModeSetting(
            "Цвет", "Источник цвета виньетки.",
            List.of("Тема", "Свой"), "Тема");

    private final ColorSetting customColor =
            new ColorSetting("Свой цвет", "Цвет виньетки в режиме Свой.", 0xFFFF0000);

    private final SliderSetting intensity =
            new SliderSetting("Интенсивность", "Прозрачность виньетки.", 0.0f, 100.0f, 60.0f);

    private final SliderSetting size =
            new SliderSetting("Размер", "Толщина виньетки от краёв.", 10.0f, 50.0f, 25.0f);

    private final BooleanSetting smooth =
            new BooleanSetting("Плавность", "Плавное появление/исчезновение.", true);

    private float animatedStrength = 0.0f;
    private long lastFrameTime = 0L;

    public Vignette() {
        super(ModuleCategory.COMBAT, "Vignette", "Виньетка при низкой прочности брони.");
        setting(threshold);
        setting(colorMode);
        customColor.setHideCondition(() -> !"Свой".equals(colorMode.getValue()));
        setting(customColor);
        setting(intensity);
        setting(size);
        setting(smooth);
        active = this;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) {
            return;
        }
        boolean shouldShow = isArmorBelowThreshold(client.player.getInventory().armor);
        boolean wasActive = animatedStrength > 0.001f;
        if (!shouldShow && !wasActive) {
            animatedStrength = 0.0f;
            return;
        }
        long now = System.currentTimeMillis();
        if (lastFrameTime == 0L) {
            lastFrameTime = now;
        }
        float deltaSeconds = (now - lastFrameTime) / 1000.0f;
        lastFrameTime = now;
        float target = shouldShow ? 1.0f : 0.0f;
        if (smooth.getValue()) {
            float speed = 3.0f * deltaSeconds;
            if (target > animatedStrength) {
                animatedStrength = Math.min(target, animatedStrength + speed);
            } else {
                animatedStrength = Math.max(target, animatedStrength - speed);
            }
        } else {
            animatedStrength = target;
        }
    }

    private boolean isArmorBelowThreshold(Iterable<ItemStack> armorItems) {
        float thresholdPercent = threshold.getValue();
        for (ItemStack stack : armorItems) {
            if (stack.isEmpty() || !stack.isDamageable()) {
                continue;
            }
            int maxDamage = stack.getMaxDamage();
            int currentDamage = stack.getDamage();
            if (maxDamage <= 0) {
                continue;
            }
            float remainingPercent = ((float) (maxDamage - currentDamage) / (float) maxDamage) * 100.0f;
            if (remainingPercent <= thresholdPercent) {
                return true;
            }
        }
        return false;
    }
    private int getVignetteColor() {
        int baseColor;
        if ("Свой".equals(colorMode.getValue())) {
            baseColor = customColor.getValue();
        } else {
            baseColor = Theme.accent();
        }
        float intensityFactor = intensity.getValue() / 100.0f;
        float totalAlpha = (animatedStrength * intensityFactor);
        if (totalAlpha <= 0.0f) {
            return 0;
        }
        int alpha = (int) (Math.min(totalAlpha, 1.0f) * 255.0f);
        return (alpha << 24) | (baseColor & 0x00FFFFFF);
    }

    public static void render(DrawContext context) {
        Vignette module = active;
        if (module == null || !module.isEnabled() || module.animatedStrength <= 0.001f) {
            return;
        }
        int color = module.getVignetteColor();
        if ((color >>> 24) == 0) {
            return;
        }
        int screenW = context.getScaledWindowWidth();
        int screenH = context.getScaledWindowHeight();
        float sizePercent = module.size.getValue() / 100.0f;
        int hSize = (int) (screenW * sizePercent);
        int vSize = (int) (screenH * sizePercent);
        int transparent = color & 0x00FFFFFF;

        // Верхняя и нижняя полосы
        RenderUtil.fillGradient(context, 0, 0, screenW, vSize, color, transparent);
        RenderUtil.fillGradient(context, 0, screenH - vSize, screenW, vSize, transparent, color);
        // Левая и правая полосы
        RenderUtil.fillGradientH(context, 0, 0, hSize, screenH, color, transparent);
        RenderUtil.fillGradientH(context, screenW - hSize, 0, hSize, screenH, transparent, color);
        // Сглаживание углов
        RenderUtil.fillGradient(context, 0, 0, hSize, vSize, color, transparent);
        RenderUtil.fillGradientH(context, 0, 0, hSize, vSize, color, transparent);
        RenderUtil.fillGradient(context, screenW - hSize, 0, hSize, vSize, color, transparent);
        RenderUtil.fillGradientH(context, screenW - hSize, 0, hSize, vSize, transparent, color);
        RenderUtil.fillGradient(context, 0, screenH - vSize, hSize, vSize, transparent, color);
        RenderUtil.fillGradientH(context, 0, screenH - vSize, hSize, vSize, color, transparent);
        RenderUtil.fillGradient(context, screenW - hSize, screenH - vSize, hSize, vSize, transparent, color);
        RenderUtil.fillGradientH(context, screenW - hSize, screenH - vSize, hSize, vSize, transparent, color);
    }
}
