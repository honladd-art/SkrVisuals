package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import net.minecraft.client.MinecraftClient;

import java.util.List;

/**
 * AspectRatio: рендерит мир с заданным соотношением сторон.
 *
 * Поддерживает 4:3, 16:9, 16:10 и кастомное соотношение, плюс отдельные
 * множители растяжения по ширине/высоте.
 *
 * Механизм: мир (и рука) рендерится с матрицей проекции, у которой аспект
 * равен целевому, а не аспекту окна. Картинка растягивается на всё окно
 * (эффект «стретча» как в 1.7), HUD/GUI остаётся в обычном аспекте.
 * Применяется через AspectRatioMixin в GameRenderer#getBasicProjectionMatrix.
 */
public class AspectRatio extends Module {

    private static AspectRatio active;

    private final ModeSetting ratioMode = new ModeSetting(
            "Режим", "Соотношение сторон экрана.",
            List.of("4:3", "16:9", "16:10", "Custom"), "16:9");

    private final SliderSetting customRatio = new SliderSetting(
            "Кастомное", "Кастомное соотношение сторон (W/H).",
            0.5f, 5.0f, 1.777f);

    private final SliderSetting stretchWidth = new SliderSetting(
            "Ширина", "Множитель растяжения по горизонтали.",
            0.5f, 2.0f, 1.0f);

    private final SliderSetting stretchHeight = new SliderSetting(
            "Высота", "Множитель растяжения по вертикали.",
            0.5f, 2.0f, 1.0f);

    public AspectRatio() {
        super(ModuleCategory.VISUALS, "AspectRatio",
                "Растягивает экран на 4:3, 16:9, 16:10 и другие. Можно настроить кастомный.");
        setting(ratioMode);
        setting(customRatio);
        setting(stretchWidth);
        setting(stretchHeight);
        customRatio.setHideCondition(() -> !ratioMode.getValue().equals("Custom"));
        active = this;
    }

    public static AspectRatio get() {
        AspectRatio m = active;
        return (m != null && m.isEnabled()) ? m : null;
    }

    /** Целевое соотношение сторон (W/H). */
    public float getTargetAspect() {
        return switch (ratioMode.getValue()) {
            case "4:3" -> 4.0f / 3.0f;
            case "16:9" -> 16.0f / 9.0f;
            case "16:10" -> 16.0f / 10.0f;
            case "Custom" -> customRatio.getValue();
            default -> 16.0f / 9.0f;
        };
    }

    /** Множитель растяжения по горизонтали (>1 — шире). */
    public float getStretchX() {
        return stretchWidth.getValue();
    }

    /** Множитель растяжения по вертикали (>1 — выше). */
    public float getStretchY() {
        return stretchHeight.getValue();
    }

    /**
     * Модифицирует матрицу перспективной проекции под целевой аспект.
     * Вызывается из миксина для каждой построенной матрицы мира/руки.
     */
    public void applyTo(org.joml.Matrix4f projection) {
        float aspect = getTargetAspect();
        float sy = getStretchY();
        float sx = getStretchX();

        // m11 = 1/tan(fovY/2). Умножение m11 на sy растягивает картинку по вертикали.
        float m11 = projection.m11() * sy;
        // m00 = m11 / aspect. Аспект = целевой, а не аспект окна -> стретч по ширине.
        float m00 = m11 / aspect * sx;

        projection.m00(m00);
        projection.m11(m11);
    }
}
