package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import com.skrvisuals.ui.theme.Colors;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.TriState;

import org.joml.Quaternionf;

import java.util.List;

/**
 * TargetESP: while the crosshair is over a player/mob, a billboard texture
 * (marker1.png) spins over its center. The point is projected to screen
 * space analytically (camera pos/rot + real frame FOV) and drawn in the HUD
 * pass, so it renders on top of the entity and the world. The effect fades
 * in, stays ~2s after the target is lost, then dissolves. Dead/removed
 * targets dissolve immediately.
 *
 * Режим "Души": спираль из светящихся душ. При первом наведении души
 * появляются на блок дальше цели (fade in), затем плавно подлетают к ней
 * и только после прибытия начинают крутиться; при смене цели быстро и
 * плавно перелетают к новому таргету (см. {@link #updateSoulAnimation}).
 *
 * Режим "Кристаллы": 15 объёмных кристаллов-октаэдров цвета темы стоят
 * вокруг цели ровным кольцом и крутятся вокруг неё. Разброса нет: у всех
 * кристаллов ОДИНАКОВОЕ расстояние до цели и ОДИНАКОВАЯ скорость вращения,
 * вся стая поворачивается как единое целое. Раскладка равномерная по сфере
 * (золотая спираль), поэтому кольцо охватывает цель на всех высотах — от ног
 * до над головой, как на референсе. Тело кристалла трёхмерное (вытянутый
 * октаэдр: две пирамиды основанием друг к другу + светлое внутреннее ядро-блик),
 * поэтому объём читается под любым углом; грани затеняются по своей нормали —
 * объём виден без текстур.
 * Анимация появления/подлёта — как в "Душах": появление россыпью с разбросом
 * по времени → подлёт пружиной → раскрутка стаи; при смене цели каждый
 * кристалл перелетает к новому таргету по своему таймеру
 * (см. {@link #updateCrystalAnimation}).
 *
 * Режим "Круг": при наведении вокруг цели появляется тонкое светящееся КОЛЬЦО
 * (без заливки и без ореола) и ходит вверх-вниз по сглаженной волне: амплитуда
 * проходит smoothstep — движение мягко разгоняется и тормозит на краях, плюс
 * вторая гармоника. След появляется ТОЛЬКО пока кольцо движется: точки ставятся
 * по пройденному пути при |скорость| выше порога, поэтому за летящим кольцом
 * тянется хвост из уменьшающихся колец, который гаснет. Вся геометрия строится
 * вручную из радиальных полос (POSITION_COLOR, аддитивный блендинг), БЕЗ единой
 * текстуры (см. {@link #updateCircleAnimation}, {@link #renderCircleWorld},
 * {@link #glowDisc}).
 */
public class TargetESP extends Module {
    private static final Identifier MARKER_TEXTURE =
            Identifier.of("skrvisuals", "textures/targetesp/marker1.png");
    private static final Identifier GLOW_TEXTURE =
            Identifier.of("skrvisuals", "textures/particles/bloom.png");
    /** Full brightness for the glow sprites: LightmapTextureManager.pack(15, 15). */
    private static final int MAX_LIGHT = 15728880;

    /**
     * Слой душ с АДДИТИВНЫМ блендингом (SRC_ALPHA, ONE — как в референсе).
     * Перекрывающиеся спрайты складываются по яркости, поэтому квадратные
     * границы текстуры не проступают. Depth-test сохранён (LEQUAL) — сущность
     * и блоки перекрывают души; глубина не записывается.
     */
    private static final RenderLayer GHOST_LAYER = RenderLayer.of(
            "skr_ghost_glow",
            VertexFormats.POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL,
            VertexFormat.DrawMode.QUADS,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(RenderPhase.ENTITY_TRANSLUCENT_PROGRAM)
                    // Билинейная фильтрация — мягкий спад к краю спрайта,
                    // без резкой окружности на границе текстуры.
                    .texture(new RenderPhase.Texture(GLOW_TEXTURE, TriState.TRUE, true))
                    .transparency(new RenderPhase.Transparency(
                            "ghost_additive",
                            () -> {
                                RenderSystem.enableBlend();
                                RenderSystem.blendFunc(770, 1); // SRC_ALPHA, ONE
                            },
                            () -> {
                                RenderSystem.defaultBlendFunc();
                                RenderSystem.disableBlend();
                            }))
                    .cull(RenderPhase.DISABLE_CULLING)
                    .depthTest(RenderPhase.LEQUAL_DEPTH_TEST)
                    .writeMaskState(RenderPhase.COLOR_MASK)
                    .lightmap(RenderPhase.ENABLE_LIGHTMAP)
                    .overlay(RenderPhase.ENABLE_OVERLAY_COLOR)
                    .build(false)
    );

    private static TargetESP active;
    private static boolean hookRegistered = false;

    /** Marker screen-space state, refreshed every world render frame. */
    private static boolean markerVisible = false;
    private static float markerScreenX;
    private static float markerScreenY;
    private static float markerScreenSize;

    // ---- target hold / fade state ----------------------------------------
    private static final long HOLD_MS = 2000L;    // keep showing after losing aim
    private static final long FADE_IN_MS = 250L;  // smooth appearance
    private static final long FADE_OUT_MS = 400L; // dissolve after the hold

    /** Last known decoration point — kept while the effect fades out. */
    private static Vec3d effectCenter;
    /** Entity the effect is attached to; keeps following it during the hold. */
    private static LivingEntity heldTarget;
    private static long lastSeenMs = -1L;
    private static long lastAimedOffMs = -1L;
    private static long lastFrameMs = -1L;
    private static boolean aimed = false;
    private static float fade = 0.0F;

    // ---- анимация душ: каждая душа летит сама (режим "Души") --------------
    /** Души рисуются 4 хвостами по 10 спрайтов (trailLength 20, шаг 2). */
    private static final int SOUL_TRAILS = 4;
    private static final int SOUL_TRAIL_LENGTH = 20;
    private static final int SOUL_STEP = 2;
    private static final int SOUL_PER_TRAIL = SOUL_TRAIL_LENGTH / SOUL_STEP;
    private static final int SOUL_COUNT = SOUL_TRAILS * SOUL_PER_TRAIL;

    /** Фазы одной души: скрыта → проявляется с дрейфом → ждёт (миграция) → летит. */
    private static final int SOUL_HIDDEN = 0;
    private static final int SOUL_FADE = 1;
    private static final int SOUL_WAIT = 2;
    private static final int SOUL_FLY = 3;

    /** Разброс моментов появления отдельных душ при первом наведении. */
    private static final float SOUL_APPEAR_STAGGER = 0.18F;
    /** Персональный fade in одной души. */
    private static final float SOUL_FADE_IN = 0.24F;
    /** Доля пути к спирали, проходимая прямо во время fade in (нет паузы). */
    private static final float SOUL_FADE_DRIFT = 0.40F;
    /** Закрутка воронки за время fade in (радианы). */
    private static final float SOUL_FADE_SWIRL = 0.7F;
    /** Радиус разлёта при первом наведении (души появляются ~в блоке). */
    private static final float SOUL_SPAWN_RADIUS = 1.0F;
    /** Насколько вдоль взгляда (дальше цели) появляются души. */
    private static final float SOUL_SPAWN_BACK = 0.6F;
    /** Разброс задержек при смене цели: каждая душа летит сама. */
    private static final float SOUL_MIGRATE_STAGGER = 0.26F;
    /** Предварительный дрейф души к новой цели во время её задержки (доля). */
    private static final double SOUL_MIGRATE_PRE_DRIFT = 0.18D;
    /** Пружина подлёта: жёсткость + критическое демпфирование (2*sqrt(k)). */
    private static final double SOUL_STIFFNESS = 110.0D;
    private static final double SOUL_DAMPING = 2.0D * Math.sqrt(SOUL_STIFFNESS);
    /** Потолок скорости перелёта, чтобы он не выглядел телепортом. */
    private static final double SOUL_MAX_SPEED = 45.0D;
    /** Порог "душа на месте": дистанция до слота и относительная скорость. */
    private static final double SOUL_ARRIVED_DIST = 0.09D;
    private static final double SOUL_ARRIVED_SPEED = 2.5D;
    /** Раскрутка спирали с момента, когда на неё встала первая душа. */
    private static final float SOUL_SPIN_RAMP = 0.35F;
    /** Угловые скорости спирали (те же, что были: ticks*3.2 / ticks*-4.4). */
    private static final float SOUL_SPIN_DEG_PER_SEC = 64.0F;
    private static final float SOUL_GLOBAL_DEG_PER_SEC = -88.0F;

    /** Текущая позиция и скорость каждой души — свои у каждой. */
    private static final Vec3d[] soulPos = new Vec3d[SOUL_COUNT];
    private static final Vec3d[] soulVel = new Vec3d[SOUL_COUNT];
    /** Слот души в спирали и его прошлая позиция (feed-forward скорости). */
    private static final Vec3d[] soulSlot = new Vec3d[SOUL_COUNT];
    private static final Vec3d[] soulSlotVel = new Vec3d[SOUL_COUNT];
    /** Разлёт: смещение от спирали + сама спираль на момент появления. */
    private static final Vec3d[] soulSpreadOff = new Vec3d[SOUL_COUNT];
    private static final Vec3d[] soulDriftAt = new Vec3d[SOUL_COUNT];
    /** Точка, из которой душа летит после смены цели. */
    private static final Vec3d[] soulWaitAt = new Vec3d[SOUL_COUNT];
    /** Фаза, таймер фазы и персональная альфа каждой души. */
    private static final int[] soulPhase = new int[SOUL_COUNT];
    private static final float[] soulTimer = new float[SOUL_COUNT];
    private static final float[] soulAppear = new float[SOUL_COUNT];
    /** Накопленные углы спирали: вращение стартует с нуля, без рывка. */
    private static float soulAngleDeg;
    private static float soulGlobalDeg;
    /** 0 — стая ещё не встала на спираль, 1 — спираль крутится. */
    private static float soulSpin;
    /** Цель, вокруг которой сейчас крутится стая. */
    private static LivingEntity soulEntity;

    // ---- анимация кристаллов: 15 октаэдров объёмной стаей вокруг цели --------
    /** Количество кристаллов в стае. */
    private static final int CRYSTAL_COUNT = 15;
    /** Разброс моментов появления кристаллов при первом наведении. */
    private static final float CRYSTAL_APPEAR_STAGGER = 0.20F;
    /** Персональный fade in одного кристалла. */
    private static final float CRYSTAL_FADE_IN = 0.26F;
    /** Доля пути к своему слоту, проходимая прямо во время fade in. */
    private static final float CRYSTAL_FADE_DRIFT = 0.45F;
    /** Закрутка воронки при появлении (радианы). */
    private static final float CRYSTAL_FADE_SWIRL = 0.8F;
    /** Радиус разлёта при появлении (кристаллы появляются ~в блоке). */
    private static final float CRYSTAL_SPAWN_RADIUS = 1.05F;
    /** Насколько вдоль взгляда (дальше цели) появляются кристаллы. */
    private static final float CRYSTAL_SPAWN_BACK = 0.65F;
    /** Разброс задержек при смене цели: каждый кристалл летит сама. */
    private static final float CRYSTAL_MIGRATE_STAGGER = 0.26F;
    /** Предварительный дрейф к новой цели во время задержки (доля). */
    private static final double CRYSTAL_MIGRATE_PRE_DRIFT = 0.18D;
    /** Пружина подлёта (жёсткость + критическое демпфирование). */
    private static final double CRYSTAL_STIFFNESS = 120.0D;
    private static final double CRYSTAL_DAMPING = 2.0D * Math.sqrt(CRYSTAL_STIFFNESS);
    /** Потолок скорости перелёта, чтобы подлёт не выглядел телепортом. */
    private static final double CRYSTAL_MAX_SPEED = 45.0D;
    /** Порог "кристалл на месте": дистанция до слота и относительная скорость. */
    private static final double CRYSTAL_ARRIVED_DIST = 0.09D;
    private static final double CRYSTAL_ARRIVED_SPEED = 2.5D;
    /** Раскрутка стаи с момента, когда на место встал первый кристалл. */
    private static final float CRYSTAL_SPIN_RAMP = 0.35F;
    /** Скорость обращения стаи вокруг цели (градусы/сек) — вся стая одна. */
    private static final float CRYSTAL_SPIN_DEG_PER_SEC = 58.0F;
    /** Скорость прокрутки кристаллов вокруг собственной оси (градусы/сек). */
    private static final float CRYSTAL_ROLL_DEG_PER_SEC = 40.0F;
    /** Минимальная яркость грани: даже "тёмная" грань читается как объём. */
    private static final double CRYSTAL_FACE_MIN = 0.42D;
    /** Высота верхней пирамиды кристалла в долях радиуса основания. */
    private static final double CRYSTAL_TOP_H = 2.15D;
    /** Высота нижней пирамиды — она короче верхней (как в референсе). */
    private static final double CRYSTAL_BOTTOM_H = 1.45D;
    /** Доля радиуса внутреннего светлого ядра (блик, как на референсе). */
    private static final double CRYSTAL_CORE_SCALE = 0.52D;

    // ---- равномерная раскладка стаи на сфере вокруг цели --------------------
    // Кристаллы НЕ разбрасываются: у всех ОДИНАКОВОЕ расстояние до цели и
    // ОДИНАКОВАЯ скорость вращения. Раскладка — равномерная по сфере
    // ("золотая спираль" Ватта), поэтому они стоят вокруг таргета ровным
    // кольцом на всех высотах и вся стая поворачивается как одно целое.
    /** Азимут кристалла на сфере (радианы). */
    private static final float[] crystalAzimuth = new float[CRYSTAL_COUNT];
    /** Полярный угол кристалла (радианы, 0 — верх сферы). */
    private static final float[] crystalPolar = new float[CRYSTAL_COUNT];

    static {
        // Равномерное покрытие сферы: высоты равномерно сверху вниз, азимуты идут
        // "золотым углом". Никакого разброса — только порядок обхода. Смещение
        // на полшага (i + 0.5) не даёт верхнему и нижнему кристаллам встать
        // точно друг над другом.
        double golden = Math.PI * (3.0D - Math.sqrt(5.0D));
        for (int i = 0; i < CRYSTAL_COUNT; i++) {
            double y = 1.0D - 2.0D * (i + 0.5D) / CRYSTAL_COUNT;
            crystalPolar[i] = (float) Math.acos(Math.max(-1.0D, Math.min(1.0D, y)));
            crystalAzimuth[i] = (float) (i * golden);
        }
    }

    /** Позиция/скорость каждого кристалла — свои у каждого. */
    private static final Vec3d[] crystalPos = new Vec3d[CRYSTAL_COUNT];
    private static final Vec3d[] crystalVel = new Vec3d[CRYSTAL_COUNT];
    /** Слот кристалла на орбите и его прошлая позиция (feed-forward скорости). */
    private static final Vec3d[] crystalSlot = new Vec3d[CRYSTAL_COUNT];
    private static final Vec3d[] crystalSlotVel = new Vec3d[CRYSTAL_COUNT];
    /** Разлёт: смещение от орбиты + сама точка орбиты на момент появления. */
    private static final Vec3d[] crystalSpreadOff = new Vec3d[CRYSTAL_COUNT];
    private static final Vec3d[] crystalDriftAt = new Vec3d[CRYSTAL_COUNT];
    /** Точка, из которой кристалл летит после смены цели. */
    private static final Vec3d[] crystalWaitAt = new Vec3d[CRYSTAL_COUNT];
    /** Фаза, таймер фазы и персональная альфа каждого кристалла. */
    private static final int[] crystalPhase = new int[CRYSTAL_COUNT];
    private static final float[] crystalTimer = new float[CRYSTAL_COUNT];
    private static final float[] crystalAppear = new float[CRYSTAL_COUNT];
    /** Накопленный угол обращения стаи вокруг цели: стартует с нуля, без рывка. */
    private static float crystalAngleDeg;
    /** Накопленный доворот кристаллов вокруг их собственных осей. */
    private static float crystalRollDeg;
    /** 0 — стая ещё не раскручена, 1 — крутится. */
    private static float crystalSpin;
    /** Цель, вокруг которой сейчас крутится стая. */
    private static LivingEntity crystalEntity;

    // ---- режим "Круг": кольцо ходит вверх-вниз и тянет за собой след --------
    /** Максимум точек следа (кольцевой буфер, старые перезаписываются). */
    private static final int CIRCLE_TRAIL_MAX = 24;
    /**
     * Расстояние между точками следа, блоки. Считается по пройденному пути,
     * поэтому вид следа не зависит от FPS.
     */
    private static final double CIRCLE_TRAIL_STEP = 0.11D;
    /** Время жизни одной точки следа, секунды. */
    private static final float CIRCLE_TRAIL_LIFE = 1.2F;
    /**
     * Порог вертикальной скорости (блок/с), ниже которого след не растёт.
     * В крайних точках хода кольцо практически стоит — новые точки не ставятся,
     * поэтому след тянется только за реальным движением.
     */
    private static final float CIRCLE_TRAIL_MIN_SPEED = 0.15F;
    /** Длительность появления круга, секунды. */
    private static final float CIRCLE_APPEAR_TIME = 0.28F;
    /** Скорость сглаживания по горизонтали (экспонента, 1/сек). */
    private static final float CIRCLE_FOLLOW = 14.0F;
    /** Скорость сглаживания по высоте — по вертикали круг идёт свободнее. */
    private static final float CIRCLE_FOLLOW_Y = 22.0F;

    /** Сегментов по окружности кольца. */
    private static final int RING_SEG_U = 32;
    /**
     * Радиальные полосы ОБОДА (доли радиуса). Заливки внутри нет — круг это
     * тонкое светящееся кольцо: полосы лежат только у самого края.
     */
    private static final double[] RING_BANDS = {0.80D, 0.90D, 0.965D, 1.0D};
    /** Яркость (вес цвета) каждой полосы — к самому краю обод горит ярче. */
    private static final double[] RING_BAND_WEIGHT = {0.28D, 0.62D, 0.90D, 1.0D};

    /**
     * Слой свечения режима "Круг": POSITION_COLOR (без текстур) с АДДИТИВНЫМ
     * блендингом (SRC_ALPHA, ONE) — плоский диск складывается по яркости и
     * читается как светящийся. Depth-test LEQUAL (сущность и блоки корректно
     * перекрывают), глубина не пишется, culling выключен (диск виден снизу).
     */
    private static final RenderLayer RING_LAYER = RenderLayer.of(
            "skr_target_ring",
            VertexFormats.POSITION_COLOR,
            VertexFormat.DrawMode.TRIANGLES,
            1536,
            false,
            true,
            RenderLayer.MultiPhaseParameters.builder()
                    .program(RenderPhase.POSITION_COLOR_PROGRAM)
                    .transparency(new RenderPhase.Transparency(
                            "ring_additive",
                            () -> {
                                RenderSystem.enableBlend();
                                RenderSystem.blendFunc(770, 1); // SRC_ALPHA, ONE
                            },
                            () -> {
                                RenderSystem.defaultBlendFunc();
                                RenderSystem.disableBlend();
                            }))
                    .cull(RenderPhase.DISABLE_CULLING)
                    .depthTest(RenderPhase.LEQUAL_DEPTH_TEST)
                    .writeMaskState(RenderPhase.COLOR_MASK)
                    .build(false)
    );

    /** Мировые координаты точек следа (кольцевой буфер). */
    private static final double[] circleTrailX = new double[CIRCLE_TRAIL_MAX];
    private static final double[] circleTrailY = new double[CIRCLE_TRAIL_MAX];
    private static final double[] circleTrailZ = new double[CIRCLE_TRAIL_MAX];
    private static final float[] circleTrailAge = new float[CIRCLE_TRAIL_MAX];
    /** Сколько точек сейчас в буфере и индекс первой (самой старой). */
    private static int circleTrailCount;
    private static int circleTrailHead;
    /** Путь, пройденный кругом с последней точки следа. */
    private static double circleTrailAccum;

    /** Текущая позиция кольца (сглаженная, следует за целью). */
    private static double circleX;
    private static double circleY;
    private static double circleZ;
    /** true, пока кольцо живо (нужно рендеру, чтобы не рисовать пустой кадр). */
    private static boolean circleStarted;
    /** Сглаженная вертикальная скорость кольца — по ней идёт растяжка. */
    private static float circleVy;
    /** Фаза хода вверх-вниз, радианы. */
    private static float circlePhase;
    /** 0 → 1 появление круга. */
    private static float circleAppear;
    /** Цель, за которой сейчас ходит кольцо. */
    private static LivingEntity circleEntity;

    private final ModeSetting mode = new ModeSetting("Режим", "Стиль эффекта на цели.",
            List.of("Маркер", "Души", "Кристаллы", "Круг"), "Маркер");
    private final SliderSetting markerSpeed =
            new SliderSetting("Скорость вращения", "Скорость кручения маркера/душ.", 5f, 180f, 60f);
    private final SliderSetting markerSize =
            new SliderSetting("Размер", "Размер маркера на цели.", 0.2f, 2.0f, 0.9f);
    private final SliderSetting crystalRadius =
            new SliderSetting("Радиус стаи", "Одинаковое расстояние от цели до всех кристаллов.", 0.3f, 2.0f, 0.85f);
    private final SliderSetting crystalSize =
            new SliderSetting("Размер кристаллов", "Размер кристаллов.", 0.2f, 2.5f, 1.0f);
    private final SliderSetting circleRadius =
            new SliderSetting("Радиус круга", "Размер кольца в режиме «Круг» (0.6 — шире корпуса цели).",
                    0.15f, 1.5f, 0.65f);
    private final SliderSetting circleTravel =
            new SliderSetting("Размах хода", "Доля роста цели, которую проходит круг (1.0 = от ног до головы).",
                    0.2f, 1.5f, 1.0f);
    private final SliderSetting circleCycleSpeed =
            new SliderSetting("Скорость хода", "Скорость хода круга вверх-вниз.", 0.2f, 4.0f, 1.2f);
    private final SliderSetting circleTrailAmount =
            new SliderSetting("Длина следа", "Сколько точек остаётся за кругом.", 0.0f, 2.0f, 1.0f);
    private final SliderSetting circleGlow =
            new SliderSetting("Яркость свечения", "Насколько ярко светится круг и его след.", 0.3f, 2.0f, 1.0f);

    public TargetESP() {
        super(ModuleCategory.COMBAT, "TargetESP", "Маркер на игроке/мобе под прицелом.");
        setting(mode);
        setting(markerSpeed);
        setting(markerSize);
        // Настройки стаи нужны только в режиме "Кристаллы".
        crystalRadius.setHideCondition(() -> !"Кристаллы".equals(mode.getValue()));
        setting(crystalRadius);
        crystalSize.setHideCondition(() -> !"Кристаллы".equals(mode.getValue()));
        setting(crystalSize);
        // Настройки режима "Круг".
        circleRadius.setHideCondition(() -> !"Круг".equals(mode.getValue()));
        setting(circleRadius);
        circleTravel.setHideCondition(() -> !"Круг".equals(mode.getValue()));
        setting(circleTravel);
        circleCycleSpeed.setHideCondition(() -> !"Круг".equals(mode.getValue()));
        setting(circleCycleSpeed);
        circleTrailAmount.setHideCondition(() -> !"Круг".equals(mode.getValue()));
        setting(circleTrailAmount);
        circleGlow.setHideCondition(() -> !"Круг".equals(mode.getValue()));
        setting(circleGlow);
        active = this;
        registerHook();
    }

    public static TargetESP getActive() {
        return active;
    }

    private static void registerHook() {
        if (hookRegistered) {
            return;
        }
        hookRegistered = true;
        WorldRenderEvents.LAST.register(TargetESP::onWorldRender);
        HudRenderCallback.EVENT.register(TargetESP::onHudRender);
    }

    private static void resetState() {
        markerVisible = false;
        aimed = false;
        fade = 0.0F;
        lastSeenMs = -1L;
        lastAimedOffMs = -1L;
        lastFrameMs = -1L;
        effectCenter = null;
        heldTarget = null;
        resetSoulAnimation();
        resetCrystalAnimation();
        resetCircleAnimation();
    }

    /**
     * Сбрасывает анимацию режима "Круг": следующее наведение снова проиграет
     * "плавное появление → ход вверх-вниз с растягиванием → растворяющийся след".
     */
    private static void resetCircleAnimation() {
        circleTrailCount = 0;
        circleTrailHead = 0;
        circleTrailAccum = 0.0D;
        circleStarted = false;
        circlePhase = 0.0F;
        circleAppear = 0.0F;
        circleX = 0.0D;
        circleY = 0.0D;
        circleZ = 0.0D;
        circleVy = 0.0F;
        circleEntity = null;
    }

    /**
     * Сбрасывает анимацию кристаллов: следующее наведение снова проиграет
     * "появление разлётом → подлёт к орбите → раскрутка стаи".
     */
    private static void resetCrystalAnimation() {
        for (int i = 0; i < CRYSTAL_COUNT; i++) {
            crystalPos[i] = null;
            crystalVel[i] = Vec3d.ZERO;
            crystalSlot[i] = null;
            crystalSlotVel[i] = Vec3d.ZERO;
            crystalSpreadOff[i] = null;
            crystalDriftAt[i] = null;
            crystalWaitAt[i] = null;
            crystalPhase[i] = SOUL_HIDDEN;
            crystalTimer[i] = 0.0F;
            crystalAppear[i] = 0.0F;
        }
        crystalEntity = null;
        crystalSpin = 0.0F;
        crystalAngleDeg = 0.0F;
        crystalRollDeg = 0.0F;
    }

    /**
     * Сбрасывает анимацию душ: следующее наведение снова проиграет
     * "спавн на блок дальше → подлёт → раскрутка".
     */
    private static void resetSoulAnimation() {
        for (int i = 0; i < SOUL_COUNT; i++) {
            soulPos[i] = null;
            soulVel[i] = Vec3d.ZERO;
            soulSlot[i] = null;
            soulSlotVel[i] = Vec3d.ZERO;
            soulSpreadOff[i] = null;
            soulDriftAt[i] = null;
            soulWaitAt[i] = null;
            soulPhase[i] = SOUL_HIDDEN;
            soulTimer[i] = 0.0F;
            soulAppear[i] = 0.0F;
        }
        soulEntity = null;
        soulSpin = 0.0F;
        soulAngleDeg = 0.0F;
        soulGlobalDeg = 0.0F;
    }

    /**
     * Анимация стаи душ (режим "Души"). Каждая душа — самостоятельный объект:
     * 1) первое наведение — души поочерёдно проявляются на разлёте ~в блоке
     *    вокруг цели (разлёт лежит в плоскости экрана, поэтому его видно) и
     *    СРАЗУ начинают тянуться к спирали по дуге-воронке (статичной паузы
     *    нет), затем допрыгивают до своих слотов пружиной;
     * 2) спираль раскручивается, как только на неё встала первая душа —
     *    остальные догоняют уже вращающуюся воронку (soulSpin 0 → 1);
     * 3) смена цели — каждая душа со своей задержкой срывается к слоту нового
     *    таргета, поэтому стая не перескакивает скопом.
     */
    private static void updateSoulAnimation(WorldRenderContext context, LivingEntity entity, float dt) {
        if (entity == null || effectCenter == null) {
            return;
        }
        // Геометрия спирали цели (та же математика, что была в рендере).
        double feetX = effectCenter.x;
        double feetY = effectCenter.y - entity.getHeight() / 2.0D;
        double feetZ = effectCenter.z;
        float radius = Math.max(0.3F, entity.getWidth());
        float centerY = entity.getHeight() / 2.0F;
        float amplitude = entity.getHeight() / 2.5F;

        // Базис камеры: право/вверх — плоскость экрана (разлёт реально видно
        // на экране), назад — вдоль взгляда, то есть "дальше цели".
        Vec3d cam = context.camera().getPos();
        float yawRad = (float) Math.toRadians(context.camera().getYaw());
        float pitchRad = (float) Math.toRadians(context.camera().getPitch());
        double rightX = -MathHelper.cos(yawRad);
        double rightZ = -MathHelper.sin(yawRad);
        double upX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        double upY = MathHelper.cos(pitchRad);
        double upZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);
        double dx = effectCenter.x - cam.x;
        double dy = effectCenter.y - cam.y;
        double dz = effectCenter.z - cam.z;
        double backLen = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double backX = 0.0D;
        double backY = 0.0D;
        double backZ = 0.0D;
        if (backLen > 1.0E-3D) {
            backX = dx / backLen * SOUL_SPAWN_BACK;
            backY = dy / backLen * SOUL_SPAWN_BACK;
            backZ = dz / backLen * SOUL_SPAWN_BACK;
        }

        float spinSpeed = active != null ? active.markerSpeed.getValue() / 60.0F : 1.0F;
        float globalRad = (float) Math.toRadians(soulGlobalDeg);
        boolean fresh = soulEntity == null;

        for (int i = 0; i < SOUL_COUNT; i++) {
            Vec3d slot = soulSlotPos(i, feetX, feetY, feetZ, radius, centerY, amplitude,
                    soulAngleDeg, globalRad);

            if (soulEntity != entity) {
                if (fresh) {
                    // Первое наведение: души появляются россыпью вокруг цели
                    // ("золотой угол" + разброс радиуса), каждая в свой момент.
                    double phi = i * 2.399963D;
                    double r = SOUL_SPAWN_RADIUS * (0.7D + 0.45D * hashUnit(i));
                    soulSpreadOff[i] = new Vec3d(
                            rightX * Math.cos(phi) * r + upX * Math.sin(phi) * r * 0.6D + backX,
                            upY * Math.sin(phi) * r * 0.6D + backY,
                            rightZ * Math.cos(phi) * r + upZ * Math.sin(phi) * r * 0.6D + backZ);
                    soulDriftAt[i] = slot;
                    soulPos[i] = slot.add(soulSpreadOff[i]);
                    soulVel[i] = Vec3d.ZERO;
                    soulPhase[i] = SOUL_HIDDEN;
                    soulTimer[i] = SOUL_APPEAR_STAGGER * (float) hashUnit(i);
                    soulAppear[i] = 0.0F;
                } else if (soulPhase[i] == SOUL_FLY) {
                    // Смена цели: душа ещё чуть висит там, где была, а затем со
                    // своей задержкой срывается к слоту нового таргета.
                    soulWaitAt[i] = soulSlot[i] != null ? soulSlot[i] : soulPos[i];
                    soulTimer[i] = SOUL_MIGRATE_STAGGER * (float) hashUnit(i);
                    soulPhase[i] = SOUL_WAIT;
                }
                soulSlotVel[i] = Vec3d.ZERO;
            }

            // Feed-forward: сглаженная скорость самого слота (цель может бежать).
            if (soulSlot[i] != null && dt > 1.0E-4F) {
                Vec3d instant = slot.subtract(soulSlot[i]).multiply(1.0D / dt);
                if (instant.lengthSquared() > 900.0D) {
                    instant = Vec3d.ZERO; // телепорт/рывок — игнорируем
                }
                soulSlotVel[i] = soulSlotVel[i].lerp(instant, 0.35D);
            }
            soulSlot[i] = slot;
        }

        if (soulEntity != entity) {
            soulEntity = entity;
            if (fresh) {
                soulSpin = 0.0F;
                soulAngleDeg = 0.0F;
                soulGlobalDeg = 0.0F;
            }
        }

        // Фазы: у каждой души свой таймер, поэтому стая никогда не статична.
        for (int i = 0; i < SOUL_COUNT; i++) {
            Vec3d slot = soulSlot[i];
            Vec3d driftAt = soulDriftAt[i] != null ? soulDriftAt[i] : slot;
            Vec3d spread = soulSpreadOff[i] != null ? soulSpreadOff[i] : Vec3d.ZERO;
            switch (soulPhase[i]) {
                case SOUL_HIDDEN -> {
                    // Своя задержка появления — души проступают поочерёдно.
                    soulTimer[i] -= dt;
                    soulPos[i] = driftAt.add(spread);
                    soulVel[i] = Vec3d.ZERO;
                    if (soulTimer[i] <= 0.0F) {
                        soulPhase[i] = SOUL_FADE;
                    }
                }
                case SOUL_FADE -> {
                    // Проявляемся и СРАЗУ тянемся к спирали по дуге (воронка),
                    // поэтому нет статичной паузы "появились и стоят".
                    soulAppear[i] = Math.min(1.0F, soulAppear[i] + dt / SOUL_FADE_IN);
                    float p = soulAppear[i];
                    float pull = 1.0F - SOUL_FADE_DRIFT * p * p;
                    soulPos[i] = driftAt.add(rotateY(spread, SOUL_FADE_SWIRL * p).multiply(pull));
                    soulVel[i] = Vec3d.ZERO;
                    if (p >= 1.0F) {
                        soulPhase[i] = SOUL_FLY;
                    }
                }
                case SOUL_WAIT -> {
                    // Смена цели: душа не стоит мёртво — сразу начинает
                    // медленный дрейф в сторону нового таргета, а со своей
                    // задержкой срывается к слоту целиком.
                    soulTimer[i] -= dt;
                    Vec3d pre = soulWaitAt[i] != null
                            ? soulWaitAt[i].lerp(slot, SOUL_MIGRATE_PRE_DRIFT)
                            : slot;
                    soulPos[i] = springStep(i, pre, soulSlotVel[i], dt);
                    if (soulTimer[i] <= 0.0F) {
                        soulPhase[i] = SOUL_FLY;
                    }
                }
                default -> soulPos[i] = springStep(i, slot, soulSlotVel[i], dt);
            }
        }

        // Раскрутка спирали — с момента, когда на неё встала первая душа:
        // остальные слетаются уже в крутящуюся воронку и никого не ждут.
        if (soulSpin < 1.0F) {
            boolean anyArrived = false;
            for (int i = 0; i < SOUL_COUNT; i++) {
                Vec3d pos = soulPos[i];
                if (soulPhase[i] == SOUL_FLY && pos != null
                        && pos.distanceTo(soulSlot[i]) <= SOUL_ARRIVED_DIST
                        && soulVel[i].subtract(soulSlotVel[i]).length() <= SOUL_ARRIVED_SPEED) {
                    anyArrived = true;
                    break;
                }
            }
            if (anyArrived) {
                soulSpin = Math.min(1.0F, soulSpin + dt / SOUL_SPIN_RAMP);
            }
        }

        // Интегральное вращение: угловая скорость нарастает вместе с soulSpin
        // (smoothstep), поэтому хвосты начинают крутиться без рывка.
        float ramp = soulSpin * soulSpin * (3.0F - 2.0F * soulSpin);
        soulAngleDeg += dt * SOUL_SPIN_DEG_PER_SEC * spinSpeed * ramp;
        soulGlobalDeg += dt * SOUL_GLOBAL_DEG_PER_SEC * spinSpeed * ramp;
    }

    /**
     * Один шаг пружины души к цели: критическое демпфирование + feed-forward
     * по скорости слота (душа не отстаёт от бегущей цели и не перелетает).
     */
    private static Vec3d springStep(int i, Vec3d target, Vec3d targetVel, float dt) {
        Vec3d pos = soulPos[i];
        if (target == null || pos == null) {
            return pos;
        }
        Vec3d vel = soulVel[i];
        // Мелкие шаги — интегратор не разъезжается при просадках FPS.
        int steps = MathHelper.clamp((int) Math.ceil(dt / (1.0F / 120.0F)), 1, 16);
        double h = dt / (double) steps;
        for (int s = 0; s < steps; s++) {
            double ax = SOUL_STIFFNESS * (target.x - pos.x) - SOUL_DAMPING * (vel.x - targetVel.x);
            double ay = SOUL_STIFFNESS * (target.y - pos.y) - SOUL_DAMPING * (vel.y - targetVel.y);
            double az = SOUL_STIFFNESS * (target.z - pos.z) - SOUL_DAMPING * (vel.z - targetVel.z);
            vel = vel.add(ax * h, ay * h, az * h);
            if (vel.lengthSquared() > SOUL_MAX_SPEED * SOUL_MAX_SPEED) {
                vel = vel.normalize().multiply(SOUL_MAX_SPEED);
            }
            pos = pos.add(vel.x * h, vel.y * h, vel.z * h);
        }
        soulVel[i] = vel;
        return pos;
    }

    /**
     * Мировая позиция слота души в спирали (математика прежнего рендера):
     * 4 хвоста, вертикальная синусоида и медленный доворот спирали.
     */
    private static Vec3d soulSlotPos(int index, double feetX, double feetY, double feetZ,
                                     float radius, float centerY, float amplitude,
                                     float moving, float globalRad) {
        int trail = index / SOUL_PER_TRAIL;
        int seg = (index % SOUL_PER_TRAIL) * SOUL_STEP;
        double aRad = Math.toRadians(moving + trail * 90.0F - seg * 2.0F);
        float px = (float) Math.sin(aRad) * radius;
        float pz = (float) Math.cos(aRad) * radius;
        float y = centerY + (float) Math.cos(aRad * 2.0D) * amplitude;
        double x = px * MathHelper.cos(globalRad) - pz * MathHelper.sin(globalRad);
        double z = px * MathHelper.sin(globalRad) + pz * MathHelper.cos(globalRad);
        return new Vec3d(feetX + x, feetY + y, feetZ + z);
    }

    /** Детерминированное псевдослучайное [0,1) по индексу души. */
    private static double hashUnit(int index) {
        double v = Math.sin(index * 12.9898D) * 43758.5453D;
        return v - Math.floor(v);
    }

    /** Поворот вектора вокруг вертикали — закрутка воронки при появлении. */
    private static Vec3d rotateY(Vec3d v, float angle) {
        float c = MathHelper.cos(angle);
        float s = MathHelper.sin(angle);
        return new Vec3d(v.x * c - v.z * s, v.y, v.x * s + v.z * c);
    }

    /**
     * Анимация кристаллов (режим "Кристаллы"). Повторяет "Души", только цель
     * движения — ровное кольцо вокруг сущности: все 15 кристаллов стоят на
     * одинаковом расстоянии и крутятся с одинаковой скоростью, вся стая
     * поворачивается как одно целое (см. {@link #crystalSlotPos}):
     * 1) первое наведение — кристаллы поочерёдно проявляются на разлёте ~в
     *    блоке вокруг цели (разлёт лежит в плоскости экрана) и сразу тянутся
     *    к своему слоту по дуге-воронке, без статичной паузы;
     * 2) кольцо начинает крутиться, как только на место встал первый кристалл
     *    (crystalSpin 0 → 1), остальные догоняют уже вращающееся кольцо;
     * 3) смена цели — каждый кристалл со своей задержкой срывается к слоту
     *    нового таргета, поэтому кольцо не перескакивает скопом.
     */
    private static void updateCrystalAnimation(WorldRenderContext context, LivingEntity entity, float dt) {
        if (entity == null || effectCenter == null) {
            return;
        }
        double cx = effectCenter.x;
        double cy = effectCenter.y;
        double cz = effectCenter.z;
        float radius = active != null ? active.crystalRadius.getValue() : 0.85F;

        // Базис камеры: право/вверх — плоскость экрана (разлёт реально виден),
        // назад — вдоль взгляда, то есть "дальше цели".
        Vec3d cam = context.camera().getPos();
        float yawRad = (float) Math.toRadians(context.camera().getYaw());
        float pitchRad = (float) Math.toRadians(context.camera().getPitch());
        double rightX = -MathHelper.cos(yawRad);
        double rightZ = -MathHelper.sin(yawRad);
        double upX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        double upY = MathHelper.cos(pitchRad);
        double upZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);
        double dx = effectCenter.x - cam.x;
        double dy = effectCenter.y - cam.y;
        double dz = effectCenter.z - cam.z;
        double backLen = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double backX = 0.0D;
        double backY = 0.0D;
        double backZ = 0.0D;
        if (backLen > 1.0E-3D) {
            backX = dx / backLen * CRYSTAL_SPAWN_BACK;
            backY = dy / backLen * CRYSTAL_SPAWN_BACK;
            backZ = dz / backLen * CRYSTAL_SPAWN_BACK;
        }

        float spinSpeed = active != null ? active.markerSpeed.getValue() / 60.0F : 1.0F;
        boolean fresh = crystalEntity == null;

        Vec3d center = new Vec3d(cx, cy, cz);

        for (int i = 0; i < CRYSTAL_COUNT; i++) {
            Vec3d slot = crystalSlotPos(i, center, radius, crystalAngleDeg);

            if (crystalEntity != entity) {
                if (fresh) {
                    // Первое наведение: кристаллы появляются россыпью вокруг
                    // цели ("золотой угол" + разброс радиуса), каждый в свой момент.
                    double phi = i * 2.399963D;
                    double r = CRYSTAL_SPAWN_RADIUS * (0.7D + 0.45D * hashUnit(i));
                    crystalSpreadOff[i] = new Vec3d(
                            rightX * Math.cos(phi) * r + upX * Math.sin(phi) * r * 0.6D + backX,
                            upY * Math.sin(phi) * r * 0.6D + backY,
                            rightZ * Math.cos(phi) * r + upZ * Math.sin(phi) * r * 0.6D + backZ);
                    crystalDriftAt[i] = slot;
                    crystalPos[i] = slot.add(crystalSpreadOff[i]);
                    crystalVel[i] = Vec3d.ZERO;
                    crystalPhase[i] = SOUL_HIDDEN;
                    crystalTimer[i] = CRYSTAL_APPEAR_STAGGER * (float) hashUnit(i);
                    crystalAppear[i] = 0.0F;
                } else if (crystalPhase[i] == SOUL_FLY) {
                    // Смена цели: кристалл ещё чуть висит на старом месте, а затем
                    // со своей задержкой срывается к слоту нового таргета.
                    crystalWaitAt[i] = crystalSlot[i] != null ? crystalSlot[i] : crystalPos[i];
                    crystalTimer[i] = CRYSTAL_MIGRATE_STAGGER * (float) hashUnit(i);
                    crystalPhase[i] = SOUL_WAIT;
                }
                crystalSlotVel[i] = Vec3d.ZERO;
            }

            // Feed-forward: сглаженная скорость самого слота (цель может бежать).
            if (crystalSlot[i] != null && dt > 1.0E-4F) {
                Vec3d instant = slot.subtract(crystalSlot[i]).multiply(1.0D / dt);
                if (instant.lengthSquared() > 900.0D) {
                    instant = Vec3d.ZERO; // телепорт/рывок — игнорируем
                }
                crystalSlotVel[i] = crystalSlotVel[i].lerp(instant, 0.35D);
            }
            crystalSlot[i] = slot;
        }

        if (crystalEntity != entity) {
            crystalEntity = entity;
            if (fresh) {
                crystalSpin = 0.0F;
                crystalAngleDeg = 0.0F;
                crystalRollDeg = 0.0F;
            }
        }

        // Фазы: у каждого кристалла свой таймер, поэтому кольцо никогда не статично.
        for (int i = 0; i < CRYSTAL_COUNT; i++) {
            Vec3d slot = crystalSlot[i];
            Vec3d driftAt = crystalDriftAt[i] != null ? crystalDriftAt[i] : slot;
            Vec3d spread = crystalSpreadOff[i] != null ? crystalSpreadOff[i] : Vec3d.ZERO;
            switch (crystalPhase[i]) {
                case SOUL_HIDDEN -> {
                    // Своя задержка появления — кристаллы проступают поочерёдно.
                    crystalTimer[i] -= dt;
                    crystalPos[i] = driftAt.add(spread);
                    crystalVel[i] = Vec3d.ZERO;
                    if (crystalTimer[i] <= 0.0F) {
                        crystalPhase[i] = SOUL_FADE;
                    }
                }
                case SOUL_FADE -> {
                    // Проявляемся и СРАЗУ тянемся к кольцу по дуге (воронка),
                    // поэтому нет паузы "появились и стоят".
                    crystalAppear[i] = Math.min(1.0F, crystalAppear[i] + dt / CRYSTAL_FADE_IN);
                    float p = crystalAppear[i];
                    float pull = 1.0F - CRYSTAL_FADE_DRIFT * p * p;
                    crystalPos[i] = driftAt.add(rotateY(spread, CRYSTAL_FADE_SWIRL * p).multiply(pull));
                    crystalVel[i] = Vec3d.ZERO;
                    if (p >= 1.0F) {
                        crystalPhase[i] = SOUL_FLY;
                    }
                }
                case SOUL_WAIT -> {
                    // Смена цели: не стоит мёртво — сразу дрейфует в сторону нового
                    // таргета, а со своей задержкой срывается к слоту целиком.
                    crystalTimer[i] -= dt;
                    Vec3d pre = crystalWaitAt[i] != null
                            ? crystalWaitAt[i].lerp(slot, CRYSTAL_MIGRATE_PRE_DRIFT)
                            : slot;
                    crystalPos[i] = crystalSpringStep(i, pre, crystalSlotVel[i], dt);
                    if (crystalTimer[i] <= 0.0F) {
                        crystalPhase[i] = SOUL_FLY;
                    }
                }
                default -> crystalPos[i] = crystalSpringStep(i, slot, crystalSlotVel[i], dt);
            }
        }

        // Раскрутка стаи — с момента, когда на место встал первый кристалл.
        if (crystalSpin < 1.0F) {
            boolean anyArrived = false;
            for (int i = 0; i < CRYSTAL_COUNT; i++) {
                Vec3d pos = crystalPos[i];
                if (crystalPhase[i] == SOUL_FLY && pos != null
                        && pos.distanceTo(crystalSlot[i]) <= CRYSTAL_ARRIVED_DIST
                        && crystalVel[i].subtract(crystalSlotVel[i]).length() <= CRYSTAL_ARRIVED_SPEED) {
                    anyArrived = true;
                    break;
                }
            }
            if (anyArrived) {
                crystalSpin = Math.min(1.0F, crystalSpin + dt / CRYSTAL_SPIN_RAMP);
            }
        }

        // Интегральное вращение: угловая скорость нарастает вместе с crystalSpin
        // (smoothstep), поэтому стая начинает крутиться без рывка. Угловой
        // накопитель ОДИН на всех — вся стая вращается как единое целое,
        // с одинаковой скоростью и без разброса.
        float ramp = crystalSpin * crystalSpin * (3.0F - 2.0F * crystalSpin);
        crystalAngleDeg += dt * CRYSTAL_SPIN_DEG_PER_SEC * spinSpeed * ramp;
        // Каждый кристалл крутится вокруг своей оси: грани переливаются, и
        // объём октаэдра читается с любого ракурса. Начинается вместе с
        // раскруткой стаи (ramp), поэтому без стартового рывка.
        crystalRollDeg += dt * CRYSTAL_ROLL_DEG_PER_SEC * spinSpeed * ramp;
    }

    /**
     * Один шаг пружины кристалла к слоту: критическое демпфирование +
     * feed-forward по скорости слота (не отстаёт от бегущей цели, не перелетает).
     */
    private static Vec3d crystalSpringStep(int i, Vec3d target, Vec3d targetVel, float dt) {
        Vec3d pos = crystalPos[i];
        if (target == null || pos == null) {
            return pos;
        }
        Vec3d vel = crystalVel[i];
        // Мелкие шаги — интегратор не разъезжается при просадках FPS.
        int steps = MathHelper.clamp((int) Math.ceil(dt / (1.0F / 120.0F)), 1, 16);
        double h = dt / (double) steps;
        for (int s = 0; s < steps; s++) {
            double ax = CRYSTAL_STIFFNESS * (target.x - pos.x) - CRYSTAL_DAMPING * (vel.x - targetVel.x);
            double ay = CRYSTAL_STIFFNESS * (target.y - pos.y) - CRYSTAL_DAMPING * (vel.y - targetVel.y);
            double az = CRYSTAL_STIFFNESS * (target.z - pos.z) - CRYSTAL_DAMPING * (vel.z - targetVel.z);
            vel = vel.add(ax * h, ay * h, az * h);
            if (vel.lengthSquared() > CRYSTAL_MAX_SPEED * CRYSTAL_MAX_SPEED) {
                vel = vel.normalize().multiply(CRYSTAL_MAX_SPEED);
            }
            pos = pos.add(vel.x * h, vel.y * h, vel.z * h);
        }
        crystalVel[i] = vel;
        return pos;
    }

    /**
     * Мировая позиция слота кристалла — точка на сфере вокруг цели.
     *
     * <p>Здесь намеренно НЕТ разброса: у всех кристаллов одинаковое расстояние
     * {@code radius} до центра цели и одинаковый угол поворота {@code moving}.
     * Позиция строится из сферических координат: фиксированные полярный угол и
     * азимут (равномерно распределены по сфере в static-блоке) плюс ОБЩИЙ угол
     * обращения. Поэтому стая стоит вокруг таргета ровным кольцом на всех
     * высотах и поворачивается как единое целое — без покачивания, разброса
     * радиусов и прецессии.
     */
    private static Vec3d crystalSlotPos(int index, Vec3d center, double radius, float moving) {
        // Направление на сфере: полярный угол задаёт высоту, азимут — сторону.
        // Поворот стаи — общий для всех, поэтому просто добавляем его к азимуту.
        double a = crystalAzimuth[index] + Math.toRadians(moving);
        double polar = crystalPolar[index];

        // Сферические координаты: равный радиус, равномерный охват по высоте.
        double ringRadius = Math.sin(polar) * radius;   // проекция на горизонталь
        double x = Math.sin(a) * ringRadius;
        double z = Math.cos(a) * ringRadius;
        double y = Math.cos(polar) * radius;            // высота относительно центра
        return new Vec3d(center.x + x, center.y + y, center.z + z);
    }

    private static Vec3d centerOf(LivingEntity entity, float delta) {
        Vec3d lerped = entity.getLerpedPos(delta);
        return new Vec3d(lerped.getX(), lerped.getY() + entity.getHeight() / 2.0D, lerped.getZ());
    }

    /**
     * FIX: проверка линии видимости для hold-фазы. Луч от глаз камеры к
     * центру и к голове сущности; если оба луча упираются в блоки мира,
     * значит цель за стеной и маркер показывать нельзя.
     */
    private static boolean hasLineOfSight(MinecraftClient client, LivingEntity entity, float delta) {
        if (client.player == null || client.world == null) {
            return false;
        }
        Vec3d eye = client.player.getEyePos();
        Vec3d lerped = entity.getLerpedPos(delta);
        Vec3d center = new Vec3d(lerped.getX(),
                lerped.getY() + entity.getHeight() / 2.0D, lerped.getZ());
        Vec3d head = new Vec3d(lerped.getX(),
                lerped.getY() + entity.getHeight() * 0.85D, lerped.getZ());

        return rayHits(client, eye, center) || rayHits(client, eye, head);
    }

    /** true, если луч от камеры до точки НЕ блокируется блоками мира. */
    private static boolean rayHits(MinecraftClient client, Vec3d from, Vec3d to) {
        HitResult result = client.world.raycast(new RaycastContext(
                from, to,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                client.player));
        return result.getType() == HitResult.Type.MISS;
    }

    private static void onWorldRender(WorldRenderContext context) {
        TargetESP module = active;
        long now = System.currentTimeMillis();
        if (module == null || !module.isEnabled()) {
            resetState();
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            resetState();
            return;
        }

        float delta = context.tickCounter().getTickDelta(false);

        // Resolve the aim target every world-render frame using the camera's
        // current crosshair.
        LivingEntity target = null;
        if (client.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity living
                && !living.isSpectator()
                && living.squaredDistanceTo(client.player) <= 64.0D) {
            target = living;
        }
        aimed = target != null;

        // FIX: мёртвую/удалённую цель больше не "держим" — hold отменяется,
        // эффект сразу уходит в fade-out и не остаётся призраком навсегда.
        if (heldTarget != null && (heldTarget.isRemoved() || !heldTarget.isAlive())) {
            heldTarget = null;
            lastAimedOffMs = -1L;
        }

        // FIX: во время hold маркер больше не рисуется сквозь стены.
        // Если прицел ушёл с цели и между камерой и сущностью появилась
        // преграда (raycast блокируется миром) — считаем цель потерянной.
        boolean lineOfSight = true;
        if (!aimed && heldTarget != null) {
            lineOfSight = hasLineOfSight(client, heldTarget, delta);
        }

        if (aimed) {
            heldTarget = target;
            lastSeenMs = now;
            lastAimedOffMs = -1L;
            effectCenter = centerOf(target, delta);
        } else if (heldTarget != null) {
            // Start the hold clock once at the moment aim leaves the target.
            if (lastAimedOffMs < 0L) {
                lastAimedOffMs = now;
            }
            // While holding after losing aim, keep following the entity itself.
            effectCenter = centerOf(heldTarget, delta);
        }

        float dt = lastFrameMs < 0L ? 0.0F
                : MathHelper.clamp((now - lastFrameMs) / 1000.0F, 0.0F, 0.1F);
        lastFrameMs = now;

        if (aimed) {
            fade = Math.min(1.0F, fade + dt / (FADE_IN_MS / 1000.0F));
        } else {
            // Полная непрозрачность держится HOLD_MS; после — затухание.
            // Если цели нет вообще (умерла/удалена) — затухание сразу.
            // FIX: если цель ушла за стену (нет линии видимости) — hold
            // тоже прекращается, и маркер затухает, не рисуясь сквозь блоки.
            boolean holding = heldTarget != null
                    && lineOfSight
                    && lastAimedOffMs >= 0L
                    && (now - lastAimedOffMs) <= HOLD_MS;
            if (!holding) {
                fade = Math.max(0.0F, fade - dt / (FADE_OUT_MS / 1000.0F));
            }
        }

        boolean soulMode = module.mode.getValue().equals("Души");
        boolean crystalMode = module.mode.getValue().equals("Кристаллы");
        boolean circleMode = module.mode.getValue().equals("Круг");
        if (!soulMode) {
            // В режиме "Маркер" анимацию душ не копим — при возврате в "Души"
            // подлёт проиграется заново, как при первом наведении.
            resetSoulAnimation();
        }
        if (!crystalMode) {
            // Так же и для кристаллов: стая собирается заново при входе
            // в режим "Кристаллы".
            resetCrystalAnimation();
        }
        if (!circleMode) {
            resetCircleAnimation();
        }

        if (effectCenter == null || fade <= 0.01F || (!aimed && !lineOfSight)) {
            markerVisible = false;
            // Эффект полностью ушёл — следующее наведение снова начнётся
            // с появления душ/кристаллов на блок дальше цели.
            resetSoulAnimation();
            resetCrystalAnimation();
            resetCircleAnimation();
            if (!aimed) {
                heldTarget = null;
                lastAimedOffMs = -1L;
            }
            return;
        }
        LivingEntity shown = heldTarget != null ? heldTarget : target;
        if (soulMode) {
            // Каждая душа анимируется отдельно: появление на разлёте → подлёт →
            // раскрутка; при смене цели — перелёт по одной. Затем мировой рендер
            // с depth-тестом: сущность и блоки перекрывают души.
            updateSoulAnimation(context, shown, dt);
            module.renderGhostsWorld(context);
        } else if (crystalMode) {
            // Каждый кристалл анимируется отдельно (появление разлётом → подлёт
            // к кольцу → раскрутка), затем рисуется мировым проходом.
            updateCrystalAnimation(context, shown, dt);
            module.renderCrystalsWorld(context);
        } else if (circleMode) {
            // Кольцо ходит вверх-вниз по eased-синусоиде и оставляет след
            // (см. updateCircleAnimation), затем рисуется мировым проходом.
            // HUD-маркер в этом режиме не рисуется.
            markerVisible = false;
            updateCircleAnimation(context, shown, dt);
            module.renderCircleWorld(context);
        } else {
            module.updateMarkerProjection(client, context, effectCenter);
        }
    }

    /**
     * Режим "Души" (по референсу SpiralGhosts): 4 спиральных хвоста из
     * светящихся "душ" кружат вокруг цели по вертикальной синусоиде.
     * Рендер идёт в мировом проходе (billboard-спрайты с bloom-текстурой),
     * поэтому души честно перекрываются моделью сущности и блоками.
     * Точки душ берутся из анимации (soulPos/soulAppear), вращение —
     * накопленные углы soulAngleDeg/soulGlobalDeg.
     */
    private void renderGhostsWorld(WorldRenderContext context) {
        float sizeMul = markerSize.getValue();

        int theme = Colors.clientColor();
        int r0 = (theme >> 16) & 0xFF;
        int g0 = (theme >> 8) & 0xFF;
        int b0 = theme & 0xFF;

        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camera = context.camera().getPos();

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer buffer = consumers.getBuffer(GHOST_LAYER);

        var entry = matrices.peek();
        var matrix = entry.getPositionMatrix();
        float yawRad = (float) Math.toRadians(context.camera().getYaw());
        float pitchRad = (float) Math.toRadians(context.camera().getPitch());
        // Полный билборд: базис камеры (yaw + pitch), чтобы спрайты не
        // "схлопывались" в линию при взгляде сверху/снизу.
        float rx = -MathHelper.cos(yawRad);
        float rz = -MathHelper.sin(yawRad);
        float ux = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uy = MathHelper.cos(pitchRad);
        float uz = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        // Точки душ уже анимированы (soulPos): стая появляется на разлёте,
        // подлетает и перелетает к новой цели по одной душе.
        for (int i = 0; i < SOUL_COUNT; i++) {
            Vec3d pos = soulPos[i];
            float appear = soulAppear[i];
            if (pos == null || appear <= 0.001F) {
                continue;
            }
            int seg = (i % SOUL_PER_TRAIL) * SOUL_STEP;

            // Хвост: ближе к "голове" — крупнее и ярче.
            float offset = (SOUL_TRAIL_LENGTH - seg) / (float) SOUL_TRAIL_LENGTH;
            float scale = (0.2F + 0.01F * (SOUL_TRAIL_LENGTH - seg)) * sizeMul;

            // Степенное затухание + ограничение яркости: при аддитивном
            // блендинге полная альфа пересвечивает спрайт в белый и
            // делает край текстуры заметным. Персональная appear даёт
            // поочерёдное появление и подлёт каждой души.
            float alphaF = (float) Math.pow(offset, 1.6D) * fade * appear * 0.65F;
            int alpha = MathHelper.clamp((int) (alphaF * 255.0F), 0, 255);
            if (alpha <= 4) {
                continue;
            }

                float wx = (float) pos.x;
            float wy = (float) pos.y;
            float wz = (float) pos.z;
            float half = scale / 2.0F;

            float rXh = rx * half, rZh = rz * half;
            float uXh = ux * half, uYh = uy * half, uZh = uz * half;

            // Билборд по полному базису камеры (right x up).
            corner(buffer, entry, matrix, wx - rXh - uXh, wy - uYh, wz - rZh - uZh, r0, g0, b0, alpha, 0.0F, 1.0F);
            corner(buffer, entry, matrix, wx + rXh - uXh, wy - uYh, wz + rZh - uZh, r0, g0, b0, alpha, 1.0F, 1.0F);
            corner(buffer, entry, matrix, wx + rXh + uXh, wy + uYh, wz + rZh + uZh, r0, g0, b0, alpha, 1.0F, 0.0F);
            corner(buffer, entry, matrix, wx - rXh + uXh, wy + uYh, wz - rZh + uZh, r0, g0, b0, alpha, 0.0F, 0.0F);

            // Обратный порядок вершин — спрайт виден с любой стороны.
            corner(buffer, entry, matrix, wx - rXh - uXh, wy - uYh, wz - rZh - uZh, r0, g0, b0, alpha, 0.0F, 1.0F);
            corner(buffer, entry, matrix, wx - rXh + uXh, wy + uYh, wz - rZh + uZh, r0, g0, b0, alpha, 0.0F, 0.0F);
            corner(buffer, entry, matrix, wx + rXh + uXh, wy + uYh, wz + rZh + uZh, r0, g0, b0, alpha, 1.0F, 0.0F);
            corner(buffer, entry, matrix, wx + rXh - uXh, wy - uYh, wz + rZh - uZh, r0, g0, b0, alpha, 1.0F, 1.0F);
        }

        consumers.draw(GHOST_LAYER);
        matrices.pop();
    }

    /** Одна вершина billboard-спрайта (как в ChinaHat). */
    private static void corner(VertexConsumer buffer, MatrixStack.Entry entry,
                               org.joml.Matrix4f matrix, float x, float y, float z,
                               int r, int g, int b, int a, float u, float v) {
        buffer.vertex(matrix, x, y, z)
                .color(r, g, b, a)
                .texture(u, v)
                .overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV)
                .light(MAX_LIGHT)
                .normal(entry, 0.0F, 1.0F, 0.0F);
    }

    // ---- режим "Круг": кольцо + движущийся след ----------------------------

    /**
     * Анимация режима "Круг". Кольцо появляется над целью, затем ходит
     * вверх-вниз по СГЛАЖЕННОЙ волне: амплитуда проходит smoothstep, поэтому
     * движение мягко разгоняется и так же мягко тормозит в крайних точках —
     * видно анимацию, а не мельтешение. Дополнительно кольцо слегка
     * «дышит» размером и растягивается по вертикали по текущей скорости.
     *
     * <p>Каждый пройденный CIRCLE_TRAIL_STEP блоков оставляет точку в
     * кольцевом буфере следа: точки стареют, уменьшаются и гаснут, поэтому за
     * кольцом тянется мягкий след (см. {@link #renderCircleWorld}). Точки
     * ставятся по ПРОЙДЕННОМУ пути, а не по кадрам, поэтому вид следа не
     * зависит от FPS.
     */
    private static void updateCircleAnimation(WorldRenderContext context, LivingEntity entity, float dt) {
        if (entity == null || effectCenter == null) {
            return;
        }
        // Смена цели — след начинается заново от нового кольца.
        if (circleEntity != entity) {
            circleEntity = entity;
            circleTrailCount = 0;
            circleTrailHead = 0;
            circleTrailAccum = 0.0D;
            circleX = effectCenter.x;
            circleY = effectCenter.y;
            circleZ = effectCenter.z;
            circlePhase = 0.0F;
            circleVy = 0.0F;
            circleStarted = true;
        }

        circleAppear = Math.min(1.0F, circleAppear + dt / CIRCLE_APPEAR_TIME);

        // Волна хода: sin → 0..1 → smoothstep. На краях скорость ≈ 0, в середине
        // максимальная, поэтому круг не "дёргается" между крайними точками.
        TargetESP module = active;
        float cycleSpeed = module != null ? module.circleCycleSpeed.getValue() : 1.2F;
        circlePhase += (float) (dt * cycleSpeed * Math.PI * 2.0D);
        if (circlePhase > (float) (Math.PI * 2.0D)) {
            circlePhase -= (float) (Math.PI * 2.0D);
        }
        float s = 0.5F + 0.5F * MathHelper.sin(circlePhase);
        float wave = s * s * (3.0F - 2.0F * s);
        // Мелкая вторая гармоника — круг слегка "дышит" и не выглядит маятником.
        wave += 0.06F * MathHelper.sin(circlePhase * 2.0F + 1.0F);

        // Размах хода задаётся ДОЛЕЙ РОСТА цели: 1.0 — кольцо идёт от ног
        // до головы, 0.5 — только по поясу, 1.5 — с запасом за тело.
        double travelFrac = module != null ? module.circleTravel.getValue() : 1.0D;
        double feetY = effectCenter.y - entity.getHeight() / 2.0D;
        double headY = feetY + entity.getHeight();
        // Центр хода — середина тела; амплитуда симметрична (и вверх, и вниз).
        double midY = (feetY + headY) * 0.5D;
        double offset = (wave - 0.5D) * entity.getHeight() * travelFrac;
        // Крайние точки за пределы тела не пускаем: совсем у пола и совсем у
        // макушки кольцо уходило бы в пол/в голову и пропадало из виду.
        double targetY = MathHelper.clamp((float) (midY + offset),
                (float) (feetY + 0.06D), (float) (headY - 0.06D));

        // Горизонталь — вялое экспоненциальное сглаживание (кольцо мягко
        // отстаёт от резких движений цели, но догоняет её), вертикаль быстрее.
        double prevY = circleY;
        double kx = 1.0D - Math.exp(-CIRCLE_FOLLOW * dt);
        double ky = 1.0D - Math.exp(-CIRCLE_FOLLOW_Y * dt);
        circleX += (effectCenter.x - circleX) * kx;
        circleZ += (effectCenter.z - circleZ) * kx;
        circleY += (targetY - circleY) * ky;

        // Сглаженная вертикальная скорость — по ней диск слегка «растягивается»
        // по ходу движения (быстрее летит — заметнее вытянут).
        if (dt > 1.0E-5F) {
            float inst = (float) ((circleY - prevY) / dt);
            circleVy += (inst - circleVy) * Math.min(1.0F, dt * 12.0F);
        }

        // След: точки ставятся ТОЛЬКО когда круг реально двигается. В крайних
        // точках хода скорость ≈ 0, новых точек не появляется — след не
        // «пылит» на месте и тянется только за движением. Порог внизу отсекает
        // микродрейф сглаживания по горизонтали.
        if (Math.abs(circleVy) > CIRCLE_TRAIL_MIN_SPEED) {
            boolean empty = circleTrailCount == 0;
            double lx = empty ? circleX : circleTrailX[lastIndex()];
            double ly = empty ? circleY : circleTrailY[lastIndex()];
            double lz = empty ? circleZ : circleTrailZ[lastIndex()];
            double sx = circleX - lx;
            double sy = circleY - ly;
            double sz = circleZ - lz;
            circleTrailAccum += Math.sqrt(sx * sx + sy * sy + sz * sz);
            while (circleTrailAccum >= CIRCLE_TRAIL_STEP) {
                circleTrailAccum -= CIRCLE_TRAIL_STEP;
                pushCircleTrail(circleX, circleY, circleZ);
            }
        } else {
            // Стоит на месте — остаток пути сбрасываем, чтобы при начале
            // движения первая точка следа встала сразу, а не через остаток.
            circleTrailAccum = 0.0D;
        }
        for (int i = 0; i < circleTrailCount; i++) {
            circleTrailAge[indexOf(i)] += dt;
        }
    }

    /** Индекс в кольцевом буфере для i-й точки от самой старой к самой новой. */
    private static int indexOf(int i) {
        return (circleTrailHead + i) % CIRCLE_TRAIL_MAX;
    }

    /** Индекс самой новой точки следа. */
    private static int lastIndex() {
        return (circleTrailHead + circleTrailCount - 1) % CIRCLE_TRAIL_MAX;
    }

    /** Добавляет точку в след (кольцевой буфер, перезаписывает самую старую). */
    private static void pushCircleTrail(double x, double y, double z) {
        if (circleTrailCount == CIRCLE_TRAIL_MAX) {
            // Полный буфер — сдвигаем начало, самая старая точка выпадает.
            circleTrailHead = (circleTrailHead + 1) % CIRCLE_TRAIL_MAX;
        } else {
            circleTrailCount++;
        }
        int idx = lastIndex();
        circleTrailX[idx] = x;
        circleTrailY[idx] = y;
        circleTrailZ[idx] = z;
        circleTrailAge[idx] = 0.0F;
    }

    /**
     * Режим "Круг": вокруг цели появляется тонкое светящееся КОЛЬЦО (как на
     * референсе, без заливки и без ореола) и ходит вверх-вниз по сглаженной
     * волне, оставляя за собой хвост из уменьшающихся колец.
     *
     * <p>Геометрия строится вручную, без единой текстуры: кольцо собрано из
     * узких радиальных полос у самого края ({@link #RING_BANDS}), яркость
     * растёт к краю ({@link #RING_BAND_WEIGHT}) — внутри пусто, горит только
     * обод. След рисуется теми же кольцами, но меньшего радиуса и с падающей
     * альфой, поэтому читается как цепочка, а не как пятно.
     *
     * <p>Рендер идёт в мировом проходе через {@link #RING_LAYER}:
     * POSITION_COLOR с АДДИТИВНЫМ блендингом, поэтому перекрывающиеся кольца
     * следа складываются по яркости, а depth-test сохраняет корректное
     * перекрытие сущностью и блоками.
     */
    private void renderCircleWorld(WorldRenderContext context) {
        if (!circleStarted || circleAppear <= 0.001F) {
            return;
        }
        int theme = Colors.clientColor();
        int r0 = (theme >> 16) & 0xFF;
        int g0 = (theme >> 8) & 0xFF;
        int b0 = theme & 0xFF;

        float radius = circleRadius.getValue();
        float trailAmount = MathHelper.clamp(circleTrailAmount.getValue(), 0.0F, 2.0F);
        float appear = circleAppear;
        float glow = circleGlow.getValue();

        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camera = context.camera().getPos();

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer buffer = consumers.getBuffer(RING_LAYER);
        var matrix = matrices.peek().getPositionMatrix();

        // Наклон диска: слегка наклонён, как на референсе, плюс мягкое
        // покачивание — диск не выглядит абсолютно плоской запятой.
        float tilt = (float) Math.toRadians(12.0D)
                + 5.0F * (float) Math.toRadians(Math.sin(circlePhase));

        // --- след: цепочка уменьшающихся колец там, где круг уже прошёл ------
        // Точки ставятся ТОЛЬКО в движении (см. updateCircleAnimation), поэтому
        // это именно хвост за летящим кольцом: каждая точка — отдельное
        // колечко, радиус и яркость падают к хвосту. Кольца нарисованы тонким
        // ободом (без заливки), поэтому цепочка читается, а не сливается в пятно.
        if (trailAmount > 0.01F) {
            for (int i = 0; i < circleTrailCount; i++) {
                int idx = indexOf(i);
                float life = circleTrailAge[idx] / (CIRCLE_TRAIL_LIFE * trailAmount);
                if (life >= 1.0F) {
                    continue;
                }
                float a = 1.0F - life;
                // Насыщенный спад: у круга хвост ещё яркий, к концу гаснет.
                int alpha = MathHelper.clamp((int) (fade * (float) Math.pow(a, 1.15D)
                        * 215.0F * glow), 0, 255);
                if (alpha <= 6) {
                    continue;
                }
                // След — кольцо, которое уходит НА СЕБЯ по хвосту: чем старше
                // точка, тем шире кольцо. Благодаря этому след вылезает из
                // силуэта живого кольца наружу (иначе он полностью прятался
                // внутри него и не читался) — плюс он виден в зазор между
                // ногами и вокруг корпуса модели.
                float r = radius * (1.0F + 0.45F * life);
                float tiltTrail = (float) Math.toRadians(14.0D) - 5.0F * life;
                glowDisc(buffer, matrix, circleTrailX[idx], circleTrailY[idx], circleTrailZ[idx],
                        r, tiltTrail, r0, g0, b0, alpha, 0.9F);
            }
        }

        // --- сам диск ---------------------------------------------------------
        // Появление: диск раздувается от центра и проявляется по альфе.
        float grow = 0.6F + 0.4F * appear;
        float r = radius * grow * (1.0F + 0.05F * (float) Math.sin(circlePhase * 2.0F));
        int alpha = MathHelper.clamp((int) (fade * appear * 255.0F * glow), 0, 255);
        if (alpha > 4) {
            glowDisc(buffer, matrix, circleX, circleY, circleZ, r, tilt,
                    r0, g0, b0, alpha, 1.0F);
        }

        consumers.draw(RING_LAYER);
        matrices.pop();
    }

    /**
     * Плоский светящийся диск, построенный вручную, без единой текстуры.
     *
     * <p>Диск собран из концентрических полос {@link #RING_BANDS}: каждая полоса
     * — кольцо треугольников с постоянным весом цвета {@link #RING_BAND_WEIGHT}.
     * Вес растёт к краю, поэтому центр еле светится, а обод горит — как
     * светящееся кольцо на референсе. Снаружи рисуется мягкий ореол
     * ({@link #RING_HALO}) — имитация bloom.
     *
     * <p>Слой аддитивный ({@link #RING_LAYER}), поэтому вклад цвета равен
     * {@code color * alpha} и перекрывающиеся следы складываются по яркости.
     *
     * @param brightness множитель общей яркости (1 — живой диск, меньше — след)
     */
    private static void glowDisc(VertexConsumer buffer, org.joml.Matrix4f matrix,
                                 double cx, double cy, double cz,
                                 double radius, double tiltRad,
                                 int r, int g, int b, int a, float brightness) {
        if (radius <= 1.0E-3D) {
            return;
        }
        // Базис плоскости диска: наклон вокруг мировой оси X. Нормаль (0, cos, sin).
        double ct = Math.cos(tiltRad);
        double st = Math.sin(tiltRad);
        double nx = 0.0D;
        double ny = ct;
        double nz = st;
        // Векторы в плоскости: "вперёд по земле", ортогонализованный к нормали,
        // и второй = normal x first.
        double oux = 0.0D;
        double ouy = 0.0D;
        double ouz = 1.0D - nz * nz;
        double ol = Math.sqrt(oux * oux + ouy * ouy + ouz * ouz);
        if (ol < 1.0E-6D) {
            oux = 1.0D;
            ouy = 0.0D;
            ouz = 0.0D;
            ol = 1.0D;
        }
        oux /= ol;
        ouy /= ol;
        ouz /= ol;
        double ovx = ny * ouz - nz * ouy;
        double ovy = nz * oux - nx * ouz;
        double ovz = nx * ouy - ny * oux;

        int seg = RING_SEG_U;
        int bands = RING_BANDS.length;

        // Полосы диска от центра к краю: яркость растёт к ободу. Без ореола
        // вокруг — диск заканчивается ровно своим радиусом.
        for (int k = 0; k + 1 < bands; k++) {
            double inner = RING_BANDS[k] * radius;
            double outer = RING_BANDS[k + 1] * radius;
            double weight = (RING_BAND_WEIGHT[k] + RING_BAND_WEIGHT[k + 1]) * 0.5D;
            emitBand(buffer, matrix, cx, cy, cz, oux, ouy, ouz, ovx, ovy, ovz,
                    inner, outer, seg, r, g, b,
                    MathHelper.clamp((int) (a * weight * brightness), 0, 255));
        }
    }

    /**
     * Одна радиальная полоса диска: кольцо треугольников между радиусами
     * {@code inner} и {@code outer} в плоскости, заданной ортонормированным
     * базисом (u, v) и центром (cx, cy, cz).
     */
    private static void emitBand(VertexConsumer buffer, org.joml.Matrix4f matrix,
                                 double cx, double cy, double cz,
                                 double ux, double uy, double uz,
                                 double vx, double vy, double vz,
                                 double inner, double outer, int seg,
                                 int r, int g, int b, int a) {
        if (a <= 2 || outer <= 0.0D) {
            return;
        }
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2.0D * i / seg;
            double a1 = Math.PI * 2.0D * (i + 1) / seg;
            double c0 = Math.cos(a0);
            double s0 = Math.sin(a0);
            double c1 = Math.cos(a1);
            double s1 = Math.sin(a1);
            // Направления на два конца сегмента в базисе плоскости.
            double d0x = c0 * ux + s0 * vx;
            double d0y = c0 * uy + s0 * vy;
            double d0z = c0 * uz + s0 * vz;
            double d1x = c1 * ux + s1 * vx;
            double d1y = c1 * uy + s1 * vy;
            double d1z = c1 * uz + s1 * vz;

            // Два треугольника на квад (слой TRIANGLES, culling выключен —
            // диск виден и снизу).
            buffer.vertex(matrix, (float) (cx + d0x * inner), (float) (cy + d0y * inner),
                    (float) (cz + d0z * inner)).color(r, g, b, a);
            buffer.vertex(matrix, (float) (cx + d0x * outer), (float) (cy + d0y * outer),
                    (float) (cz + d0z * outer)).color(r, g, b, a);
            buffer.vertex(matrix, (float) (cx + d1x * outer), (float) (cy + d1y * outer),
                    (float) (cz + d1z * outer)).color(r, g, b, a);

            buffer.vertex(matrix, (float) (cx + d0x * inner), (float) (cy + d0y * inner),
                    (float) (cz + d0z * inner)).color(r, g, b, a);
            buffer.vertex(matrix, (float) (cx + d1x * outer), (float) (cy + d1y * outer),
                    (float) (cz + d1z * outer)).color(r, g, b, a);
            buffer.vertex(matrix, (float) (cx + d1x * inner), (float) (cy + d1y * inner),
                    (float) (cz + d1z * inner)).color(r, g, b, a);
        }
    }

    /**
     * Режим "Кристаллы": 15 объёмных кристаллов-октаэдров цвета темы стоят
     * ровным кольцом вокруг цели и крутятся вокруг неё с одинаковой скоростью
     * (см. {@link #crystalSlotPos}). Точки уже анимированы (crystalPos): кольцо
     * появляется разлётом, подлетает и перелетает к новой цели по одному
     * кристаллу. Все кристаллы одинакового размера и одинаково ориентированы
     * остриём от цели, поэтому стая выглядит ровной. Тело настоящее
     * трёхмерное (октаэдр + светлое ядро-блик), поэтому кристалл читается
     * объёмным под любым углом, а не как плоский треугольник. Грани затеняются
     * по своей нормали — объём виден без единой текстуры.
     */
    private void renderCrystalsWorld(WorldRenderContext context) {
        if (effectCenter == null) {
            return;
        }
        float sizeMul = this.crystalSize.getValue();

        int theme = Colors.clientColor();
        int r0 = (theme >> 16) & 0xFF;
        int g0 = (theme >> 8) & 0xFF;
        int b0 = theme & 0xFF;

        MinecraftClient client = MinecraftClient.getInstance();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camera = context.camera().getPos();

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();
        // Тот же proven-слой, что у ChinaHat/KillEffect/JumpCircle: debug_quads
        // (POSITION_COLOR) без отсечения задних граней. Со слоем от
        // RenderLayer.of() геометрия здесь не выводилась, поэтому берём ванильный.
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getDebugQuads());
        var matrix = matrices.peek().getPositionMatrix();

        // Точки кристаллов уже анимированы (crystalPos): стая появляется
        // разлётом, подлетает на свои орбиты и перелетает к новой цели
        // по одному кристаллу.
        for (int i = 0; i < CRYSTAL_COUNT; i++) {
            Vec3d pos = crystalPos[i];
            float appear = crystalAppear[i];
            if (pos == null || appear <= 0.001F) {
                continue;
            }
            int alpha = MathHelper.clamp((int) (fade * appear * 255.0F), 0, 255);
            if (alpha <= 4) {
                continue;
            }

            // Ось кристалла: остриём от цели и чуть вверх. Одинаковая для всех
            // (только направление "наружу" своё у каждой позиции) — без разброса,
            // стая выглядит ровной, а не разнородной.
            Vec3d radial = pos.subtract(effectCenter);
            if (radial.lengthSquared() < 1.0E-6D) {
                continue;
            }
            radial = radial.normalize();
            double upMix = 0.55D;
            Vec3d axis = radial.multiply(1.0D - upMix)
                    .add(new Vec3d(0.0D, upMix, 0.0D)).normalize();

            // Размер одинаковый у всех кристаллов (только растёт при появлении).
            float size = 0.16F * sizeMul * (0.35F + 0.65F * appear);
            // Свет: сверху и со стороны камеры — классическая схема, при
            // которой грани кристалла различаются по яркости и виден объём.
            Vec3d toCam = pos.subtract(camera);
            if (toCam.lengthSquared() < 1.0E-6D) {
                continue;
            }
            Vec3d light = toCam.normalize().add(0.0D, 0.85D, 0.0D).normalize();

            // Собственное вращение — общее для всей стаи, грани переливаются
            // одинаково, кристалл не выглядит "наклеенным".
            crystalShard(buffer, matrix, pos, axis, size,
                    (float) Math.toRadians(crystalRollDeg), r0, g0, b0, alpha, light);
        }

        consumers.draw(RenderLayer.getDebugQuads());
        matrices.pop();
    }

    /**
     * Объёмный кристалл-октаэдр по референсу: вытянутый ромб из двух пирамид,
     * стыкующихся основанием (верхняя выше нижней — кристалл «вытянут вверх»,
     * как аметист на скрине). Внутри — светлое ядро поменьше: на референсе у
     * кристаллов есть белый внутренний блик, «светящаяся сердцевина».
     *
     * <p>Ось {@code axis} — длинная ось кристалла; тело строится в
     * ортонормированном базисе вокруг неё и поворачивается на {@code rollRad}.
     * Рисуются 4 грани верхней пирамиды + 4 грани нижней; culling в
     * debug_quads выключен, поэтому объём виден с обеих сторон, а плоский
     * шейдинг по нормали даёт читаемый объём без единой текстуры.
     */
    private static void crystalShard(VertexConsumer buffer, org.joml.Matrix4f matrix,
                                     Vec3d pos, Vec3d axis, float size, float rollRad,
                                     int r, int g, int b, int a, Vec3d light) {
        // Ортонормированный базис вокруг оси. Опору берём от мирового "вверх"
        // (иначе "вбок"), чтобы кристалл не вырождался в прямую, когда взгляд
        // почти совпадает с его осью.
        Vec3d u = new Vec3d(0.0D, 1.0D, 0.0D).crossProduct(axis);
        if (u.lengthSquared() < 1.0E-4D) {
            u = new Vec3d(1.0D, 0.0D, 0.0D).crossProduct(axis);
        }
        u = u.normalize();
        Vec3d v = axis.crossProduct(u).normalize();

        // Доворот основания вокруг оси — переливание граней при вращении.
        double cr = Math.cos(rollRad);
        double sr = Math.sin(rollRad);
        Vec3d uu = new Vec3d(u.x * cr + v.x * sr, u.y * cr + v.y * sr, u.z * cr + v.z * sr);
        Vec3d vv = new Vec3d(u.x * sr - v.x * cr, u.y * sr - v.y * cr, u.z * sr - v.z * cr);

        // Две вершины вдоль оси: верхняя дальше нижней (вытянутый кристалл).
        double topH = size * CRYSTAL_TOP_H;
        double botH = size * CRYSTAL_BOTTOM_H;
        Vec3d top = pos.add(axis.x * topH, axis.y * topH, axis.z * topH);
        Vec3d bottom = pos.add(-axis.x * botH, -axis.y * botH, -axis.z * botH);

        // Экватор — ромб из 4 точек в плоскости, перпендикулярной оси. Четыре
        // вершины дают «кристаллическое» сечение с острым силуэтом, как на
        // референсе (сдвиг 45° — ромб стоит углами к граням).
        Vec3d[] eq = new Vec3d[4];
        for (int k = 0; k < 4; k++) {
            double ang = k * (Math.PI * 0.5D) + Math.PI * 0.25D;
            double c = Math.cos(ang) * size;
            double s = Math.sin(ang) * size;
            eq[k] = new Vec3d(
                    pos.x + uu.x * c + vv.x * s,
                    pos.y + uu.y * c + vv.y * s,
                    pos.z + uu.z * c + vv.z * s);
        }

        // Верхняя пирамида: вершина + ребро экватора.
        for (int k = 0; k < 4; k++) {
            Vec3d p0 = eq[k];
            Vec3d p1 = eq[(k + 1) % 4];
            double shade = faceShade(top, p0, p1, light);
            tri(buffer, matrix,
                    top.x, top.y, top.z,
                    p0.x, p0.y, p0.z,
                    p1.x, p1.y, p1.z,
                    scale(r, shade), scale(g, shade), scale(b, shade), a);
        }
        // Нижняя пирамида — обратный обход, чтобы нижние грани не накладывались
        // на верхние по winding (culling выключен, но это важно для блендинга).
        for (int k = 0; k < 4; k++) {
            Vec3d p0 = eq[k];
            Vec3d p1 = eq[(k + 1) % 4];
            double shade = faceShade(bottom, p0, p1, light);
            tri(buffer, matrix,
                    bottom.x, bottom.y, bottom.z,
                    p1.x, p1.y, p1.z,
                    p0.x, p0.y, p0.z,
                    scale(r, shade), scale(g, shade), scale(b, shade), a);
        }

        drawCrystalCore(buffer, matrix, pos, top, bottom, eq, light, r, g, b, a);
    }

    /**
     * Светлое внутреннее ядро кристалла — «светящаяся сердцевина», как на
     * референсе. Это тот же октаэдр, ужатый к центру тела и сдвинутый к камере,
     * поэтому он читается как внутренний блик сквозь полупрозрачные грани, а
     * не как вторая накладка. Рисуется с меньшей альфой и осветлённым цветом.
     */
    private static void drawCrystalCore(VertexConsumer buffer, org.joml.Matrix4f matrix,
                                        Vec3d pos, Vec3d top, Vec3d bottom, Vec3d[] eq,
                                        Vec3d light, int r, int g, int b, int a) {
        Vec3d lightCore = toward(pos, top, bottom, eq, 0.6D);
        Vec3d ct = shrink(top, pos, CRYSTAL_CORE_SCALE, lightCore);
        Vec3d cb = shrink(bottom, pos, CRYSTAL_CORE_SCALE, lightCore);
        Vec3d[] ce = new Vec3d[eq.length];
        for (int k = 0; k < eq.length; k++) {
            ce[k] = shrink(eq[k], pos, CRYSTAL_CORE_SCALE, lightCore);
        }

        // Ядро светлее и чуть прозрачнее — читается как блик внутри тела.
        int cr = lighten(r, 0.45D);
        int cg = lighten(g, 0.45D);
        int cblue = lighten(b, 0.45D);
        int coreAlpha = MathHelper.clamp((int) (a * 0.55F), 0, 255);
        if (coreAlpha <= 2) {
            return;
        }
        for (int k = 0; k < ce.length; k++) {
            Vec3d p0 = ce[k];
            Vec3d p1 = ce[(k + 1) % ce.length];
            double shade = faceShade(ct, p0, p1, light);
            tri(buffer, matrix,
                    ct.x, ct.y, ct.z,
                    p0.x, p0.y, p0.z,
                    p1.x, p1.y, p1.z,
                    scale(cr, shade), scale(cg, shade), scale(cblue, shade), coreAlpha);
        }
        for (int k = 0; k < ce.length; k++) {
            Vec3d p0 = ce[k];
            Vec3d p1 = ce[(k + 1) % ce.length];
            double shade = faceShade(cb, p0, p1, light);
            tri(buffer, matrix,
                    cb.x, cb.y, cb.z,
                    p1.x, p1.y, p1.z,
                    p0.x, p0.y, p0.z,
                    scale(cr, shade), scale(cg, shade), scale(cblue, shade), coreAlpha);
        }
    }

    /**
     * Подтягивает точку октаэдра к центру {@code pos} в {@code factor} раз и
     * слегка смещает к {@code toward} — так ядро оказывается внутри тела, но
     * не тонет в гранях.
     */
    private static Vec3d shrink(Vec3d point, Vec3d pos, double factor, Vec3d toward) {
        return new Vec3d(
                pos.x + (point.x - pos.x) * factor + toward.x * 0.002D,
                pos.y + (point.y - pos.y) * factor + toward.y * 0.002D,
                pos.z + (point.z - pos.z) * factor + toward.z * 0.002D);
    }

    /** Направление "наружу" кристалла — усреднение его вершин. */
    private static Vec3d toward(Vec3d pos, Vec3d top, Vec3d bottom, Vec3d[] eq, double scale) {
        Vec3d sum = new Vec3d(0.0D, 0.0D, 0.0D);
        sum = sum.add(top.subtract(pos).multiply(scale));
        sum = sum.add(bottom.subtract(pos).multiply(scale));
        for (Vec3d p : eq) {
            sum = sum.add(p.subtract(pos).multiply(scale));
        }
        return sum.lengthSquared() < 1.0E-8D ? new Vec3d(0.0D, 1.0D, 0.0D) : sum.normalize();
    }

    /** Осветляет канал цвета toward белого — для бликов кристалла. */
    private static int lighten(int channel, double amount) {
        return MathHelper.clamp((int) (channel + (255 - channel) * amount), 0, 255);
    }

    /**
     * Плоский шейдинг грани: яркость по углу между нормалью и вектором света.
     * Берём |dot|, потому что culling выключен и видны обе стороны — задние
     * грани освещены так же, но не путаются с передними.
     */
    private static double faceShade(Vec3d p0, Vec3d p1, Vec3d p2, Vec3d light) {
        Vec3d n = p1.subtract(p0).crossProduct(p2.subtract(p0));
        double len = n.length();
        if (len < 1.0E-6D) {
            return CRYSTAL_FACE_MIN;
        }
        double d = Math.abs(n.dotProduct(light) / len);
        return CRYSTAL_FACE_MIN + (1.0D - CRYSTAL_FACE_MIN) * d;
    }

    private static int scale(int channel, double shade) {
        return MathHelper.clamp((int) (channel * shade), 0, 255);
    }

    /**
     * Один треугольник для debug_quads: слой рисует QUADS, поэтому третья
     * вершина дублируется (вырожденный четырехугольник = треугольник) — так
     * же, как конус в ChinaHat. Culling выключен, грань видна с обеих сторон.
     */
    private static void tri(VertexConsumer buffer, org.joml.Matrix4f matrix,
                            double ax, double ay, double az,
                            double bx, double by, double bz,
                            double cx, double cy, double cz,
                            int r, int g, int b, int a) {
        buffer.vertex(matrix, (float) ax, (float) ay, (float) az).color(r, g, b, a);
        buffer.vertex(matrix, (float) bx, (float) by, (float) bz).color(r, g, b, a);
        buffer.vertex(matrix, (float) cx, (float) cy, (float) cz).color(r, g, b, a);
        buffer.vertex(matrix, (float) cx, (float) cy, (float) cz).color(r, g, b, a);
    }

    /**
     * Computes the marker's screen position and size analytically from the
     * camera position/rotation. Вертикальный FOV берётся из РЕАЛЬНОЙ
     * проекционной матрицы кадра, поэтому учтён модификатор FOV от спринта,
     * эффектов скорости, зума и т.п. — маркер больше не "убегает" с цели.
     */
    private void updateMarkerProjection(MinecraftClient client, WorldRenderContext context, Vec3d center) {
        markerVisible = false;

        float[] proj = new float[3];
        if (!projectPoint(client, context, center, proj)) {
            return;
        }

        float pxPerUnit = proj[2];
        float sidePx = MathHelper.clamp(this.markerSize.getValue() * 0.9F * pxPerUnit, 6.0F, 1500.0F);

        markerScreenX = proj[0];
        markerScreenY = proj[1];
        markerScreenSize = sidePx;
        markerVisible = true;
    }

    /**
     * Проекция мировой точки в scaled-пиксели (математика TargetESP:
     * базис камеры + реальный FOV кадра из проекционной матрицы).
     * out = {screenX, screenY, pxPerUnit}. false = за камерой/за экраном.
     */
    private static boolean projectPoint(MinecraftClient client, WorldRenderContext context,
                                        Vec3d point, float[] out) {
        Vec3d d = point.subtract(context.camera().getPos());
        float yawRad = (float) Math.toRadians(context.camera().getYaw());
        float pitchRad = (float) Math.toRadians(context.camera().getPitch());
        float cosP = MathHelper.cos(pitchRad);

        // Camera basis: look (forward), right, up.
        float lX = -MathHelper.sin(yawRad) * cosP;
        float lY = -MathHelper.sin(pitchRad);
        float lZ = MathHelper.cos(yawRad) * cosP;
        float rX = -MathHelper.cos(yawRad);
        float rZ = -MathHelper.sin(yawRad);
        float uX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uY = MathHelper.cos(pitchRad);
        float uZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        float depth = (float) d.x * lX + (float) d.y * lY + (float) d.z * lZ;
        if (depth < 0.2F) {
            return false; // behind the camera or too close
        }
        float xOff = (float) d.x * rX + (float) d.z * rZ;
        float yOff = (float) d.x * uX + (float) d.y * uY + (float) d.z * uZ;

        // Реальный FOV кадра из проекционной матрицы (m11 = 1/tan(fovY/2)).
        float tanHalf = 1.0F / context.projectionMatrix().m11();

        int scaledW = client.getWindow().getScaledWidth();
        int scaledH = client.getWindow().getScaledHeight();
        float aspect = scaledW / (float) scaledH;

        float ndcX = (xOff / depth) / (tanHalf * aspect);
        float ndcY = (yOff / depth) / tanHalf;
        if (MathHelper.abs(ndcX) > 1.4F || MathHelper.abs(ndcY) > 1.4F) {
            return false; // fully off screen
        }

        float pxPerUnit = scaledH / (2.0F * tanHalf * depth);

        out[0] = (ndcX * 0.5F + 0.5F) * scaledW;
        out[1] = (0.5F - ndcY * 0.5F) * scaledH;
        out[2] = pxPerUnit;
        return true;
    }

    /**
     * Draws the projected marker as a HUD overlay: on top of the entity and
     * the world, spinning in the screen plane. Цвет — из активной темы.
     */
    private static void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        TargetESP module = active;
        if (module == null || !module.isEnabled() || !markerVisible || fade <= 0.02F) {
            return;
        }

        int side = Math.max(4, (int) markerScreenSize);
        int half = side / 2;
        float angle = (float) (((System.currentTimeMillis() % 36000000L) / 1000.0D)
                * module.markerSpeed.getValue() % 360.0D);

        // FIX: подхватываем тему — цвет берётся из Colors.clientColor().
        // Хорошо работает, если marker1.png белая/серая (умножение цвета).
        int color = Colors.clientColor();
        int tint = (((int) (fade * 255.0F) & 0xFF) << 24) | (color & 0x00FFFFFF);

        var matrices = context.getMatrices();
        matrices.push();
        matrices.translate(markerScreenX, markerScreenY, 0.0F);
        matrices.multiply(new Quaternionf().rotationZ((float) Math.toRadians(angle)));
        // textureWidth/Height == side: sample the FULL texture scaled to side x side.
        context.drawTexture(RenderLayer::getGuiTextured, MARKER_TEXTURE, -half, -half,
                0.0F, 0.0F, side, side, side, side, tint);
        matrices.pop();
    }
}
