package com.skrvisuals.modules.settings;

public class SliderSetting extends Setting {
    private final float min;
    private final float max;
    private float value;

    public SliderSetting(String name, String description, float min, float max, float defaultValue) {
        super(name, description);
        this.min = min;
        this.max = max;
        this.value = defaultValue;
    }

    public float getMin() {
        return this.min;
    }

    public float getMax() {
        return this.max;
    }

    public float getValue() {
        return this.value;
    }

    public void setValue(float value) {
        this.value = Math.max(min, Math.min(max, value));
    }

    public float getProgress() {
        if (Float.compare(min, max) == 0) {
            return 0f;
        }
        return (this.value - this.min) / (this.max - this.min);
    }
}