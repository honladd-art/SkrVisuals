package com.skrvisuals.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** UI sounds of the mod. */
public final class ModuleSounds {
    public static final SoundEvent GUI_OPEN   = SoundEvent.of(Identifier.of("skrvisuals", "gui.clickgui"));
    public static final SoundEvent MODULE_ON  = SoundEvent.of(Identifier.of("skrvisuals", "gui.module_enable"));
    public static final SoundEvent MODULE_OFF = SoundEvent.of(Identifier.of("skrvisuals", "gui.module_disable"));

    private ModuleSounds() {
    }

    public static void play(SoundEvent sound) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(sound, 1.0f));
    }
}
