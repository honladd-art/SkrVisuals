package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * HitDamage: показывает, сколько урона ты нанёс сущности.
 *
 * Режимы отображения (на 1 секунду):
 *  - «Мир» — цифра урона над сущностью, спроецированная в экранные координаты;
 *  - «ActionBar» — цифра по центру над хотбаром.
 *
 * Механика: при ударе запоминаем цель и её текущее здоровье; на тиках
 * сравниваем — если здоровье упало, разница и есть нанесённый урон.
 */
public class HitDamage extends Module {
    /** Сколько времени виден урон (мс). */
    private static final long DISPLAY_MS = 1000L;

    private static HitDamage active;
    private static boolean hooksRegistered = false;

    private final ModeSetting mode = new ModeSetting(
            "Режим",
            "Где отображать нанесённый урон.",
            List.of("Мир", "ActionBar"),
            "Мир"
    );

    /** Цель удара и её здоровье на момент удара. */
    private Entity lastTarget;
    private float lastHealth = -1f;

    /** Текущий показ урона. */
    private float damage;
    private Entity damageTarget;
    private long shownAt;

    /** Экранная позиция цели для режима «Мир» (обновляется каждый кадр). */
    private float screenX;
    private float screenY;
    private boolean projected;

    public HitDamage() {
        super(ModuleCategory.VISUALS, "HitDamage", "Показывает, сколько урона ты нанёс сущности.");
        setting(mode);
        active = this;
        registerHooks();
    }

    private static void registerHooks() {
        if (hooksRegistered) {
            return;
        }
        hooksRegistered = true;

        // Запоминаем цель и её здоровье при каждом ударе (только клиент).
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            HitDamage module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
            if (!(world instanceof ClientWorld)) {
                return ActionResult.PASS;
            }
            if (entity instanceof FakePlayerEntity) {
                return ActionResult.PASS;
            }
            module.lastTarget = entity;
            module.lastHealth = entity instanceof LivingEntity living ? living.getHealth() : -1f;
            return ActionResult.PASS;
        });

        // Проекция цели в экранные координаты для режима «Мир».
        WorldRenderEvents.AFTER_ENTITIES.register(HitDamage::updateProjection);
        HudRenderCallback.EVENT.register(HitDamage::onHudRender);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (!isEnabled()) {
            lastTarget = null;
            lastHealth = -1f;
            return;
        }
        Entity target = lastTarget;
        if (target == null || lastHealth < 0f) {
            return;
        }
        if (client.world == null || target.getWorld() != client.world
                || !(target instanceof LivingEntity living)) {
            lastTarget = null;
            lastHealth = -1f;
            return;
        }
        float health = living.getHealth();
        if (health < lastHealth) {
            damage = lastHealth - health;
            damageTarget = target;
            shownAt = System.currentTimeMillis();
        }
        lastHealth = health;
    }

    /** Проекция центра цели на экран (аналитически, как в TargetESP). */
    private static void updateProjection(WorldRenderContext context) {
        HitDamage module = active;
        if (module == null || !module.isEnabled()
                || !module.mode.getValue().equals("Мир")) {
            return;
        }
        module.projected = false;
        Entity target = module.damageTarget;
        if (target == null || target.getWorld() != context.world()) {
            return;
        }
        long age = System.currentTimeMillis() - module.shownAt;
        if (age > DISPLAY_MS) {
            return;
        }
        Vec3d center = target.getPos().add(0, target.getHeight() / 2f + 0.4f, 0);
        float[] out = new float[3];
        if (projectPoint(context, center, out)) {
            module.screenX = out[0];
            module.screenY = out[1];
            module.projected = true;
        }
    }

    /**
     * out = {screenX, screenY, pxPerUnit}. false = точка за камерой.
     * Базис камеры + FOV из проекционной матрицы (как в TargetESP).
     */
    private static boolean projectPoint(WorldRenderContext context, Vec3d point, float[] out) {
        Vec3d d = point.subtract(context.camera().getPos());
        float yawRad = (float) Math.toRadians(context.camera().getYaw());
        float pitchRad = (float) Math.toRadians(context.camera().getPitch());
        float cosP = MathHelper.cos(pitchRad);

        float lX = -MathHelper.sin(yawRad) * cosP;
        float lY = -MathHelper.sin(pitchRad);
        float lZ = MathHelper.cos(yawRad) * cosP;
        float rX = -MathHelper.cos(yawRad);
        float rZ = -MathHelper.sin(yawRad);
        float uX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uY = MathHelper.cos(pitchRad);
        float uZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        float depth = (float) d.x * lX + (float) d.y * lY + (float) d.z * lZ;
        if (depth < 0.2F) {
            return false;
        }
        float xOff = (float) d.x * rX + (float) d.z * rZ;
        float yOff = (float) d.x * uX + (float) d.y * uY + (float) d.z * uZ;

        float tanHalf = 1.0F / context.projectionMatrix().m11();

        MinecraftClient client = MinecraftClient.getInstance();
        int scaledW = client.getWindow().getScaledWidth();
        int scaledH = client.getWindow().getScaledHeight();
        float aspect = scaledW / (float) scaledH;

        float ndcX = (xOff / depth) / (tanHalf * aspect);
        float ndcY = (yOff / depth) / tanHalf;
        if (MathHelper.abs(ndcX) > 1.4F || MathHelper.abs(ndcY) > 1.4F) {
            return false;
        }

        out[0] = (ndcX * 0.5F + 0.5F) * scaledW;
        out[1] = (0.5F - ndcY * 0.5F) * scaledH;
        out[2] = scaledH / (2.0F * tanHalf * depth);
        return true;
    }

    private static void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        HitDamage module = active;
        if (module == null || !module.isEnabled() || module.damageTarget == null) {
            return;
        }
        long age = System.currentTimeMillis() - module.shownAt;
        if (age > DISPLAY_MS) {
            return;
        }
        float alpha = 1f - age / (float) DISPLAY_MS;
        alpha = MathHelper.clamp(alpha, 0f, 1f);
        if (alpha <= 0.02f) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        String text = String.format("%.1f", module.damage);
        var font = Fonts.get();
        int color = RenderUtil.withAlpha(Colors.clientColor(), alpha);

        if (module.mode.getValue().equals("ActionBar")) {
            // По центру над хотбаром.
            float w = client.getWindow().getScaledWidth();
            float h = client.getWindow().getScaledHeight();
            RenderUtil.drawString(context, font, text,
                    w / 2f - font.getWidth(text) / 2f, h - 59f, color);
        } else {
            // Над сущностью в мире.
            if (!module.projected) {
                return;
            }
            RenderUtil.drawString(context, font, text,
                    module.screenX - font.getWidth(text) / 2f, module.screenY, color);
        }
    }
}
