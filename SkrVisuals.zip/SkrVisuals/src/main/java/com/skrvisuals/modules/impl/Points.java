package com.skrvisuals.modules.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.config.ConfigManager;

import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringJoiner;

/**
 * Points: метки (waypoints) в мире.
 *
 * Управление — чат-команды с префиксом точки (не уходят на сервер):
 *   .gps here <имя>            — метка на твоих координатах
 *   .gps add <x> <y> <z> <имя> — метка на заданных координатах
 *   .gps remove <имя>          — удалить метку
 *   .gps list                  — список меток
 *   .gps clear                 — удалить все метки
 *   .gps                       — помощь
 *
 * Сообщения в чате в стиле мода: префикс "SkrVisuals" красится
 * в акцент текущей темы клиента.
 *
 * Рендер — HUD-проход в стиле мода: вертикальный луч-«маячок»,
 * пульсирующий ромб цвета темы и плашка с именем, дистанцией
 * («N блоков») и координатами. Плашки плавно тают с дистанцией.
 * Метки хранятся в конфиге (раздел "points").
 */
public class Points extends Module {

    private static Points active;
    private static boolean hookRegistered = false;

    /** tan(FOV/2) реального кадра — обновляется каждый кадр. */
    private static volatile float tanHalf = 1.0F;

    private static final List<Waypoint> waypoints = new ArrayList<>();

    public static final class Waypoint {
        public final String name;
        public final int x, y, z;

        public Waypoint(String name, int x, int y, int z) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private final BooleanSetting showLine =
            new BooleanSetting("Луч", "Вертикальный луч-маячок от блока.", true);

    private final BooleanSetting showDistance =
            new BooleanSetting("Дистанция", "Показывать сколько блоков осталось до метки.", true);

    private final BooleanSetting showCoords =
            new BooleanSetting("Координаты", "Показывать координаты метки.", true);

    public Points() {
        super(ModuleCategory.POINTS, "Points", "Метки в мире: имя, дистанция, координаты.");
        setting(showLine);
        setting(showDistance);
        setting(showCoords);
        active = this;
        registerHook();
    }

    // ---- API для команд / панели / конфига ---------------------------------

    public static Points getActive() {
        return active;
    }

    public BooleanSetting getShowLine() {
        return showLine;
    }

    public BooleanSetting getShowDistance() {
        return showDistance;
    }

    public BooleanSetting getShowCoords() {
        return showCoords;
    }

    public static List<Waypoint> getWaypoints() {
        return waypoints;
    }

    public static void add(String name, int x, int y, int z) {
        for (Iterator<Waypoint> it = waypoints.iterator(); it.hasNext(); ) {
            if (it.next().name.equalsIgnoreCase(name)) {
                it.remove();
                break;
            }
        }
        waypoints.add(new Waypoint(name, x, y, z));
        ConfigManager.save();
    }

    public static boolean remove(String name) {
        boolean removed = false;
        Iterator<Waypoint> it = waypoints.iterator();
        while (it.hasNext()) {
            if (it.next().name.equalsIgnoreCase(name)) {
                it.remove();
                removed = true;
            }
        }
        if (removed) {
            ConfigManager.save();
        }
        return removed;
    }

    public static void clear() {
        if (!waypoints.isEmpty()) {
            waypoints.clear();
            ConfigManager.save();
        }
    }

    /** Сериализация в раздел конфига "points". */
    public static JsonArray saveJson() {
        JsonArray arr = new JsonArray();
        for (Waypoint wp : waypoints) {
            JsonObject o = new JsonObject();
            o.addProperty("name", wp.name);
            o.addProperty("x", wp.x);
            o.addProperty("y", wp.y);
            o.addProperty("z", wp.z);
            arr.add(o);
        }
        return arr;
    }

    public static void loadJson(JsonArray arr) {
        waypoints.clear();
        if (arr == null) {
            return;
        }
        for (JsonElement el : arr) {
            try {
                JsonObject o = el.getAsJsonObject();
                waypoints.add(new Waypoint(
                        o.get("name").getAsString(),
                        o.get("x").getAsInt(),
                        o.get("y").getAsInt(),
                        o.get("z").getAsInt()));
            } catch (Exception ignored) {
            }
        }
    }

    // ---- Хуки --------------------------------------------------------------

    private static void registerHook() {
        if (hookRegistered) return;
        hookRegistered = true;

        // Реальный FOV кадра — обновляется каждый кадр
        WorldRenderEvents.LAST.register(context -> {
            if (context.projectionMatrix() != null) {
                tanHalf = 1.0F / context.projectionMatrix().m11();
            }
        });

        // Рендер в HUD-проходе
        HudRenderCallback.EVENT.register((DrawContext context, net.minecraft.client.render.RenderTickCounter tick) -> {
            Points module = active;
            if (module == null || !module.isEnabled() || waypoints.isEmpty()) {
                return;
            }
            module.draw(context);
        });

        registerChatHandler();
    }

    /** Префикс чат-команд модуля. */
    private static final String PREFIX = ".gps";

    /** Клиентские чат-команды .gps: here, add, remove, list, clear. */
    private static void registerChatHandler() {
        // Перехват сообщения до отправки на сервер: ".gps ..." — обрабатываем и глотаем
        ClientSendMessageEvents.ALLOW_CHAT.register((message) -> {
            if (!message.startsWith(PREFIX)) {
                return true;
            }
            String rest = message.substring(PREFIX.length()).trim();
            if (rest.isEmpty()) {
                handleHelp();
                return false;
            }
            String[] parts = rest.split("\\s+");
            switch (parts[0].toLowerCase(java.util.Locale.ROOT)) {
                case "here" -> handleHere(parts);
                case "add" -> handleAdd(parts);
                case "remove" -> handleRemove(parts);
                case "list" -> handleList();
                case "clear" -> handleClear();
                default -> handleHelp();
            }
            return false;
        });
    }

    private static void handleHelp() {
        chat("Команды: here <имя>, add <x> <y> <z> <имя>, remove <имя>, list, clear", Colors.textDescription());
    }

    private static void handleHere(String[] parts) {
        String name = join(parts, 1);
        if (name.isEmpty()) {
            chat("Использование: .gps here <имя>", Colors.textDescription());
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) {
            return;
        }
        int x = mc.player.getBlockX();
        int y = mc.player.getBlockY();
        int z = mc.player.getBlockZ();
        add(name, x, y, z);
        chat("Метка \"" + name + "\" добавлена: " + x + " " + y + " " + z, Colors.textPrimary());
    }

    private static void handleAdd(String[] parts) {
        if (parts.length < 5) {
            chat("Использование: .gps add <x> <y> <z> <имя>", Colors.textDescription());
            return;
        }
        int x, y, z;
        try {
            x = Integer.parseInt(parts[1]);
            y = Integer.parseInt(parts[2]);
            z = Integer.parseInt(parts[3]);
        } catch (NumberFormatException e) {
            chat("Координаты должны быть числами", 0xFFFF6B6B);
            return;
        }
        String name = join(parts, 4);
        add(name, x, y, z);
        chat("Метка \"" + name + "\" добавлена: " + x + " " + y + " " + z, Colors.textPrimary());
    }

    private static void handleRemove(String[] parts) {
        String name = join(parts, 1);
        if (name.isEmpty()) {
            chat("Использование: .gps remove <имя>", Colors.textDescription());
            return;
        }
        if (remove(name)) {
            chat("Метка \"" + name + "\" удалена", Colors.textPrimary());
        } else {
            chat("Метка \"" + name + "\" не найдена", 0xFFFF6B6B);
        }
    }

    private static void handleList() {
        if (waypoints.isEmpty()) {
            chat("Меток нет. .gps here <имя>", Colors.textDescription());
            return;
        }
        chat("Меток: " + waypoints.size(), Colors.textPrimary());
        for (Waypoint wp : waypoints) {
            chat("  " + wp.name + ": " + wp.x + " " + wp.y + " " + wp.z, Colors.textDescription());
        }
    }

    private static void handleClear() {
        int n = waypoints.size();
        clear();
        chat("Удалено меток: " + n, Colors.textPrimary());
    }

    /** Имя = все слова с индекса from, склеенные пробелом. */
    private static String join(String[] parts, int from) {
        StringJoiner j = new StringJoiner(" ");
        for (int i = from; i < parts.length; i++) {
            j.add(parts[i]);
        }
        return j.toString();
    }

    /**
     * Сообщение в чат в стиле мода: префикс "SkrVisuals" красится
     * в акцент текущей темы клиента, текст — в заданный цвет.
     */
    private static void chat(String text, int color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud == null) {
            return;
        }
        Text msg = Text.empty()
                .append(Text.literal("SkrVisuals")
                        .styled(s -> s.withColor(TextColor.fromRgb(Colors.clientColor()))))
                .append(Text.literal(" » ")
                        .styled(s -> s.withColor(TextColor.fromRgb(Colors.textDescription()))))
                .append(Text.literal(text)
                        .styled(s -> s.withColor(TextColor.fromRgb(color))));
        mc.inGameHud.getChatHud().addMessage(msg);
    }

    // ---- Рендер -------------------------------------------------------------

    private void draw(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) {
            return;
        }

        Vec3d cam = client.gameRenderer.getCamera().getPos();
        float yaw = client.gameRenderer.getCamera().getYaw();
        float pitch = client.gameRenderer.getCamera().getPitch();

        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();
        float aspect = w / (float) h;
        TextRenderer font = Fonts.get();

        // Практически бесконечная дистанция отрисовки
        float maxDist = 1.0E9F;
        float fadeStart = maxDist * 0.75F;
        float pulse = 0.5F + 0.5F * MathHelper.sin((System.currentTimeMillis() % 20000L) * 0.005F);
        int accent = Colors.clientColor();

        for (Waypoint wp : waypoints) {
            Vec3d base = new Vec3d(wp.x + 0.5D, wp.y + 1.0D, wp.z + 0.5D);
            double dist = cam.distanceTo(base);
            if (dist > maxDist) {
                continue;
            }

            // Плавное растворение с дистанцией
            float alpha = 1.0F;
            if (dist > fadeStart) {
                alpha = MathHelper.clamp(1.0F - (float) (dist - fadeStart) / (maxDist - fadeStart), 0.0F, 1.0F);
            }
            if (alpha <= 0.02F) {
                continue;
            }

            float[] pBase = project(base, cam, yaw, pitch, aspect, w, h);
            Vec3d top = base.add(0.0D, 1.2D, 0.0D);
            float[] pTop = project(top, cam, yaw, pitch, aspect, w, h);
            if (pTop == null) {
                continue;
            }

            // Луч-маячок от блока к маркеру
            if (showLine.getValue() && pBase != null) {
                int lineColor = RenderUtil.withAlpha(accent, alpha * 0.45F);
                line(context, pBase, pTop, 1.0F, lineColor);
            }

            // Пульсирующий ромб-маркер
            int d = MathHelper.floor(2.5F + pulse * 1.5F);
            MatrixStack matrices = context.getMatrices();
            matrices.push();
            matrices.translate(pTop[0], pTop[1], 0.0F);
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(45.0F));
            RenderUtil.fill(context, -d - 1, -d - 1, (d + 1) * 2f, (d + 1) * 2f, RenderUtil.withAlpha(0xFF101014, alpha));
            RenderUtil.fill(context, -d, -d, d * 2f, d * 2f, RenderUtil.withAlpha(accent, alpha));
            matrices.pop();

            // Плашка: имя / дистанция / координаты
            drawChip(context, font, wp, pTop, (float) dist, alpha);
        }
    }

    /** Плашка в стиле мода: имя / дистанция / координаты. */
    private void drawChip(DrawContext context, TextRenderer font, Waypoint wp,
                          float[] anchor, float dist, float alpha) {
        List<String> lines = new ArrayList<>();
        lines.add(wp.name);
        if (showDistance.getValue()) {
            lines.add((int) dist + " " + blocksSuffix((long) dist));
        }
        if (showCoords.getValue()) {
            lines.add(wp.x + " " + wp.y + " " + wp.z);
        }

        int lineH = font.fontHeight + 1;
        int textW = 0;
        for (String s : lines) {
            textW = Math.max(textW, font.getWidth(s));
        }

        float padX = 4.0F, padY = 3.0F;
        float cw = textW + padX * 2.0F;
        float ch = lines.size() * lineH + padY * 2.0F - 1.0F;
        float cx = anchor[0] - cw / 2.0F;
        float cy = anchor[1] - ch - 10.0F;

        RenderUtil.roundedRect(context, cx - 1.0F, cy - 1.0F, cw + 2.0F, ch + 2.0F, 4.0F,
                RenderUtil.withAlpha(Colors.clientColor(), alpha * 0.8F));
        RenderUtil.roundedRect(context, cx, cy, cw, ch, 3.0F,
                RenderUtil.withAlpha(0xE8101014, alpha));

        float ty = cy + padY;
        for (int i = 0; i < lines.size(); i++) {
            int color;
            if (i == 0) {
                color = Colors.textPrimary();
            } else if (i == 1 && showDistance.getValue()) {
                color = Colors.clientColor();
            } else {
                color = Colors.textDescription();
            }
            RenderUtil.drawString(context, font, lines.get(i), cx + padX, ty, RenderUtil.withAlpha(color, alpha));
            ty += lineH;
        }
    }

    /** Русская плюрализация: 1 блок / 2 блока / 5 блоков. */
    private static String blocksSuffix(long n) {
        long mod100 = n % 100;
        if (mod100 >= 11 && mod100 <= 14) {
            return "блоков";
        }
        return switch ((int) (n % 10)) {
            case 1 -> "блок";
            case 2, 3, 4 -> "блока";
            default -> "блоков";
        };
    }

    /** Линия через ванильный fill() с поворотом матрицы (математика BlockOverlay). */
    private static void line(DrawContext context, float[] p1, float[] p2,
                             float half, int argb) {
        float dx = p2[0] - p1[0];
        float dy = p2[1] - p1[1];
        float len = MathHelper.sqrt(dx * dx + dy * dy);
        if (len < 0.5F) return;

        float angle = (float) Math.toDegrees(Math.atan2(dy, dx));
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(p1[0], p1[1], 0.0F);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle));
        RenderUtil.fill(context, 0, -half, len, half * 2f, argb);
        matrices.pop();
    }

    /** Проекция мировой точки в scaled-пиксели. null = за камерой / вне экрана. */
    private static float[] project(Vec3d point, Vec3d cam, float yaw, float pitch,
                                   float aspect, int w, int h) {
        double dx = point.x - cam.x;
        double dy = point.y - cam.y;
        double dz = point.z - cam.z;

        float yawRad = (float) Math.toRadians(yaw);
        float pitchRad = (float) Math.toRadians(pitch);
        float cosP = MathHelper.cos(pitchRad);

        float lX = -MathHelper.sin(yawRad) * cosP;
        float lY = -MathHelper.sin(pitchRad);
        float lZ = MathHelper.cos(yawRad) * cosP;
        float rX = -MathHelper.cos(yawRad);
        float rZ = -MathHelper.sin(yawRad);
        float uX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uY = MathHelper.cos(pitchRad);
        float uZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        float depth = (float) dx * lX + (float) dy * lY + (float) dz * lZ;
        if (depth < 0.1F) return null;

        float xOff = (float) dx * rX + (float) dz * rZ;
        float yOff = (float) dx * uX + (float) dy * uY + (float) dz * uZ;

        float ndcX = (xOff / depth) / (tanHalf * aspect);
        float ndcY = (yOff / depth) / tanHalf;
        if (MathHelper.abs(ndcX) > 1.2F || MathHelper.abs(ndcY) > 1.2F) return null;

        return new float[]{
                (ndcX * 0.5F + 0.5F) * w,
                (0.5F - ndcY * 0.5F) * h
        };
    }
}
