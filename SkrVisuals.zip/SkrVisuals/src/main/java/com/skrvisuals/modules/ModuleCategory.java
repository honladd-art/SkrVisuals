package com.skrvisuals.modules;

import com.skrvisuals.ui.theme.Colors;

/**
 * Placeholder module categories. Each maps to its own module screen when selected.
 */
public enum ModuleCategory {
    VISUALS("Visuals", Colors.categoryVisuals()),
    COMBAT("Combat", Colors.categoryCombat()),
    UTILITY("Utility", Colors.categoryUtility()),
    POINTS("Points", Colors.categoryPoints()),
    FRIENDS("Friends", Colors.categoryFriends()),
    THEMES("Themes", 0xFFE6E6FF);

    private final String displayName;
    private final int accentColor;

    ModuleCategory(String displayName, int accentColor) {
        this.displayName = displayName;
        this.accentColor = accentColor;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public int getAccentColor() {
        return this.accentColor;
    }
}