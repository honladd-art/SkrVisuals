package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.anim.Animation;
import com.skrvisuals.ui.anim.Easing;
import com.skrvisuals.ui.render.Fonts;
import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

/**
 * CustomHotbar: заменяет ванильный хотбар на кастомный.
 *
 * - Ванильный хотбар гасится в InGameHudMixin (renderHotbar);
 * - Свой рисуется в HUD-проходе: скруглённая панель в цветах темы,
 *   9 предметов, количество предмета — в цвет темы (не показывается при 1);
 * - Настраиваются прозрачность и масштаб;
 * - Выделение выбранного слота плавно скользит между ячейками
 *   (Animation + EASE_OUT_CUBIC) вместо резкой телепортации, как в ванилле.
 */
public class CustomHotbar extends Module {

    private static CustomHotbar active;
    private static boolean hookRegistered = false;

    /** Плавное скольжение выделения по слотам (в экранных пикселях от левого края панели). */
    private static final Animation selection = new Animation(Easing.EASE_OUT_CUBIC, 250L);
    private static boolean selectionInit = false;

    private final SliderSetting opacity =
            new SliderSetting("Прозрачность", "Прозрачность панели хотбара.", 0.1f, 1.0f, 1.0f);

    private final SliderSetting scale =
            new SliderSetting("Масштаб", "Масштаб хотбара (1 — как ванильный).", 0.5f, 2.0f, 1.0f);

    public CustomHotbar() {
        super(ModuleCategory.VISUALS, "CustomHotbar", "Кастомный хотбар вместо ванильного.");
        setting(opacity);
        setting(scale);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) return;
        hookRegistered = true;
        HudRenderCallback.EVENT.register(CustomHotbar::onHud);

        // Ванильный HUD-проход не вызывается при открытом экране, поэтому
        // рисуем хотбар поверх любого GUI через after-render событие экрана
        // (чат, clickgui и т.д.), иначе он "исчезает" при открытии GUI.
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) ->
                ScreenEvents.afterRender(screen).register((s, context, mx, my, delta) ->
                        onHud(context, null)));
    }

    /** Вызывается из InGameHudMixin: прятать ли ванильный хотбар. */
    public static boolean shouldHideVanilla() {
        CustomHotbar module = active;
        return module != null && module.isEnabled();
    }

    private static void onHud(DrawContext context, RenderTickCounter tick) {
        CustomHotbar module = active;
        if (module == null || !module.isEnabled()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        // Как ванилла: без игрока хотбар не рисуем. При открытом экране
        // продолжаем рисовать (проход через ScreenEvents.afterRender).
        if (client.player == null) {
            return;
        }

        float s = MathHelper.clamp(module.scale.getValue(), 0.5f, 2.0f);
        float op = MathHelper.clamp(module.opacity.getValue(), 0.1f, 1.0f);

        // При открытом GUI (кроме чата) снижаем альфу — хотбар "блюрится"
        // через ванильное затемнение, как и остальные HUD-элементы.
        boolean screenOpen = client.currentScreen != null;
        boolean isChat = client.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen;
        if (screenOpen && !isChat) {
            op *= 0.55f;
        }

        float w = client.getWindow().getScaledWidth();
        float h = client.getWindow().getScaledHeight();

        // Геометрия ванильного хотбара (182x22), умноженная на масштаб.
        float barW = 182f * s;
        float barH = 22f * s;
        float cell = 20f * s;
        float x0 = w / 2f - barW / 2f;
        float y0 = h - barH;

        // ---- Панель ----
        RenderUtil.roundedShadow(context, x0 - 2f, y0 - 2f, barW + 4f, barH + 4f, 5f * s, 0.5f * op);
        RenderUtil.roundedGradient(context, x0, y0, barW, barH, 4f * s,
                RenderUtil.withAlpha(Colors.guiBackgroundTop(), 0.75f * op),
                RenderUtil.withAlpha(Colors.guiBackgroundBottom(), 0.85f * op));
        RenderUtil.roundedOutline(context, x0, y0, barW, barH, 4f * s, 1f,
                RenderUtil.withAlpha(Colors.guiBorder(), op));
        // Акцентная полоска слева, как у остальных HUD-элементов.
        RenderUtil.roundedRect(context, x0 + 3f, y0 + 3f, 2f, barH - 6f, 1f,
                RenderUtil.withAlpha(Colors.clientColor(), 0.9f * op));

        // ---- Разделители между слотами (как в ванильной текстуре) ----
        int sepColor = RenderUtil.withAlpha(Colors.guiBorder(), 0.9f * op);
        for (int i = 1; i < 9; i++) {
            float sx = x0 + i * cell;
            RenderUtil.fill(context, sx, y0 + 2f * s, Math.max(1f, 1f * s), barH - 4f * s, sepColor);
        }

        // ---- Плавное выделение выбранного слота ----
        int selected = client.player.getInventory().selectedSlot;
        float target = selected * cell;
        if (!selectionInit) {
            selection.setValue(target);
            selectionInit = true;
        }
        selection.run(target);
        float selX = x0 + selection.getValue() + 0.5f * s;
        float selY = y0 + 0.5f * s;
        float selW = 19f * s;
        float selH = barH - s;
        RenderUtil.roundedRect(context, selX, selY, selW, selH, 3f * s,
                RenderUtil.withAlpha(Colors.clientColor(), 0.25f * op));
        RenderUtil.roundedOutline(context, selX, selY, selW, selH, 3f * s, 1f,
                RenderUtil.withAlpha(Colors.clientColor(), 0.9f * op));

        // ---- Предметы и количество ----
        TextRenderer font = Fonts.get();
        MatrixStack matrices = context.getMatrices();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().main.get(i);
            if (stack == null || stack.isEmpty()) {
                continue;
            }

            float ix = x0 + 3f * s + i * cell;
            float iy = y0 + 3f * s;

            matrices.push();
            matrices.translate(ix, iy, 0f);
            matrices.scale(s, s, 1f);
            // Только иконка: количество рисуем своё, в цвет темы.
            context.drawItem(stack, 0, 0);
            if (stack.getCount() > 1) {
                String countText = String.valueOf(stack.getCount());
                // Поднимаем текст по глубине (как drawStackOverlay в InventoryHUD
                // рисует счётчик на z=200), иначе он оказывается позади предмета,
                // который рендерится на z=150+.
                float k = 8f / font.fontHeight;
                matrices.push();
                matrices.translate(16f, 16f, 300f);
                matrices.scale(k, k, 1f);
                RenderUtil.drawString(context, font, countText,
                        -font.getWidth(countText), -font.fontHeight,
                        RenderUtil.withAlpha(Colors.clientColor(), op));
                matrices.pop();
            }
            matrices.pop();
        }
    }
}
