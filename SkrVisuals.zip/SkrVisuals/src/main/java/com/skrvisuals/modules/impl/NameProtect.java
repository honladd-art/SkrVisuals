package com.skrvisuals.modules.impl;

import java.util.ArrayList;
import java.util.List;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.StringSetting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;

/**
 * NameProtect: визуально скрывает твой ник там, где он упоминается —
 * в чате, над головами игроков, в таб-листе и скорборде.
 * Ник задаётся строковой настройкой (по умолчанию "SkrVisuals")
 * и заменяется на "***".
 */
public class NameProtect extends Module {

    public final StringSetting replacement = new StringSetting(
            "Заменять на", "На что заменять твой ник.", "SkrVisuals");
    public final BooleanSetting chat = new BooleanSetting(
            "Чат", "Скрывать ник в сообщениях чата.", true);
    public final BooleanSetting nametags = new BooleanSetting(
            "Ники и таб", "Скрывать ник над головой, в таб-листе и скорборде.", true);

    public NameProtect() {
        super(ModuleCategory.UTILITY, "NameProtect", "Скрывает твой ник там, где он упоминается.");
        setting(replacement);
        setting(chat);
        setting(nametags);
    }

    private static NameProtect INSTANCE;

    @Override
    protected void onEnabledChange() {
        INSTANCE = this.isEnabled() ? this : null;
    }

    // ------------------------------------------------------------------ //

    public static boolean isActive() {
        NameProtect m = INSTANCE;
        return m != null && m.isEnabled();
    }

    /** Ник для скрытия — берётся из профиля игры (лаунчера). */
    public static String getNickname() {
        if (!isActive()) return null;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.player != null) {
            String name = client.player.getGameProfile().getName();
            if (name != null && !name.isBlank()) {
                return name;
            }
        }
        return null; // в меню ещё не знаем ник — нечего скрывать
    }

    /** Текст-замена (на что менять ник) или null, если защита выключена. */
    public static String getReplacement() {
        if (!isActive()) return null;
        String rep = INSTANCE.replacement.getValue();
        return rep == null || rep.isEmpty() ? null : rep;
    }

    /** Заменяет вхождения ника на текст-замену. Возвращает null, если менять не нужно. */
    public static String protect(String text) {
        String nick = getNickname();
        String rep = getReplacement();
        if (nick == null || rep == null || text == null) return null;
        if (!text.toLowerCase().contains(nick.toLowerCase())) return null;
        return replaceIgnoreCase(text, nick, rep);
    }

    /**
     * Подменяет все вхождения ника на текст-замену в любом тексте на экране.
     * Возвращает null, если менять не нужно.
     */
    public static OrderedText protectOrdered(OrderedText text, boolean chatOnly) {
        String nick = getNickname();
        String rep = getReplacement();
        if (nick == null || rep == null || text == null) return null;
        if (chatOnly && !INSTANCE.chat.getValue()) return null;
        if (!chatOnly && !INSTANCE.nametags.getValue()) return null;

        // Собираем кодпойнты и стили исходного текста.
        List<Integer> codePoints = new ArrayList<>();
        List<Style> styles = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        text.accept((index, style, codePoint) -> {
            codePoints.add(codePoint);
            styles.add(style);
            sb.appendCodePoint(codePoint);
            return true;
        });

        String s = sb.toString();
        if (!s.toLowerCase().contains(nick.toLowerCase())) return null;

        // Разбираем ник и замену на кодпойнты.
        int[] nickCps = nick.codePoints().toArray();
        int[] repCps = rep.codePoints().toArray();

        // Ищем вхождения ника (регистронезависимо) по кодпойнтам.
        List<Integer> outCps = new ArrayList<>();
        List<Style> outStyles = new ArrayList<>();
        String lower = s.toLowerCase();
        String nickLower = nick.toLowerCase();

        int cpIdx = 0;
        while (cpIdx < codePoints.size()) {
            // Совпадает ли ник с этой позиции? Сравниваем в символьных координатах строки.
            int charPos = 0;
            for (int i = 0; i < cpIdx; i++) {
                charPos += Character.charCount(codePoints.get(i));
            }
            boolean match = charPos + nick.length() <= s.length()
                    && lower.startsWith(nickLower, charPos);
            if (match) {
                Style style = styles.get(cpIdx);
                for (int cp : repCps) {
                    outCps.add(cp);
                    outStyles.add(style);
                }
                cpIdx += nickCps.length;
            } else {
                outCps.add(codePoints.get(cpIdx));
                outStyles.add(styles.get(cpIdx));
                cpIdx++;
            }
        }

        return visitor -> {
            for (int i = 0; i < outCps.size(); i++) {
                if (!visitor.accept(i, outStyles.get(i), outCps.get(i))) {
                    return false;
                }
            }
            return true;
        };
    }

    private static String replaceIgnoreCase(String text, String from, String to) {
        StringBuilder out = new StringBuilder();
        String lower = text.toLowerCase();
        String fromLower = from.toLowerCase();
        int i = 0;
        int idx;
        while ((idx = lower.indexOf(fromLower, i)) >= 0) {
            out.append(text, i, idx).append(to);
            i = idx + from.length();
        }
        out.append(text.substring(i));
        return out.toString();
    }
}