package com.skrvisuals.modules.impl;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * JumpCircle: draws an animated, fading textured circle on the ground
 * wherever the local player jumps (port of the reference module).
 *
 * Modes:
 * - «Круги»: классические текстурные круги на земле.
 * - «Блоки»: подсвечивает блоки в радиусе точки прыжка цветом темы.
 */
public class JumpCircle extends Module {
    private static final Identifier CIRCLE_TEXTURE =
            Identifier.of("skrvisuals", "textures/jumpcircles/circle.png");

    private static final long LIFETIME_MS = 2000L;
    private static final long FADE_START_MS = 1500L;
    private static final long FADE_DURATION_MS = 500L;
    private static final long GROW_DURATION_MS = 600L;
    private static final float MAX_RADIUS = 2.5F;
    /** Full brightness for the decal: LightmapTextureManager.pack(15, 15). */
    private static final int MAX_LIGHT = 15728880;
    /** Время жизни эффекта блоков. */
    private static final long BLOCK_LIFETIME_MS = 1000L;
    /** Время появления блоков от центра к краям. */
    private static final long BLOCK_APPEAR_MS = 200L;
    /** Начало затухания для крайних блоков. */
    private static final long BLOCK_FADE_START_MS = 200L;
    /** Длительность затухания блоков. */
    private static final long BLOCK_FADE_MS = 300L;

    private static JumpCircle active;
    private static boolean renderHookRegistered = false;

    private final CopyOnWriteArrayList<Circle> circles = new CopyOnWriteArrayList<>();
    private final SliderSetting radius = new SliderSetting("Радиус круга", "Размер круга", 0.5f, 1.0f, 0.5f);
    private final ModeSetting mode = new ModeSetting(
            "Режим",
            "Круги — текстурные круги, Блоки — подсветка блоков в радиусе.",
            List.of("Круги", "Блоки"),
            "Круги"
    );
    private final SliderSetting blockRadius = new SliderSetting(
            "Радиус блоков",
            "Радиус подсветки блоков в режиме «Блоки».",
            1.0f, 10.0f, 5.0f
    );

    private boolean wasOnGround = false;
    private long lastJumpTime = 0L;

    public JumpCircle() {
        super(ModuleCategory.VISUALS, "JumpCircle", "Круги при прыжке.");
        setting(mode);
        // «Радиус круга» нужен только режиму «Круги», «Радиус блоков» — «Блоки».
        radius.setHideCondition(() -> !"Круги".equals(mode.getValue()));
        blockRadius.setHideCondition(() -> !"Блоки".equals(mode.getValue()));
        setting(radius);
        setting(blockRadius);
        active = this;
        registerRenderHook();
    }

    private static void registerRenderHook() {
        if (renderHookRegistered) {
            return;
        }
        renderHookRegistered = true;
        WorldRenderEvents.LAST.register(JumpCircle::onWorldRender);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;

        if (!this.isEnabled()) {
            this.circles.clear();
            this.wasOnGround = player != null && player.isOnGround();
            return;
        }
        if (player == null || client.world == null) {
            this.wasOnGround = false;
            return;
        }

        boolean onGround = player.isOnGround();
        // Left the ground while moving up => a jump just happened.
        if (this.wasOnGround && !onGround && player.getVelocity().y > 0.15D) {
            long now = System.currentTimeMillis();
            if (now - this.lastJumpTime >= 150L) {
                this.lastJumpTime = now;
                BlockPos below = player.getBlockPos().down();
                double y = below.getY() + 1.01D; // sit on top of the block below
                this.circles.add(new Circle(new Vec3d(player.getX(), y, player.getZ())));
            }
        }
        this.wasOnGround = onGround;
    }

    // ---------------------------------------------------------------- rendering
    private static void onWorldRender(WorldRenderContext context) {
        JumpCircle module = active;
        if (module == null || !module.isEnabled() || module.circles.isEmpty()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }

        long now = System.currentTimeMillis();
        module.circles.removeIf(circle -> now - circle.time > LIFETIME_MS);
        if (module.circles.isEmpty()) {
            return;
        }

        String currentMode = module.mode.getValue();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();

        if ("Блоки".equals(currentMode)) {
            drawBlocks(module, client, matrices, consumers, now);
        } else {
            drawCircles(module, matrices, consumers, now);
        }
    }

    /**
     * Рисует текстурные круги (классический режим).
     */
    private static void drawCircles(JumpCircle module, MatrixStack matrices,
                                     VertexConsumerProvider.Immediate consumers, long now) {
        MinecraftClient client = MinecraftClient.getInstance();
        Vec3d camera = client.gameRenderer.getCamera().getPos();
        float radiusValue = module.radius.getValue();

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        VertexConsumer buffer =
                consumers.getBuffer(RenderLayer.getEntityTranslucent(CIRCLE_TEXTURE));

        var entry = matrices.peek();
        var matrix = entry.getPositionMatrix();

        int baseColor = Colors.clientColor();
        int r = (baseColor >> 16) & 0xFF;
        int g = (baseColor >> 8) & 0xFF;
        int b = baseColor & 0xFF;

        for (Circle circle : module.circles) {
            long lifeTime = now - circle.time;
            circle.animation.update();

            float growProgress = (float) circle.animation.getValue();
            float rad = Math.min(MAX_RADIUS, growProgress * radiusValue * MAX_RADIUS);
            if (rad <= 0.01F) {
                continue;
            }

            float fadeFactor;
            if (lifeTime < FADE_START_MS) {
                fadeFactor = 1.0F;
            } else {
                float fadeProgress = (lifeTime - FADE_START_MS) / (float) FADE_DURATION_MS;
                fadeFactor = 1.0F - easeInOut(MathHelper.clamp(fadeProgress, 0.0F, 1.0F));
            }
            int alpha = Math.max(0, (int) (255.0F * fadeFactor));
            if (alpha <= 0) {
                continue;
            }

            float px = (float) (circle.position.x - rad / 2.0D);
            float py = (float) circle.position.y;
            float pz = (float) (circle.position.z - rad / 2.0D);

            drawCorner(buffer, entry, matrix, px, py, pz,
                    r, g, b, alpha, 0.0F, 0.0F);
            drawCorner(buffer, entry, matrix, px + rad, py, pz,
                    r * 0.8f, g * 1.2f, b, alpha, 1.0F, 0.0F);
            drawCorner(buffer, entry, matrix, px + rad, py, pz + rad,
                    r * 0.6f, g, b * 1.2f, alpha, 1.0F, 1.0F);
            drawCorner(buffer, entry, matrix, px, py, pz + rad,
                    r, g * 0.8f, b * 1.3f, alpha, 0.0F, 1.0F);
        }

        consumers.draw(RenderLayer.getEntityTranslucent(CIRCLE_TEXTURE));
        matrices.pop();
    }

    private static void drawCorner(VertexConsumer buffer, MatrixStack.Entry entry,
                                   org.joml.Matrix4f matrix, float x, float y, float z,
                                   float r, float g, float b, int a, float u, float v) {
        buffer.vertex(matrix, x, y, z)
                .color(clamp255(r), clamp255(g), clamp255(b), a)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(MAX_LIGHT)
                .normal(entry, 0.0F, 1.0F, 0.0F);
    }

    private static int clamp255(float value) {
        return MathHelper.clamp((int) value, 0, 255);
    }

    private static float easeInOut(float x) {
        return (x < 0.5F)
                ? (2.0F * x * x)
                : (1.0F - (float) Math.pow(-2.0D * x + 2.0D, 2.0D) / 2.0F);
    }

    /**
     * Подсвечивает блоки в радиусе точки прыжка цветом темы.
     * Блоки плавно появляются от центра к краям и плавно исчезают от краёв к центру.
     */
    private static void drawBlocks(JumpCircle module, MinecraftClient client, MatrixStack matrices,
                                   VertexConsumerProvider.Immediate consumers, long now) {
        int base = Colors.clientColor();
        int r = (base >> 16) & 0xFF;
        int g = (base >> 8) & 0xFF;
        int b = base & 0xFF;

        int radius = Math.round(module.blockRadius.getValue());
        ClientWorld world = client.world;

        matrices.push();
        Vec3d camera = client.gameRenderer.getCamera().getPos();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        var buffer = consumers.getBuffer(RenderLayer.getDebugQuads());

        for (Circle circle : module.circles) {
            long elapsed = now - circle.time;
            if (elapsed >= BLOCK_LIFETIME_MS) {
                continue;
            }

            int cx = (int) Math.floor(circle.position.x);
            int cy = (int) Math.floor(circle.position.y);
            int cz = (int) Math.floor(circle.position.z);

            for (int dx = -radius; dx <= radius; dx++) {
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        // Расстояние от центра (0..1)
                        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz) / radius;
                        if (dist > 1.0D) {
                            continue;
                        }

                        // Анимация появления: центральные блоки появляются первыми
                        // Блок появляется, когда elapsed > dist * BLOCK_APPEAR_MS
                        float appearProgress = MathHelper.clamp(
                                (float) ((elapsed / (double) BLOCK_APPEAR_MS) - dist),
                                0.0F, 1.0F
                        );
                        if (appearProgress <= 0.0F) {
                            continue;
                        }

                        // Анимация исчезновения: крайние блоки исчезают первыми (от краёв к центру)
                        // fadeStart для блока = BLOCK_FADE_START_MS + (1 - dist) * BLOCK_FADE_MS
                        float fadeStart = BLOCK_FADE_START_MS + (1.0F - (float) dist) * BLOCK_FADE_MS;
                        float fadeFactor = 1.0F;
                        if (elapsed >= fadeStart) {
                            float fadeProgress = (elapsed - fadeStart) / (float) BLOCK_FADE_MS;
                            fadeFactor = 1.0F - easeInOut(MathHelper.clamp(fadeProgress, 0.0F, 1.0F));
                        }
                        if (fadeFactor <= 0.0F) {
                            continue;
                        }

                        BlockPos p = new BlockPos(cx + dx, cy + dy, cz + dz);
                        var state = world.getBlockState(p);
                        if (state.isAir() || state.isReplaceable() || !state.isOpaqueFullCube()) {
                            continue;
                        }

                        // Более прозрачный (64 вместо 128)
                        int alpha = Math.max(0, (int) (64.0F * fadeFactor * appearProgress));
                        if (alpha <= 0) {
                            continue;
                        }

                        float x0 = p.getX() - 0.001F;
                        float y0 = p.getY() - 0.001F;
                        float z0 = p.getZ() - 0.001F;
                        float x1 = p.getX() + 1.002F;
                        float y1 = p.getY() + 1.002F;
                        float z1 = p.getZ() + 1.002F;

                        var matrix = matrices.peek().getPositionMatrix();

                        if (isFaceExposed(world, p, x0, y1, z0, x1, y1, z1)) {
                            face(buffer, matrix, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, r, g, b, alpha);
                        }
                        if (isFaceExposed(world, p, x0, y0, z1, x1, y0, z1)) {
                            face(buffer, matrix, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, r, g, b, alpha);
                        }
                        if (isFaceExposed(world, p, x0, y0, z0, x0, y1, z0, x0, y1, z1)) {
                            face(buffer, matrix, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, r, g, b, alpha);
                        }
                        if (isFaceExposed(world, p, x1, y0, z0, x1, y1, z0, x1, y1, z1)) {
                            face(buffer, matrix, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, r, g, b, alpha);
                        }
                        if (isFaceExposed(world, p, x0, y0, z0, x1, y0, z0, x1, y1, z0)) {
                            face(buffer, matrix, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, r, g, b, alpha);
                        }
                        if (isFaceExposed(world, p, x0, y0, z1, x1, y0, z1, x0, y1, z1)) {
                            face(buffer, matrix, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, r, g, b, alpha);
                        }
                    }
                }
            }
        }
        consumers.draw(RenderLayer.getDebugQuads());
        matrices.pop();
    }

    /** true, если хотя бы одна точка грани открыта (воздух/растение/прозрачный блок по ту сторону). */
    private static boolean isFaceExposed(ClientWorld world, BlockPos pos,
                                         float... samples) {
        for (int i = 0; i + 2 < samples.length; i += 3) {
            float fx = samples[i];
            float fy = samples[i + 1];
            float fz = samples[i + 2];
            int dx = fx < pos.getX() ? -1 : (fx > pos.getX() + 1.0F ? 1 : 0);
            int dy = fy < pos.getY() ? -1 : (fy > pos.getY() + 1.0F ? 1 : 0);
            int dz = fz < pos.getZ() ? -1 : (fz > pos.getZ() + 1.0F ? 1 : 0);
            BlockPos n = pos.add(dx, dy, dz);
            var ns = world.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable() || !ns.isOpaqueFullCube()) {
                return true;
            }
        }
        return false;
    }

    private static void face(VertexConsumer buffer, org.joml.Matrix4f matrix,
                             float ax, float ay, float az,
                             float bx, float by, float bz,
                             float cx, float cy, float cz,
                             float dx, float dy, float dz,
                             int r, int g, int b, int a) {
        buffer.vertex(matrix, ax, ay, az).color(r, g, b, a);
        buffer.vertex(matrix, bx, by, bz).color(r, g, b, a);
        buffer.vertex(matrix, cx, cy, cz).color(r, g, b, a);
        buffer.vertex(matrix, dx, dy, dz).color(r, g, b, a);
    }

    // ------------------------------------------------------------------ data
    private static final class Circle {
        private final Vec3d position;
        private final long time;
        private final Animation animation;

        private Circle(Vec3d position) {
            this.position = position;
            this.time = System.currentTimeMillis();
            this.animation = new Animation();
            this.animation.animate(0.0D, 1.0D);
        }
    }

    /** Ease-out-cubic growth over {@code GROW_DURATION_MS}. */
    private static final class Animation {
        private double startValue;
        private double endValue;
        private double currentValue;
        private long startTime;
        private long duration = GROW_DURATION_MS;

        private void animate(double start, double end) {
            this.startValue = start;
            this.endValue = end;
            this.currentValue = start;
            this.startTime = System.currentTimeMillis();
        }

        private void update() {
            long elapsed = System.currentTimeMillis() - this.startTime;
            if (elapsed >= this.duration) {
                this.currentValue = this.endValue;
                return;
            }
            float progress = Math.min(1.0F, elapsed / (float) this.duration);
            float eased = 1.0F - (float) Math.pow(1.0D - progress, 3.0D);
            this.currentValue = this.startValue + (this.endValue - this.startValue) * eased;
        }

        private double getValue() {
            return this.currentValue;
        }
    }
}