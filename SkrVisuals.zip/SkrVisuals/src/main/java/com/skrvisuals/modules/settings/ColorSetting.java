package com.skrvisuals.modules.settings;

public class ColorSetting extends Setting {
    private int value; // ARGB

    public ColorSetting(String name, String description, int defaultValue) {
        super(name, description);
        this.value = defaultValue;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}