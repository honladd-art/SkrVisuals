package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import com.skrvisuals.ui.render.RenderUtil;
import com.skrvisuals.ui.theme.Colors;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * BlockOverlay: заменяет ванильную обводку блока под прицелом на свою.
 *
 * - BEFORE_BLOCK_OUTLINE гасит ванильную рамку;
 * - рисование — в HUD-проходе экранными quads: углы блока проецируются
 *   на экран (базис камеры + реальный FOV кадра), линии — ванильный
 *   fill() с поворотом матрицы.
 *
 * Фильтры (защита от «рендера в воздухе»):
 * 1) воздух (state.isAir()) — не подсвечиваем;
 * 2) блоки без видимой outline-формы;
 * 3) камера внутри блока (голова в листве): грани изнутри не видны,
 *    а raycast бьёт в блок в любую сторону — классический фантом.
 *
 * Особенность: линии окклюдятся миром — блок за стеной не рисуется.
 *
 * «Плавность»: подсветка плавно переезжает на новый блок под прицелом
 * (вместо резкого прыжка), скорость переезда — слайдер «Скорость плавности».
 * Пока подсветка едет между блоками, своими для проверки окклюзии считаются
 * все блоки, которые она накрывает — иначе половина граней гасла бы на середине.
 */
public class BlockOverlay extends Module {

    private static BlockOverlay active;
    private static boolean hookRegistered = false;

    /** Маленькое расширение коробки, чтобы линии не зезали в грань блока. */
    private static final double EPS = 0.002D;

    /** tan(FOV/2) реального кадра. */
    private static volatile float tanHalf = 1.0F;

    private final ModeSetting type = new ModeSetting(
            "Тип",
            "Углы — только уголки, Полный — вся коробка.",
            List.of("Углы", "Полный"),
            "Углы"
    );

    private final SliderSetting opacity =
            new SliderSetting("Прозрачность", "Непрозрачность линий, %.", 0.0f, 100.0f, 100.0f);

    private final SliderSetting thickness =
            new SliderSetting("Толщина", "Толщина линий в пикселях.", 1.0f, 4.0f, 2.0f);

    private final SliderSetting cornerLength =
            new SliderSetting("Длина углов", "Длина сегментов уголка (доля ребра блока).", 0.05f, 0.5f, 0.25f);

    private final BooleanSetting fill =
            new BooleanSetting("Заливка", "Заливает грани блока цветом темы.", false);

    private final SliderSetting fillOpacity =
            new SliderSetting("Прозрачность заливки", "Непрозрачность заливки граней, %.", 0.0f, 100.0f, 25.0f);

    /** Плавный переезд подсветки на новый блок вместо мгновенного скачка. */
    private final BooleanSetting smooth =
            new BooleanSetting("Плавность", "Плавно переносит подсветку на новый блок, а не резко.", true);

    private final SliderSetting smoothSpeed =
            new SliderSetting("Скорость плавности", "Скорость переезда подсветки к новому блоку (выше — резче).",
                    1.0f, 20.0f, 8.0f);

    /** Текущие границы подсветки (без EPS) — догоняют коробку целевого блока. */
    private double animMinX;
    private double animMinY;
    private double animMinZ;
    private double animMaxX;
    private double animMaxY;
    private double animMaxZ;
    private boolean animInit = false;
    private long animLastNanos = 0L;

    /** Блок, дальше которого (в блоках) подсветка не едет, а переносится мгновенно. */
    private static final double SMOOTH_SNAP_DISTANCE = 6.0D;

    public BlockOverlay() {
        super(ModuleCategory.VISUALS, "BlockOverlay", "Кастомное выделение блока под прицелом.");
        setting(type);
        setting(opacity);
        setting(thickness);
        // «Длина углов» нужна только в режиме «Углы».
        cornerLength.setHideCondition(() -> !"Углы".equals(type.getValue()));
        setting(cornerLength);
        setting(fill);
        // «Прозрачность заливки» нужна только при включённой заливке.
        fillOpacity.setHideCondition(() -> !fill.getValue());
        setting(fillOpacity);
        setting(smooth);
        // «Скорость плавности» нужна только при включённой плавности
        smoothSpeed.setHideCondition(() -> !smooth.getValue());
        setting(smoothSpeed);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) return;
        hookRegistered = true;

        // Реальный FOV кадра — обновляется каждый кадр
        WorldRenderEvents.LAST.register(context -> {
            if (context.projectionMatrix() != null) {
                tanHalf = 1.0F / context.projectionMatrix().m11();
            }
        });

        // Гасим ванильную обводку, пока модуль включен
        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((context, outline) -> {
            BlockOverlay module = active;
            return module == null || !module.isEnabled();
        });

        // Рисование: цель прицела читается каждый кадр заново; историю
        // хранит только «Плавность» (текущие границы подсветки).
        HudRenderCallback.EVENT.register((DrawContext context, net.minecraft.client.render.RenderTickCounter tick) -> {
            BlockOverlay module = active;
            if (module == null || !module.isEnabled()) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.world == null || client.player == null) {
                module.resetAnimation();
                return;
            }
            // Не блок (небо/сущность) — не рисуем ничего
            if (!(client.crosshairTarget instanceof BlockHitResult hit)) {
                // Цель потеряна: следующая подсветка появится на новом блоке,
                // а не «прилетит» из старой точки.
                module.resetAnimation();
                return;
            }
            module.draw(context, hit.getBlockPos());
        });
    }

    private void draw(DrawContext context, BlockPos pos) {
        MinecraftClient client = MinecraftClient.getInstance();
        Vec3d cam = client.gameRenderer.getCamera().getPos();

        // --- Фильтр 1: воздух не подсвечиваем ---
        BlockState state = client.world.getBlockState(pos);
        if (state.isAir()) {
            resetAnimation();
            return;
        }

        // --- Фильтр 2: нет видимой формы — не подсвечиваем ---
        VoxelShape shape = state.getOutlineShape(client.world, pos);
        if (shape == null || shape.isEmpty()) {
            resetAnimation();
            return;
        }

        // --- Фильтр 3: камера внутри блока (голова в листве) — не рисуем ---
        Box shapeBox = shape.getBoundingBox().offset(pos.getX(), pos.getY(), pos.getZ());
        if (shapeBox.contains(cam)) {
            resetAnimation();
            return;
        }

        // --- Плавность: границы подсветки едут к целевому блоку ---
        updateAnimation(pos);

        // Границы подсветки (с расширением EPS, чтобы линии не зезали в грань блока)
        double minX = animMinX - EPS, minY = animMinY - EPS, minZ = animMinZ - EPS;
        double maxX = animMaxX + EPS, maxY = animMaxY + EPS, maxZ = animMaxZ + EPS;
        Box animBox = new Box(minX, minY, minZ, maxX, maxY, maxZ);

        // Камера внутри самой подсветки — грани изнутри не видны
        if (animBox.contains(cam)) {
            return;
        }

        // Пока подсветка едет между блоками, своими для окклюзии считаем все
        // блоки, которые она накрывает (иначе половина граней гасла бы
        // на середине переезда), плюс сам целевой блок.
        Set<BlockPos> own = overlappedBlocks();
        own.add(pos);

        // --- Фильтр 4: блок за стеной — не рисуем сквозь стены ---
        if (isOccluded(client, cam, animBox, own)) {
            return;
        }

        int color = Colors.clientColor();
        float a = MathHelper.clamp(opacity.getValue() / 100.0F, 0.0F, 1.0F);
        if (a <= 0.01F) return;
        int argb = (((int) (a * 255.0F)) << 24) | (color & 0x00FFFFFF);

        float yaw = client.gameRenderer.getCamera().getYaw();
        float pitch = client.gameRenderer.getCamera().getPitch();

        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();
        float aspect = w / (float) h;
        float half = thickness.getValue() * 0.5F;

        // 8 углов блока -> экран
        Vec3d[] c = {
                new Vec3d(minX, minY, minZ), new Vec3d(maxX, minY, minZ),
                new Vec3d(maxX, minY, maxZ), new Vec3d(minX, minY, maxZ),
                new Vec3d(minX, maxY, minZ), new Vec3d(maxX, maxY, minZ),
                new Vec3d(maxX, maxY, maxZ), new Vec3d(minX, maxY, maxZ)
        };
        float[][] s = new float[8][];
        for (int i = 0; i < 8; i++) {
            s[i] = project(c[i], cam, yaw, pitch, aspect, w, h);
            if (s[i] == null) return; // блок частично за камерой — пропускаем кадр
        }

        // --- Заливка граней (до линий, чтобы линии были поверх) ---
        if (fill.getValue()) {
            float fa = MathHelper.clamp(fillOpacity.getValue() / 100.0F, 0.0F, 1.0F);
            if (fa > 0.01F) {
                int fillArgb = (((int) (fa * 255.0F)) << 24) | (color & 0x00FFFFFF);
                // 6 граней: {индексы углов, ось нормали (0=x,1=y,2=z), наружу в min?}
                int[][] faces = {
                        {0, 1, 2, 3, 1, 1}, // низ  (y-)
                        {4, 5, 6, 7, 1, 0}, // верх (y+)
                        {0, 1, 5, 4, 2, 1}, // север (z-)
                        {3, 2, 6, 7, 2, 0}, // юг   (z+)
                        {0, 3, 7, 4, 0, 1}, // запад (x-)
                        {1, 2, 6, 5, 0, 0}  // восток (x+)
                };
                for (int[] f : faces) {
                    // Front-face: камера снаружи грани.
                    double camCoord = f[4] == 0 ? cam.x : (f[4] == 1 ? cam.y : cam.z);
                    double faceCoord = f[5] == 1
                            ? (f[4] == 0 ? minX : (f[4] == 1 ? minY : minZ))
                            : (f[4] == 0 ? maxX : (f[4] == 1 ? maxY : maxZ));
                    boolean front = f[5] == 1 ? camCoord < faceCoord : camCoord > faceCoord;
                    if (!front) continue;
                    // Окклюзия: центр грани не перекрыт другим блоком.
                    Vec3d center = new Vec3d(
                            (c[f[0]].x + c[f[2]].x) * 0.5D,
                            (c[f[0]].y + c[f[2]].y) * 0.5D,
                            (c[f[0]].z + c[f[2]].z) * 0.5D);
                    if (!segmentVisible(client, cam, center, own)) continue;
                    RenderUtil.fillQuad(context,
                            s[f[0]][0], s[f[0]][1],
                            s[f[1]][0], s[f[1]][1],
                            s[f[2]][0], s[f[2]][1],
                            s[f[3]][0], s[f[3]][1],
                            fillArgb);
                }
            }
        }

        if ("Полный".equals(type.getValue())) {
            int[][] edges = {
                    {0, 1}, {1, 2}, {2, 3}, {3, 0},   // низ
                    {4, 5}, {5, 6}, {6, 7}, {7, 4},   // верх
                    {0, 4}, {1, 5}, {2, 6}, {3, 7}    // вертикали
            };
            for (int[] e : edges) {
                Vec3d mid = new Vec3d(
                        (c[e[0]].x + c[e[1]].x) * 0.5D,
                        (c[e[0]].y + c[e[1]].y) * 0.5D,
                        (c[e[0]].z + c[e[1]].z) * 0.5D);
                if (!segmentVisible(client, cam, mid, own)) continue;
                line(context, s[e[0]], s[e[1]], half, argb);
            }
        } else {
            // Восемь уголков: в каждом по три сегмента «внутрь» блока.
            // Каждый сегмент проверяется на окклюзию отдельно — уголки
            // за стеной/сундуком не рисуются, видимые остаются.
            float len = cornerLength.getValue();
            for (int ix = 0; ix < 2; ix++) {
                double x = ix == 0 ? minX : maxX;
                double dx = ix == 0 ? len : -len;
                for (int iy = 0; iy < 2; iy++) {
                    double y = iy == 0 ? minY : maxY;
                    double dy = iy == 0 ? len : -len;
                    for (int iz = 0; iz < 2; iz++) {
                        double z = iz == 0 ? minZ : maxZ;
                        double dz = iz == 0 ? len : -len;
                        Vec3d corner = new Vec3d(x, y, z);
                        Vec3d segX = new Vec3d(x + dx, y, z);
                        Vec3d segY = new Vec3d(x, y + dy, z);
                        Vec3d segZ = new Vec3d(x, y, z + dz);
                        float[] p1 = project(corner, cam, yaw, pitch, aspect, w, h);
                        if (p1 == null) continue;
                        float[] p2 = project(segX, cam, yaw, pitch, aspect, w, h);
                        float[] p3 = project(segY, cam, yaw, pitch, aspect, w, h);
                        float[] p4 = project(segZ, cam, yaw, pitch, aspect, w, h);
                        if (p2 != null && segmentVisible(client, cam, corner.add(segX).multiply(0.5D), own)) {
                            line(context, p1, p2, half, argb);
                        }
                        if (p3 != null && segmentVisible(client, cam, corner.add(segY).multiply(0.5D), own)) {
                            line(context, p1, p3, half, argb);
                        }
                        if (p4 != null && segmentVisible(client, cam, corner.add(segZ).multiply(0.5D), own)) {
                            line(context, p1, p4, half, argb);
                        }
                    }
                }
            }
        }
    }

    /**
     * Видим ли конкретный сегмент: рейкаст из глаз до его середины.
     * Если луч упёрся в блок, не относящийся к подсветке — сегмент скрыт
     * и не рисуется. Это решает случай частичного перекрытия (например,
     * блок за сундуком): проверка коробкой целиком здесь не подходит,
     * нужны именно посегментные проверки.
     */
    private static boolean segmentVisible(MinecraftClient client, Vec3d eye, Vec3d mid, Set<BlockPos> own) {
        return !isBlocked(client, eye, mid, own);
    }

    /**
     * Проверка окклюзии: рейкаст из глаз до ближайшей к камере точки коробки,
     * при неудаче — до центра коробки. Если оба луча упёрлись в чужой блок,
     * подсветка скрыта стеной и не рисуется.
     */
    private static boolean isOccluded(MinecraftClient client, Vec3d eye, Box box, Set<BlockPos> own) {
        Vec3d nearest = new Vec3d(
                MathHelper.clamp(eye.x, box.minX, box.maxX),
                MathHelper.clamp(eye.y, box.minY, box.maxY),
                MathHelper.clamp(eye.z, box.minZ, box.maxZ));
        return isBlocked(client, eye, nearest, own)
                && isBlocked(client, eye, box.getCenter(), own);
    }

    /** true, если луч прервался блоком, которого нет в списке «своих». */
    private static boolean isBlocked(MinecraftClient client, Vec3d from, Vec3d to, Set<BlockPos> own) {
        if (from.squaredDistanceTo(to) < 1.0E-6D) {
            return false;
        }
        BlockHitResult hit = client.world.raycast(new RaycastContext(
                from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, client.player));
        if (hit.getType() == HitResult.Type.MISS) {
            return false;
        }
        return !own.contains(hit.getBlockPos());
    }

    /**
     * Границы подсветки: при включённой «Плавности» они экспоненциально
     * догоняют коробку целевого блока (шаг не зависит от FPS), иначе —
     * встают на блок мгновенно. Далеко переносить не пытаемся: если цель
     * дальше {@link #SMOOTH_SNAP_DISTANCE} блоков, ставим сразу.
     */
    private void updateAnimation(BlockPos pos) {
        double x0 = pos.getX(), y0 = pos.getY(), z0 = pos.getZ();
        double x1 = x0 + 1.0D, y1 = y0 + 1.0D, z1 = z0 + 1.0D;

        long now = System.nanoTime();
        if (!smooth.getValue() || !animInit || needsSnap(x0, y0, z0, x1, y1, z1)) {
            animMinX = x0;
            animMinY = y0;
            animMinZ = z0;
            animMaxX = x1;
            animMaxY = y1;
            animMaxZ = z1;
            animInit = true;
            animLastNanos = now;
            return;
        }

        float dt = animLastNanos == 0L ? 1.0F / 60.0F : (now - animLastNanos) / 1.0E9F;
        animLastNanos = now;
        dt = MathHelper.clamp(dt, 0.001F, 0.1F);

        // 1 - exp(-rate*dt): одинаковая скорость переезда при любом FPS.
        float rate = MathHelper.clamp(smoothSpeed.getValue(), 1.0F, 20.0F);
        float t = 1.0F - (float) Math.exp(-rate * dt);

        animMinX += (x0 - animMinX) * t;
        animMinY += (y0 - animMinY) * t;
        animMinZ += (z0 - animMinZ) * t;
        animMaxX += (x1 - animMaxX) * t;
        animMaxY += (y1 - animMaxY) * t;
        animMaxZ += (z1 - animMaxZ) * t;
    }

    /** Слишком далёкая цель (телепорт, прыжок камеры) — едем без анимации. */
    private boolean needsSnap(double x0, double y0, double z0, double x1, double y1, double z1) {
        return Math.abs(animMinX - x0) > SMOOTH_SNAP_DISTANCE
                || Math.abs(animMinY - y0) > SMOOTH_SNAP_DISTANCE
                || Math.abs(animMinZ - z0) > SMOOTH_SNAP_DISTANCE
                || Math.abs(animMaxX - x1) > SMOOTH_SNAP_DISTANCE
                || Math.abs(animMaxY - y1) > SMOOTH_SNAP_DISTANCE
                || Math.abs(animMaxZ - z1) > SMOOTH_SNAP_DISTANCE;
    }

    /** Блоки, которые накрывает текущая подсветка (обычно 1, на переезде до 8). */
    private Set<BlockPos> overlappedBlocks() {
        int x0 = MathHelper.floor(animMinX + 1.0E-4D);
        int y0 = MathHelper.floor(animMinY + 1.0E-4D);
        int z0 = MathHelper.floor(animMinZ + 1.0E-4D);
        int x1 = MathHelper.floor(animMaxX - 1.0E-4D);
        int y1 = MathHelper.floor(animMaxY - 1.0E-4D);
        int z1 = MathHelper.floor(animMaxZ - 1.0E-4D);
        Set<BlockPos> blocks = new HashSet<>();
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    blocks.add(new BlockPos(x, y, z));
                }
            }
        }
        return blocks;
    }

    /** Сброс плавности: следующая цель появится на месте, без переезда. */
    private void resetAnimation() {
        animInit = false;
        animLastNanos = 0L;
    }

    /**
     * Линия через ванильный fill(): translate в начало, поворот на угол
     * линии, осевой fill по локальной оси X. fill() учитывает матрицу.
     */
    private static void line(DrawContext context, float[] p1, float[] p2,
                             float half, int argb) {
        float dx = p2[0] - p1[0];
        float dy = p2[1] - p1[1];
        float len = MathHelper.sqrt(dx * dx + dy * dy);
        if (len < 0.5F) return;

        float angle = (float) Math.toDegrees(Math.atan2(dy, dx));
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(p1[0], p1[1], 0.0F);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(angle));
        RenderUtil.fill(context, 0, -half, len, half * 2f, argb);
        matrices.pop();
    }

    /**
     * Проекция мировой точки в scaled-пиксели — математика TargetESP
     * (базис камеры + реальный FOV кадра). null = за камерой.
     */
    private static float[] project(Vec3d point, Vec3d cam, float yaw, float pitch,
                                   float aspect, int w, int h) {
        double dx = point.x - cam.x;
        double dy = point.y - cam.y;
        double dz = point.z - cam.z;

        float yawRad = (float) Math.toRadians(yaw);
        float pitchRad = (float) Math.toRadians(pitch);
        float cosP = MathHelper.cos(pitchRad);

        float lX = -MathHelper.sin(yawRad) * cosP;
        float lY = -MathHelper.sin(pitchRad);
        float lZ = MathHelper.cos(yawRad) * cosP;
        float rX = -MathHelper.cos(yawRad);
        float rZ = -MathHelper.sin(yawRad);
        float uX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uY = MathHelper.cos(pitchRad);
        float uZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        float depth = (float) dx * lX + (float) dy * lY + (float) dz * lZ;
        if (depth < 0.1F) return null;

        float xOff = (float) dx * rX + (float) dz * rZ;
        float yOff = (float) dx * uX + (float) dy * uY + (float) dz * uZ;

        float ndcX = (xOff / depth) / (tanHalf * aspect);
        float ndcY = (yOff / depth) / tanHalf;
        if (MathHelper.abs(ndcX) > 2.0F || MathHelper.abs(ndcY) > 2.0F) return null;

        return new float[]{
                (ndcX * 0.5F + 0.5F) * w,
                (0.5F - ndcY * 0.5F) * h
        };
    }
}