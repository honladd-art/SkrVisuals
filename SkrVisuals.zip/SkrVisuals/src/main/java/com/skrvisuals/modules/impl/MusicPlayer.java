package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.music.MediaTracker;
import com.skrvisuals.ui.hud.HudElement;
import com.skrvisuals.ui.hud.HudElement.Renderer;
import com.skrvisuals.ui.hud.HudManager;

/**
 * Music Player: HUD-элемент с текущим треком — обложка, название, артист.
 * Источник — System Media Transport Controls (Windows), поэтому работает
 * и с Яндекс Музыкой, и со Spotify (и любым другим SMTC-плеером).
 */
public class MusicPlayer extends Module {
    private static MusicPlayer active;

    public MusicPlayer() {
        super(ModuleCategory.VISUALS, "Music Player", "Текущий трек с Яндекс Музыки или Spotify.");
        active = this;

        Renderer musicRenderer = (ctx, element) -> HudManager.renderMusicPlayer(ctx, element);
        HudManager.register(new HudElement("musicplayer", 6f, 240f, musicRenderer));

        MediaTracker.start();
    }

    public static MusicPlayer getActive() {
        return active;
    }
}