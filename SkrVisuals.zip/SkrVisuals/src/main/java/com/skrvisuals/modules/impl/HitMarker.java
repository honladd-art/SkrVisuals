package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * HitMarker: при ударе по игроку/мобу в точке удара появляется текстурка
 * hitmarker (assets/skrvisuals/textures/hitmarker/hitmarker.png).
 *
 * Точка удара — центр хитбокса цели (или точная точка попадания луча),
 * зафиксированная в момент атаки. Каждый кадр она проецируется в экранные
 * координаты (как в HitDamage, режим «Мир»), поэтому маркер «сидит» на
 * месте удара в мире.
 *
 * Настройки:
 *  - «Цель» — кого нужно ударить, чтобы маркер появился (Игроки / Мобы / Все);
 *  - «Размер» — размер маркера на экране, px.
 */
public class HitMarker extends Module {

    /** Сколько миллисекунд виден маркер. */
    private static final long DISPLAY_MS = 300L;

    /** Размер исходной текстуры. */
    private static final int TEX_WIDTH = 735;
    private static final int TEX_HEIGHT = 752;

    private static final Identifier TEXTURE =
            Identifier.of("skrvisuals", "textures/hitmarker/hitmarker.png");

    private static HitMarker active;
    private static boolean hooksRegistered = false;

    private final ModeSetting targetMode = new ModeSetting(
            "Цель", "Кого нужно ударить, чтобы появился маркер.",
            List.of("Игроки", "Мобы", "Все"), "Все");

    private final SliderSetting size = new SliderSetting(
            "Размер", "Размер маркера на экране, px.", 10f, 200f, 60f);

    /** Время последнего подходящего удара (мс) и точка удара в мире. */
    private long shownAt = Long.MIN_VALUE;
    private Vec3d hitPos;

    /** Экранная позиция точки удара (обновляется каждый кадр). */
    private float screenX;
    private float screenY;
    private boolean projected;

    public HitMarker() {
        super(ModuleCategory.COMBAT, "HitMarker", "Показывает hitmarker в точке удара по игроку/мобу.");
        setting(targetMode);
        setting(size);
        active = this;
        registerHooks();
    }

    private static void registerHooks() {
        if (hooksRegistered) {
            return;
        }
        hooksRegistered = true;

        // Удар по сущности (клиентский хук — как в HitDamage/HitColor).
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            HitMarker module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
            if (entity == player || entity instanceof FakePlayerEntity) {
                return ActionResult.PASS;
            }
            if (module.matches(entity)) {
                module.shownAt = System.currentTimeMillis();
                module.hitPos = module.findHitPoint(entity, hitResult);
            }
            return ActionResult.PASS;
        });

        // Проекция точки удара в экранные координаты каждый кадр.
        WorldRenderEvents.AFTER_ENTITIES.register(HitMarker::updateProjection);
        HudRenderCallback.EVENT.register(HitMarker::onHudRender);
    }

    /** Проверяет, подходит ли цель под настройку «Цель». */
    private boolean matches(Entity entity) {
        if (!(entity instanceof LivingEntity)) {
            return false;
        }
        return switch (targetMode.getValue()) {
            case "Игроки" -> entity instanceof PlayerEntity;
            case "Мобы" -> !(entity instanceof PlayerEntity);
            default -> true;
        };
    }

    /**
     * Точка удара: Fabric AttackEntityCallback передаёт hitResult = null
     * (см. ClientPlayerInteractionManagerMixin), поэтому точку считаем сами:
     * 1) crosshairTarget в момент атаки — точный raycast ваниллы по прицелу;
     * 2) иначе пересечение луча взгляда с хитбоксом цели (Box.raycast);
     * 3) иначе центр хитбокса.
     */
    private Vec3d findHitPoint(Entity entity, net.minecraft.util.hit.HitResult eventHitResult) {
        MinecraftClient client = MinecraftClient.getInstance();

        // 1) Точная точка ванилльного прицеливания.
        if (client != null
                && client.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult ehr
                && ehr.getEntity() == entity) {
            return ehr.getPos();
        }

        // 2) Пересечение луча взгляда с хитбоксом цели.
        if (client != null && client.player != null) {
            Vec3d eye = client.player.getEyePos();
            Vec3d dir = client.player.getRotationVec(1.0f).normalize();
            Vec3d end = eye.add(dir.multiply(64.0));
            var boxHit = entity.getBoundingBox().raycast(eye, end);
            if (boxHit.isPresent()) {
                return boxHit.get();
            }
        }

        // 3) Центр хитбокса.
        return entity.getBoundingBox().getCenter();
    }

    private static void updateProjection(WorldRenderContext context) {
        HitMarker module = active;
        if (module == null || !module.isEnabled() || module.hitPos == null) {
            return;
        }
        long age = System.currentTimeMillis() - module.shownAt;
        if (age < 0 || age > DISPLAY_MS) {
            return;
        }
        float[] out = new float[2];
        if (projectPoint(context, module.hitPos, out)) {
            module.screenX = out[0];
            module.screenY = out[1];
            module.projected = true;
        } else {
            module.projected = false;
        }
    }

    /**
     * out = {screenX, screenY}. false = точка за камерой.
     * Базис камеры + FOV из проекционной матрицы (как в HitDamage/TargetESP).
     */
    private static boolean projectPoint(WorldRenderContext context, Vec3d point, float[] out) {
        Vec3d d = point.subtract(context.camera().getPos());
        float yawRad = (float) Math.toRadians(context.camera().getYaw());
        float pitchRad = (float) Math.toRadians(context.camera().getPitch());
        float cosP = MathHelper.cos(pitchRad);

        float lX = -MathHelper.sin(yawRad) * cosP;
        float lY = -MathHelper.sin(pitchRad);
        float lZ = MathHelper.cos(yawRad) * cosP;
        float rX = -MathHelper.cos(yawRad);
        float rZ = -MathHelper.sin(yawRad);
        float uX = -MathHelper.sin(yawRad) * MathHelper.sin(pitchRad);
        float uY = MathHelper.cos(pitchRad);
        float uZ = MathHelper.cos(yawRad) * MathHelper.sin(pitchRad);

        float depth = (float) d.x * lX + (float) d.y * lY + (float) d.z * lZ;
        if (depth < 0.2F) {
            return false;
        }
        float xOff = (float) d.x * rX + (float) d.z * rZ;
        float yOff = (float) d.x * uX + (float) d.y * uY + (float) d.z * uZ;

        float tanHalf = 1.0F / context.projectionMatrix().m11();

        MinecraftClient client = MinecraftClient.getInstance();
        int scaledW = client.getWindow().getScaledWidth();
        int scaledH = client.getWindow().getScaledHeight();
        float aspect = scaledW / (float) scaledH;

        float ndcX = (xOff / depth) / (tanHalf * aspect);
        float ndcY = (yOff / depth) / tanHalf;
        if (MathHelper.abs(ndcX) > 1.4F || MathHelper.abs(ndcY) > 1.4F) {
            return false;
        }

        out[0] = (ndcX * 0.5F + 0.5F) * scaledW;
        out[1] = (0.5F - ndcY * 0.5F) * scaledH;
        return true;
    }

    private static void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        HitMarker module = active;
        if (module == null || !module.isEnabled() || module.hitPos == null) {
            return;
        }
        long age = System.currentTimeMillis() - module.shownAt;
        if (age < 0 || age > DISPLAY_MS) {
            return;
        }

        // Плавное появление/затухание: первые 15% — нарастание, дальше спад.
        float t = age / (float) DISPLAY_MS;
        float alpha = t < 0.15f ? t / 0.15f : 1f - (t - 0.15f) / 0.85f;
        alpha = MathHelper.clamp(alpha, 0f, 1f);
        if (alpha <= 0.02f) {
            return;
        }

        if (!module.projected) {
            return; // точка удара за камерой / вне экрана
        }

        int size = Math.max(4, Math.round(module.size.getValue()));

        // Немного увеличиваем маркер в начале (эффект «щёлка»).
        float pop = 1f + 0.15f * (1f - Math.min(1f, t / 0.25f));
        int drawSize = Math.round(size * pop);

        int x = Math.round(module.screenX) - drawSize / 2;
        int y = Math.round(module.screenY) - drawSize / 2;

        // Цвет маркера подхватывается из темы клиента (белые пиксели текстуры
        // перекрашиваются в акцентный цвет темы).
        int color = (Math.round(alpha * 255f) << 24) | (Colors.clientColor() & 0x00FFFFFF);

        // 13-арг оверлоад: region = вся текстура (735x752), масштабируется в size x size.
        // 11-арг оверлоад рисовал бы только верхний левый уголок size x size пикселей.
        context.drawTexture(RenderLayer::getGuiTextured, TEXTURE,
                x, y, 0.0F, 0.0F, drawSize, drawSize, TEX_WIDTH, TEX_HEIGHT, TEX_WIDTH, TEX_HEIGHT, color);
    }
}
