package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BindSetting;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * FreeLook: при зажатой кнопке включается третье лицо (как F5), и мышь
 * вращает свободную камеру — голова персонажа при этом не двигается.
 *
 * Реализация:
 * - MouseMixin перехватывает движение мыши (onCursorPos) и, пока фрилук
 *   активен, копит углы в freeYaw/freePitch вместо поворота игрока;
 * - CameraMixin в конце Camera#update подменяет yaw/pitch камеры нашими
 *   углами (setRotation пересчитывает кватернион и базис);
 * - onTick включает THIRD_PERSON_BACK при зажатии и возвращает прежнюю
 *   перспективу при отпускании.
 */
public class FreeLook extends Module {

    private static FreeLook active;

    private final BindSetting bind =
            new BindSetting("Бинд", "Кнопка свободного осмотра. СКМ по строке — привязать, ЛКМ — сброс.", GLFW.GLFW_KEY_F);

    private final SliderSetting sensitivity =
            new SliderSetting("Чувствительность", "Скорость вращения свободной камеры, %.", 10.0f, 200.0f, 100.0f);

    private final BooleanSetting invertPitch =
            new BooleanSetting("Инвертировать", "Инвертировать вертикальное вращение.", false);

    // Свободные углы камеры
    private static float freeYaw;
    private static float freePitch;
    private static boolean looking;
    private static Perspective prevPerspective;

    public FreeLook() {
        super(ModuleCategory.UTILITY, "FreeLook", "Свободный осмотр в третьем лице без поворота головы.");
        setting(bind);
        setting(sensitivity);
        setting(invertPitch);
        active = this;
    }

    @Override
    public void onTick(MinecraftClient client) {
        boolean pressed = isEnabled() && client.player != null && client.currentScreen == null && isBindPressed();

        if (pressed && !looking) {
            looking = true;
            freeYaw = client.player.getYaw();
            freePitch = client.player.getPitch();
            prevPerspective = client.options.getPerspective();
            client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!pressed && looking) {
            looking = false;
            // Вернуть перспективу, если игрок сам не переключил её во время осмотра.
            if (client.options.getPerspective() == Perspective.THIRD_PERSON_BACK) {
                client.options.setPerspective(prevPerspective != null ? prevPerspective : Perspective.FIRST_PERSON);
            }
        }
    }

    /* ============================ бинд ============================ */

    private boolean isBindPressed() {
        MinecraftClient client = MinecraftClient.getInstance();
        long handle = client.getWindow().getHandle();
        int code = bind.getKeyCode();
        if (code == -1) {
            return false; // бинд не назначен
        }
        if (code <= -100) { // кнопка мыши: -100 - glfwButton
            int button = -code - 100;
            return GLFW.glfwGetMouseButton(handle, button) == GLFW.GLFW_PRESS;
        }
        return InputUtil.isKeyPressed(handle, code);
    }

    /* ==================== статика для миксинов ==================== */

    public static boolean isLooking() {
        FreeLook module = active;
        return module != null && module.isEnabled() && looking;
    }

    public static float getFreeYaw() {
        return freeYaw;
    }

    public static float getFreePitch() {
        return freePitch;
    }

    /** Вызывается из MouseMixin вместо поворота головы игрока. */
    public static void addMouseDelta(double deltaX, double deltaY) {
        FreeLook module = active;
        if (module == null) {
            return;
        }
        // Формула ванильной чувствительности мыши (Mouse#updateMouse).
        double sens = module.isEnabled() ? module.sensitivity.getValue() / 100.0D : 1.0D;
        double f = MinecraftClient.getInstance().options.getMouseSensitivity().getValue() * 0.6D + 0.2D;
        f = f * f * f * 8.0D * sens;
        float factor = (float) f * 0.15F;

        freeYaw += (float) deltaX * factor;
        float pitchDelta = (float) deltaY * factor * (module.invertPitch.getValue() ? -1f : 1f);
        freePitch = MathHelper.clamp(freePitch - pitchDelta, -90.0F, 90.0F);
    }
}
