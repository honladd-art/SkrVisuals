package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import net.minecraft.client.MinecraftClient;

/**
 * NoRender: hides distracting things in the game.
 * ScoreBoard — the sidebar scoreboard; Fire — the fire overlay on screen
 * (both via HUD mixins); Grass — plants/grass in the world (render type mixin).
 */
public class NoRender extends Module {

    public enum Feature {
        SCOREBOARD, FIRE, GRASS, HURTCAM, PUMPKIN, FOG, VIGNETTE
    }

    private static NoRender active;

    private final BooleanSetting hideScoreboard =
            new BooleanSetting("ScoreBoard", "Скрывает скорборд сбоку экрана.", true);
    private final BooleanSetting hideFire =
            new BooleanSetting("Огонь на экране", "Скрывает огонь, когда горишь.", true);
    private final BooleanSetting hideGrass =
            new BooleanSetting("Трава", "Скрывает траву и растения в мире.", true);
    private final BooleanSetting noHurtCam =
            new BooleanSetting("NoHurtCam", "Убирает тряску экрана при получении урона.", true);
    private final BooleanSetting noPumpkin =
            new BooleanSetting("NoPumpkin", "Убирает оверлей тыквы, когда она надета.", true);
    private final BooleanSetting noFog =
            new BooleanSetting("NoFog", "Убирает туман в мире.", true);
    private final BooleanSetting noVignette =
            new BooleanSetting("NoVignette", "Убирает виньетку по краям экрана.", true);

    /** Remembers the last grass state to refresh chunk meshes on toggle. */
    private boolean lastGrassHidden = false;

    public NoRender() {
        super(ModuleCategory.UTILITY, "NoRender", "Убирает мешающие штуки в игре.");
        setting(hideScoreboard);
        setting(hideFire);
        setting(hideGrass);
        setting(noHurtCam);
        setting(noPumpkin);
        setting(noFog);
        setting(noVignette);
        active = this;
        this.lastGrassHidden = shouldHide(Feature.GRASS);
    }

    /** Queried by mixins. Safe to call from any render phase. */
    public static boolean shouldHide(Feature feature) {
        NoRender module = active;
        if (module == null || !module.isEnabled()) {
            return false;
        }
        return switch (feature) {
            case SCOREBOARD -> module.hideScoreboard.getValue();
            case FIRE -> module.hideFire.getValue();
            case GRASS -> module.hideGrass.getValue();
            case HURTCAM -> module.noHurtCam.getValue();
            case PUMPKIN -> module.noPumpkin.getValue();
            case FOG -> module.noFog.getValue();
            case VIGNETTE -> module.noVignette.getValue();
        };
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Chunk meshes cache their geometry: request a rebuild once when the
        // grass option flips so the change is visible immediately.
        boolean hidden = shouldHide(Feature.GRASS);
        if (hidden != this.lastGrassHidden) {
            this.lastGrassHidden = hidden;
            if (client.worldRenderer != null) {
                client.worldRenderer.scheduleTerrainUpdate();
            }
        }
    }
}