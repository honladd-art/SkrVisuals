package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;

import java.util.List;

/**
 * KillSounds: играет звук, когда твоя цель умирает после твоего удара.
 *
 * Механика: запоминаем последнюю атакованную сущность (только клиентскую —
 * в синглплеере событие срабатывает и на интегрированном сервере, там
 * сущность серверная, и мы её игнорируем). Если в течение KILL_WINDOW_MS
 * она начала анимацию смерти (deathTime > 0) или удалена из мира —
 * засчитываем убийство.
 */
public class KillSounds extends Module {

    private static KillSounds active;

    /** Защита от повторной регистрации события. */
    private static boolean hookRegistered = false;

    /** Сколько миллисекунд после удара смерть цели засчитывается как твоё убийство. */
    private static final long KILL_WINDOW_MS = 5000L;

    private static SoundEvent sound(String name) {
        return SoundEvent.of(Identifier.of("skrvisuals", name));
    }

    private static final SoundEvent CS   = sound("killsounds.cs");
    private static final SoundEvent TANK = sound("killsounds.tank");

    private final ModeSetting sound = new ModeSetting(
            "Звук",
            "Какой звук играть при убийстве.",
            List.of("CS", "Tank"),
            "CS"
    );

    private final BooleanSetting players =
            new BooleanSetting("Игроки", "Звук при убийстве игроков.", true);

    private final BooleanSetting mobs =
            new BooleanSetting("Мобы", "Звук при убийстве мобов и животных.", true);

    private final SliderSetting volume =
            new SliderSetting("Громкость", "Громкость звука убийства.", 0.0f, 1.0f, 1.0f);

    /** Последняя сущность, по которой ударил, и время удара. */
    private Entity lastTarget;
    private long lastHitTime;

    public KillSounds() {
        super(ModuleCategory.COMBAT, "KillSounds", "Проигрывает звук, когда ты убиваешь сущность.");
        setting(sound);
        setting(players);
        setting(mobs);
        setting(volume);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) return;
        hookRegistered = true;

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            KillSounds module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
            // КЛЮЧЕВАЯ ПРОВЕРКА: в синглплеере событие приходит и от интегрированного
            // сервера (Server thread в логе). Там сущность — серверная копия, её мир
            // не совпадает с клиентским, и она затирала нашу запись. Берём только клиент.
            if (!(world instanceof ClientWorld)) {
                return ActionResult.PASS;
            }
            // Фейк бессмертен — не считаем
            if (entity instanceof FakePlayerEntity) {
                return ActionResult.PASS;
            }
            if (!module.targetAllowed(entity)) {
                return ActionResult.PASS;
            }
            module.lastTarget = entity;
            module.lastHitTime = System.currentTimeMillis();
            System.out.println("[SKR] KS: цель записана (клиент): " + entity.getType().getName().getString());
            return ActionResult.PASS; // удар не отменяем — просто запомнили цель
        });
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (!isEnabled()) {
            reset();
            return;
        }
        Entity target = lastTarget;
        if (target == null) {
            return;
        }
        // Вышли из мира / сменили измерение — сбрасываем
        if (client.world == null || target.getWorld() != client.world) {
            reset();
            return;
        }
        // Прошло слишком много времени после удара — не убийство
        if (System.currentTimeMillis() - lastHitTime > KILL_WINDOW_MS) {
            reset();
            return;
        }

        boolean died;
        if (target instanceof LivingEntity living) {
            died = living.deathTime > 0 || living.isRemoved();
        } else {
            died = target.isRemoved();
        }

        if (died) {
            System.out.println("[SKR] KS: убийство засчитано, играю " + sound.getValue());
            playKillSound();
            reset();
        }
    }

    private void playKillSound() {
        float vol = volume.getValue();
        if (vol <= 0.0f) {
            return;
        }
        SoundEvent chosen = switch (sound.getValue()) {
            case "CS" -> CS;
            default   -> TANK;
        };
        MinecraftClient.getInstance().getSoundManager().play(
                PositionedSoundInstance.master(chosen, 1.0f, vol)
        );
    }

    /** Фильтр цели: игроки и мобы переключаются отдельно. */
    private boolean targetAllowed(Entity target) {
        return target instanceof PlayerEntity ? players.getValue() : mobs.getValue();
    }

    private void reset() {
        lastTarget = null;
        lastHitTime = 0L;
    }
}