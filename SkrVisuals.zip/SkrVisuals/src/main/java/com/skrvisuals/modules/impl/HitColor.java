package com.skrvisuals.modules.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;

/**
 * HitColor: при ударе по игроку/мобу цель на короткое время перекрашивается
 * в цвет темы. Настройки:
 * - «Прозрачность» — сила перекраски (0 = нет эффекта, 100 = полностью залито).
 * - «Режим» — «Только игрок» (красится скин) или «Игрок с бронёй» (красится
 *   ещё и слой брони через ArmorFeatureRenderer).
 *
 * Тело красится через LivingEntityRenderer#getMixColor (смеситель цвета модели),
 * броня — через оборачивание VertexConsumerProvider внутри ArmorFeatureRenderer.
 */
public class HitColor extends Module {

    private static HitColor active;
    private static boolean hookRegistered = false;

    /** Сколько миллисекунд цель остаётся окрашенной после удара. */
    private static final long TINT_MS = 500L;

    private final SliderSetting opacity =
            new SliderSetting("Прозрачность", "Сила перекраски цели в цвет темы, %.", 0f, 100f, 60f);

    private final ModeSetting mode = new ModeSetting(
            "Режим",
            "Что красить: только скин или скин вместе с бронёй.",
            List.of("Только игрок", "Игрок с бронёй"),
            "Только игрок"
    );

    /** entity -> время, до которого цель окрашена (клиентский тред). */
    private static final Map<Entity, Long> tintedUntil = new ConcurrentHashMap<>();

    /**
     * EntityRenderState -> сила окраски (0..1). Заполняется в
     * LivingEntityRenderer#updateRenderState, читается в getMixColor.
     * Рендер-стейтов ровно по одному на рендерер, поэтому карта крошечная.
     */
    private static final Map<EntityRenderState, Float> stateStrength = new ConcurrentHashMap<>();

    /** Сила окраски сущности, которая рендерится прямо сейчас (для feature-рендереров). */
    private static float currentStrength = 0f;

    public HitColor() {
        super(ModuleCategory.COMBAT, "HitColor", "Перекрашивает игрока/моба в цвет темы при попадании.");
        setting(opacity);
        setting(mode);
        active = this;
        registerHook();
    }

    public static HitColor getActive() {
        return active;
    }

    private static void registerHook() {
        if (hookRegistered) {
            return;
        }
        hookRegistered = true;

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            HitColor module = active;
            if (module == null || !module.isEnabled()) {
                return ActionResult.PASS;
            }
            if (!(world instanceof net.minecraft.client.world.ClientWorld)) {
                return ActionResult.PASS;
            }
            if (!(entity instanceof LivingEntity)) {
                return ActionResult.PASS;
            }
            // Фейка обслуживает FakePlayer.tryInterceptAttack (onFakeAttacked)
            if (entity instanceof FakePlayerEntity) {
                return ActionResult.PASS;
            }
            tint(entity);
            return ActionResult.PASS;
        });
    }

    /** Удар по фейковому игроку — вызывается из FakePlayer.tryInterceptAttack. */
    public static void onFakeAttacked(PlayerEntity attacker, Entity target) {
        if (active == null || !active.isEnabled()) {
            return;
        }
        tint(target);
    }

    private static void tint(Entity target) {
        if (active.opacity.getValue() <= 0f) {
            return;
        }
        tintedUntil.put(target, System.currentTimeMillis() + TINT_MS);
    }

    /**
     * Сила окраски сущности с учётом «Прозрачности» и плавного затухания.
     * Вызывается только на клиентском рендер-треде.
     */
    private static float strengthFor(Entity entity) {
        HitColor module = active;
        if (module == null || !module.isEnabled()) {
            return 0f;
        }
        float base = module.opacity.getValue() / 100f;
        if (base <= 0f) {
            return 0f;
        }
        Long until = tintedUntil.get(entity);
        if (until == null) {
            return 0f;
        }
        long now = System.currentTimeMillis();
        if (now >= until) {
            tintedUntil.remove(entity, until);
            return 0f;
        }
        float remain = (until - now) / (float) TINT_MS;
        return base * Math.min(1f, Math.max(0f, remain));
    }

    /** Вызывается из миксина LivingEntityRenderer#updateRenderState. */
    public static void recordRenderState(EntityRenderState state, Entity entity) {
        float strength = strengthFor(entity);
        if (strength > 0f) {
            stateStrength.put(state, strength);
        } else {
            stateStrength.remove(state);
        }
    }

    /** Начало рендера living-сущности: фиксируем силу окраски для feature-ов. */
    public static void beginRender(EntityRenderState state) {
        Float strength = stateStrength.get(state);
        currentStrength = strength == null ? 0f : strength;
    }

    /** Конец рендера living-сущности. */
    public static void endRender() {
        currentStrength = 0f;
    }

    /**
     * Цвет для LivingEntityRenderer#getMixColor. 0 означает «не вмешиваться».
     * Цвет = белый, смешанный с цветом темы по силе окраски (ColorHelper.mix
     * перемножает каналы, поэтому «белый» является нейтральным элементом).
     */
    public static int bodyTint(EntityRenderState state) {
        float strength = currentStrength > 0f ? currentStrength : 0f;
        if (strength <= 0f) {
            return 0;
        }
        return blendTowardsTheme(0xFFFFFFFF, strength);
    }

    /** Сила окраски брони текущей сущности (учитывает режим «Игрок с бронёй»). */
    public static float armorStrength() {
        if (currentStrength <= 0f) {
            return 0f;
        }
        HitColor module = active;
        if (module == null || !module.isEnabled()
                || !"Игрок с бронёй".equals(module.mode.getValue())) {
            return 0f;
        }
        return currentStrength;
    }

    /** Смешивает цвет from с цветом темы: from + (theme - from) * strength. */
    private static int blendTowardsTheme(int from, float strength) {
        int theme = Colors.clientColor();
        int tr = (theme >> 16) & 0xFF;
        int tg = (theme >> 8) & 0xFF;
        int tb = theme & 0xFF;
        int fr = (from >> 16) & 0xFF;
        int fg = (from >> 8) & 0xFF;
        int fb = from & 0xFF;
        int r = fr + Math.round((tr - fr) * strength);
        int g = fg + Math.round((tg - fg) * strength);
        int b = fb + Math.round((tb - fb) * strength);
        return (from & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    /**
     * Оборачивает провайдер буферов так, что все вершины получают цвет,
     * смешанный с цветом темы по силе окраски. Используется для брони.
     */
    public static VertexConsumerProvider wrap(VertexConsumerProvider provider, float strength) {
        final float s = Math.min(1f, Math.max(0f, strength));
        return layer -> new TintedVertexConsumer(provider.getBuffer(layer), s);
    }

    /**
     * Декоратор VertexConsumer: перекрашивает вызовы color(...),
     * всё остальное прозрачно делегирует настоящему буферу.
     */
    private static final class TintedVertexConsumer implements VertexConsumer {
        private final VertexConsumer delegate;
        private final float strength;

        private TintedVertexConsumer(VertexConsumer delegate, float strength) {
            this.delegate = delegate;
            this.strength = strength;
        }

        @Override
        public VertexConsumer vertex(float x, float y, float z) {
            this.delegate.vertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer color(int red, int green, int blue, int alpha) {
            int original = (Math.max(0, Math.min(255, red)) << 16)
                    | (Math.max(0, Math.min(255, green)) << 8)
                    | Math.max(0, Math.min(255, blue));
            int blended = blendTowardsTheme(original, this.strength);
            this.delegate.color((blended >> 16) & 0xFF, (blended >> 8) & 0xFF, blended & 0xFF, alpha);
            return this;
        }

        @Override
        public VertexConsumer texture(float u, float v) {
            this.delegate.texture(u, v);
            return this;
        }

        @Override
        public VertexConsumer overlay(int u, int v) {
            this.delegate.overlay(u, v);
            return this;
        }

        @Override
        public VertexConsumer light(int u, int v) {
            this.delegate.light(u, v);
            return this;
        }

        @Override
        public VertexConsumer normal(float x, float y, float z) {
            this.delegate.normal(x, y, z);
            return this;
        }
    }
}