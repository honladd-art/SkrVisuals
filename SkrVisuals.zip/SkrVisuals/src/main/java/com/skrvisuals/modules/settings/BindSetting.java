package com.skrvisuals.modules.settings;

public class BindSetting extends Setting {
    private int keyCode;

    public BindSetting(String name, String description, int defaultKey) {
        super(name, description);
        this.keyCode = defaultKey;
    }

    public int getKeyCode() {
        return this.keyCode;
    }

    public void setKeyCode(int keyCode) {
        this.keyCode = keyCode;
    }
}