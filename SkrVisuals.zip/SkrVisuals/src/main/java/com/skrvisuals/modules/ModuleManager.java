package com.skrvisuals.modules;

import com.skrvisuals.modules.impl.Animations;
import com.skrvisuals.modules.impl.AspectRatio;
import com.skrvisuals.modules.impl.AutoSprint;
import com.skrvisuals.modules.impl.BlockOverlay;
import com.skrvisuals.modules.impl.BotPractice;
import com.skrvisuals.modules.impl.ChinaHat;
import com.skrvisuals.modules.impl.CustomFog;
import com.skrvisuals.modules.impl.CustomCape;
import com.skrvisuals.modules.impl.CustomCrosshair;
import com.skrvisuals.modules.impl.CustomHotbar;
import com.skrvisuals.modules.impl.CustomHitbox;
import com.skrvisuals.modules.impl.CustomScreen;
import com.skrvisuals.modules.impl.CustomSky;
import com.skrvisuals.modules.impl.FakePlayer;
import com.skrvisuals.modules.impl.Friends;
import com.skrvisuals.modules.impl.FreeLook;
import com.skrvisuals.modules.impl.FullBright;
import com.skrvisuals.modules.impl.GuiBackground;
import com.skrvisuals.modules.impl.HitSounds;
import com.skrvisuals.modules.impl.HitColor;
import com.skrvisuals.modules.impl.HitDamage;
import com.skrvisuals.modules.impl.HitMarker;
import com.skrvisuals.modules.impl.Hud;
import com.skrvisuals.modules.impl.JumpCircle;
import com.skrvisuals.modules.impl.MusicPlayer;
import com.skrvisuals.modules.impl.NameProtect;
import com.skrvisuals.modules.impl.KillEffect;
import com.skrvisuals.modules.impl.KillSounds;
import com.skrvisuals.modules.impl.NoRender;
import com.skrvisuals.modules.impl.Optimize;
import com.skrvisuals.modules.impl.Particles;
import com.skrvisuals.modules.impl.SuperOptimize;
import com.skrvisuals.modules.impl.Points;
import com.skrvisuals.modules.impl.SwingAnimation;
import com.skrvisuals.modules.impl.TargetESP;
import com.skrvisuals.modules.impl.Trails;
import com.skrvisuals.modules.impl.ViewModel;
import com.skrvisuals.modules.impl.Vignette;
import com.skrvisuals.modules.impl.Zoom;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Module registry: создаёт все модули и держит их отсортированный список.
 */
public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        Friends.init();
        registerAll();
        this.modules.sort(Comparator.comparing(Module::getName));
    }

    private void registerAll() {
        register(new Particles());
        register(new TargetESP());
        register(new Points());
        register(new FullBright());
        register(new JumpCircle());
        register(new Trails());
        register(new ChinaHat());
        register(new BlockOverlay());
        register(new Hud());
        register(new MusicPlayer());
        register(new AutoSprint());
        register(new NoRender());
        register(new SwingAnimation());
        register(new ViewModel());
        register(new Vignette());
        register(new HitSounds());
        register(new HitColor());
        register(new KillSounds());
        register(new KillEffect());
        register(new HitDamage());
        register(new HitMarker());
        register(new FakePlayer());
        register(new BotPractice());
        register(new Zoom());
        register(new CustomFog());
        register(new CustomCrosshair());
        register(new CustomHotbar());
        register(new FreeLook());
        register(new CustomHitbox());
        register(new CustomCape());
        register(new CustomScreen());
        register(new CustomSky());
        register(new AspectRatio());
        register(new Optimize());
        register(new SuperOptimize());
        register(new NameProtect());
        register(new GuiBackground());
        register(new Animations());
    }

    private void register(Module module) {
        this.modules.add(module);
    }

    public List<Module> getModules() {
        return this.modules;
    }

    public List<Module> getModules(ModuleCategory category) {
        List<Module> out = new ArrayList<>();
        for (Module m : this.modules) {
            if (m.getCategory() == category) {
                out.add(m);
            }
        }
        return out;
    }
}