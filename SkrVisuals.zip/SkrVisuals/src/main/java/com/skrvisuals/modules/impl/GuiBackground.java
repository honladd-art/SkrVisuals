package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import com.skrvisuals.ui.clickgui.ClickScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * GuiBackground: картинка в углу экрана (по умолчанию — справа снизу),
 * видна ТОЛЬКО внутри открытого ClickGUI (не в игре и не в чате).
 *
 * Почему не HudRenderCallback: HUD в 1.21+ блюрится вместе с миром под
 * открытым Screen — картинка выглядела замыленной. Поэтому рисуем её
 * прямо в ClickScreen.render() после затемнения — чётко и поверх панели.
 *
 * Перетаскивание: в ClickGUI зажми ЛКМ на картинке и тащи.
 * «Заблокировать перемещение» запрещает drag.
 *
 * Позиция хранится как отступ от правого/нижнего края (переживает смену
 * разрешения окна), сбрасывается при перезапуске игры.
 */
public class GuiBackground extends Module {

    private static GuiBackground active;

    /** Русское название -> имя файла в assets/skrvisuals/textures/gui/. */
    private static final Map<String, String> IMAGES = Map.of(
            "Кошкадевочка",   "catgirl.png",
            "Кошкадевочка 2", "catgirl2.png",
            "Эмилия",        "emilia.png",
            "Горничная",     "furrymaid.png",
            "Кис-кис",       "kiskis.png",
            "Обезьяна",      "monkey.png",
            "Иисус",    "mylove.png",
            "Нолик",         "nolik.png",
            "Няшка",         "nyashka.png",
            "Пинки",         "pinky.png"
    );

    /** Порядок в настройках. */
    private static final List<String> IMAGE_NAMES = List.of(
            "Нолик", "Няшка", "Кис-кис", "Пинки", "Эмилия",
            "Кошкадевочка", "Кошкадевочка 2", "Горничная",
            "Иисус", "Обезьяна"
    );

    // ----- drag-состояние (сбрасывается при перезапуске игры) -----
    private static boolean dragging = false;
    private static int dragStartMX, dragStartMY;
    private static int dragStartOffsetX, dragStartOffsetY;
    /** Отступ картинки от правого/нижнего края экрана, scaled-px. */
    private static int offsetX = 10, offsetY = 10;

    /** Кэш пропорций картинок (ширина/высота), читается один раз. */
    private static final Map<String, Float> ASPECTS = new ConcurrentHashMap<>();

    private final ModeSetting image = new ModeSetting(
            "Картинка",
            "Какая текстура отображается в углу.",
            IMAGE_NAMES,
            "Нолик"
    );

    private final SliderSetting size =
            new SliderSetting("Размер", "Высота картинки в пикселях.", 40.0f, 400.0f, 150.0f);

    private final BooleanSetting lockPosition =
            new BooleanSetting("Забл. перемещ.", "Запрещает перетаскивание картинки.", false);

    public GuiBackground() {
        super(ModuleCategory.VISUALS, "GuiBackground", "Картинка внутри ClickGUI. Двигается зажатой ЛКМ.");
        setting(image);
        setting(size);
        setting(lockPosition);
        active = this;
        // Никаких HudRenderCallback: рисуем из ClickScreen.render()
    }

    /* ========================= отрисовка ========================= */

    /** Вызывается из ClickScreen.render() — картинка видна только в GUI. */
    public static void renderInGui(DrawContext context) {
        GuiBackground module = active;
        if (module == null || !module.isEnabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();

        int h = Math.max(16, Math.round(module.size.getValue()));
        int w = Math.max(16, Math.round(h * module.aspect()));

        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();

        // Перетаскивание: зажатая ЛКМ таскает картинку
        if (dragging) {
            long handle = client.getWindow().getHandle();
            double[] xs = new double[1], ys = new double[1];
            GLFW.glfwGetCursorPos(handle, xs, ys);
            double scale = client.getWindow().getScaleFactor();
            int mx = (int) Math.round(xs[0] / scale);
            int my = (int) Math.round(ys[0] / scale);

            offsetX = MathHelper.clamp(dragStartOffsetX + (dragStartMX - mx), 0, Math.max(0, sw - w));
            offsetY = MathHelper.clamp(dragStartOffsetY + (dragStartMY - my), 0, Math.max(0, sh - h));

            // Отпустили ЛКМ (в т.ч. мимо окна) — закончили
            if (GLFW.glfwGetMouseButton(handle, 0) != GLFW.GLFW_PRESS) {
                dragging = false;
            }
        }

        int x = sw - w - offsetX;
        int y = sh - h - offsetY;

        String file = IMAGES.getOrDefault(module.image.getValue(), "nolik.png");
        Identifier id = Identifier.of("skrvisuals", "textures/gui/" + file);
        context.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0.0F, 0.0F, w, h, w, h, 0xFFFFFFFF);
    }

    /** Текущие экранные границы картинки (для hit-теста drag'а). */
    private static int[] bounds() {
        GuiBackground module = active;
        MinecraftClient client = MinecraftClient.getInstance();
        int h = Math.max(16, Math.round(module.size.getValue()));
        int w = Math.max(16, Math.round(h * module.aspect()));
        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();
        return new int[]{sw - w - offsetX, sh - h - offsetY, w, h};
    }

    /** Пропорции картинки (ширина/высота), читаются один раз из PNG. */
    private float aspect() {
        String file = IMAGES.getOrDefault(image.getValue(), "nolik.png");
        Float cached = ASPECTS.get(file);
        if (cached != null) {
            return cached;
        }
        float a = 1.0F;
        try {
            Identifier id = Identifier.of("skrvisuals", "textures/gui/" + file);
            InputStream in = MinecraftClient.getInstance().getResourceManager()
                    .getResourceOrThrow(id).getInputStream();
            try (NativeImage img = NativeImage.read(in)) {
                a = img.getWidth() / (float) img.getHeight();
            }
        } catch (Exception ignored) {
            // не прочитался — рисуем квадратом
        }
        ASPECTS.put(file, a);
        return a;
    }

    /* ==================== перетаскивание ==================== */

    /**
     * Вызывается из ClickScreen ПЕРЕД обработкой кликов GUI.
     * true — клик попал на картинку, дальше в модули не передаём.
     */
    public static boolean tryStartDrag(double mouseX, double mouseY, int button) {
        GuiBackground module = active;
        if (module == null || !module.isEnabled() || module.lockPosition.getValue()) {
            return false;
        }
        if (!(MinecraftClient.getInstance().currentScreen instanceof ClickScreen)) {
            return false; // таскаем только в ClickGUI
        }
        if (button != 0) {
            return false; // только ЛКМ
        }

        int[] b = bounds();
        if (mouseX >= b[0] && mouseX <= b[0] + b[2] && mouseY >= b[1] && mouseY <= b[1] + b[3]) {
            dragging = true;
            dragStartMX = (int) mouseX;
            dragStartMY = (int) mouseY;
            dragStartOffsetX = offsetX;
            dragStartOffsetY = offsetY;
            return true;
        }
        return false;
    }

    /** Вызывается из ClickScreen при отпускании кнопки мыши. */
    public static void stopDrag() {
        dragging = false;
    }
}