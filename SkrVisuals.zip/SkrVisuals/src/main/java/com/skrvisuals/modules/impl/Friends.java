package com.skrvisuals.modules.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.skrvisuals.config.ConfigManager;

import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Friends: статический менеджер друзей (без модуля-карточки). Управление —
 * через панель раздела "Friends" в ClickGUI или команды
 * {@code .friend add <ник>} / {@code .friend remove <ник>} / {@code .friend clear}.
 */
public final class Friends {
    private static final List<String> friends = new ArrayList<>();

    private static boolean chinaHatOnFriends = false;
    private static boolean trailsOnFriends = false;

    private static boolean chatHookRegistered = false;

    private Friends() {
    }

    /** Вызывается один раз при старте клиента. */
    public static void init() {
        registerChatHook();
    }

    private static void registerChatHook() {
        if (chatHookRegistered) {
            return;
        }
        chatHookRegistered = true;
        ClientSendMessageEvents.ALLOW_CHAT.register(Friends::onChat);
    }

    // ------------------------------------------------------------------ list
    public static List<String> getFriends() {
        return Collections.unmodifiableList(friends);
    }

    /** Добавляет друга (без учёта регистра). false — если ник пустой или уже есть. */
    public static boolean add(String name) {
        if (name == null) {
            return false;
        }
        String nick = name.trim();
        if (nick.isEmpty() || nick.length() > 16) {
            return false;
        }
        if (isFriend(nick)) {
            return false;
        }
        boolean added = friends.add(nick);
        if (added) {
            ConfigManager.save();
        }
        return added;
    }

    /** Удаляет друга по нику (без учёта регистра). false — если его нет. */
    public static boolean remove(String name) {
        if (name == null) {
            return false;
        }
        boolean removed = false;
        for (var it = friends.iterator(); it.hasNext(); ) {
            if (it.next().equalsIgnoreCase(name.trim())) {
                it.remove();
                removed = true;
            }
        }
        if (removed) {
            ConfigManager.save();
        }
        return removed;
    }

    public static void clear() {
        if (!friends.isEmpty()) {
            friends.clear();
            ConfigManager.save();
        }
    }

    /** Является ли игрок с данным ником другом. */
    public static boolean isFriend(String name) {
        if (name == null) {
            return false;
        }
        for (String f : friends) {
            if (f.equalsIgnoreCase(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Является ли сущность другом. Проверяется и ник профиля, и отображаемое
     * имя (намтаг, без цветовых кодов) — серверы часто переименовывают игроков.
     */
    public static boolean isFriend(net.minecraft.entity.Entity entity) {
        if (entity == null) {
            return false;
        }
        if (entity instanceof net.minecraft.entity.player.PlayerEntity player) {
            if (isFriend(player.getGameProfile().getName())) {
                return true;
            }
        }
        String display = entity.getName() != null ? entity.getName().getString() : "";
        return isFriend(stripCodes(display));
    }

    /** Убирает коды форматирования (§a, §l и т.п.) из строки. */
    private static String stripCodes(String s) {
        return s == null ? "" : s.replaceAll("§.", "");
    }

    // --------------------------------------------------------------- toggles
    public static boolean isChinaHatOnFriends() {
        return chinaHatOnFriends;
    }

    public static void setChinaHatOnFriends(boolean value) {
        chinaHatOnFriends = value;
    }

    public static boolean isTrailsOnFriends() {
        return trailsOnFriends;
    }

    public static void setTrailsOnFriends(boolean value) {
        trailsOnFriends = value;
    }

    // ----------------------------------------------------------------- chat
    /** Перехватываем {@code .friend ...} в чате, не отправляя его на сервер. */
    private static boolean onChat(String message) {
        if (!message.toLowerCase().startsWith(".friend")) {
            return true;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return true;
        }

        String[] parts = message.trim().split("\\s+");
        String sub = parts.length > 1 ? parts[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> {
                if (parts.length < 3) {
                    feedback(client, "§cИспользование: .friend add <ник>");
                    return false;
                }
                boolean added = add(parts[2]);
                feedback(client, added ? "§aДруг §f" + parts[2] + " §aдобавлен"
                        : "§cДруг §f" + parts[2] + " §cуже в списке");
            }
            case "remove" -> {
                if (parts.length < 3) {
                    feedback(client, "§cИспользование: .friend remove <ник>");
                    return false;
                }
                boolean removed = remove(parts[2]);
                feedback(client, removed ? "§aДруг §f" + parts[2] + " §aудалён"
                        : "§cДруг §f" + parts[2] + " §cне найден");
            }
            case "clear" -> {
                clear();
                feedback(client, "§aСписок друзей очищен");
            }
            default -> feedback(client, "§cИспользование: .friend add/remove/clear <ник>");
        }
        return false; // команду не отправляем на сервер
    }

    private static void feedback(MinecraftClient client, String text) {
        client.player.sendMessage(Text.literal(text), true);
    }

    // --------------------------------------------------------------- config
    public static com.google.gson.JsonObject saveJson() {
        com.google.gson.JsonObject o = new com.google.gson.JsonObject();
        com.google.gson.JsonArray names = new com.google.gson.JsonArray();
        for (String f : friends) {
            names.add(f);
        }
        o.add("names", names);
        o.addProperty("chinaHat", chinaHatOnFriends);
        o.addProperty("trails", trailsOnFriends);
        return o;
    }

    public static void loadJson(com.google.gson.JsonObject o) {
        friends.clear();
        if (o.has("names") && o.get("names").isJsonArray()) {
            for (var el : o.getAsJsonArray("names")) {
                String nick = el.getAsString();
                if (!nick.isEmpty() && nick.length() <= 16 && !isFriend(nick)) {
                    friends.add(nick);
                }
            }
        }
        chinaHatOnFriends = o.has("chinaHat") && o.get("chinaHat").getAsBoolean();
        trailsOnFriends = o.has("trails") && o.get("trails").getAsBoolean();
    }
}