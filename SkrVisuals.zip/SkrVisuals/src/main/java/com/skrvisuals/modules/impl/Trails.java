package com.skrvisuals.modules.impl;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Trails: draws fading ribbon quads behind the player while moving
 * (port of the reference module).
 */
public class Trails extends Module {
    private static final long POINT_LIFETIME_MS = 500L;
    // Record a point almost every rendered frame => a smooth, continuous ribbon.
    private static final double MIN_POINT_DISTANCE_SQ = 0.0025D;
    /** Near-opaque so the ribbon really reads. */
    private static final float MAX_ALPHA = 250.0F;
    /** Brightens the accent so the ribbon pops against any background. */
    private static final float LIGHTEN = 1.30F;
    /** Soft white radial texture; sampled at its opaque center => solid tinted quads. */
    private static final Identifier BLOOM_TEXTURE =
            Identifier.of("skrvisuals", "textures/particles/bloom.png");
    /** Full brightness: LightmapTextureManager.pack(15, 15). */
    private static final int MAX_LIGHT = 15728880;

    private static Trails active;
    private static boolean hookRegistered = false;

    private final BooleanSetting hideFirstPerson =
            new BooleanSetting("Скрывать в 1 лице", "Не рисовать след от себя в первом лице.", true);

    /** След одного игрока: точки ленты + последняя записанная позиция. */
    private static final class Ribbon {
        private final ArrayDeque<Point> points = new ArrayDeque<>();
        private Vec3d lastPoint = null;
    }

    private final Ribbon playerRibbon = new Ribbon();
    private final Map<String, Ribbon> friendRibbons = new HashMap<>();

    public Trails() {
        super(ModuleCategory.VISUALS, "Trails", "Отображает следы за игроками.");
        setting(hideFirstPerson);
        active = this;
        registerHook();
    }

    private static void registerHook() {
        if (hookRegistered) {
            return;
        }
        hookRegistered = true;
        WorldRenderEvents.LAST.register(Trails::onWorldRender);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (!this.isEnabled()) {
            this.playerRibbon.points.clear();
            this.playerRibbon.lastPoint = null;
            this.friendRibbons.clear();
        }
    }

    // ---------------------------------------------------------------- rendering
    private static void onWorldRender(WorldRenderContext context) {
        Trails module = active;
        if (module == null || !module.isEnabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {
            return;
        }

        long now = System.currentTimeMillis();

        // Reference behaviour: don't leave a trail behind yourself in first person.
        boolean hiddenInFirstPerson = module.hideFirstPerson.getValue()
                && client.options.getPerspective().isFirstPerson();
        if (hiddenInFirstPerson) {
            module.playerRibbon.points.clear();
            module.playerRibbon.lastPoint = null;
        } else {
            module.recordAndRender(context, player, module.playerRibbon, now);
        }

        // Следы на друзьях.
        if (Friends.isTrailsOnFriends()) {
            Set<String> seen = new HashSet<>();
            for (var entity : client.world.getPlayers()) {
                if (entity == player) {
                    continue;
                }
                String name = entity.getGameProfile().getName();
                if (!Friends.isFriend(entity)) {
                    continue;
                }
                seen.add(name);
                module.recordAndRender(context, entity,
                        module.friendRibbons.computeIfAbsent(name, k -> new Ribbon()), now);
            }
            // Убираем ленты друзей, которых больше нет рядом.
            module.friendRibbons.keySet().retainAll(seen);
        }
    }

    /** Записывает точку следа и рисует ленту для данного игрока. */
    private void recordAndRender(WorldRenderContext context, PlayerEntity entity,
                                 Ribbon ribbon, long now) {
        float delta = context.tickCounter().getTickDelta(false);
        // Interpolated position: the ribbon hugs the player smoothly.
        Vec3d pos = entity.getLerpedPos(delta);
        if (ribbon.lastPoint == null
                || ribbon.lastPoint.squaredDistanceTo(pos) > MIN_POINT_DISTANCE_SQ) {
            ribbon.points.add(new Point(pos));
            ribbon.lastPoint = pos;
        }

        ribbon.points.removeIf(point -> point.expired(now));
        if (ribbon.points.size() < 2) {
            return;
        }

        renderRibbon(context, entity.getHeight(), new ArrayList<>(ribbon.points), now);
    }

    private void renderRibbon(WorldRenderContext context, float height, List<Point> ordered, long now) {
        int count = ordered.size();

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camera = context.camera().getPos();

        int baseColor = Colors.clientColor();
        float r = Math.min(255.0F, ((baseColor >> 16) & 0xFF) * LIGHTEN);
        float g = Math.min(255.0F, ((baseColor >> 8) & 0xFF) * LIGHTEN);
        float b = Math.min(255.0F, (baseColor & 0xFF) * LIGHTEN);

        matrices.push();
        matrices.translate(-camera.x, -camera.y, -camera.z);

        MinecraftClient client = MinecraftClient.getInstance();
        VertexConsumerProvider.Immediate consumers =
                client.getBufferBuilders().getEntityVertexConsumers();
        // Same proven translucent path as JumpCircle/ChinaHat (soft blending).
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.getEntityTranslucent(BLOOM_TEXTURE));

        var entry = matrices.peek();
        var matrix = entry.getPositionMatrix();

        for (int i = 0; i < count - 1; i++) {
            Point p1 = ordered.get(i);
            Point p2 = ordered.get(i + 1);

            // Newer segments are more opaque; older ones also dissolve with age.
            float progress = (count <= 1) ? 1.0F : (float) (i + 1) / (float) count;
            float ageFade = 1.0F - MathHelper.clamp((now - p1.time) / (float) POINT_LIFETIME_MS, 0.0F, 1.0F);
            int alpha = (int) (progress * ageFade * MAX_ALPHA);
            if (alpha <= 4) {
                continue;
            }

            quad(buffer, entry, matrix,
                    p1.position.x, p1.position.y, p1.position.z,
                    p2.position.x, p2.position.y, p2.position.z,
                    p2.position.x, p2.position.y + height, p2.position.z,
                    p1.position.x, p1.position.y + height, p1.position.z,
                    r, g, b, alpha);
        }

        consumers.draw(RenderLayer.getEntityTranslucent(BLOOM_TEXTURE));
        matrices.pop();
    }

    /** Emits one vertical quad (both windings so it is visible from any side). */
    private static void quad(VertexConsumer buffer, MatrixStack.Entry entry,
                             org.joml.Matrix4f matrix,
                             double x1, double y1, double z1,
                             double x2, double y2, double z2,
                             double x3, double y3, double z3,
                             double x4, double y4, double z4,
                             float r, float g, float b, int a) {
        vertex(buffer, entry, matrix, x1, y1, z1, r, g, b, a);
        vertex(buffer, entry, matrix, x2, y2, z2, r, g, b, a);
        vertex(buffer, entry, matrix, x3, y3, z3, r, g, b, a);
        vertex(buffer, entry, matrix, x4, y4, z4, r, g, b, a);

        // reversed winding
        vertex(buffer, entry, matrix, x1, y1, z1, r, g, b, a);
        vertex(buffer, entry, matrix, x4, y4, z4, r, g, b, a);
        vertex(buffer, entry, matrix, x3, y3, z3, r, g, b, a);
        vertex(buffer, entry, matrix, x2, y2, z2, r, g, b, a);
    }

    private static void vertex(VertexConsumer buffer, MatrixStack.Entry entry,
                               org.joml.Matrix4f matrix,
                               double x, double y, double z,
                               float r, float g, float b, int a) {
        buffer.vertex(matrix, (float) x, (float) y, (float) z)
                .color((int) r, (int) g, (int) b, a)
                .texture(0.5F, 0.5F)
                .overlay(net.minecraft.client.render.OverlayTexture.DEFAULT_UV)
                .light(MAX_LIGHT)
                .normal(entry, 0.0F, 1.0F, 0.0F);
    }

    // ------------------------------------------------------------------ data
    private static final class Point {
        private final Vec3d position;
        private final long time;

        private Point(Vec3d position) {
            this.position = position;
            this.time = System.currentTimeMillis();
        }

        private boolean expired(long now) {
            return now - this.time >= POINT_LIFETIME_MS;
        }
    }
}