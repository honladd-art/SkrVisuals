package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.SliderSetting;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

/**
 * ViewModel: меняет позицию (X, Y, Z) и размер первой руки/предмета.
 * Трансформации применяет HeldItemRendererMixin сразу после push матрицы
 * в HeldItemRenderer#renderFirstPersonItem, снимает их перед RETURN.
 */
public class ViewModel extends Module {

    private static ViewModel active;

    /* ===== Правая рука (сверху) ===== */
    private final SliderSetting rightPosX = new SliderSetting(
            "Правая: Pos X", "Смещение правой руки по X.", -2.0F, 2.0F, 0.0F);
    private final SliderSetting rightPosY = new SliderSetting(
            "Правая: Pos Y", "Смещение правой руки по Y.", -2.0F, 2.0F, 0.0F);
    private final SliderSetting rightPosZ = new SliderSetting(
            "Правая: Pos Z", "Смещение правой руки по Z.", -2.0F, 2.0F, 0.0F);
    private final SliderSetting rightSize = new SliderSetting(
            "Правая: Размер", "Масштаб правой руки/предмета.", 0.1F, 2.0F, 1.0F);

    /* ===== Левая рука (снизу) ===== */
    private final SliderSetting leftPosX = new SliderSetting(
            "Левая: Pos X", "Смещение левой руки по X.", -2.0F, 2.0F, 0.0F);
    private final SliderSetting leftPosY = new SliderSetting(
            "Левая: Pos Y", "Смещение левой руки по Y.", -2.0F, 2.0F, 0.0F);
    private final SliderSetting leftPosZ = new SliderSetting(
            "Левая: Pos Z", "Смещение левой руки по Z.", -2.0F, 2.0F, 0.0F);
    private final SliderSetting leftSize = new SliderSetting(
            "Левая: Размер", "Масштаб левой руки/предмета.", 0.1F, 2.0F, 1.0F);

    public ViewModel() {
        super(ModuleCategory.VISUALS, "ViewModel", "Позиция и размер рук от первого лица.");
        // Сначала правая рука, затем левая
        setting(rightPosX);
        setting(rightPosY);
        setting(rightPosZ);
        setting(rightSize);
        setting(leftPosX);
        setting(leftPosY);
        setting(leftPosZ);
        setting(leftSize);

        active = this;
    }

    /** Queried by HeldItemRendererMixin. */
    public static ViewModel get() {
        return active;
    }

    /**
     * Смещение (X, Y, Z) выбранной руки. Вызывается из миксина сразу после
     * ванильного {@code MatrixStack.push()} внутри renderFirstPersonItem —
     * двигает всю руку как единое целое.
     */
    public void applyHandPosition(MatrixStack matrices, Arm arm) {
        boolean right = arm == Arm.RIGHT;
        matrices.translate(
                (right ? rightPosX : leftPosX).getValue(),
                (right ? rightPosY : leftPosY).getValue(),
                (right ? rightPosZ : leftPosZ).getValue());
    }

    /**
     * Масштаб (размер) предмета/руки. Применяется ОТДЕЛЬНО от смещения — сразу
     * вокруг модели предмета (после всех ванильных трансформаций руки). Благодаря
     * этому изменение «Размер» меняет только величину предмета и НЕ двигает руку
     * (в противном случае масштаб умножал бы ещё и базовое смещение equip-овода,
     * из-за чего предмет «улетал» при перемещении ползунка).
     */
    public void applyHandScale(MatrixStack matrices, Arm arm) {
        float scale = (arm == Arm.RIGHT ? rightSize : leftSize).getValue();
        matrices.scale(scale, scale, scale);
    }
}
