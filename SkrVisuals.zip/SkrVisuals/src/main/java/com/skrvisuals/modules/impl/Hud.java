package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.ui.hud.HudElement.Renderer;
import com.skrvisuals.ui.hud.HudManager;
import com.skrvisuals.ui.hud.HudElement;
import com.skrvisuals.ui.theme.Colors;

import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

/**
 * Hud: draws draggable HUD elements.
 * - Watermark: client name, nickname and FPS.
 * - TargetHUD: appears when you aim at a player, showing nick/HP/armor.
 * - Potions: active status effects on you with their remaining time.
 *   Elements can be repositioned with the mouse while any screen (e.g. the
 *   chat) is open; previews render there when there is nothing to show.
 */
public class Hud extends Module {
    private static Hud active;

    private final BooleanSetting watermark =
            new BooleanSetting("Watermark", "Название клиента, ник и FPS.", true);
    private final BooleanSetting targetHud =
            new BooleanSetting("TargetHUD", "Информация о игроке в прицеле.", true);
    private final BooleanSetting potions =
            new BooleanSetting("Potions", "Активные эффекты и время их действия.", true);
    private final BooleanSetting keystrokes =
            new BooleanSetting("Keystrokes", "Отображение нажатий WASD, ЛКМ и ПКМ.", true);
    private final BooleanSetting armorHud =
            new BooleanSetting("ArmorHUD", "Надетая броня и её прочность.", true);
    private final BooleanSetting coordinates =
            new BooleanSetting("Coordinates", "Ваши координаты X, Y и Z.", true);
    private final BooleanSetting notifications =
            new BooleanSetting("Notifications", "Уведомления о включении/выключении функций.", true);
    private final BooleanSetting inventory =
            new BooleanSetting("Inventory", "Предметы основного инвентаря (без хотбара и брони).", true);

    // Watermark sub-settings (toggled from the RMB popup on the element).
    private final BooleanSetting wmFps =
            new BooleanSetting("WM FPS", "Показ FPS в ватермарке.", true);
    private final BooleanSetting wmNick =
            new BooleanSetting("WM Ник", "Показ ника в ватермарке.", true);
    private final BooleanSetting wmPing =
            new BooleanSetting("WM Пинг", "Показ пинга в ватермарке.", true);
    private final BooleanSetting wmTime =
            new BooleanSetting("WM Время", "Показ времени в ватермарке.", true);
    private final BooleanSetting wmRole =
            new BooleanSetting("WM Роль", "Показ роли в ватермарке.", true);

    public Hud() {
        super(ModuleCategory.VISUALS, "Hud", "Красивые элементы интерфейса.");
        setting(watermark);
        // Ватермарк-сабнастройки скрыты из ClickGUI — меняются в попапе (ПКМ по ватермарке).
        wmFps.setHideCondition(() -> true);
        wmNick.setHideCondition(() -> true);
        wmPing.setHideCondition(() -> true);
        wmTime.setHideCondition(() -> true);
        wmRole.setHideCondition(() -> true);
        setting(wmFps);
        setting(wmNick);
        setting(wmPing);
        setting(wmTime);
        setting(wmRole);
        setting(targetHud);
        setting(potions);
        setting(keystrokes);
        setting(armorHud);
        setting(coordinates);
        setting(notifications);
        setting(inventory);
        active = this;

        Renderer watermarkRenderer = (ctx, element) -> HudManager.renderWatermark(ctx, element);
        Renderer targetRenderer = (ctx, element) -> HudManager.renderTargetHud(ctx, element);
        Renderer potionsRenderer = (ctx, element) -> HudManager.renderPotions(ctx, element);
        Renderer keystrokesRenderer = (ctx, element) -> HudManager.renderKeystrokes(ctx, element);
        Renderer armorRenderer = (ctx, element) -> HudManager.renderArmorHud(ctx, element);
        Renderer coordinatesRenderer = (ctx, element) -> HudManager.renderCoordinates(ctx, element);
        Renderer notificationsRenderer = (ctx, element) -> HudManager.renderNotifications(ctx, element);
        Renderer inventoryRenderer = (ctx, element) -> HudManager.renderInventory(ctx, element);

        HudManager.register(new HudElement("watermark", 6f, 6f, watermarkRenderer));
        // Fixed default position: the window is not available this early;
        // config load overrides it and dragging clamps it on screen.
        HudManager.register(new HudElement("targethud", 200f, 60f, targetRenderer));
        HudManager.register(new HudElement("potions", 6f, 27f, potionsRenderer));
        HudManager.register(new HudElement("keystrokes", 6f, 120f, keystrokesRenderer));
        HudManager.register(new HudElement("armorhud", 6f, 80f, armorRenderer));
        HudManager.register(new HudElement("coordinates", 6f, 160f, coordinatesRenderer));
        HudManager.register(new HudElement("notifications", 200f, 6f, notificationsRenderer));
        HudManager.register(new HudElement("inventory", 6f, 200f, inventoryRenderer));
        HudManager.initHooks();
        registerFpsChatHandler();
    }

    /** Префикс чат-команды .fps. */
    private static final String FPS_PREFIX = ".fps";

    /** Клиентская чат-команда .fps: set <значение>, off/reset. */
    private static void registerFpsChatHandler() {
        ClientSendMessageEvents.ALLOW_CHAT.register((message) -> {
            if (!message.startsWith(FPS_PREFIX)) {
                return true;
            }
            String rest = message.substring(FPS_PREFIX.length()).trim();
            if (rest.isEmpty()) {
                chatFps("Использование: .fps set <значение> | .fps off", 0xFFAAAAAA);
                return false;
            }
            String[] parts = rest.split("\\s+");
            switch (parts[0].toLowerCase(java.util.Locale.ROOT)) {
                case "set" -> {
                    if (parts.length < 2) {
                        chatFps("Использование: .fps set <значение>", 0xFFAAAAAA);
                        return false;
                    }
                    try {
                        int value = Integer.parseInt(parts[1]);
                        if (value <= 0) {
                            chatFps("Значение должно быть > 0", 0xFFFF6B6B);
                            return false;
                        }
                        HudManager.setFakeFps(value);
                        chatFps("Fake FPS установлен: " + value + " (колебания ±15%)", 0xFF55FF55);
                    } catch (NumberFormatException e) {
                        chatFps("Неверное число: " + parts[1], 0xFFFF6B6B);
                    }
                }
                case "off", "reset", "disable" -> {
                    HudManager.resetFakeFps();
                    chatFps("Fake FPS отключён", 0xFFAAAAAA);
                }
                default -> chatFps("Использование: .fps set <значение> | .fps off", 0xFFAAAAAA);
            }
            return false;
        });
    }

    /** Сообщение в чат в стиле мода: префикс "SkrVisuals" красится в акцент темы. */
    private static void chatFps(String text, int color) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud == null) {
            return;
        }
        Text msg = Text.empty()
                .append(Text.literal("SkrVisuals")
                        .styled(s -> s.withColor(TextColor.fromRgb(Colors.clientColor()))))
                .append(Text.literal(" » ")
                        .styled(s -> s.withColor(TextColor.fromRgb(Colors.textDescription()))))
                .append(Text.literal(text)
                        .styled(s -> s.withColor(TextColor.fromRgb(color))));
        mc.inGameHud.getChatHud().addMessage(msg);
    }

    public static Hud getActive() {
        return active;
    }

    public boolean isWatermarkEnabled() {
        return this.watermark.getValue();
    }

    public boolean isTargetHudEnabled() {
        return this.targetHud.getValue();
    }

    public boolean isPotionsEnabled() {
        return this.potions.getValue();
    }

    public boolean isKeystrokesEnabled() {
        return this.keystrokes.getValue();
    }

    public boolean isArmorHudEnabled() {
        return this.armorHud.getValue();
    }

    public boolean isCoordinatesEnabled() {
        return this.coordinates.getValue();
    }

    public boolean isNotificationsEnabled() {
        return this.notifications.getValue();
    }

    public boolean isInventoryEnabled() {
        return this.inventory.getValue();
    }

    public boolean isWatermarkFpsEnabled() {
        return this.wmFps.getValue();
    }

    public boolean isWatermarkNickEnabled() {
        return this.wmNick.getValue();
    }

    public boolean isWatermarkPingEnabled() {
        return this.wmPing.getValue();
    }

    public boolean isWatermarkTimeEnabled() {
        return this.wmTime.getValue();
    }

    public boolean isWatermarkRoleEnabled() {
        return this.wmRole.getValue();
    }

    public void toggleWatermarkFps() {
        this.wmFps.setValue(!this.wmFps.getValue());
    }

    public void toggleWatermarkNick() {
        this.wmNick.setValue(!this.wmNick.getValue());
    }

    public void toggleWatermarkPing() {
        this.wmPing.setValue(!this.wmPing.getValue());
    }

    public void toggleWatermarkTime() {
        this.wmTime.setValue(!this.wmTime.getValue());
    }

    public void toggleWatermarkRole() {
        this.wmRole.setValue(!this.wmRole.getValue());
    }
}