package com.skrvisuals.modules.impl;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;

import java.util.UUID;

/**
 * Клиентская сущность бота для тренировки (только одиночная игра).
 *
 * Живой бот: гравитация, толкание (ударом и телом), его можно убивать,
 * он сам бегает за игроком и бьёт при включённом PvP (/skbot pvp on).
 * Урон по игроку наносится через интегрированный сервер — по-настоящему.
 * Урон по боту честно режется его бронёй (считается из его экипировки).
 */
public class BotPracticeEntity extends OtherClientPlayerEntity {

    /** Клиентские id берём из другого диапазона, чтобы не пересечься с серверными и с FakePlayer. */
    private static int nextEntityId = 600_000_000;

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private final BotPractice module;

    /** Тиков до следующей атаки бота по игроку. */
    private int attackCooldown = 0;

    /** Тики, в течение которых бот летит от knockback и НЕ двигается сам. */
    private int knockbackTicks = 0;

    /** Диагностика: если ванильная физика не двигает клиентскую сущность — двигаем сами. */
    private boolean manualMovement = false;
    private int stuckTicks = 0;

    public BotPracticeEntity(BotPractice module, ClientWorld world, ClientPlayerEntity template) {
        super(world, forgeUniqueProfile(template.getGameProfile()));

        this.module = module;
        this.setId(nextEntityId++);

        copyFrom(template);
        refreshPositionAndAngles(template.getX(), template.getY(), template.getZ(),
                template.getYaw(), template.getPitch());
        this.bodyYaw = template.bodyYaw;
        this.headYaw = template.headYaw;
        alignPrevRotations();
        setVelocity(Vec3d.ZERO);

        this.setHealth(this.getMaxHealth());

        // Бот полностью копирует твой инвентарь (броня, хотбар, оффхенд)
        copyFullInventoryFrom(template);
    }

    @Override
    public void tick() {
        Vec3d posBefore = this.getPos();
        Vec3d velBefore = this.getVelocity();

        super.tick();

        if (!module.isEnabled()) {
            this.discard();
            return;
        }

        // --- Определяем, двигает ли нас ваниль ---
        if (!manualMovement) {
            boolean shouldHaveMoved = Math.abs(velBefore.x) > 0.05 || Math.abs(velBefore.z) > 0.05
                    || Math.abs(velBefore.y) > 0.05;
            boolean moved = this.squaredDistanceTo(posBefore) > 1.0e-7;
            if (shouldHaveMoved && !moved) {
                stuckTicks++;
                if (stuckTicks >= 3) {
                    manualMovement = true; // ваниль физику не применяет — включаем свою
                }
            } else {
                stuckTicks = 0;
            }
        }

        if (manualMovement) {
            tickPhysics();
        }

        // --- Простой ИИ: преследуем и бьём игрока, если включён PvP ---
        if (module.isPvpEnabled()) {
            tickCombatAI();
        } else {
            this.attackCooldown = 0;
        }

        handleBodyPush();
    }

    /**
     * Своя физика: гравитация + трение + move(). Включается автоматически,
     * если ваниль сама не двигает эту клиентскую сущность.
     */
    private void tickPhysics() {
        Vec3d vel = this.getVelocity();
        double y = vel.y;
        if (!this.isOnGround() && !this.isTouchingWater()) {
            y = Math.max(y - 0.08, -0.6); // гравитация с потолком скорости
        }
        double friction = this.isOnGround() ? 0.55 : 0.91;
        double x = vel.x * friction;
        double z = vel.z * friction;
        if (Math.abs(x) < 0.005) x = 0;
        if (Math.abs(z) < 0.005) z = 0;

        Vec3d next = new Vec3d(x, y, z);
        this.setVelocity(next);
        this.move(MovementType.SELF, next);
    }

    /**
     * Толкание телом: как в ваниле pushAwayFrom — клиентские сущности
     * сами друг друга не толкают, поэтому делаем это руками.
     */
    private void handleBodyPush() {
        ClientPlayerEntity player = module.getPlayer();
        if (player == null || this.isRemoved()) return;

        double dx = this.getX() - player.getX();
        double dz = this.getZ() - player.getZ();
        double distSq = dx * dx + dz * dz;
        if (distSq > 1.44 || distSq < 1.0e-5) return; // толкаем только вплотную

        double dist = Math.sqrt(distSq);
        double push = (1.0 - dist) * 0.35;
        Vec3d v = this.getVelocity();
        this.setVelocity(v.x + (dx / dist) * push * 0.5, v.y, v.z + (dz / dist) * push * 0.5);
        if (manualMovement) {
            this.move(MovementType.SELF, this.getVelocity());
        }
    }

    private void tickCombatAI() {
        // Бот летит от удара — не вмешиваемся в его скорость, пусть отлетает
        if (knockbackTicks > 0) {
            knockbackTicks--;
            if (manualMovement) {
                tickPhysics(); // продолжаем лететь по инерции даже в своей физике
            }
            return;
        }

        ClientPlayerEntity target = module.getPlayer();
        if (target == null || target.isDead() || this.isRemoved()) {
            return;
        }

        Vec3d toTarget = target.getPos().subtract(this.getPos());
        double distSq = toTarget.horizontalLengthSquared();
        double reach = 3.0;

        // Поворачиваемся к игроку (плавно, чтобы не дёргался рендер)
        float targetYaw = (float) (Math.toDegrees(Math.atan2(toTarget.z, toTarget.x)) - 90.0);
        this.setYaw(this.getYaw() + MathHelper.wrapDegrees(targetYaw - this.getYaw()) * 0.4f);
        this.bodyYaw = this.getYaw();
        this.headYaw = this.getYaw();
        this.prevBodyYaw = this.bodyYaw;
        this.prevHeadYaw = this.headYaw;

        if (distSq > 1.2) {
            // Как настоящий игрок: издалека бежит (спринт), вблизи подходит шагом
            double speed = distSq > 16.0 ? 0.30 : 0.22;
            Vec3d dir = new Vec3d(toTarget.x, 0, toTarget.z).normalize().multiply(speed);
            Vec3d vel = this.getVelocity();
            this.setVelocity(dir.x, vel.y, dir.z);
            this.setSprinting(distSq > 16.0);
            if (this.horizontalCollision && this.isOnGround()) {
                this.jump(); // автопрыжок, чтобы не застревать у блоков
            }
            if (this.age % 20 == 0 && distSq <= reach * reach * 2.0) {
                this.swingHand(Hand.MAIN_HAND);
            }
        } else {
            this.setSprinting(false);
            Vec3d vel = this.getVelocity();
            this.setVelocity(vel.x * 0.6, vel.y, vel.z * 0.6);
        }

        if (this.attackCooldown > 0) {
            this.attackCooldown--;
            return;
        }

        if (distSq <= reach * reach) {
            this.attackCooldown = module.getAttackIntervalTicks();
            module.onBotAttackPlayer(this, target);
        }
    }


    /* ==================== Урон от игрока (меня) ==================== */

    /**
     * Игрок ударил бота (перехвачено в AttackEntityCallback).
     * Возвращает true, если удар обработан локально.
     */
    public boolean receiveAttack(ClientPlayerEntity attacker) {
        if (this.isRemoved() || !module.isEnabled()) return false;

        float progress = MathHelper.clamp(attacker.getAttackCooldownProgress(0.0f), 0.0f, 1.0f);
        float baseDamage = computeBaseDamage(attacker);
        float damage = baseDamage * (0.2f + progress * progress * 0.8f);

        boolean crit = damage > 0.0f && canCriticalHit(attacker);
        if (crit) damage *= 1.5f;

        // Честный ванильный расчёт: броня + сопротивление + зачарования
        damage = applyArmorReduction(damage);

        attacker.resetLastAttackedTicks();
        attacker.swingHand(Hand.MAIN_HAND);

        // Толкаем бота — его можно пинать по арене.
        // Спринт-удар как в ваниле: отбрасывает заметно сильнее.
        Vec3d dir = this.getPos().subtract(attacker.getPos());
        float knockback = attacker.isSprinting() ? 0.8f : 0.45f;
        this.takeKnockback(knockback, dir.x, dir.z);
        if (crit) {
            this.setVelocity(this.getVelocity().add(0.0, 0.25, 0.0)); // крит подкидывает
        }
        this.knockbackTicks = 12; // 0.6 сек ИИ не двигает бота — knockback успевает отыграть
        this.hurtTime = 10;
        this.maxHurtTime = 10;

        if (damage > 0.0f) {
            applyDamage(damage, crit);
        }
        return true;
    }

    private boolean canCriticalHit(ClientPlayerEntity attacker) {
        return attacker.getVelocity().y < 0.0
                && !attacker.isOnGround()
                && !attacker.isClimbing()
                && !attacker.isTouchingWater()
                && !attacker.hasStatusEffect(StatusEffects.BLINDNESS)
                && !attacker.hasVehicle()
                && !attacker.isSprinting();
    }

    /**
     * Урон с учётом оружия. Атрибут ATTACK_DAMAGE на клиенте не всегда успевает
     * включить модификатор предмета, поэтому урон также считаем напрямую из
     * компонента предмета и берём максимум из двух.
     */
    private float computeBaseDamage(ClientPlayerEntity attacker) {
        float attributeDamage = (float) attacker.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);

        float itemDamage = 1.0f; // кулак
        ItemStack held = attacker.getMainHandStack();
        if (!held.isEmpty()) {
            AttributeModifiersComponent mods = held.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
            if (mods != null) {
                for (AttributeModifiersComponent.Entry entry : mods.modifiers()) {
                    if (entry.attribute() == EntityAttributes.ATTACK_DAMAGE
                            && entry.slot() == net.minecraft.component.type.AttributeModifierSlot.MAINHAND
                            && entry.modifier().operation() == EntityAttributeModifier.Operation.ADD_VALUE) {
                        itemDamage += (float) entry.modifier().value();
                    }
                }
            }
        }
        return Math.max(attributeDamage, itemDamage);
    }

    /** Ванильная формула: сначала защита зачарований, потом броня. */
    private float applyArmorReduction(float incoming) {
        if (incoming <= 0.0f) return incoming;

        // Броню и твёрдость считаем из надетых предметов напрямую: у клиентской
        // сущности атрибуты из экипировки сервером не синхронятся, поэтому
        // берём максимум из атрибута сущности и суммы модификаторов предметов.
        double armor = computeEquipmentAttribute(EntityAttributes.ARMOR, this.getArmor());
        double toughness = computeEquipmentAttribute(EntityAttributes.ARMOR_TOUGHNESS,
                this.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS));

        // Зачарования защиты считаем из компонентов предметов бота.
        // ВАЖНО: нельзя звать EnchantmentHelper с миром бота — это ClientWorld,
        // а хелпер требует ServerWorld (раньше на этом крашился весь клиент).
        int enchantProtection = 0;
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack piece = this.getEquippedStack(slot);
            if (piece.isEmpty()) continue;
            ItemEnchantmentsComponent enchants = piece.get(DataComponentTypes.ENCHANTMENTS);
            if (enchants == null) continue;
            for (var entry : enchants.getEnchantmentEntries()) {
                String path = entry.getKey().getKey()
                        .map(id -> id.getValue().getPath()).orElse("");
                int level = entry.getIntValue();
                switch (path) {
                    case "protection" -> enchantProtection += level;
                    // Эти виды защиты в EP стоят вдвое дороже, как в ваниле
                    case "fire_protection", "blast_protection", "projectile_protection" ->
                            enchantProtection += level * 2;
                }
            }
        }
        enchantProtection = Math.min(enchantProtection, 20);

        // 1) Против зачарований: damage * (1 - ep/25)
        float damage = incoming * (1.0f - enchantProtection / 25.0f);

        // 2) Против брони: damage * (1 - min(20, max(armor/5, armor - damage/(2+t/4)))/25)
        double defense = Math.min(20.0, Math.max(armor / 5.0, armor - damage / (2.0 + toughness / 4.0)));
        damage = (float) (damage * (1.0 - defense / 25.0));

        return Math.max(0.0f, damage);
    }

    /**
     * Сумма ADD_VALUE модификаторов атрибута по всей броне бота.
     * Берётся максимум из значения атрибута сущности и суммы предметов,
     * чтобы работало и когда атрибут синхронизирован, и когда нет.
     */
    private double computeEquipmentAttribute(net.minecraft.registry.entry.RegistryEntry<EntityAttribute> attribute,
                                             double entityBase) {
        double sum = 0.0;
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack piece = this.getEquippedStack(slot);
            if (piece.isEmpty()) continue;
            AttributeModifiersComponent mods = piece.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
            if (mods == null) continue;
            for (AttributeModifiersComponent.Entry entry : mods.modifiers()) {
                if (entry.attribute() == attribute
                        && entry.modifier().operation() == EntityAttributeModifier.Operation.ADD_VALUE) {
                    sum += entry.modifier().value();
                }
            }
        }
        return Math.max(entityBase, sum);
    }

    private void applyDamage(float damage, boolean crit) {
        float resultingHealth = this.getHealth() - damage;

        if (resultingHealth <= 0.01f) {
            if (module.isInfiniteTotems()) {
                useTotem();
            } else {
                dieForReal();
            }
            return;
        }

        this.setHealth(resultingHealth);

        ClientWorld world = (ClientWorld) this.getWorld();
        world.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.PLAYERS, 1.0f,
                crit ? 1.15f : 1.0f);
        world.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ENTITY_PLAYER_HURT, SoundCategory.PLAYERS, 0.7f, 1.0f);

        if (crit) {
            Random rnd = this.getRandom();
            for (int i = 0; i < 14; i++) {
                world.addParticle(ParticleTypes.CRIT,
                        getX() + (rnd.nextDouble() - 0.5) * getWidth() * 1.5,
                        getY() + rnd.nextDouble() * getHeight(),
                        getZ() + (rnd.nextDouble() - 0.5) * getWidth() * 1.5,
                        (rnd.nextDouble() - 0.5) * 0.3,
                        rnd.nextDouble() * 0.2 + 0.1,
                        (rnd.nextDouble() - 0.5) * 0.3);
            }
        }
    }


    /* ==================== Тотем / смерть ==================== */

    private void useTotem() {
        this.setHealth(this.getMaxHealth());
        this.hurtTime = 0;
        this.maxHurtTime = 0;

        ClientWorld world = (ClientWorld) this.getWorld();
        Random rnd = this.getRandom();

        world.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ITEM_TOTEM_USE, SoundCategory.PLAYERS, 1.0f, 1.0f);
        for (int i = 0; i < 35; i++) {
            world.addParticle(ParticleTypes.TOTEM_OF_UNDYING,
                    getX() + (rnd.nextDouble() - 0.5) * getWidth() * 2.0,
                    getY() + rnd.nextDouble() * getHeight(),
                    getZ() + (rnd.nextDouble() - 0.5) * getWidth() * 2.0,
                    (rnd.nextDouble() - 0.5) * 0.08,
                    rnd.nextDouble() * 0.12 + 0.05,
                    (rnd.nextDouble() - 0.5) * 0.08);
        }
        this.swingHand(Hand.OFF_HAND);
    }

    /** Бот умер по-настоящему (тотемы выключены): партиклы + удаление, респавн делает модуль. */
    private void dieForReal() {
        ClientWorld world = (ClientWorld) this.getWorld();
        Random rnd = this.getRandom();

        world.playSound(null, getX(), getY(), getZ(),
                SoundEvents.ENTITY_PLAYER_DEATH, SoundCategory.PLAYERS, 1.0f, 1.0f);
        for (int i = 0; i < 30; i++) {
            world.addParticle(ParticleTypes.POOF,
                    getX() + (rnd.nextDouble() - 0.5) * getWidth() * 2.0,
                    getY() + rnd.nextDouble() * getHeight(),
                    getZ() + (rnd.nextDouble() - 0.5) * getWidth() * 2.0,
                    (rnd.nextDouble() - 0.5) * 0.1,
                    rnd.nextDouble() * 0.1,
                    (rnd.nextDouble() - 0.5) * 0.1);
        }

        this.setHealth(0.0f);
        this.discard();
        module.onBotDied();
    }

    /** Принудительное убийство (команда /skbot kill) — минуя тотем. */
    public void killForced() {
        dieForReal();
    }

    /* ==================== Вспомогательное ==================== */

    public void teleportTo(Vec3d pos, float yaw, float pitch) {
        refreshPositionAndAngles(pos.x, pos.y, pos.z, yaw, pitch);
        alignPrevRotations();
        setVelocity(Vec3d.ZERO);
    }

    private void alignPrevRotations() {
        this.prevYaw = this.getYaw();
        this.prevPitch = this.getPitch();
        this.prevBodyYaw = this.bodyYaw;
        this.prevHeadYaw = this.headYaw;
    }

    private void copyFullInventoryFrom(ClientPlayerEntity source) {
        PlayerInventory srcInv = source.getInventory();
        PlayerInventory dstInv = this.getInventory();
        for (int i = 0; i < srcInv.size(); i++) {
            dstInv.setStack(i, srcInv.getStack(i).copy());
        }
        dstInv.selectedSlot = srcInv.selectedSlot;
    }

    private static GameProfile forgeUniqueProfile(GameProfile original) {
        GameProfile forged = new GameProfile(UUID.randomUUID(), original.getName());
        forged.getProperties().putAll(original.getProperties());
        return forged;
    }

    @Override
    public Text getDisplayName() {
        String hp = String.format("%.1f", this.getHealth());
        return Text.literal("[Bot] ").formatted(Formatting.AQUA)
                .append(Text.literal(this.getGameProfile().getName()).formatted(Formatting.WHITE))
                .append(Text.literal(" [").formatted(Formatting.GRAY))
                .append(Text.literal(hp).formatted(
                        this.getHealth() > this.getMaxHealth() * 0.5f ? Formatting.GREEN : Formatting.RED))
                .append(Text.literal("]").formatted(Formatting.GRAY));
    }
}

