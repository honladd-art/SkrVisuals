package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import com.skrvisuals.modules.settings.SliderSetting;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.List;

/**
 * SwingAnimation: заменяет стандартную анимацию удара рукой на одну из
 * пяти пользовательских (по референсу). Логика трансформаций портирована
 * из референс-модуля, применяет её HeldItemRendererMixin.
 */
public class SwingAnimation extends Module {

    private static SwingAnimation active;

    private final ModeSetting swingMode = new ModeSetting(
            "Анимация", "Вариант анимации удара.",
            List.of("Первый", "Второй", "Третий", "Четвёртый", "Пятый"), "Первый");

    private final ModeSetting typeSwing = new ModeSetting(
            "Тип", "Направ. замаха (только для режима «Третий»).",
            List.of("Первый", "Второй"), "Первый");

    private final SliderSetting swingPower = new SliderSetting(
            "Угол", "Угол поворота для режима «Третий».", -180.0F, 180.0F, 90.0F);

    private final ModeSetting easeMode = new ModeSetting(
            "Интерп.", "Сглаживание прогресса удара.",
            List.of("Первый", "Второй", "Третий"), "Первый");

    private final SliderSetting animSpeed = new SliderSetting(
            "Скорость", "Ускорение прогресса удара.", 0.1F, 4.0F, 1.0F);

    private final SliderSetting animSize = new SliderSetting(
            "Сила", "Амплитуда поворотов.", 0.1F, 10.0F, 6.0F);

    public SwingAnimation() {
        super(ModuleCategory.VISUALS, "SwingAnimation", "Кастомные анимации удара рукой.");
        setting(swingMode);
        setting(typeSwing);
        setting(swingPower);
        setting(easeMode);
        setting(animSpeed);
        setting(animSize);

        // «Тип» и «Угол» видны только в режиме «Третий»
        swingPower.setHideCondition(() -> !swingMode.getValue().equals("Третий"));
        typeSwing.setHideCondition(() -> !swingMode.getValue().equals("Третий"));

        active = this;
    }

    /** Queried by HeldItemRendererMixin. */
    public static SwingAnimation get() {
        return active;
    }

    /** True для рук/настроек, которые миксин должен перехватить. */
    public boolean shouldOverride(Arm arm) {
        SwingAnimation module = active;
        if (module == null || !module.isEnabled()) {
            return false;
        }
        // Отменяем ванильные смещения только для основной руки игрока
        net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
        return client.player != null && arm == client.player.getMainArm();
    }

    /* ======================= анимация ======================= */

    private float modifySwingProgress(float swingProgress) {
        float speedMultiplier = animSpeed.getValue();
        if (speedMultiplier != 1.0F) {
            swingProgress = MathHelper.clamp(swingProgress * speedMultiplier, 0.0F, 1.0F);
        }
        return swingProgress;
    }

    /** Интерполяция «Первый» — SINE_OUT, «Второй» — BACK_OUT, «Третий» — линейно. */
    private float easeProgress(float progress) {
        float x = MathHelper.clamp(progress, 0.0F, 1.0F);
        return switch (easeMode.getValue()) {
            case "Первый" -> (float) Math.sin(x * Math.PI * 0.5D); // sine out
            case "Второй" -> {                                     // back out
                float c = 1.70158F;
                float t = x - 1.0F;
                yield 1.0F + (c + 1.0F) * t * t * t + c * t * t;
            }
            default -> x;
        };
    }

    /**
     * Применяет трансформации выбранной анимации. Вызывается из миксина
     * сразу после push матрицы в renderFirstPersonItem.
     */
    public void renderSwordAnimation(MatrixStack matrices, float swingProgress, float equipProgress, Arm arm) {
        swingProgress = modifySwingProgress(swingProgress);
        boolean rightHand = arm == Arm.RIGHT;
        int i = rightHand ? 1 : -1;

        float t = easeProgress(swingProgress);
        float sin1 = MathHelper.sin(t * t * (float) Math.PI);
        float sin2 = MathHelper.sin((float) Math.sqrt(t) * (float) Math.PI);
        float sinSmooth = sin1 * sin2;
        if (easeMode.getValue().equals("Третий")) {
            sinSmooth = (float) Math.sin(swingProgress * Math.PI * 0.5D * 2.0D);
        }

        float size = animSize.getValue();
        switch (swingMode.getValue()) {
            case "Первый" -> {
                matrices.translate(i * 0.56F, -0.52F, -0.72F);
                float g = sinSmooth;
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -180.0F * size / 10.0F));
                matrices.multiply(RotationAxis.NEGATIVE_X.rotationDegrees(g * (rightHand ? -60.0F : 60.0F) * size / 10.0F));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(g * (rightHand ? -60.0F : 60.0F) * size / 10.0F));
            }
            case "Второй" -> {
                matrices.translate(i * 0.56F, -0.42F, -0.72F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(sinSmooth * -(24.0F * size)));
                matrices.translate(0.0D, -0.1D, 0.0D);
            }
            case "Третий" -> {
                matrices.translate(i * 0.7F, -0.35F, -0.9D);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * 60.0F));
                matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(i * -60.0F));
                float dir = typeSwing.getValue().equals("Первый") ? 1.0F : -1.0F;
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(
                        -swingPower.getValue() - dir * size * 24.0F * sinSmooth));
            }
            case "Четвёртый" -> {
                matrices.translate(i * 0.56F, -0.42F, -0.72F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(t * 360.0F));
                matrices.translate(0.0D, -0.1D, 0.0D);
            }
            case "Пятый" -> {
                matrices.translate(i * 0.7F, -0.35F, -0.9D);
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(i * 65.0F));
                matrices.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(i * -10.0F));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F - size * 24.0F * sinSmooth));
            }
        }
    }
}

