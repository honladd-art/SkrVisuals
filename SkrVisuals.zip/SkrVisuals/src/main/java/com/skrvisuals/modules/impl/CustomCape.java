package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Map;

/**
 * CustomCape: надевает на локального игрока кастомный плащ.
 *
 * Текстуры лежат в assets/skrvisuals/textures/cape/*.png и выбираются
 * настройкой «Плащ». Плащ рендерится ванильной моделью плаща через
 * CapeFeatureRendererMixin (замена текстуры + форс рендера, даже если
 * у игрока нет своего плаща). Виден в третьем лице / F5.
 */
public class CustomCape extends Module {

    private static CustomCape active;

    /** Название в настройке -> файл в assets/skrvisuals/textures/cape/. */
    private static final Map<String, String> CAPES = Map.of(
            "Фиолетовый", "capefiol.png",
            "Красный",    "capekras.png",
            "Розовый",    "caperoz.png",
            "Синий",      "capesin.png",
            "Зелёный",    "capezel.png");

    private final ModeSetting capeMode = new ModeSetting(
            "Плащ", "Какой плащ надеть.",
            List.of("Фиолетовый", "Красный", "Розовый", "Синий", "Зелёный"),
            "Фиолетовый");

    public CustomCape() {
        super(ModuleCategory.VISUALS, "CustomCape",
                "Надевает на тебя кастомный плащ. Можно выбрать текстуру.");
        setting(capeMode);
        active = this;
    }

    public static CustomCape get() {
        CustomCape m = active;
        return (m != null && m.isEnabled()) ? m : null;
    }

    /** Текущая текстура плаща по настройке. */
    public static Identifier currentTexture() {
        CustomCape m = active;
        String file = m != null ? CAPES.getOrDefault(m.capeMode.getValue(), "capefiol.png") : "capefiol.png";
        return Identifier.of("skrvisuals", "textures/cape/" + file);
    }
}
