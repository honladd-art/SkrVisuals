package com.skrvisuals.modules.impl;

import com.skrvisuals.modules.Module;
import com.skrvisuals.modules.ModuleCategory;
import com.skrvisuals.modules.settings.BooleanSetting;
import com.skrvisuals.modules.settings.SliderSetting;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * BotPractice: тренировочный бот (ТОЛЬКО ОДИНОЧНЫЙ РЕЖИМ).
 *
 * Включаешь модуль и пишешь в чат "/skbot spawn" — бот появляется рядом с
 * тобой, полностью копируя твой инвентарь. Его можно бить, толкать и убивать.
 * Если включить "/skbot pvp on" — бот сам бегает за тобой и бьёт (урон
 * настоящий: наносится через интегрированный сервер, так что работает броня
 * и i-frames).
 *
 * Команды: /skbot spawn|despawn|pvp on|off|heal|kill|tp|info
 *
 * Дополнительно от себя: слайдер урона и скорости атак бота, бесконечные
 * тотемы (настройка), авто-респавн после смерти (настройка), /skbot heal и
 * /skbot tp.
 */
public class BotPractice extends Module {

    /** Имя команды БЕЗ слэша: в command-канал приходит "skbot ..." ("/" срезается). */
    private static final String COMMAND_NAME = "skbot";

    private static BotPractice active;
    private static boolean hookRegistered = false;

    /* ----- Настройки ----- */

    private final BooleanSetting pvp =
            new BooleanSetting("PvP", "Бот атакует тебя (то же, что /skbot pvp on).", false);

    private final BooleanSetting infiniteTotems =
            new BooleanSetting("Бесконечные тотемы", "Бот не умирает: при обнулении ХП срабатывает тотем.", true);

    private final BooleanSetting autoRespawn =
            new BooleanSetting("Авто-респавн", "После смерти бот возрождается через 1.5 секунды.", true);

    private final SliderSetting attackDamage =
            new SliderSetting("Урон бота", "Сколько половинок сердец бот снимает за удар.", 0f, 10f, 3f);

    private final SliderSetting attackSpeed =
            new SliderSetting("Скорость атак", "Задержка между ударами бота в тиках (20 = 1 сек).", 5f, 40f, 20f);

    /* ----- Состояние ----- */

    private BotPracticeEntity bot;
    private int respawnTimer = -1;

    public BotPractice() {
        super(ModuleCategory.UTILITY, "BotPractice",
                "Тренировочный бот (только сингл): /skbot spawn, pvp on/off, heal, kill, tp, info.");
        setting(pvp);
        setting(infiniteTotems);
        setting(autoRespawn);
        setting(attackDamage);
        setting(attackSpeed);
        active = this;
        registerHooks();
    }

    private static void registerHooks() {
        if (hookRegistered) return;
        hookRegistered = true;

        // Перехват команды: "/skbot ..." (сообщения с "/" идут через command-канал,
        // а не через чат, поэтому здесь нужен ALLOW_COMMAND, а не ALLOW_CHAT)
        ClientSendMessageEvents.ALLOW_COMMAND.register(message -> {
            String trimmed = message.trim();
            if (!trimmed.startsWith(COMMAND_NAME)) return true;
            handleCommand(trimmed);
            return false; // команду глотаем — сервер её не получает
        });

        // На всякий случай — вариант без слэша ("skbot ..."), если кто-то напишет в чат
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.startsWith(COMMAND_NAME)) return true;
            handleCommand(message);
            return false;
        });

        // Перехват удара по боту: обрабатываем локально
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (entity instanceof BotPracticeEntity botTarget && active != null && active.isEnabled()) {
                if (botTarget.receiveAttack((ClientPlayerEntity) player)) {
                    return ActionResult.FAIL;
                }
            }
            return ActionResult.PASS;
        });
    }

    /* ============================ Команды ============================ */

    private static void handleCommand(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        BotPractice module = active;
        if (module == null) return;

        String[] args = message.trim().split("\\s+");
        String sub = args.length > 1 ? args[1].toLowerCase() : "help";

        if (client.player == null || client.world == null) {
            sendChat("§cМир не загружен.");
            return;
        }
        if (!isSingleplayer(client)) {
            sendChat("§cBotPractice работает ТОЛЬКО в одиночном режиме!");
            return;
        }

        switch (sub) {
            case "spawn" -> module.commandSpawn(client);
            case "despawn", "remove" -> module.commandDespawn();
            case "pvp" -> module.commandPvp(args);
            case "heal" -> module.commandHeal(client);
            case "kill" -> module.commandKill();
            case "tp" -> module.commandTp(client);
            case "info" -> module.commandInfo();
            default -> sendChat("§7Команды: §fspawn§7, §fdespawn§7, §fpvp on|off§7, §fheal§7, §fkill§7, §ftp§7, §finfo");
        }
    }

    private static boolean isSingleplayer(MinecraftClient client) {
        return client.getServer() != null; // интегрированный сервер = одиночка
    }

    /** Точка спавна: чуть перед игроком, чтобы бот не застрял внутри тебя. */
    private static Vec3d spawnOffset(ClientPlayerEntity player) {
        Vec3d look = player.getRotationVector();
        Vec3d offset = new Vec3d(look.x, 0, look.z);
        if (offset.lengthSquared() < 1.0e-4) offset = new Vec3d(0, 0, 1);
        return offset.normalize().multiply(2.0);
    }

    /* ============================ Команды: действия ============================ */

    private void commandSpawn(MinecraftClient client) {
        if (bot != null && !bot.isRemoved()) {
            sendChat("§eБот уже заспавнен. §7(/skbot despawn чтобы убрать)");
            return;
        }
        respawnTimer = -1;
        spawnBot(client);
        sendChat("§aБот заспавнен! Инвентарь скопирован.");
    }

    private void spawnBot(MinecraftClient client) {
        ClientWorld world = (ClientWorld) client.world;
        ClientPlayerEntity player = client.player;

        BotPracticeEntity created = new BotPracticeEntity(this, world, player);
        created.teleportTo(player.getPos().add(spawnOffset(player)), player.getYaw(), player.getPitch());
        world.addEntity(created);
        bot = created;
    }

    private void commandDespawn() {
        if (bot != null) {
            bot.discard();
            bot = null;
            sendChat("§aБот убран.");
        } else {
            sendChat("§eБота нет.");
        }
    }

    private void commandPvp(String[] args) {
        String mode = args.length > 2 ? args[2].toLowerCase() : "";
        boolean enabled;
        if (mode.equals("on")) enabled = true;
        else if (mode.equals("off")) enabled = false;
        else {
            sendChat("§7Использование: §f/skbot pvp on|off");
            return;
        }
        pvp.setValue(enabled);
        sendChat(enabled ? "§aPvP включён — бот теперь атакует тебя!" : "§cPvP выключен.");
    }



    private void commandHeal(MinecraftClient client) {
        if (bot != null && !bot.isRemoved()) {
            bot.setHealth(bot.getMaxHealth());
            bot.hurtTime = 0;
        }
        healServerPlayer(client);
        sendChat("§aБот и ты полностью вылечены.");
    }

    private void commandKill() {
        if (bot == null || bot.isRemoved()) {
            sendChat("§eБота нет.");
            return;
        }
        if (infiniteTotems.getValue()) {
            sendChat("§eБот с бесконечными тотемами не умирает. §7Выключи «Бесконечные тотемы» в настройках.");
            return;
        }
        bot.killForced();
    }

    private void commandTp(MinecraftClient client) {
        if (bot == null || bot.isRemoved()) {
            sendChat("§eБота нет. Заспавни: §f/skbot spawn");
            return;
        }
        bot.teleportTo(client.player.getPos().add(spawnOffset(client.player)),
                client.player.getYaw(), client.player.getPitch());
        sendChat("§aБот телепортирован к тебе.");
    }

    private void commandInfo() {
        boolean alive = bot != null && !bot.isRemoved();
        sendChat("§9--- BotPractice ---");
        sendChat("§7Бот: " + (alive ? "§aзаспавнен" : "§cнет"));
        sendChat("§7PvP: " + (pvp.getValue() ? "§aвкл" : "§cвыкл"));
        sendChat("§7Тотемы: " + (infiniteTotems.getValue() ? "§aбесконечные" : "§cнет (бот умирает)"));
        sendChat(String.format("§7Урон бота: §f%.1f §7| Задержка: §f%.0f тик.",
                attackDamage.getValue(), attackSpeed.getValue()));
    }

    /* ==================== Бот бьёт игрока (через сервер) ==================== */

    /**
     * Бот в радиусе удара — наносим игроку настоящий урон через
     * интегрированный сервер (единственный способ в сингле).
     */
    public void onBotAttackPlayer(BotPracticeEntity botEntity, ClientPlayerEntity target) {
        MinecraftClient client = MinecraftClient.getInstance();
        IntegratedServer server = client.getServer();
        if (server == null) return;

        botEntity.swingHand(Hand.MAIN_HAND);
        target.getWorld().playSound(null, botEntity.getX(), botEntity.getY(), botEntity.getZ(),
                SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, SoundCategory.PLAYERS, 1.0f, 1.0f);

        final float damage = attackDamage.getValue();
        final double dx = target.getX() - botEntity.getX();
        final double dz = target.getZ() - botEntity.getZ();

        server.execute(() -> {
            ServerPlayerEntity sp = server.getPlayerManager().getPlayer(target.getUuid());
            if (sp == null || sp.isDead()) return;
            sp.damage((net.minecraft.server.world.ServerWorld) sp.getWorld(),
                    sp.getDamageSources().generic(), damage);
            sp.takeKnockback(0.4, -dx, -dz);
        });
    }

    private void healServerPlayer(MinecraftClient client) {
        IntegratedServer server = client.getServer();
        if (server == null || client.player == null) return;
        server.execute(() -> {
            ServerPlayerEntity sp = server.getPlayerManager().getPlayer(client.player.getUuid());
            if (sp != null) sp.setHealth(sp.getMaxHealth());
        });
    }

    /* ============================ Колбэки ============================ */

    /** Смерть бота (тотемы выключены). */
    public void onBotDied() {
        bot = null;
        if (autoRespawn.getValue()) {
            respawnTimer = 30; // 1.5 секунды
        }
    }

    ClientPlayerEntity getPlayer() {
        MinecraftClient client = MinecraftClient.getInstance();
        return (client.world != null) ? client.player : null;
    }

    boolean isPvpEnabled() {
        return pvp.getValue();
    }

    boolean isInfiniteTotems() {
        return infiniteTotems.getValue();
    }

    int getAttackIntervalTicks() {
        return (int) attackSpeed.getValue();
    }

    /* ============================ Тик ============================ */

    @Override
    public void onTick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            bot = null;
            return;
        }

        if (bot != null && (bot.isRemoved() || bot.getWorld() != client.world)) {
            bot = null; // сменилось измерение или бот удалён
        }

        if (respawnTimer > 0) {
            respawnTimer--;
            if (respawnTimer == 0) {
                respawnTimer = -1;
                if (isEnabled() && isSingleplayer(client)) {
                    spawnBot(client);
                }
            }
        }
    }

    /* ============================ Чат ============================ */

    private static void sendChat(String text) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.inGameHud != null) {
            client.inGameHud.getChatHud().addMessage(
                    Text.literal("[§bBotPractice§r] ").append(Text.literal(text)));
        }
    }
}

