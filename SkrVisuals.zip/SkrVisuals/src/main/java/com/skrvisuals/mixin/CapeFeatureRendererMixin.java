package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.CustomCape;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * CustomCape: рисует плащ локального игрока с кастомной текстурой.
 *
 * Ванильный CapeFeatureRenderer рисует плащ только если у игрока есть свой
 * плащ (skinTextures.capeTexture() != null) и он не скрыт. Мы на HEAD
 * перехватываем render: если модуль включён и это локальный игрок —
 * отменяем ванильный рендер и рисуем ту же ванильную модель плаща
 * (PlayerCapeModel с позой из render state), но с нашей текстурой.
 * Для всех остальных игроков ничего не меняем.
 */
@Mixin(CapeFeatureRenderer.class)
public class CapeFeatureRendererMixin {

    @Shadow @Final private BipedEntityModel<PlayerEntityRenderState> model;

    @Shadow
    private boolean hasCustomModelForLayer(ItemStack stack, EquipmentModel.LayerType layerType) {
        throw new AssertionError();
    }

    /** getContextModel() объявлен в родительском FeatureRenderer, поэтому @Shadow не годится. */
    private PlayerEntityModel skr$contextModel() {
        @SuppressWarnings({"unchecked", "rawtypes"})
        net.minecraft.client.render.entity.feature.FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> fr =
                (net.minecraft.client.render.entity.feature.FeatureRenderer) (Object) this;
        return fr.getContextModel();
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void skr$customCape(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                PlayerEntityRenderState state, float f, float g, CallbackInfo ci) {
        CustomCape cape = CustomCape.get();
        if (cape == null) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || state == null) {
            return;
        }
        // Только на локального игрока (в третьем лице / F5).
        if (client.player.getId() != state.id || state.invisible || state.spectator) {
            return;
        }

        // Как в ванилле: если на груди крылья (элитры) с кастомной моделью — плащ не рисуем.
        if (this.hasCustomModelForLayer(state.equippedChestStack, EquipmentModel.LayerType.WINGS)) {
            ci.cancel();
            return;
        }

        ci.cancel();

        matrices.push();
        if (this.hasCustomModelForLayer(state.equippedChestStack, EquipmentModel.LayerType.HUMANOID)) {
            matrices.translate(0.0F, -0.053125F, 0.06875F);
        }

        VertexConsumer vertexConsumer =
                vertexConsumers.getBuffer(RenderLayer.getEntitySolid(CustomCape.currentTexture()));
        this.skr$contextModel().copyTransforms(this.model);
        this.model.setAngles(state);
        this.model.render(matrices, vertexConsumer, light, OverlayTexture.DEFAULT_UV);
        matrices.pop();
    }
}
