package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.Animations;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Animations: плавное появление ВСЕГО меню инвентаря (панель + слоты + предметы).
 *
 * Почему не {@code HandledScreen#render}: панель (текстура GUI) рисуется в
 * переопределённом render() подкласса ПОСЛЕ вызова {@code super.render()},
 * то есть уже после выхода из HandledScreen#render. Инжект туда анимировал бы
 * только слоты и предметы, но не саму панель.
 *
 * {@code Screen#renderWithTooltip} — финальная точка, которая оборачивает
 * ВЕСЬ рендер экрана (её вызывает GameRenderer), поэтому трансформация
 * накрывает и панель, и слоты, и подписи.
 *
 * Фон (затемнение) исключён отдельными хуками в {@link HandledScreenMixin}:
 * он рисуется внутри render(), но анимировать его не нужно.
 *
 * Хучим только экраны-наследники {@link HandledScreen}, чтобы не зацепить
 * остальные экраны (Creative-поиск, настройки, чат и т.д.).
 */
@Mixin(Screen.class)
public abstract class ScreenMixin {

    @Inject(method = "renderWithTooltip", at = @At("HEAD"))
    private void skr$animationsPush(DrawContext context, int mouseX, int mouseY,
                                    float delta, CallbackInfo ci) {
        if ((Object) this instanceof HandledScreen) {
            Animations.pushScreen(context);
        }
    }

    @Inject(method = "renderWithTooltip", at = @At("TAIL"))
    private void skr$animationsPop(DrawContext context, int mouseX, int mouseY,
                                   float delta, CallbackInfo ci) {
        if ((Object) this instanceof HandledScreen) {
            Animations.popScreen(context);
        }
    }
}
