package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.CustomHitbox;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * CustomHitbox: пока модуль включен, подменяем ванильный рендер хитбоксов
 * своим — прямо в точке вызова EntityRenderDispatcher#renderHitbox,
 * поэтому координаты и матрицы полностью совпадают с ванильными.
 */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {

    @Inject(method = "renderHitbox", at = @At("HEAD"), cancellable = true)
    private static void skr$cancelVanillaHitbox(MatrixStack matrices, VertexConsumer vertices,
                                                Entity entity, float tickDelta,
                                                float red, float green, float blue,
                                                CallbackInfo ci) {
        if (CustomHitbox.shouldCancelVanilla()) {
            ci.cancel();
            CustomHitbox.renderHitbox(matrices, vertices, entity, tickDelta);
        }
    }
}
