package com.skrvisuals.mixin;

import com.skrvisuals.ui.mainmenu.MenuStyle;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.EditWorldScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Единый фон для ванильных экранов создания и редактирования мира. */
@Mixin({CreateWorldScreen.class, EditWorldScreen.class})
public abstract class WorldMenuRenderMixin {

    @Inject(method = "render", at = @At("HEAD"), cancellable = false)
    private void skr$worldBackdrop(DrawContext context, int mouseX, int mouseY, float delta,
                                    CallbackInfo ci) {
        Screen screen = (Screen) (Object) this;
        MenuStyle.backdrop(context, screen.width, screen.height,
                (System.currentTimeMillis() % 10000L) / 1000.0F, 1.0F);
    }
}
