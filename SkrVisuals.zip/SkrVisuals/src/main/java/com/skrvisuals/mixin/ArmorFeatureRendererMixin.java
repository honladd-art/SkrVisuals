package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.HitColor;

import net.minecraft.client.model.Model;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.equipment.EquipmentModel;
import net.minecraft.client.render.entity.equipment.EquipmentRenderer;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.EquipmentAsset;
import net.minecraft.registry.RegistryKey;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * HitColor (броня): в режиме «Игрок с бронёй» оборачивает
 * VertexConsumerProvider перед EquipmentRenderer#render, чтобы все вершины
 * брони перекрашивались в цвет темы вместе с скином.
 */
@Mixin(ArmorFeatureRenderer.class)
public abstract class ArmorFeatureRendererMixin {

    @Redirect(
            method = "renderArmor",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/entity/equipment/EquipmentRenderer;render(Lnet/minecraft/client/render/entity/equipment/EquipmentModel$LayerType;Lnet/minecraft/registry/RegistryKey;Lnet/minecraft/client/model/Model;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"
            )
    )
    private void skr$tintArmor(EquipmentRenderer renderer,
                               EquipmentModel.LayerType layerType,
                               RegistryKey<EquipmentAsset> assetKey,
                               Model model,
                               ItemStack stack,
                               MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers,
                               int light) {
        float strength = HitColor.armorStrength();
        if (strength <= 0f) {
            renderer.render(layerType, assetKey, model, stack, matrices, vertexConsumers, light);
        } else {
            renderer.render(layerType, assetKey, model, stack, matrices,
                    HitColor.wrap(vertexConsumers, strength), light);
        }
    }
}