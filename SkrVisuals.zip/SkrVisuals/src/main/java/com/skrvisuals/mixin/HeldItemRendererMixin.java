package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.SwingAnimation;
import com.skrvisuals.modules.impl.ViewModel;

import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.Arm;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Миксин для кастомной анимации удара (SwingAnimation).
 *
 * В 1.21.4 вся ванильная базовая трансформация руки (bob-перенос,
 * applyEquipOffset и applySwingOffset) инкапсулирована в методе
 * HeldItemRenderer#swingArm(swingProgress, equipProgress, matrices, light, arm)
 * — именно он вызывается для предметов в первой руке. Перехватываем его целиком:
 * применяем свою анимацию и отменяем ванильную.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    @Inject(method = {"swingArm", "method_65816"}, at = @At("HEAD"), cancellable = true)
    private void skr$onSwingArm(float swingProgress, float equipProgress, MatrixStack matrices,
                                int light, Arm arm, CallbackInfo ci) {
        SwingAnimation swing = SwingAnimation.get();
        if (swing == null || !swing.isEnabled() || !swing.shouldOverride(arm)) {
            return;
        }
        swing.renderSwordAnimation(matrices, swingProgress, equipProgress, arm);
        ci.cancel();
    }

    /**
     * ViewModel: применяет смещение и масштаб руки.
     * ВАЖНО: применяем трансформацию сразу ПОСЛЕ ванильного
     * {@code MatrixStack.push()} внутри renderFirstPersonItem (в скоупе
     * push/pop текущей руки), а НЕ в @At("HEAD") до push. Иначе трансформации
     * попадают на внешнюю матрицу кадра, которая не сбрасывается между
     * руками — из-за этого настройки правой руки "протекали" в левую руку
     * (размер и позиция складывались). После push трансформация изолирована
     * собственной парой push/pop руки и автоматически снимается.
     */
    @Inject(method = "renderFirstPersonItem", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
            shift = At.Shift.AFTER))
    private void skr$onRenderFirstPersonItem(net.minecraft.client.network.AbstractClientPlayerEntity player,
                                             float tickDelta, float pitch, net.minecraft.util.Hand hand,
                                             float swingProgress, net.minecraft.item.ItemStack item,
                                             float equipProgress, MatrixStack matrices,
                                             net.minecraft.client.render.VertexConsumerProvider vertexConsumers,
                                             int light, CallbackInfo ci) {
        ViewModel vm = ViewModel.get();
        if (vm == null || !vm.isEnabled() || player == null) {
            return;
        }
        // Здесь применяем только СМЕЩЕНИЕ руки. Масштаб применяется отдельно,
        // непосредственно вокруг модели предмета (см. skr$onRenderItem ниже).
        Arm arm = hand == net.minecraft.util.Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        vm.applyHandPosition(matrices, arm);
    }

    /**
     * Масштаб (Размер) применяем сразу вокруг самой модели, а не ко всему
     * кадру руки. Иначе масштаб умножал бы ещё и ванильные переносы
     * (applyEquipOffset / swingArm), из-за чего предмет «улетал» при смене
     * Ползунка «Размер». Метод HeldItemRenderer#renderItem — та самая точка,
     * где предмет из первой руки отрисовывается ПОСЛЕ всех трансформаций руки.
     */
    @Inject(method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"))
    private void skr$onRenderItemStart(LivingEntity entity, ItemStack stack, ModelTransformationMode transformMode,
                                       boolean leftHanded, MatrixStack matrices,
                                       VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        ViewModel vm = ViewModel.get();
        if (vm == null || !vm.isEnabled() || transformMode == null) {
            return;
        }
        matrices.push();
        // transformMode сам говорит, какая это рука — правая или левая.
        Arm arm = transformMode == ModelTransformationMode.FIRST_PERSON_LEFT_HAND
                ? Arm.LEFT : Arm.RIGHT;
        vm.applyHandScale(matrices, arm);
    }

    @Inject(method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("RETURN"))
    private void skr$onRenderItemEnd(LivingEntity entity, ItemStack stack, ModelTransformationMode transformMode,
                                     boolean mirror, MatrixStack matrices,
                                     VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        ViewModel vm = ViewModel.get();
        if (vm == null || !vm.isEnabled() || transformMode == null) {
            return;
        }
        matrices.pop();
    }
}
