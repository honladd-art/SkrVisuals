package com.skrvisuals.mixin;

import com.skrvisuals.ui.mainmenu.MainMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the vanilla TitleScreen with our custom MainMenuScreen.
 * The client tick event opens our custom screen instead of the vanilla one.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {

    /**
     * When the game tries to open the title screen, we redirect to our custom main menu.
     * This is triggered on init and when returning to the title screen.
     */
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void skr$replaceMainMenu(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null) {
            client.setScreen(new MainMenuScreen());
            ci.cancel();
        }
    }
}