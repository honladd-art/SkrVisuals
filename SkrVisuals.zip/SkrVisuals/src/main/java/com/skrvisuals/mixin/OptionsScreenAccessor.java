package com.skrvisuals.mixin;

import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к приватному полю {@code parent} у ванильного {@link OptionsScreen}.
 * Зеркалим стиль {@link MinecraftClientAccessor} / {@link MouseAccessor}.
 */
@Mixin(OptionsScreen.class)
public interface OptionsScreenAccessor {

    @Accessor("parent")
    Screen skr$getParent();
}
