package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.FreeLook;
import com.skrvisuals.modules.impl.FreeLook;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * FreeLook: пока свободный осмотр активен, перехватываем движение мыши
 * (Mouse#onCursorPos) и НЕ передаём его дальше — игрок не поворачивает
 * голову, дельты уходят в свободную камеру (FreeLook#addMouseDelta).
 *
 * Цель по имени + дескриптор (JDD)V (intermediary method_1600).
 */
@Mixin(Mouse.class)
public abstract class MouseMixin {

    @Inject(method = {
            "onCursorPos(JDD)V",
            "method_1600(JDD)V"
    }, at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$freeLookCursor(long window, double x, double y, CallbackInfo ci) {
        if (!FreeLook.isLooking()) {
            return;
        }
        if (GLFW.glfwGetWindowAttrib(window, GLFW.GLFW_FOCUSED) == 0) {
            return;
        }
        // Копим дельты в свободные углы и глотаем событие.
        MouseAccessor self = (MouseAccessor) this;
        double deltaX = x - self.getX();
        double deltaY = y - self.getY();
        if (deltaX != 0.0D || deltaY != 0.0D) {
            FreeLook.addMouseDelta(deltaX, deltaY);
        }
        self.setX(x);
        self.setY(y);
        ci.cancel();
    }
}
