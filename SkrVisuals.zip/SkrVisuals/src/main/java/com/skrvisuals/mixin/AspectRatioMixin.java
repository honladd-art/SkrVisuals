package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.AspectRatio;
import net.minecraft.client.render.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * AspectRatio: мир рендерится с матрицей проекции, у которой аспект равен
 * целевому соотношению, а не аспекту окна. Картинка растягивается на всё
 * окно (стретч), HUD/GUI остаётся в обычном аспекте.
 *
 * Инъекция в GameRenderer#getBasicProjectionMatrix(F) на RETURN: метод
 * используется и для мира, и для руки первого лица — обе сцены получают
 * согласованное растяжение. Модифицируем m00/m11 уже готовой матрицы,
 * поэтому Zoom и прочие FOV-модули (меняющие fov до построения матрицы)
 * полностью совместимы.
 */
@Mixin(GameRenderer.class)
public class AspectRatioMixin {

    @Inject(method = {
            "getBasicProjectionMatrix",
            "*(F)Lorg/joml/Matrix4f;"
    }, at = @At("RETURN"), cancellable = true)
    private void skr$applyAspectRatio(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        AspectRatio aspect = AspectRatio.get();
        if (aspect == null) {
            return;
        }
        Matrix4f projection = cir.getReturnValue();
        if (projection != null) {
            aspect.applyTo(projection);
            cir.setReturnValue(projection);
        }
    }
}
