package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.CustomSky;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

/**
 * CustomSky: перехватывает {@code SkyRendering.renderSky}. Цвет небесного купола
 * задаётся вызовом {@code RenderSystem.setShaderColor(...)} внутри renderSky.
 * Второй такой вызов — это сброс цвета к белому (1,1,1,1), поэтому задеваем
 * только первый (ordinal = 0), заменяя цвет купола на светлый тон темы.
 */
@Mixin(SkyRendering.class)
public abstract class SkyRenderingMixin {

    @ModifyArgs(method = "renderSky",
            at = @At(value = "INVOKE", ordinal = 0,
                    target = "Lcom/mojang/blaze3d/systems/RenderSystem;setShaderColor(FFFF)V"))
    private void skr$customSky(Args args) {
        CustomSky customSky = CustomSky.getActive();
        if (customSky == null || !customSky.isEnabled()) {
            return;
        }

        int argb = customSky.getColor();
        args.set(0, ((argb >> 16) & 0xFF) / 255.0f);
        args.set(1, ((argb >> 8) & 0xFF) / 255.0f);
        args.set(2, (argb & 0xFF) / 255.0f);
    }
}