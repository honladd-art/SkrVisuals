package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.CustomCrosshair;
import com.skrvisuals.modules.impl.CustomHotbar;
import com.skrvisuals.modules.impl.CustomScreen;
import com.skrvisuals.modules.impl.NoRender;
import com.skrvisuals.modules.impl.Vignette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * InGameHud миксины:
 * - NoRender: скрывает скорборд, виньетку и оверлей тыквы;
 * - CustomCrosshair: скрывает ванильный прицел, пока включен свой.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$hideScoreboard(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (NoRender.shouldHide(NoRender.Feature.SCOREBOARD)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$noVignette(DrawContext context, net.minecraft.entity.Entity entity, CallbackInfo ci) {
        if (NoRender.shouldHide(NoRender.Feature.VIGNETTE)) {
            ci.cancel();
        }
    }

    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$noPumpkin(DrawContext context, net.minecraft.util.Identifier texture, float opacity, CallbackInfo ci) {
        if (NoRender.shouldHide(NoRender.Feature.PUMPKIN)
                && texture != null
                && texture.getPath().contains("pumpkinblur")) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void skr$customScreen(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        CustomScreen.render(context);
    }

    /**
     * Vignette: рисует виньетку по краям экрана при низкой прочности брони.
     * Точка внедрения — TAIL метода render, чтобы виньетка была поверх всего HUD.
     */
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void skr$armorVignette(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        Vignette.render(context);
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$hideVanillaCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (CustomCrosshair.shouldHideVanilla()) {
            ci.cancel();
        }
    }

    /**
     * CustomHotbar: скрывает ванильный хотбар, пока включен свой
     * (опыт, здоровье и т.п. продолжают рисоваться как обычно).
     */
    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$hideVanillaHotbar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (CustomHotbar.shouldHideVanilla()) {
            ci.cancel();
        }
    }

    /**
     * CustomCrosshair: скрывает ванильный прицел, пока включен свой.
     * Точка внедрения — InGameHud#renderCrosshair (method_1736).
     */
}