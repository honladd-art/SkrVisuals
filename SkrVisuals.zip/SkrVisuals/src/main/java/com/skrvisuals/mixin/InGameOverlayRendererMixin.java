package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides the first-person fire overlay (drawn in world space by
 * InGameOverlayRenderer#renderFireOverlay) when NoRender asks for it.
 */
@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {

    // Target is a STATIC method => the handler must be static too.
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void skr$hideFireOverlay(MatrixStack matrices, VertexConsumerProvider vertexConsumers, CallbackInfo ci) {
        if (NoRender.shouldHide(NoRender.Feature.FIRE)) {
            ci.cancel();
        }
    }
}