package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.SuperOptimize;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Куллинг частиц за спиной камеры + ограничение дистанции спавна.
 *
 * В ParticleManager#addParticle ванилли создаёт частицу и добавляет её в очередь.
 * Если частица дальше допустимой дистанции (настройка «Дистанция частиц») или
 * находится за спиной камеры (настройка «Куллинг частиц»), отменяем спавн —
 * экономия на каждой ненужной частице.
 *
 * Настройки игры не затрагиваются.
 */
@Mixin(ParticleManager.class)
public abstract class ParticleCullingMixin {

    @Inject(method = {
            "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)"
                    + "Lnet/minecraft/client/particle/Particle;"
    }, at = @At("HEAD"), cancellable = true)
    private void skr$cullParticles(ParticleEffect parameters, double x, double y, double z,
                                    double velocityX, double velocityY, double velocityZ,
                                    CallbackInfoReturnable<@Nullable Particle> cir) {
        if (!SuperOptimize.getInstance().isEnabled()) {
            return;
        }

        if (SuperOptimize.isParticleTooFar(x, y, z)) {
            cir.setReturnValue(null);
            return;
        }

        if (SuperOptimize.isParticleCullingEnabled() && SuperOptimize.isBehindCamera(x, y, z)) {
            cir.setReturnValue(null);
        }
    }
}
