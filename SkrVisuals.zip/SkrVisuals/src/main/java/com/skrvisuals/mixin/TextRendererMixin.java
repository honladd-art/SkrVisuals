package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.NameProtect;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.OrderedText;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import org.spongepowered.asm.mixin.injection.Inject;

/**
 * NameProtect (везде): цензурирует ЛЮБОЙ текст, отрисовываемый на экране —
 * чат, ники над головой, таб-лист, скорборд, экшенбар и т.д.
 * Точка внедрения — TextRenderer#drawInternal(String/OrderedText, ...),
 * в который сходятся все публичные методы draw/drawWithOutline.
 */
@Mixin(TextRenderer.class)
public abstract class TextRendererMixin {

    // ---- строковый вариант ------------------------------------------------ //

    @ModifyVariable(
            method = "drawInternal(Ljava/lang/String;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;IIZ)I",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0
    )
    private String skr$protectString(String text) {
        String masked = NameProtect.protect(text);
        return masked != null ? masked : text;
    }

    // ---- OrderedText вариант ---------------------------------------------- //

    @ModifyVariable(
            method = "drawInternal(Lnet/minecraft/text/OrderedText;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;IIZ)I",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0
    )
    private OrderedText skr$protectOrdered(OrderedText text) {
        OrderedText masked = NameProtect.protectOrdered(text, false);
        return masked != null ? masked : text;
    }

    //getWidth also needs protection for correct centering/wrap widths
    @Inject(method = "getWidth(Lnet/minecraft/text/OrderedText;)I", at = @At("HEAD"), cancellable = true)
    private void skr$protectWidth(OrderedText text, CallbackInfoReturnable<Integer> cir) {
        OrderedText masked = NameProtect.protectOrdered(text, false);
        if (masked != null) {
            cir.setReturnValue(skr$measure(masked));
        }
    }

    @Unique
    private int skr$measure(OrderedText text) {
        final int[] width = {0};
        text.accept((index, style, codePoint) -> {
            width[0] += ((TextRenderer) (Object) this).getWidth(new String(Character.toChars(codePoint)));
            return true;
        });
        return width[0];
    }
}