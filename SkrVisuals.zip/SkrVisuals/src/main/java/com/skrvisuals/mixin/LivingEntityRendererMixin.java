package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.HitColor;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * HitColor (тело): запоминает, какая сущность какому RenderState принадлежит,
 * и подменяет цвет модели в LivingEntityRenderer#getMixColor, пока цель
 * окрашена. Если окраски нет — ванильное поведение не трогаем.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(method = "updateRenderState", at = @At("HEAD"))
    private void skr$recordState(LivingEntity entity, LivingEntityRenderState state,
                                 float tickDelta, CallbackInfo ci) {
        HitColor.recordRenderState(state, entity);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void skr$renderStart(LivingEntityRenderState state, MatrixStack matrices,
                                 VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        HitColor.beginRender(state);
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skr$renderEnd(LivingEntityRenderState state, MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        HitColor.endRender();
    }

    @Inject(method = "getMixColor", at = @At("HEAD"), cancellable = true)
    private void skr$tintBody(LivingEntityRenderState state, CallbackInfoReturnable<Integer> cir) {
        int color = HitColor.bodyTint(state);
        if (color != 0) {
            cir.setReturnValue(color);
        }
    }
}