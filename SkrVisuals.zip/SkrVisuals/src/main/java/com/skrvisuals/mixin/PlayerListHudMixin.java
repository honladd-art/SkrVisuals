package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.Animations;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardObjective;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Animations: плавное появление списка игроков (Tab).
 *
 * Ванильный PlayerListHud рисуется только пока зажат Tab, поэтому анимация
 * запускается автоматически: модуль сам отслеживает паузу в рендере.
 */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {

    /** Была ли применена трансформация в текущем кадре — чтобы снять её в TAIL. */
    @Unique
    private boolean skr$animationsApplied;

    @Inject(method = "render", at = @At("HEAD"))
    private void skr$animationsPush(DrawContext context, int tickCounter,
                                    Scoreboard scoreboard, ScoreboardObjective objective,
                                    CallbackInfo ci) {
        this.skr$animationsApplied = Animations.pushTab(context);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void skr$animationsPop(DrawContext context, int tickCounter,
                                   Scoreboard scoreboard, ScoreboardObjective objective,
                                   CallbackInfo ci) {
        Animations.popTransform(context, this.skr$animationsApplied);
        this.skr$animationsApplied = false;
    }
}
