package com.skrvisuals.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.FontManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {

    @Accessor("fontManager")
    FontManager skr$getFontManager();

    @Mutable
    @Accessor("session")
    void skr$setSession(net.minecraft.client.session.Session session);

    @Mutable
    @Accessor("gameProfileFuture")
    void skr$setGameProfileFuture(java.util.concurrent.CompletableFuture<com.mojang.authlib.yggdrasil.ProfileResult> future);
}
