package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.NoRender;
import com.skrvisuals.modules.impl.Zoom;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * GameRenderer миксины:
 * - NoHurtCam: убирает наклон экрана при получении урона
 *   (GameRenderer#tiltViewWhenHurt);
 * - Zoom: зум через модификацию FOV — единый источник проекции для мира
 *   и сущностей, поэтому при зуме мобы не отрываются от блоков
 *   (метод FOV-расчёта, в 1.21.4 возвращает float).
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void skr$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (NoRender.shouldHide(NoRender.Feature.HURTCAM)) {
            ci.cancel();
        }
    }

    /**
     * Зум через FOV. Цель задаём ПО ДЕСКРИПТОРУ, а не по имени: рефмап
     * не генерирует запись для имени этого метода в 1.21.4. Сигнатура
     * (Camera=class_4184, float, boolean) -> float снята с живых сорсов.
     * Первый вариант — для релизного jar (intermediary), второй — для dev.
     */
    @Inject(method = {
            "*(Lnet/minecraft/class_4184;FZ)F",
            "*(Lnet/minecraft/client/render/Camera;FZ)F"
    }, at = @At("RETURN"), cancellable = true)
    private void skr$applyZoomFov(Camera camera, float tickDelta, boolean changingFov,
                                  CallbackInfoReturnable<Float> cir) {
        float zoomed = Zoom.modifyFov(cir.getReturnValueF(), changingFov);
        if (zoomed != cir.getReturnValueF()) {
            cir.setReturnValue(zoomed);
        }
    }
}