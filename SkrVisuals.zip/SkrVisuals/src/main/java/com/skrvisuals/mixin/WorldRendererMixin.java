package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.SuperOptimize;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.util.math.BlockPos;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Куллинг чанков за спиной камеры.
 *
 * В WorldRenderer#renderLayer ванилли для каждого BuiltChunk вызывает
 * builtChunk.getData().isEmpty(renderLayer) — если данные пустые, чанк не
 * рендерится. Редиректим getData(): если центр чанка находится за спиной камеры
 * (и модуль включён), возвращаем ChunkData.EMPTY — тогда isEmpty() вернёт true и
 * весь чанк пропускается на всех рендер-слоях.
 *
 * Это аналог «выгрузки чанков позади тебя», но реализован на уровне рендера
 * (миксин), а не через правку ванильных настроек — настройки игры не затрагиваются.
 */
@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {

    @Redirect(method = {
            "renderLayer(Lnet/minecraft/client/render/RenderLayer;DDDLorg/joml/Matrix4f;Lorg/joml/Matrix4f;)V"
    }, at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/render/chunk/ChunkBuilder$BuiltChunk;getData()Lnet/minecraft/client/render/chunk/ChunkBuilder$ChunkData;"))
    private ChunkBuilder.ChunkData skr$cullChunksBehindCamera(ChunkBuilder.BuiltChunk builtChunk) {
        if (SuperOptimize.isChunkCullingEnabled()) {
            BlockPos origin = builtChunk.getOrigin();
            // Центр чанка (origin — это угол секции, секция 16×16×16).
            double cx = origin.getX() + 8.0;
            double cy = origin.getY() + 8.0;
            double cz = origin.getZ() + 8.0;
            if (SuperOptimize.isBehindCamera(cx, cy, cz)) {
                return ChunkBuilder.ChunkData.EMPTY;
            }
        }
        return builtChunk.getData();
    }
}
