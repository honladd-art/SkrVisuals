package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.Animations;
import com.skrvisuals.modules.impl.NameProtect;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * ChatHud миксины:
 * - NameProtect: перехватывает добавление сообщений в чат
 *   и заменяет ник на "***" ещё до добавления в историю;
 * - Animations: плавное появление ТОЛЬКО свежей строки чата.
 */
@Mixin(ChatHud.class)
public abstract class ChatHudMixin {

    /** Список видимых строк чата — нужен, чтобы опознать свежую строку. */
    @Shadow
    @Final
    private List<ChatHudLine.Visible> visibleMessages;

    @Shadow
    public abstract void addMessage(Text message, MessageSignatureData signature, MessageIndicator indicator);

    @Inject(method = "addMessage(Lnet/minecraft/text/Text;)V", at = @At("HEAD"), cancellable = true)
    private void skr$protectName(Text message, CallbackInfo ci) {
        String protectedText = NameProtect.protect(message.getString());
        if (protectedText == null) {
            return;
        }
        ci.cancel();
        addMessage(Text.literal(protectedText).setStyle(message.getStyle()), null, null);
    }

    /**
     * Animations: новое сообщение в чате = новое «появление» чата.
     * Хук стоит на 3-аргументном addMessage, потому что 1-аргументный
     * делегирует в него (иначе анимация срабатывала бы дважды).
     */
    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"))
    private void skr$animationsOnMessage(Text message, MessageSignatureData signature,
                                         MessageIndicator indicator, CallbackInfo ci) {
        Animations.onChatMessage();
    }

    /**
     * Animations: анимируем ТОЛЬКО свежую строку чата.
     *
     * Vanilla рисует все строки в одном цикле внутри ChatHud#render, поэтому
     * трансформация на весь чат уехала бы вместе со старыми строками. Вместо
     * этого перехватываем отрисовку текста: анимация применяется лишь к
     * САМОЙ НОВОЙ строке (последний элемент visibleMessages), остальные
     * рисуются как обычно.
     *
     * Якорь трансформации — левый нижний угол самой строки, поэтому она
     * «всплывает» на своё место, а не вылетает из угла экрана.
     */
    @Redirect(
            method = "render(Lnet/minecraft/client/gui/DrawContext;IIIZ)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow"
                            + "(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/OrderedText;III)I"))
    private int skr$animationsNewestLine(DrawContext context, TextRenderer textRenderer,
                                         OrderedText text, int x, int y, int color) {
        boolean applied = false;
        if (skr$isNewestLine(text)) {
            applied = Animations.pushChatLine(context, x, y);
        }
        int width = context.drawTextWithShadow(textRenderer, text, x, y, color);
        Animations.popTransform(context, applied);
        return width;
    }

    /**
     * Свежая ли это строка? Vanilla рисует сообщения от последнего к первому,
     * поэтому новая строка — последний элемент {@code visibleMessages}.
     * Сравниваем по ссылке на {@link ChatHudLine.Visible#content()} — это
     * надёжнее сравнения текста (одинаковые сообщения не путаются).
     */
    private boolean skr$isNewestLine(OrderedText text) {
        List<ChatHudLine.Visible> messages = this.visibleMessages;
        if (messages == null || messages.isEmpty()) {
            return false;
        }
        ChatHudLine.Visible last = messages.get(messages.size() - 1);
        return last != null && last.content() == text;
    }
}