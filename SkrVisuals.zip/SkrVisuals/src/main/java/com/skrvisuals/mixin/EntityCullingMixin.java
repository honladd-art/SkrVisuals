package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.SuperOptimize;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Куллинг сущностей за спиной камеры + уменьшение дистанции рендера сущностей.
 *
 * В EntityRenderDispatcher#render ванилли принимает x/y/z — позицию сущности
 * ОТНОСИТЕЛЬНО камеры (entity.pos - camera.pos). Если сущность дальше дистанции
 * куллинга и находится за спиной (скалярное произведение с направлением взгляда < 0),
 * отменяем рендер — экономия на каждой сущности, которую игрок не видит.
 *
 * Дополнительно к куллингу: настройка «Дистанция сущностей» ограничивает, как
 * далеко вообще рендерятся сущности. Сущности за пределами (множитель × ванильная
 * дальность) пропускаются — это даёт заметный прирост FPS на серверах с кучей мобов.
 *
 * Работает только когда включён модуль SuperOptimize и его настройка «Куллинг сущностей».
 * Настройки игры не затрагиваются.
 */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityCullingMixin {

    @Inject(method = {
            "render(Lnet/minecraft/entity/Entity;DDDF"
                    + "Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;"
                    + "I)V"
    }, at = @At("HEAD"), cancellable = true)
    private void skr$cullEntitiesBehindCamera(Entity entity, double x, double y, double z,
                                               float tickDelta, MatrixStack matrices,
                                               VertexConsumerProvider vertexConsumers,
                                               int light, CallbackInfo ci) {
        if (!SuperOptimize.getInstance().isEnabled()) {
            return;
        }

        // Куллинг за спиной камеры.
        if (SuperOptimize.isEntityCullingEnabled() && SuperOptimize.isBehindCameraRel(x, y, z)) {
            ci.cancel();
            return;
        }

        // Ограничение дистанции рендера сущностей (если множитель < 1.0).
        float multiplier = SuperOptimize.getEntityDistanceMultiplier();
        if (multiplier < 1.0f) {
            double distSq = x * x + y * y + z * z;
            double maxDist = getVanillaEntityRenderDistance() * multiplier;
            if (distSq > maxDist * maxDist) {
                ci.cancel();
            }
        }
    }

    /** Ванильная дальность рендера сущностей в блоках (приближённо из viewDistance). */
    private static double getVanillaEntityRenderDistance() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return 64.0;
        }
        // Ваниль рисует сущности примерно в радиусе viewDistance * 16 блоков,
        // но не далее фиксированного потолка. Берём консервативную оценку.
        int viewDistance = client.options.getViewDistance().getValue();
        return Math.min(viewDistance * 16.0, 128.0);
    }
}
