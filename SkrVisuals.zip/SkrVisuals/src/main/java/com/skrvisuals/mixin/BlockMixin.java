package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.NoRender;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.PlantBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hides grass/plants in the world by making their render type invisible
 * while chunk sections are meshed (NoRender module).
 *
 * Target note: getRenderType(BlockState) is declared in AbstractBlock
 * (intermediary class_4970) and inherited by Block — it is NOT overridden
 * there, so AbstractBlock is the correct mixin target.
 */
@Mixin(AbstractBlock.class)
public abstract class BlockMixin {

    // require = 0: never hard-crash if the target can't be resolved.
    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true, require = 0)
    private void skr$hidePlants(BlockState state, CallbackInfoReturnable<BlockRenderType> cir) {
        if (state.getBlock() instanceof PlantBlock && NoRender.shouldHide(NoRender.Feature.GRASS)) {
            cir.setReturnValue(BlockRenderType.INVISIBLE);
        }
    }
}