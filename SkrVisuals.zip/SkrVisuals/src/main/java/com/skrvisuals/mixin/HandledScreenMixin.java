package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.Animations;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Animations: затемнение при открытии инвентаря НЕ анимируется.
 *
 * Сама трансформация навешивается в {@link ScreenMixin} через
 * {@code Screen#renderWithTooltip} — это нужно, чтобы анимировалась вся панель,
 * а не только предметы (панель рисуется подклассом уже после super.render()).
 *
 * Этот миксин отвечает только за фон: HandledScreen.renderBackground вызывается
 * изнутри render() и рисует затемнение на весь экран. Если оставить его внутри
 * трансформации, затемнение масштабируется вместе с GUI и по краям экрана
 * появляется «незатемнённая» рамка. Поэтому на время фона матрица снимается,
 * а после него возвращается.
 */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {

    /** Фон рисуется без анимации: снимаем матрицу перед renderBackground. */
    @Inject(method = "renderBackground", at = @At("HEAD"))
    private void skr$animationsSuspend(DrawContext context, int mouseX, int mouseY,
                                       float delta, CallbackInfo ci) {
        Animations.suspendScreenTransform(context);
    }

    /** Возвращаем трансформацию сразу после фона, до панели и слотов. */
    @Inject(method = "renderBackground", at = @At("TAIL"))
    private void skr$animationsResume(DrawContext context, int mouseX, int mouseY,
                                      float delta, CallbackInfo ci) {
        Animations.resumeScreenTransform(context);
    }
}
