package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.SuperOptimize;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Куллинг блок-энтити за спиной камеры.
 *
 * В BlockEntityRenderDispatcher#render ванилли рисует каждый блок-энтити
 * (сундуки, таблички, рамки, варочные стойки и т.п.). Если позиция блок-энтити
 * находится за спиной камеры (и модуль включён), отменяем рендер — каждая
 * отменённая отрисовка экономит вызовы GPU.
 *
 * Настройки игры не затрагиваются.
 */
@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityCullingMixin {

    @Inject(method = {
            "render(Lnet/minecraft/block/entity/BlockEntity;F"
                    + "Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;)V"
    }, at = @At("HEAD"), cancellable = true)
    private void skr$cullBlockEntities(BlockEntity blockEntity, float tickDelta,
                                        MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                        CallbackInfo ci) {
        if (SuperOptimize.isBlockEntityCullingEnabled()) {
            BlockPos pos = blockEntity.getPos();
            if (pos != null && SuperOptimize.isBehindCamera(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5)) {
                ci.cancel();
            }
        }
    }
}
