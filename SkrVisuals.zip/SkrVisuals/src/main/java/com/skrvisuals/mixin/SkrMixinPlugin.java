package com.skrvisuals.mixin;

import java.util.List;
import java.util.Set;

import net.fabricmc.loader.api.FabricLoader;

import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Плагин конфига миксинов SkrVisuals.
 *
 * Единственная задача — не давать применяться миксинам, которые конфликтуют с
 * сторонними рендер-модификациями (Sodium и его форками). Sodium полностью
 * перезаписывает WorldRenderer#renderChunkLayer своим LevelRendererMixin, поэтому
 * наш @Redirect (WorldRendererMixin, куллинг чанков за спиной) не находит точку
 * вставки и Mixin падает с InvalidInjectionException на старте игры.
 *
 * При установленном Sodium чанковый куллинг просто отключается: Sodium сам
 * выполняет агрессивный фрустум-куллинг чанков, так что функционал дублирует
 * уже сделанную оптимизацию.
 */
public class SkrMixinPlugin implements IMixinConfigPlugin {

    private static final Logger LOGGER = LoggerFactory.getLogger("SkrVisuals/Mixin");

    /** Моды (и форки), патчащие пайплайн рендера чанков WorldRenderer. */
    private static final Set<String> CHUNK_RENDERER_MODS = Set.of(
            "sodium",      //caffeinemc Sodium
            "embeddium"    // форк Sodium для Fabric
    );

    /**
     * Миксины, которые нельзя применять при наличии альтернативного рендера
     * чанков (их точки инъекции перезаписаны Sodium).
     */
    private static final Set<String> RENDERER_INCOMPATIBLE_MIXINS = Set.of(
            "com.skrvisuals.mixin.WorldRendererMixin"
    );

    /** Найден ли установленный Sodium-подобный рендер-мод (кэш onLoad). */
    private static volatile boolean chunkRendererPresent;

    /** true, если Sodium/форк установлен и чанковый куллинг SkrVisuals отключён. */
    public static boolean isChunkRendererPresent() {
        return chunkRendererPresent;
    }

    @Override
    public void onLoad(String mixinPackage) {
        FabricLoader loader = FabricLoader.getInstance();
        String found = CHUNK_RENDERER_MODS.stream()
                .filter(loader::isModLoaded)
                .findFirst()
                .orElse(null);
        chunkRendererPresent = found != null;
        if (chunkRendererPresent) {
            LOGGER.info("[SkrVisuals] Обнаружен рендер-мод '{}': куллинг чанков за спиной "
                    + "(WorldRendererMixin) отключён — Sodium сам оптимизирует рендер чанков.", found);
        }
    }

    @Override
    public String getRefMapperConfig() {
        return null; // использовать стандартный refmap
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        if (chunkRendererPresent && RENDERER_INCOMPATIBLE_MIXINS.contains(mixinClassName)) {
            LOGGER.info("[SkrVisuals] Пропускаю {} — конфликтует с Sodium (WorldRenderer#renderChunkLayer перезаписан).",
                    mixinClassName);
            return false;
        }
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        return null; // список миксинов берётся из skrvisuals.mixins.json
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }
}
