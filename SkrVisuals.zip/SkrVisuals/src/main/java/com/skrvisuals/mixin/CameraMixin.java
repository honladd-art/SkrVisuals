package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.FreeLook;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * FreeLook: перехватываем вызов Camera#setRotation внутри Camera#update.
 *
 * Ваниль в update(): сначала ставит поворот камеры по голове игрока, потом
 * (в третьем лице) отодвигает камеру назад ПРОТИВ направления взгляда
 * (moveBy по diagonalPlane). Подменяя поворот ДО отодвигания, получаем
 * классический F5-осмотр: камера облетает персонажа вокруг, а голова
 * игрока остаётся на месте (мышь перехватывает MouseMixin).
 *
 * Цель задаём и по имени, и по дескриптору (intermediary) — как в
 * GameRendererMixin: первый вариант для dev-среды, второй надёжнее для
 * релизного jar.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Redirect(method = {
            "update(Lnet/minecraft/world/BlockView;Lnet/minecraft/entity/Entity;ZZF)V",
            "update(Lnet/minecraft/class_1937;Lnet/minecraft/class_1297;ZZF)V"
    }, at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"), require = 0)
    private void skr$freeLookRotation(Camera instance, float yaw, float pitch) {
        if (FreeLook.isLooking()) {
            // Свободные углы — камера облетит игрока вокруг них.
            ((CameraAccessor) (Object) instance).skr$setRotation(
                    FreeLook.getFreeYaw(), FreeLook.getFreePitch());
        } else {
            ((CameraAccessor) (Object) instance).skr$setRotation(yaw, pitch);
        }
    }
}
