package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.CustomFog;
import com.skrvisuals.modules.impl.NoRender;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NoFog: pushes the world/sky fog far away so it is effectively invisible.
 * Only touches FOG_SKY / FOG_TERRAIN — water and lava fog stay intact so
 * the player can still see what they are doing underwater/in lava.
 */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {

    private static final float NOFOG_DISTANCE = 1_000_000.0f;

    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void skr$noFog(Camera camera, BackgroundRenderer.FogType fogType,
                                  Vector4f color, float viewDistance, boolean thickenFog,
                                  float tickDelta, CallbackInfoReturnable<Fog> cir) {
        if (NoRender.shouldHide(NoRender.Feature.FOG)) {
            Fog fog = cir.getReturnValue();
            cir.setReturnValue(new Fog(NOFOG_DISTANCE, NOFOG_DISTANCE, FogShape.CYLINDER,
                    fog.red(), fog.green(), fog.blue(), fog.alpha()));
            return;
        }

        CustomFog customFog = CustomFog.getActive();
        if (customFog == null || !customFog.isEnabled()
                || (fogType != BackgroundRenderer.FogType.FOG_SKY
                && fogType != BackgroundRenderer.FogType.FOG_TERRAIN)) {
            return;
        }

        Fog fog = cir.getReturnValue();
        float start = viewDistance * 0.25f;
        float end = viewDistance;
        int argb = customFog.getColor();
        float red = ((argb >> 16) & 0xFF) / 255.0f;
        float green = ((argb >> 8) & 0xFF) / 255.0f;
        float blue = (argb & 0xFF) / 255.0f;
        // Красим и сам туман, и цвет неба/горизонта, чтобы не было
        // полосы ванильного цвета между небом и туманной дымкой.
        color.set(red, green, blue, color.w());
        cir.setReturnValue(new Fog(start, end, fog.shape(), red, green, blue, fog.alpha()));
    }
}
