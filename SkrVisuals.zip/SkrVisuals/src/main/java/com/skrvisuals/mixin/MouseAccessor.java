package com.skrvisuals.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import net.minecraft.client.Mouse;

/**
 * Доступ к приватной позиции курсора мыши (Mouse#x / Mouse#y).
 */
@Mixin(Mouse.class)
public interface MouseAccessor {

    @Accessor("x")
    double getX();

    @Accessor("x")
    void setX(double x);

    @Accessor("y")
    double getY();

    @Accessor("y")
    void setY(double y);
}
