package com.skrvisuals.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import net.minecraft.client.render.Camera;

/**
 * Вызов защищённого Camera#setRotation (method_19325) — пересчитывает
 * кватернион поворота и векторы базиса камеры.
 */
@Mixin(Camera.class)
public interface CameraAccessor {

    @Invoker("setRotation")
    void skr$setRotation(float yaw, float pitch);
}
