package com.skrvisuals.mixin;

import com.skrvisuals.modules.impl.SuperOptimize;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WeatherRendering;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Отключение рендера дождя и снега.
 *
 * В WeatherRendering#renderPrecipitation ванилли рисует капли дождя и снежинки.
 * Когда настройка «Без дождя/снега» включена, отзываем метод — осадки не
 * рендерятся вообще. Заметный прирост FPS в плохую погоду, особенно на слабых
 * видеокартах.
 *
 * Настройки игры не затрагиваются.
 */
@Mixin(WeatherRendering.class)
public abstract class WeatherRenderingMixin {

    @Inject(method = {
            "renderPrecipitation(Lnet/minecraft/world/World;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;"
                    + "IFLnet/minecraft/util/math/Vec3d;)V"
    }, at = @At("HEAD"), cancellable = true)
    private void skr$disableWeather(World world, VertexConsumerProvider vertexConsumers,
                                     int ticks, float delta, Vec3d pos, CallbackInfo ci) {
        if (SuperOptimize.isWeatherDisabled()) {
            ci.cancel();
        }
    }
}
